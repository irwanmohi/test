#!/bin/bash
clear

echo -e "===============================================" | lolcat
echo -e "               JoekersVPN                      " | lolcat
echo -e "-----------------------------------------------" | lolcat
echo -e " >> Debian 9 & Debian 10 64 bit               " | lolcat
echo -e " >> Ubuntu 18.04 & Ubuntu 20.04 64 bit        " | lolcat
echo -e "===============================================" | lolcat