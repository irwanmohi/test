Add Ons Installation
