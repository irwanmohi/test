squid: 
  /usr/sbin/squid 
  /usr/lib/squid 
  /etc/squid 
  /usr/share/squid 
  /usr/share/man/man8/squid.8.gz