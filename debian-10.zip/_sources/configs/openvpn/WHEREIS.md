openvpn: 
/usr/sbin/openvpn 
/usr/lib/x86_64-linux-gnu/openvpn 
/etc/openvpn /usr/include/openvpn 
/usr/share/openvpn 
/usr/share/man/man8/openvpn.8.gz

plugins:
  /usr/lib/x86_64-linux-gnu/openvpn/plugins
    - openvpn-plugin-auth-pam.so
    - openvpn-plugin-down-root.so