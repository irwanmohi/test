dropbear: 
  /usr/sbin/dropbear 
  /usr/lib/dropbear 
  /etc/dropbear 
  /usr/share/man/man8/dropbear.8.gz