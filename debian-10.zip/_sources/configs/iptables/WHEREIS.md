iptables: 
  /usr/sbin/iptables 
  /etc/iptables 
  /usr/share/iptables 
  /usr/share/man/man8/iptables.8.gz