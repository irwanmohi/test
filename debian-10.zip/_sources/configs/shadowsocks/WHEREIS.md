shadowsocks-libev: 
  /etc/shadowsocks-libev 
  /usr/share/shadowsocks-libev 
  /usr/share/man/man8/shadowsocks-libev.8.gz