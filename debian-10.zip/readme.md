[[ CYBERTIZE SETUP MANAGER ]]

packages:
  openssh [-p 1991]
  dropbear [-p 8695] [-p 5968]
  openvpn [-p 6545] [-p 5456]
  squid [-p 4613] [-p 3164]
  badvpn [-p 7300]
  shadowsocks [-p 6242] [-p 2426]
  v2ray [-p 4014] [-p 4104]
  wireguard [-p 3576] [-p 6753]
  nginx [-p 80] [-p 443]
  webmin [-p 10000]
