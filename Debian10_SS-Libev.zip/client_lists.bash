#!/bin/bash
clear

echo ""
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo "|C| |Y| |B| |E| |R| |T| |I| |Z| |E|"
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo ""

if [ "$EUID" -ne 0 ]; then
  echo "[ ● ] Script needs to be run as root" && exit
fi

echo "========================================="
echo "Senarai akaun shadowsocks-libev"
echo "-----------------------------------------"
if [[ -f /usr/share/plugins/shadowsocks/.libev ]]; then
  while read line
  do
    echo "$line" | awk '{print $1,$2,$6}'
  done < /usr/share/plugins/shadowsocks/.libev
fi
echo "-----------------------------------------"
echo "Created by Doctype, Powered by Cybertize."
echo "========================================="