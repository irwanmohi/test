#!/bin/bash
clear

echo ""
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo "|C| |Y| |B| |E| |R| |T| |I| |Z| |E|"
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo ""

if [ "$EUID" -ne 0 ]; then
  echo "[ ● ] Script needs to be run as root" && exit
fi

ALAMATIP=$( wget -qO- icanhazip.com )
ALAMATHOS=$( cat /etc/hostname )
TLSPORT=$( cat /usr/share/plugins/shadowsocks/.libev | tail -n1 | awk '{print $3}' )
HTTPPORT=$( cat /usr/share/plugins/shadowsocks/.libev | tail -n1 | awk '{print $4}' )

if [[ $TLSPORT == '' ]]; then
  TLS=6101
else
  TLS="$(( $TLSPORT + 1 ))"
fi

if [[ $HTTPPORT == '' ]]; then
  HTTP=6001
else
  HTTP="$(( $HTTPPORT + 1 ))"
fi

read -p "Masukkan nama pengguna: " NAMAPENGGUNA
read -p "Masukkan kata laluan: " KATALALUAN
read -p "Tempoh masa aktif (Hari) : " TEMPOHAKTIF

TARIKHBUAT=$( date +%F )
TANGGALHARIINI=$( date +%s )
MASAAKTIFSAAT=$(( $TEMPOHAKTIF * 86400 ))
MASATAMATTEMPOH=$(( $TANGGALHARIINI + $MASAAKTIFSAAT ))
TARIKHLUPUT=$( date -u --date="1970-01-01 $MASATAMATTEMPOH sec GMT" +%F )

egrep "^$NAMAPENGGUNA" /usr/share/plugins/shadowsocks/.libev &>/dev/null
if [ $? -eq 0 ]; then
  echo "Nama pengguna sudah diguna!" && exit 1
fi
egrep "^$KATALALUAN" /usr/share/plugins/shadowsocks/.libev &>/dev/null
if [ $? -eq 0 ]; then
  echo "Kata laluan tidak sah!" && exit 2
fi

cat > /etc/shadowsocks-libev/$NAMAPENGGUNA-tls.json<<END
{
    "server":["www.cybertize.tk","0.0.0.0"],
    "server_port":$TLS,
    "local_port":1080,
    "password":"$KATALALUAN",
    "method":"chacha20-ietf-poly1305",
    "timeout":60,
    "fast_open":true,
    "no_delay":true,
    "plugin":"obfs-server",
    "plugin_opts":"obfs=tls",
    "nameserver":"1.1.1.1",
    "mode":"tcp_and_udp"
}
END

cat > /etc/shadowsocks-libev/$NAMAPENGGUNA-http.json <<-END
{
    "server":["www.cybertize.tk","0.0.0.0"],
    "server_port":$HTTP,
    "local_port":1080,
    "password":"$KATALALUAN",
    "method":"chacha20-ietf-poly1305",
    "timeout":60,
    "fast_open":true,
    "no_delay":true,
    "plugin":"obfs-server",
    "plugin_opts":"obfs=tls",
    "nameserver":"1.1.1.1",
    "mode":"tcp_and_udp"
}
END

systemctl start shadowsocks-libev-server@$NAMAPENGGUNA-tls.service &>/dev/null
systemctl enable shadowsocks-libev-server@$NAMAPENGGUNA-tls.service &>/dev/null
systemctl start shadowsocks-libev-server@$NAMAPENGGUNA-http.service &>/dev/null
systemctl enable shadowsocks-libev-server@$NAMAPENGGUNA-http.service &>/dev/null
systemctl status shadowsocks-libev-server@$NAMAPENGGUNA-http.service | grep "active" &>/dev/null
if [[ $? = 0 ]]; then STATUS="Active"; fi

LIBEVTLS=$( echo -n "chacha20-ietf-poly1305:$KATALALUAN@$ALAMATHOS:$TLS" | base64 )
LIBEVHTTP=$( echo -n "chacha20-ietf-poly1305:$KATALALUAN@$ALAMATHOS:$HTTP" | base64 )
echo "$NAMAPENGGUNA $KATALALUAN $TLS $HTTP $STATUS $TEMPOHAKTIF hari $TARIKHBUAT $TARIKHLUPUT" >> /usr/share/plugins/shadowsocks/.libev

echo "========================================="
echo "[LIBEV] Maklumat akaun pengguna"
echo "-----------------------------------------"
echo "Alamat IP: $ALAMATIP"
echo "Alamat Hos: $ALAMATHOS"
echo "Ports : $TLS(TLS) $HTTP(HTTP)"
echo "Tempoh aktif: $TEMPOHAKTIF hari"
echo "Tarikh luput: $TARIKHLUPUT"
echo "--------------------------------------"
echo "TLS File: $LIBEVTLS#$NAMAPENGGUNA"
echo "HTTP File: $LIBEVHTTP#$NAMAPENGGUNA"
echo "-----------------------------------------"
echo "Created by Doctype, Powered by Cybertize."
echo "========================================="