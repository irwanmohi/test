#!/bin/bash
clear

echo ""
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo "|C| |Y| |B| |E| |R| |T| |I| |Z| |E|"
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo ""

if [ "$EUID" -ne 0 ]; then
  echo "[ ● ] Script needs to be run as root" && exit
fi

ALAMATIP=$( wget -qO- icanhazip.com )
ALAMATHOS=$( cat /etc/hostname )
NAMAPENGGUNA=$(</dev/urandom tr -dc a-z | head -c8)
KATALALUAN=$( openssl rand -base64 12 )
TEMPOHAKTIF="1"
TLSPORT=$(( 1024 + $RANDOM ))
HTTPPORT=$(( 1024 + $RANDOM ))

TARIKHBUAT=$( date +%F )
HARIINI=$( date +%s )
MASAAKTIFSAAT=$(( $TEMPOHAKTIF * 86400 ))
TAMATTEMPOH=$(( $HARIINI + $MASAAKTIFSAAT ))
TARIKHLUPUT=$( date -u --date="1970-01-01 $TAMATTEMPOH sec GMT" +%F )

egrep "^$NAMAPENGGUNA" /usr/share/plugins/shadowsocks/.libev &>/dev/null
if [ $? -eq 0 ]; then
  echo "Nama pengguna tidak sah!" && exit 1
fi
egrep "^$KATALALUAN" /usr/share/plugins/shadowsocks/.libev &>/dev/null
if [ $? -eq 0 ]; then
  echo "Kata laluan tidak sah!" && exit 2
fi

cat > /etc/shadowsocks-libev/$NAMAPENGGUNA-tls.json<<END
{
    "server":["www.cybertize.tk","0.0.0.0"],
    "server_port":$TLSPORT,
    "local_port":1080,
    "password":"$KATALALUAN",
    "method":"chacha20-ietf-poly1305",
    "timeout":60,
    "fast_open":true,
    "no_delay":true,
    "plugin":"obfs-server",
    "plugin_opts":"obfs=tls",
    "nameserver":"1.1.1.1",
    "mode":"tcp_only"
}
END

cat > /etc/shadowsocks-libev/$NAMAPENGGUNA-http.json <<-END
{
    "server":["www.cybertize.tk","0.0.0.0"],
    "server_port":$HTTPPORT,
    "local_port":1080,
    "password":"$KATALALUAN",
    "method":"chacha20-ietf-poly1305",
    "timeout":60,
    "fast_open":true,
    "no_delay":true,
    "plugin":"obfs-server",
    "plugin_opts":"obfs=tls",
    "nameserver":"1.1.1.1",
    "mode":"tcp_only"
}
END

systemctl start shadowsocks-libev-server@$NAMAPENGGUNA-tls.service &>/dev/null
systemctl enable shadowsocks-libev-server@$NAMAPENGGUNA-tls.service &>/dev/null
systemctl start shadowsocks-libev-server@$NAMAPENGGUNA-http.service &>/dev/null
systemctl enable shadowsocks-libev-server@$NAMAPENGGUNA-http.service &>/dev/null
systemctl status shadowsocks-libev-server@$NAMAPENGGUNA-http.service | grep "active" &>/dev/null
if [[ $? = 0 ]]; then STATUS="Active"; fi
echo "$NAMAPENGGUNA $KATALALUAN $TLSPORT $HTTPPORT $STATUS $TEMPOHAKTIF hari $TARIKHBUAT $TARIKHLUPUT" >> /usr/share/plugins/shadowsocks/.libev

echo "========================================="
echo "[LIBEV] Maklumat akaun pengguna"
echo "-----------------------------------------"
echo "Alamat IP: $ALAMATIP"
echo "Alamat Hos: $ALAMATHOS"
echo "Ports : $TLSPORT(TLS) $HTTPPORT(HTTP)"
echo "Tempoh aktif: $TEMPOHAKTIF hari"
echo "Tarikh luput: $TARIKHLUPUT"
echo "-----------------------------------------"
echo "Created by Doctype, Powered by Cybertize."
echo "========================================="