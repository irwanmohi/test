#!/bin/bash
clear

echo ""
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo "|C| |Y| |B| |E| |R| |T| |I| |Z| |E|"
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo ""

if [ "$EUID" -ne 0 ]; then
  echo "[ ● ] Script needs to be run as root" && exit
fi

read -p "Masukkan nama pengguna: " NAMAPENGGUNA
egrep "^$NAMAPENGGUNA" /usr/share/plugins/shadowsocks/.libev &>/dev/null
if [ $? -ne 0 ]; then
  echo "Nama pengguna tidak dijumpai!" && exit 1
fi

read -p "Tempoh masa aktif (Hari): " TEMPOHAKTIF

TAMATTEMPOH=$( grep -w "$PENGGUNA" /usr/share/plugins/shadowsocks/.libev | cut -d ' ' -f 9 )
TAMATTEMPOH_SAAT=$( date -d "$TAMATTEMPOH" +%s )
HARIINI=$( date +%F )
HARIINI_SAAT=$( date -d "$HARIINI" +%s )

BAKITEMPOH=$(( (TAMATTEMPOH_SAAT - HARIINI_SAAT) / 86400 ))
TEMPOHAKTIF=$(( $BAKITEMPOH + $TEMPOHAKTIF ))
TARIKHLUPUT=$( date -d "$TEMPOHAKTIF days" +"%F" )

echo "========================================="
echo "Maklumat akaun pengguna"
echo "-----------------------------------------"
echo "Nama pengguna: $NAMAPENGGUNA"
echo "Tempoh aktif: $TEMPOHAKTIF hari"
echo "Tarikh luput: $TARIKHLUPUT"
echo "-----------------------------------------"
echo "Created by Doctype, Powered by Cybertize."
echo "========================================="