#!/bin/bash
clear

echo ""
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo "|C| |Y| |B| |E| |R| |T| |I| |Z| |E|"
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo ""

SENARAIAKAUN=( `cat /usr/src/shadowsocks/.accounts | cut -d ' ' -f 1` )
HARIINI=$( date +%F )
for PENGGUNA in "${SENARAIAKAUN[@]}"
do
  TARIKHLUPUT=$( grep -w "$PENGGUNA" /usr/src/shadowsocks/.accounts | cut -d ' ' -f 9 )
  TARIKHLUPUT_SAAT=$( date -d "$TARIKHLUPUT" +%s )
  HARIINI_SAAT=$( date -d "$HARIINI" +%s )
  TEMPOHAKTIF=$(( (TARIKHLUPUT_SAAT - HARIINI_SAAT) / 86400 ))
  if [[ "$TEMPOHAKTIF" -eq "0" ]] || [[ "$TEMPOHAKTIF" -lt "0" ]]; then
    systemctl disable shadowsocks-libev-server@$PENGGUNA-tls.service &>/dev/null
    systemctl stop shadowsocks-libev-server@$PENGGUNA-tls.service &>/dev/null
    systemctl disable shadowsocks-libev-server@$PENGGUNA-http.service &>/dev/null
    systemctl stop shadowsocks-libev-server@$PENGGUNA-http.service &>/dev/null

    sed -i "/$PENGGUNA/d" /usr/src/shadowsocks/.accounts
    rm -f /etc/shadowsocks-libev/$PENGGUNA-tls.json &>/dev/null
    rm -f /etc/shadowsocks-libev/$PENGGUNA-http.json &>/dev/null
  fi
done

echo "==============================================="
echo "Selesai menghapus akaun yang telah tamat tempoh"
echo "-----------------------------------------------"
echo "Created by Doctype, Powered by Cybertize."
echo "==============================================="