use Net::SSH::Perl;

##

sub Send_hhnsinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MNS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass,includepath,sshport FROM server WHERE type='$FORM{'ns'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass,$includepath,$sshport)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$statement=qq(SELECT DISTINCT(ip) FROM server WHERE type='client' || type='signup');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($referer,@referer);
push(@referer,$ENV{'SERVER_ADDR'});
while(($referer)=$query_output->fetchrow)
	{
	if($referer ne $ENV{'SERVER_ADDR'}){push(@referer,$referer);}
	}
$ENV{HOME}=$system{'cgipath'};
my $ssh=Net::SSH::Perl->new($ip,protocol=>'2',port=>$sshport);
my($root)="root";
eval {$ssh->login($root,$FORM{'pass'});};
if($@ =~ /Permission denied/i){&Error("The root password was incorrect.");}
my($cmd)=qq(mkdir -p $includepath;chmod 700 $includepath;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$host="$ip";' > $includepath/hhns.inc;echo '\$port="$port";' >> $includepath/hhns.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$key='"'"'$serverpass'"'"';' >> $includepath/hhns.inc;echo "\@referers=\(');
$cmd.=join("','",@referer);
$cmd.=qq('\);" >> $includepath/hhns.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo "1;" >> $includepath/hhns.inc;chmod 600 $includepath/hhns.inc;);
$ssh->cmd($cmd);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>hhns.inc File Information For );
if($FORM{'ns'} eq "ns1"){print qq(Primary);}
else{print qq(Secondary);}
print qq( Name Server</td></tr>
<tr><td class="prgout" align=left>The file $FORM{'path'}/hhns.inc was created and the following information placed in it.</td></tr>
<tr><td class="prgout" align=left>\$host=&quot;$ip&quot;;<br>
\$port=&quot;$port&quot;;<br>
\$key='$serverpass';<br>
\@referers=\(');
print join ("','",@referer);
print qq('\);<br>
1;
</td></tr>
<tr><td class="prgout" align=left>The name server daemon, hhnsd, can now be started.</td></tr>
</table>);
&Bottom;
}

##

sub NSinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MNS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass,includepath FROM server WHERE type='$FORM{'ns'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass,$includepath)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
if(!$includepath){&Error("The includepath was not defined for this name server. Please go into Define for this name server and enter the include path and save the settings.");}
$statement=qq(SELECT DISTINCT(ip) FROM server WHERE type='client' || type='signup');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($referer,@referer);
push(@referer,$ENV{'SERVER_ADDR'});
while(($referer)=$query_output->fetchrow)
	{
	if($referer ne $ENV{'SERVER_ADDR'}){push(@referer,$referer);}
	}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the name server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>hhns.inc File Information For );
if($FORM{'ns'} eq "ns1"){print qq(Primary);}
else{print qq(Secondary);}
print qq( Name Server</td></tr>
<tr><td class="prgout" align=left colspan=2>\$host=&quot;$ip&quot;;<br>
\$port=&quot;$port&quot;;<br>
\$key='$serverpass';<br>
\@referers=\(');
print join ("','",@referer);
print qq('\);<br>
1;
</td></tr>
<tr><td class="prgout" align=left colspan=2>This file can be created by hand and placed in $includepath,<br>
or can be sent to server via SSH if root ssh with password access is available.</td></tr>
<tr><td class="heada" align=center colspan=2>Generate hhns.inc on );
if($FORM{'ns'} eq "ns1"){print qq(Primary );}
else{print qq(Secondary );}
print qq(name server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send hhns.inc"></td></tr>
</table>
<input name="ns" type="hidden" value="$FORM{'ns'}">
<input name="do" type="hidden" value="Send hhnsinc">
</form>);
&Bottom;
}

##

sub NSinc_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MNS3'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Generate hhns.inc File Information</td></tr>
<tr><td class="prgout" align=left Valign=top>Name Server</td>
<td class="prgout" align=left><a href="$script?do=NSinc&ns=ns1" class="prgout">Primary Name Server</a><br>
<a href="$script?do=NSinc&ns=ns2" class="prgout">Secondary Name Server</a></td></tr>
</table>);
&Bottom;
}

##

sub Define_NS2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MNS2'} ne "yes")){&Error('Insufficient access for this function');}
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverpass)=$cipher->encrypt($FORM{'serverpass'});
$serverpass=&encode_base64($serverpass);
my($sdbpass);
if($FORM{'dnsdbpass'}){$sdbpass=&encode_base64($cipher->encrypt($FORM{'dnsdbpass'}));}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE server SET name='$FORM{'name'}',ip='$FORM{'ip'}',port='$FORM{'port'}',serverpass='$serverpass',nsconf='$FORM{'nsconf'}',
nsdir='$FORM{'nsdir'}',nsstart='$FORM{'nsstart'}',nsstop='$FORM{'nsstop'}',nsrestart='$FORM{'nsrestart'}',nspid='$FORM{'nspid'}',
netfilter='$FORM{'netfilter'}',nfpath='$FORM{'nfpath'}',autofirewall='$FORM{'autofirewall'}',usefilecheck='$FORM{'usefilecheck'}',
includepath='$FORM{'includepath'}',dnstype='$FORM{'dnstype'}',sdbhost='$FORM{'dnsdbhost'}',sdbname='$FORM{'dnsdbname'}',sdbuser='$FORM{'dnsdbuser'}',
sdbpass='$sdbpass',sshport='$FORM{'sshport'}',sshstart='$FORM{'sshstart'}',sshstop='$FORM{'sshstop'}',sshrestart='$FORM{'sshrestart'}',
sshpid='$FORM{'sshpid'}' WHERE type='ns2');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the name server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Generate hhns.inc on Secondary name server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send hhns.inc"></td></tr>
</table>
<input name="ns" type="hidden" value="ns2">
<input name="do" type="hidden" value="Send hhnsinc">
</form>);
&Bottom;
}

##

sub Define_NS2_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MNS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM server WHERE type='ns2');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
if(($query_output->execute)+0 <= 0)
	{
	$statement=qq(INSERT INTO server (type) VALUES ('ns2'));
	$db->query($statement);
	}
my(@values)=$query_output->fetchrow_array;
my($cipher);
my($serverpass,$dnsdbpass);
if($values[5])
	{
	if(&decode_base64($values[5]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($values[5]));
	}
if($values[27])
	{
	if(&decode_base64($values[27]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$dnsdbpass=$cipher->decrypt(&decode_base64($values[27]));
	}
if(!$values[74]){$values[74] = "/etc/gnuhh/nameserver";}
if(!$values[85]){$values[85] = "22";}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
function changeIt()
{
if(document.forms[0].dnstype.selectedIndex==0)
	{
	document.forms[0].nsconf.disabled=false;
	document.forms[0].nsdir.disabled=false;
	document.forms[0].dnsdbhost.disabled=true;
	document.forms[0].dnsdbname.disabled=true;
	document.forms[0].dnsdbuser.disabled=true;
	document.forms[0].dnsdbpass.disabled=true;
	}
if(document.forms[0].dnstype.selectedIndex==1)
	{
	document.forms[0].nsconf.disabled=true;
	document.forms[0].nsdir.disabled=true;
	document.forms[0].dnsdbhost.disabled=false;
	document.forms[0].dnsdbname.disabled=false;
	document.forms[0].dnsdbuser.disabled=false;
	document.forms[0].dnsdbpass.disabled=false;
	}
}
// -->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Define Secondary Name Server</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dnstype');" class="prgout">DNS Server Type</a></td>
<td class="prgout" align=left><select name="dnstype" size=1 onChange="return changeIt();"><option value="bind">BIND<option value="mydns");
if($values[75] eq "mydns"){print qq( selected);}
print qq(>MyDNS</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsname');" class="prgout">Secondary Name Server Name</a></td>
<td class="prgout" align=left><input name="name" type="text" value="$values[2]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsip');" class="prgout">Secondary Name Server IP Address</a></td>
<td class="prgout" align=left><input name="ip" type="text" value="$values[3]" size=15,1 maxlength=15></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsport');" class="prgout">Secondary Name Server Port</a></td>
<td class="prgout" align=left><input name="port" type="text" value="$values[4]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverpass');" class="prgout">Secondary Name Server Password</a></td>
<td class="prgout" align=left><input name="serverpass" type="text" value="$serverpass" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="$values[85]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsconf');" class="prgout">Secondary Name Server Configuration File</a></td>
<td class="prgout" align=left><input name="nsconf" type="text" value="$values[60]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsdir');" class="prgout">Secondary Name Server Data Directory</a></td>
<td class="prgout" align=left><input name="nsdir" type="text" value="$values[61]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsstart');" class="prgout">Secondary Name Server Start Command</a></td>
<td class="prgout" align=left><input name="nsstart" type="text" value="$values[62]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsstop');" class="prgout">Secondary Name Server Stop Command</a></td>
<td class="prgout" align=left><input name="nsstop" type="text" value="$values[63]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsrestart');" class="prgout">Secondary Name Server Restart Command</a></td>
<td class="prgout" align=left><input name="nsrestart" type="text" value="$values[64]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nspid');" class="prgout">Secondary Name Server PID File</a></td>
<td class="prgout" align=left><input name="nspid" type="text" value="$values[65]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dnsdbhost');" class="prgout">Name Server Database Host</a></td>
<td class="prgout" align=left><input name="dnsdbhost" type="text" value="$values[24]" size=20,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dnsdbname');" class="prgout">Name Server Database Name</a></td>
<td class="prgout" align=left><input name="dnsdbname" type="text" value="$values[25]" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dnsdbuser');" class="prgout">Name Server Database Username</a></td>
<td class="prgout" align=left><input name="dnsdbuser" type="text" value="$values[26]" size=20,1 maxlength=64></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dnsdbpass');" class="prgout">Name Server Database Password</a></td>
<td class="prgout" align=left><input name="dnsdbpass" type="text" value="$dnsdbpass" size=20,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter on Secondary Name Server?</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no");
if($values[20] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path on Secondary Name Server</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" value="$values[52]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no");
if($values[53] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no");
if($values[23] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">Include Path</a></td>
<td class="prgout" align=left><input name="includepath" type="text" value="$values[74]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" value="$values[86]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" value="$values[87]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" value="$values[88]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" value="$values[89]" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Information"></td></tr>
<input name="do" type="hidden" value="Define NS2">
</table>
</form>);
my($extra)=qq(<script language="javascript">
<!--
changeIt();
// -->
</script>);
&Bottom($extra);
}

##

sub Define_NS1
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MNS1'} ne "yes")){&Error('Insufficient access for this function');}
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
if(!$FORM{'serverpass'}){&Error("A password for the server is required");}
my($serverpass)=$cipher->encrypt($FORM{'serverpass'});
$serverpass=&encode_base64($serverpass);
my($sdbpass);
if($FORM{'dnsdbpass'}){$sdbpass=&encode_base64($cipher->encrypt($FORM{'dnsdbpass'}));}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE server SET name='$FORM{'name'}',ip='$FORM{'ip'}',port='$FORM{'port'}',serverpass='$serverpass',nsconf='$FORM{'nsconf'}',
nsdir='$FORM{'nsdir'}',nsstart='$FORM{'nsstart'}',nsstop='$FORM{'nsstop'}',nsrestart='$FORM{'nsrestart'}',nspid='$FORM{'nspid'}',
netfilter='$FORM{'netfilter'}',nfpath='$FORM{'nfpath'}',autofirewall='$FORM{'autofirewall'}',usefilecheck='$FORM{'usefilecheck'}',
includepath='$FORM{'includepath'}',dnstype='$FORM{'dnstype'}',sdbhost='$FORM{'dnsdbhost'}',sdbname='$FORM{'dnsdbname'}',sdbuser='$FORM{'dnsdbuser'}',
sdbpass='$sdbpass',sshport='$FORM{'sshport'}',sshstart='$FORM{'sshstart'}',sshstop='$FORM{'sshstop'}',sshrestart='$FORM{'sshrestart'}',
sshpid='$FORM{'sshpid'}' WHERE type='ns1');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the name server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Generate hhns.inc on Primary name server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send hhns.inc"></td></tr>
</table>
<input name="ns" type="hidden" value="ns1">
<input name="do" type="hidden" value="Send hhnsinc">
</form>);
&Bottom;
}

##

sub Define_NS1_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MNS1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM server WHERE type='ns1');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
if(($query_output->execute)+0 <= 0)
	{
	$statement=qq(INSERT INTO server (type) VALUES ('ns1'));
	$db->query($statement);
	}
my(@values)=$query_output->fetchrow_array;
my($cipher);
my($serverpass,$dnsdbpass);
if($values[5])
	{
	if(&decode_base64($values[5]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($values[5]));
	}
if($values[27])
	{
	if(&decode_base64($values[27]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$dnsdbpass=$cipher->decrypt(&decode_base64($values[27]));
	}
if(!$values[74]){$values[74] = "/etc/gnuhh/nameserver";}
if(!$values[85]){$values[85] = "22";}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
function changeIt()
{
if(document.forms[0].dnstype.selectedIndex==0)
	{
	document.forms[0].nsconf.disabled=false;
	document.forms[0].nsdir.disabled=false;
	document.forms[0].dnsdbhost.disabled=true;
	document.forms[0].dnsdbname.disabled=true;
	document.forms[0].dnsdbuser.disabled=true;
	document.forms[0].dnsdbpass.disabled=true;
	}
if(document.forms[0].dnstype.selectedIndex==1)
	{
	document.forms[0].nsconf.disabled=true;
	document.forms[0].nsdir.disabled=true;
	document.forms[0].dnsdbhost.disabled=false;
	document.forms[0].dnsdbname.disabled=false;
	document.forms[0].dnsdbuser.disabled=false;
	document.forms[0].dnsdbpass.disabled=false;
	}
}
// -->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Define Primary Name Server</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dnstype');" class="prgout">DNS Server Type</a></td>
<td class="prgout" align=left><select name="dnstype" size=1 onChange="return changeIt();"><option value="bind">BIND<option value="mydns");
if($values[75] eq "mydns"){print qq( selected);}
print qq(>MyDNS</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsname');" class="prgout">Primary Name Server Name</a></td>
<td class="prgout" align=left><input name="name" type="text" value="$values[2]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsip');" class="prgout">Primary Name Server IP Address</a></td>
<td class="prgout" align=left><input name="ip" type="text" value="$values[3]" size=15,1 maxlength=15></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsport');" class="prgout">Primary Name Server Port</a></td>
<td class="prgout" align=left><input name="port" type="text" value="$values[4]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverpass');" class="prgout">Primary Name Server Password</a></td>
<td class="prgout" align=left><input name="serverpass" type="text" value="$serverpass" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="$values[85]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsconf');" class="prgout">Primary Name Server Configuration File</a></td>
<td class="prgout" align=left><input name="nsconf" type="text" value="$values[60]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsdir');" class="prgout">Primary Name Server Data Directory</a></td>
<td class="prgout" align=left><input name="nsdir" type="text" value="$values[61]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsstart');" class="prgout">Primary Name Server Start Command</a></td>
<td class="prgout" align=left><input name="nsstart" type="text" value="$values[62]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsstop');" class="prgout">Primary Name Server Stop Command</a></td>
<td class="prgout" align=left><input name="nsstop" type="text" value="$values[63]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nsrestart');" class="prgout">Primary Name Server Restart Command</a></td>
<td class="prgout" align=left><input name="nsrestart" type="text" value="$values[64]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nspid');" class="prgout">Primary Name Server PID File</a></td>
<td class="prgout" align=left><input name="nspid" type="text" value="$values[65]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dnsdbhost');" class="prgout">Name Server Database Host</a></td>
<td class="prgout" align=left><input name="dnsdbhost" type="text" value="$values[24]" size=20,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dnsdbname');" class="prgout">Name Server Database Name</a></td>
<td class="prgout" align=left><input name="dnsdbname" type="text" value="$values[25]" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dnsdbuser');" class="prgout">Name Server Database Username</a></td>
<td class="prgout" align=left><input name="dnsdbuser" type="text" value="$values[26]" size=20,1 maxlength=64></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dnsdbpass');" class="prgout">Name Server Database Password</a></td>
<td class="prgout" align=left><input name="dnsdbpass" type="text" value="$dnsdbpass" size=20,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter on Primary Name Server?</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no");
if($values[20] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path on Primary Name Server</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" value="$values[52]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no");
if($values[53] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no");
if($values[23] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">Include Path</a></td>
<td class="prgout" align=left><input name="includepath" type="text" value="$values[74]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" value="$values[86]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" value="$values[87]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" value="$values[88]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" value="$values[89]" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Information"></td></tr>
</table>
<input name="do" type="hidden" value="Define NS1">
</form>);
my($extra)=qq(<script language="javascript">
<!--
changeIt();
// -->
</script>);
&Bottom($extra);
}

##

sub Configure_NS2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MNS5'} ne "yes")){&Error('Insufficient access for this function');}
my($dnsdbpass,$serverpass);
my($cipher);
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip FROM server WHERE type='ns1');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ns1,$ns1ip)=$query_output->fetchrow;
$statement=qq(SELECT * FROM server WHERE type='ns2');
$query_output=$db->query($statement);
my(@values)=$query_output->fetchrow_array;
if($values[5])
	{
	if(&decode_base64($values[5]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($values[5]));
	}
if($values[27])
	{
	if(&decode_base64($values[27]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$dnsdbpass=$cipher->decrypt(&decode_base64($values[27]));
	}
foreach(@values){$_=&uri_escape($_);}
my($command)=qq(do=save+nameserver+configuration&dnstype=$values[75]&ns1name=$ns1&ns1ip=$ns1ip&ns2name=$values[2]&type=secondary&netfilter=$values[20]);
if($values[75] eq "bind"){$command.=qq(&conf=$values[60]&dir=$values[61]);}
if($values[75] eq "mydns"){$command.=qq(&dbhost=$values[24]&dbname=$values[25]&dbuser=$values[26]&dbpass=$dnsdbpass);}
$command.=qq(&restart=$values[64]&start=$values[62]&stop=$values[63]&nfpath=$values[52]);
$command.=qq(&autofirewall=$values[53]&nspid=$values[65]&usefilecheck=$values[23]&adminemail=$system{'adminemail'});
$command.=qq(&sshstart=$values[86]&sshstop=$values[87]&sshrestart=$values[88]&sshpid=$values[89]);
&Connect($values[3],$values[4],$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Secondary name server configured</td></tr>
</table>);
&Bottom;
}

##

sub Configure_NS1
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MNS4'} ne "yes")){&Error('Insufficient access for this function');}
my($dnsdbpass,$serverpass);
my($cipher);
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name FROM server WHERE type='ns2');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ns2)=$query_output->fetchrow;
$statement=qq(SELECT * FROM server WHERE type='ns1');
$query_output=$db->query($statement);
my(@values)=$query_output->fetchrow_array;
if($values[5])
	{
	if(&decode_base64($values[5]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($values[5]));
	}
if($values[27])
	{
	if(&decode_base64($values[27]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$dnsdbpass=$cipher->decrypt(&decode_base64($values[27]));
	}
foreach(@values){$_=&uri_escape($_);}
my($command)=qq(do=save+nameserver+configuration&dnstype=$values[75]&ns1name=$values[2]&ns2name=$ns2&type=primary&netfilter=$values[20]&conf=$values[60]);
if($values[75] eq "bind"){$command.=qq(&conf=$values[60]&dir=$values[61]);}
if($values[75] eq "mydns"){$command.=qq(&dbhost=$values[24]&dbname=$values[25]&dbuser=$values[26]&dbpass=$dnsdbpass);}
$command.=qq(&dir=$values[61]&restart=$values[64]&start=$values[62]&stop=$values[63]&nfpath=$values[52]);
$command.=qq(&autofirewall=$values[53]&nspid=$values[65]&usefilecheck=$values[23]&adminemail=$system{'adminemail'});
$command.=qq(&sshstart=$values[86]&sshstop=$values[87]&sshrestart=$values[88]&sshpid=$values[89]);
&Connect($values[3],$values[4],$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Primary name server configured</td></tr>
</table>);
&Bottom;
}

1;
