sub Remove_Res_Package
{
if(($Cookies{'level'} ne "1")&&($access{'PM7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM reseller_packages WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
#add lines for updating resellers here
#if($FORM{'newid'} ne "")
#	{
#	$statement=qq(UPDATE resellers SET package='$FORM{'newid'}' WHERE package='$FORM{'id'}');
#	$db->query($statement);
#	if($error=$db->errmsg){&Error($error);}
#	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="prgout">
<tr><td class="prgout" align=left>The reseller package has been removed.</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Res_Package_Select
{
if(($Cookies{'level'} ne "1")&&($access{'PM7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM reseller_packages ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(document.forms[0].id.selectedIndex == 0)
	{
	alert("Select a reseller package to remove.");
	return false;
	}
if(! confirm("Do you want to delete this reseller package?"))
	{
	return false;
	}
if(document.forms[0].newid.selectedIndex == 0)
	{
	if(! confirm("You did not select a new reseller package to move existing resellers to.\\nIf you do not select a move to reseller package a reseller may not get charged for accounts."))
		{
		return false;
		}
	}
if(document.forms[0].id.value == document.forms[0].newid.value)
	{
	alert("You can not move existing resellers to the reseller package you are removing.");
	return false;
	}
else
return true;
}
// -->
</script>
<form action="$script" method="Post" onSubmit="return ConFirm()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Reseller Package</td></tr>
<tr><td class="prgout" align=left valign=top>Package</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Package--);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<option value="$id">$name);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left>Move existing to reseller package:</td>
<td class="prgout" align=left><select name="newid" size=1><option value="">--None--);
$query_output=$db->query($statement);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<option value="$id">$name);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Remove Reseller Package"></td></tr>
</table>
<input name="do" type="hidden" value="Remove Res Package">
</form>);
&Bottom;
}

##

sub Save_Res_Package
{
if(($Cookies{'level'} ne "1")&&($access{'PM6'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE reseller_packages SET storage='$FORM{'storage'}',transfer='$FORM{'transfer'}',pop='$FORM{'pop'}',popspace='$FORM{'popspace'}',
responder='$FORM{'responder'}',mysql='$FORM{'mysql'}',subs='$FORM{'subs'}',setup='$FORM{'setup'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Reseller Package Updated.</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Res_Package
{
if(($Cookies{'level'} ne "1")&&($access{'PM6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,storage,transfer,pop,popspace,responder,mysql,subs,setup FROM reseller_packages WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$setup)=$query_output->fetchrow;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Reseller Package $name</td></tr>
<tr><td class="prgout" align=left>Storage</td>
<td class="prgout" align=left>\$<input name="storage" type="text" value="$storage" size=4,1 maxlength=7> per megabyte</td></tr>
<tr><td class="prgout" align=left>Transfer</td>
<td class="prgout" align=left>\$<input name="transfer" type="text" value="$transfer" size=4,1 maxlength=7> per gigabyte</td></tr>
<tr><td class="prgout" align=left>Pop Accounts</td>
<td class="prgout" align=left>\$<input name="pop" type="text" value="$pop" size=4,1 maxlength=7> per account</td></tr>
<tr><td class="prgout" align=left>Pop Disk Space</td>
<td class="prgout" align=left>\$<input name="popspace" type="text" value="$popspace" size=4,1 maxlength=7> per megabyte</td></tr>
<tr><td class="prgout" align=left>Email Auto-Responders</td>
<td class="prgout" align=left>\$<input name="responder" type="text" value="$responder" size=4,1 maxlength=7> per auto-responder</td></tr>
<tr><td class="prgout" align=left>MySQL Databases</td>
<td class="prgout" align=left>\$<input name="mysql" type="text" value="$mysql" size=4,1 maxlength=7> per MySQL database</td></tr>
<tr><td class="prgout" align=left>Sub Domains</td>
<td class="prgout" align=left>\$<input name="subs" type="text" value="$subs" size=4,1 maxlength=7> per sub domain</td></tr>
<tr><td class="prgout" align=left>Setup Fee</td>
<td class="prgout" align=left>\$<input name="setup" type="text" value="$setup" size=4,1 maxlength=7> per account</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Reseller Package"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Res Package">
</form>);
&Bottom;
}

##

sub Edit_Res_Package_Select
{
if(($Cookies{'level'} ne "1")&&($access{'PM6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM reseller_packages ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Reseller Package</td></tr>
<tr><td class="prgout" align=left valign=top>Package</td>);
if($count < 10)
	{
	print qq(<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Edit+Res+Package&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<td class="prgout" align=left><select name="id" size=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td align=center colspan=2><input type="submit" value="Edit Reseller Package"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Edit Res Package">
</form>);
&Bottom;
}

##

sub Add_Res_Package
{
if(($Cookies{'level'} ne "1")&&($access{'PM5'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'name'}=~s/\'/\\'/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(INSERT INTO reseller_packages (name,storage,transfer,pop,popspace,responder,mysql,subs,setup) VALUES
('$FORM{'name'}','$FORM{'storage'}','$FORM{'transfer'}','$FORM{'pop'}','$FORM{'popspace'}','$FORM{'responder'}','$FORM{'mysql'}','$FORM{'subs'}','$FORM{'setup'}'));
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Reseller package added.</td></tr>
</table>);
&Bottom;
}

##

sub Add_Res_Package_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'PM5'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Reseller Package</td></tr>
<tr><td class="prgout" align=left>Name</td>
<td class="prgout" align=left><input name="name" type="text" size=20,1 maxlength=25></td></tr>
<tr><td class="prgout" align=left>Storage</td>
<td class="prgout" align=left>\$<input name="storage" type="text" size=4,1 maxlength=7> per megabyte</td></tr>
<tr><td class="prgout" align=left>Transfer</td>
<td class="prgout" align=left>\$<input name="transfer" type="text" size=4,1 maxlength=7> per gigabyte</td></tr>
<tr><td class="prgout" align=left>Pop Accounts</td>
<td class="prgout" align=left>\$<input name="pop" type="text" size=4,1 maxlength=7> per account</td></tr>
<tr><td class="prgout" align=left>Pop Disk Space</td>
<td class="prgout" align=left>\$<input name="popspace" type="text" size=4,1 maxlength=7> per megabyte</td></tr>
<tr><td class="prgout" align=left>Email Auto-Responders</td>
<td class="prgout" align=left>\$<input name="responder" type="text" size=4,1 maxlength=7> per auto-responder</td></tr>
<tr><td class="prgout" align=left>MySQL Databases</td>
<td class="prgout" align=left>\$<input name="mysql" type="text" size=4,1 maxlength=7> per MySQL database</td></tr>
<tr><td class="prgout" align=left>Sub Domains</td>
<td class="prgout" align=left>\$<input name="subs" type="text" size=4,1 maxlength=7> per sub domain</td></tr>
<tr><td class="prgout" align=left>Setup Fee</td>
<td class="prgout" align=left>\$<input name="setup" type="text" size=4,1 maxlength=7> per account</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Reseller Package"></td></tr>
</table>
<input name="do" type="hidden" value="Add Res Package">
</form>);
&Bottom;
}

##

sub Install_Invoice
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SC3'} ne "yes")){&Error('Insufficient access for this function');}
my($perlpath)=$^X;
open(FILE,">invoice.cgi");
print FILE qq(#!$perlpath
use strict;
use vars qw/\%system \$cgipath \$Version/;
\$cgipath="$system{'cgipath'}";
require "$system{'cgipath'}/mail-lib.pl";\n);
open(TMP,"invoice.txt");
while(<TMP>)
	{
	print FILE $_;
	}
close(TMP);
close(FILE);
chmod(0755,"invoice.cgi");
my(@info)=qx|crontab -l|;
open(TMP,">crontab.tmp");
foreach(@info)
	{
	if($_ !~ m|$system{'cgipath'}/invoice.cgi$|)
		{
		print TMP $_;
		}
	}
print TMP "30 2 * * * $system{'cgipath'}/invoice.cgi\n";
close(TMP);
qx|crontab crontab.tmp|;
unlink("crontab.tmp");
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Invoice cron process installed</td></tr>
</table>);
&Bottom;
}

##

sub Install_Invoice_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SC3'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Install Invoice Cron</td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Install Invoice Program"></td></tr>
</table>
<input name="do" type="hidden" value="Install Invoice">
</form>);
&Bottom;
}

##

sub Save_Statement_Email
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SC2'} ne "yes")){&Error('Insufficient access for this function');}
open(FILE,">statement.dat");
print FILE $FORM{'statement'};
close(FILE);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Email statement form updated</td></tr>
</table>);
&Bottom;
}

##

sub Statement_Email_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SC2'} ne "yes")){&Error('Insufficient access for this function');}
open(FILE,"statement.dat");
my(@statement)=<FILE>;
close(FILE);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Statement Email</td></tr>
<tr><td class="prgout" align=left>Use %%NAME%% to place the name of the billing contact<br>
Use %%ADDRESS%% to place the address (billed)<br>
Use %%DOMAIN%% to place the name of the domain<br>
Use %%PREVIOUS%% to place the previous balance of the account<br>
Use %%AMOUNT%% to place the total amount of the invoice<br>
Use %%CHARGE%% to place the total charge amount (will account for credits on account)<br>
Use %%DETAILS%% to place the details of the invoice<br>
Use %%SCRIPT%% to place a link to the client interface<br>
Use %%CC%% to display last 4 digits of credit card number</td></tr>
<tr><td class="prgout" align=left> <TEXTAREA name="statement" ROWS=15 COLS=50 WRAP=off>).join("",@statement).qq(</TEXTAREA></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Statement Email"></td></tr>
</table>
<input name="do" type="hidden" value="Save Statement Email">
</form>);
&Bottom;
}

##

sub Save_Invoice_Email
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SC1'} ne "yes")){&Error('Insufficient access for this function');}
open(FILE,">invoice.dat");
print FILE $FORM{'invoice'};
close(FILE);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Invoice email form updated</td></tr>
</table>);
&Bottom;
}

##

sub Invoice_Email_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SC1'} ne "yes")){&Error('Insufficient access for this function');}
open(FILE,"invoice.dat");
my(@invoice)=<FILE>;
close(FILE);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Invoice Email</td></tr>
<tr><td class="prgout" align=left>Use %%NAME%% to place the name of the billing contact<br>
Use %%ADDRESS%% to place the address (billed)<br>
Use %%DOMAIN%% to place the name of the domain<br>
Use %%PREVIOUS%% to place the previous balance of the account<br>
Use %%AMOUNT%% to place the total amount of the invoice<br>
Use %%CHARGE%% to place the total charge amount (will account for credits on account)<br>
Use %%DETAILS%% to place the details of the invoice<br>
Use %%SCRIPT%% to place a link to the client interface</td></tr>
<tr><td class="prgout" align=left> <TEXTAREA name="invoice" ROWS=15 COLS=50 WRAP=off>).join("",@invoice).qq(</TEXTAREA></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Invoice Email"></td></tr>
</table>
<input name="do" type="hidden" value="Save Invoice Email">
</form>);
&Bottom;
}

##

sub Save_Addons
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'PM4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM addon ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
while(($id,$name)=$query_output->fetchrow)
	{
	$statement=qq(UPDATE addon SET price='$FORM{"price$id"}',annual='$FORM{"annual$id"}' WHERE id='$id');
	$db->query($statement);
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Add on prices updated</td></tr>
</table>);
&Bottom;
}

##

sub Manage_Addons
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'PM4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name,price,annual FROM addon ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name,$price,$annual);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" colspan=3>Manage Addons</td></tr>
<tr><td class="headb" align=left>Addon</td>
<td class="headb" align=left>Price</td>
<td class="headb" align=left>Annual</td></tr>\n);
while(($id,$name,$price,$annual)=$query_output->fetchrow)
	{
	print qq(<tr><td class="prgout" align=left>$name</td>
<td class="prgout" align=left>\$<input name="price$id" type="text" value="$price" size=5,1></td>
<td class="prgout" align=left>\$<input name="annual$id" type="text" value="$annual" size=5,1></td></tr>\n);
	}
print qq(<tr><td class="prgout" align=center colspan=3><input type="submit" value="Save Addons"></td></tr>
</table>
<input name="do" type="hidden" value="Save Addons">
</form>);
&Bottom;
}

##

sub Remove_Package
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'PM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM packages WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting package removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Package_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'PM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM packages WHERE name != 'Forward' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(document.forms[0].id.selectedIndex <= 0)
{
alert("A package must be selected to be removed");
return false;
}
if(confirm("Do you want to delete this package?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<form action="$script" method="Post" onSubmit="return ConFirm()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Package</td></tr>
<tr><td class="prgout" align=left>Package to Remove</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Package--);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<option value="$id">$name);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Remove Package"></td></tr>
</table>
<input name="do" type="hidden" value="Remove Package">
</form>\n);
&Bottom;
}

##

sub Save_Package
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'PM2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE packages SET storage='$FORM{'storage'}',transfer='$FORM{'transfer'}',pop='$FORM{'pop'}',popspace='$FORM{'popspace'}',
responder='$FORM{'responder'}',mysql='$FORM{'mysql'}',subs='$FORM{'subs'}',price='$FORM{'price'}',
setup='$FORM{'setup'}',annual='$FORM{'annual'}',client='$FORM{'client'}',signup='$FORM{'signup'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting package updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Package
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'PM2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name,storage,transfer,pop,popspace,responder,mysql,subs,price,setup,annual,client,signup FROM packages WHERE name != 'Forward' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$price,$setup,$annual,$client,$signup);
&Top;
print qq(<script language="javascript">
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a package to edit");
return false;
}
else
return true;
}
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Package</td></tr>
<tr><td class="prgout" align=left>Package to Edit</td>
<td class="prgout" align=left><select name="id" size=1 onchange="ChgVal(this.options.selectedIndex);"><option value="">--Select Package--);
while(($id,$name,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$price,$setup,$annual,$client,$signup)=$query_output->fetchrow)
	{
	print qq(<option value="$id">$name);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left>Storage</td>
<td class="prgout" align=left><input name="storage" type="text" size=10,1> MB</td></tr>
<tr><td class="prgout" align=left>Transfer</td>
<td class="prgout" align=left><input name="transfer" type="text" size=10,1> GB</td></tr>
<tr><td class="prgout" align=left>Pop Accounts</td>
<td class="prgout" align=left><input name="pop" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Pop Disk Space<br>(per account)</td>
<td class="prgout" align=left><input name="popspace" type="text" size=5,1 maxlength=5> MB</td></tr>
<tr><td class="prgout" align=left>Auto Responders</td>
<td class="prgout" align=left><input name="responder" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>MySQL Database(s)</td>
<td class="prgout" align=left><input name="mysql" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Sub Domain(s)</td>
<td class="prgout" align=left><input name="subs" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Price</td>
<td class="prgout" align=left>\$<input name="price" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Setup Fee</td>
<td class="prgout" align=left>\$<input name="setup" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Annual Fee</td>
<td class="prgout" align=left>\$<input name="annual" type="text" size=10,1></td></tr>
<tr><td class="prgout" align=left>Visable in Client?</td>
<td class="prgout" align=left><select name="client" size=1><option value="y">Yes<option value="n">No</select></td></tr>
<tr><td class="prgout" align=left>Visable in Signup?</td>
<td class="prgout" align=left><select name="signup" size=1><option value="y">Yes<option value="n">No</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Package"></td></tr>
</table>
<input name="do" type="hidden" value="Save Package">
</form>
<script language="javascript">
<!--
function ChgVal(x)
	{
	document.forms[0].storage.value = eval(group[x][1]);
	document.forms[0].transfer.value = eval(group[x][2]);
	document.forms[0].pop.value = eval(group[x][3]);
	document.forms[0].popspace.value = eval(group[x][4]);
	document.forms[0].responder.value = eval(group[x][5]);
	document.forms[0].mysql.value = eval(group[x][6]);
	document.forms[0].subs.value = eval(group[x][7]);
	document.forms[0].price.value = eval(group[x][8]);
	document.forms[0].setup.value = eval(group[x][9]);
	document.forms[0].annual.value = eval(group[x][10]);
	document.forms[0].client.selectedIndex = eval(group[x][11]);
	document.forms[0].signup.selectedIndex = eval(group[x][12]);
	}
var groups=document.forms[0].id.options.length;
var group=new Array();
for(i=0;i<groups;i++)
group[i]=new Array();
group[0][1]=new String("");
group[0][2]=new String("");
group[0][3]=new String("");
group[0][4]=new String("");
group[0][5]=new String("");
group[0][6]=new String("");
group[0][7]=new String("");
group[0][8]=new String("");
group[0][9]=new String("");
group[0][10]=new String("");
group[0][11]=new Number(0);
group[0][12]=new Number(0);\n);
my($i)=0;
$query_output->dataseek();
while(($id,$name,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$price,$setup,$annual,$client,$signup)=$query_output->fetchrow)
	{
	$i++;
	print qq(group[$i][1]=new Number($storage);
group[$i][2]=new Number($transfer);
group[$i][3]=new Number($pop);
group[$i][4]=new Number($popspace);
group[$i][5]=new Number($responder);
group[$i][6]=new Number($mysql);
group[$i][7]=new Number($subs);
group[$i][8]=new Number($price);
group[$i][9]=new Number($setup);
group[$i][10]=new Number($annual);
group[$i][11]=new Number\();
	if($client eq "y"){print qq(0);}
	else{print qq(1);}
	print qq(\);
group[$i][12]=new Number\();
	if($signup eq "y"){print qq(0);}
	else{print qq(1);}
	print qq(\);\n);
	}
print qq(// -->
</script>\n);
&Bottom;
}

##

sub Add_Package
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'PM1'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(INSERT INTO packages (name,storage,transfer,pop,popspace,responder,mysql,subs,price,setup,annual,client,signup)
VALUES ('$FORM{'name'}','$FORM{'storage'}','$FORM{'transfer'}','$FORM{'pop'}','$FORM{'popspace'}',
'$FORM{'responder'}','$FORM{'mysql'}','$FORM{'subs'}','$FORM{'price'}','$FORM{'setup'}','$FORM{'annual'}','$FORM{'client'}','$FORM{'signup'}'));
$db->query($statement);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting package added</td></tr>
</table>);
&Bottom;
}

##

sub Add_Package_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'PM1'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pop.value > 0)
	{
	if(document.forms[0].popspace.value <= 0)
		{
		alert("Pop disk space must be defined if pop accounts are used.");
		return false;
		}
	}
var nametest=document.forms[0].name.value.toLowerCase();
if(nametest == "forward")
	{
	alert("Package name 'Forward' is internally reserved and can not be used");
	return false;
	}
return true;
}
//-->
</script>
<form action="$script" method="Post"  onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2><B>Add Package</B></td></tr>
<tr><td class="prgout" align=left>Package Name</td>
<td class="prgout" align=left><input name="name" type="text" size=20,1></td></tr>
<tr><td class="prgout" align=left>Storage</td>
<td class="prgout" align=left><input name="storage" type="text" size=10,1> MB</td></tr>
<tr><td class="prgout" align=left>Transfer</td>
<td class="prgout" align=left><input name="transfer" type="text" size=10,1> GB</td></tr>
<tr><td class="prgout" align=left>Pop Accounts</td>
<td class="prgout" align=left><input name="pop" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Pop Disk Space<br>(per account)</td>
<td class="prgout" align=left><input name="popspace" type="text" size=5,1 maxlength=5> MB</td></tr>
<tr><td class="prgout" align=left>Auto Responders</td>
<td class="prgout" align=left><input name="responder" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>MySQL Database(s)</td>
<td class="prgout" align=left><input name="mysql" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Sub Domain(s)</td>
<td class="prgout" align=left><input name="subs" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Monthly Price</td>
<td  class="prgout"align=left>\$<input name="price" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Setup Fee</td>
<td class="prgout" align=left>\$<input name="setup" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Annual Fee</td>
<td class="prgout" align=left>\$<input name="annual" type="text" size=10,1></td></tr>
<tr><td class="prgout" align=left>Visable in Client?</td>
<td class="prgout" align=left><select name="client" size=1><option value="y">Yes<option value="n">No</select></td></tr>
<tr><td class="prgout" align=left>Visable in Signup?</td>
<td class="prgout" align=left><select name="signup" size=1><option value="y">Yes<option value="n">No</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Package"></td></tr>
</table>
<input name="do" type="hidden" value="Add Package">
</form>\n);
&Bottom;
}

##

sub Setup_Database
{
&Check_Password;
if($Cookies{'level'} ne "1"){&Error('This function requires top level administrative access');}
my($db,$query_output,$statement,$error);
if((!$system{'dbhost'})||(!$system{'dbname'})||(!$system{'dbuser'})||(!$system{'dbpass'})){&Error("Please configure the database variables in the system configuration <a href=\"$script?do=variables\" class=\"prgout\">Here</a>");}
&Error("Database connection error") unless $db=Mysql->connect($FORM{'dbhost'},'mysql',$FORM{'dbruser'},$FORM{'dbrpass'});
$statement=qq(CREATE DATABASE $system{'dbname'});
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(GRANT ALL ON $system{'dbname'}.* TO $system{'dbuser'}\@$system{'dbhost'} IDENTIFIED BY "$system{'dbpass'}" WITH GRANT OPTION);
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(Flush privileges);
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
require "fields.pl";
my(@tablefields);
my($col)=0;
$statement=qq(SHOW VARIABLES LIKE 'version');
$query_output=$db->query($statement);
my($null,$vers)=$query_output->fetchrow;
if(substr($vers,0,3) eq "4.1"){$col=1;}
my(@exttables)=$db->listtables;
foreach(@exttables){$_=~s/\`//g;}
for($x=0;$x<=$#tables;$x++)
	{
	$exist=0;
	foreach(@tables)
		{
		if($exttables[$z] eq $_){$exist=1;}
		}
	if((!$exist)&&($exttables[$x]))
		{
		$statement=qq(DROP TABLE `$exttables[$x]`);
		$db->query($statement);
		}
	}
my(@exttables)=$db->listtables;
foreach(@exttables){$_=~s/\`//g;}
$y=0;
for($x=0;$x<=$#tables;$x++)
	{
	if($exttables[$y] ne $tables[$x])
		{
		if($dbinfo{$table}[$x]->{'default'} eq ""){$default="NULL";}
		else{$default="'$dbinfo{$tables[$x]}[0]->{'default'}'";}
		if(($dbinfo{$table}[$x]->{'null'} !~ /^Yes$/i)&&($dbinfo{$table}[$x]->{'default'} eq "")){$default="''";}
		$statement=qq(CREATE TABLE `$tables[$x]` \(`$dbinfo{$tables[$x]}[0]->{'field'}` $dbinfo{$tables[$x]}[0]->{'type'});
		if($dbinfo{$table}[$x]->{'null'} !~ /^Yes$/i){$statement.=qq( not null);}
		if($dbinfo{$tables[$x]}[0]->{'extra'} ne "auto_increment"){$statement.=qq( default $default);}
		$statement.=qq( $dbinfo{$tables[$x]}[0]->{'extra'});
		if($dbinfo{$tables[$x]}[0]->{'key'} eq "PRI"){$statement.=qq(, PRIMARY KEY (`$dbinfo{$tables[$x]}[0]->{'field'}`));}
		if($dbinfo{$tables[$x]}[0]->{'key'} eq "MUL"){$statement.=qq(, INDEX (`$dbinfo{$tables[$x]}[0]->{'field'}`));}
		$statement.=qq(\));
		$db->query($statement);
		}
	else{$y++;}
	}
my(@exttables)=$db->listtables;
foreach(@exttables){$_=~s/\`//g;}
for($x=0;$x<=$#exttables;$x++)
	{
	$table=$exttables[$x];
	$statement=qq(SHOW FULL FIELDS FROM `$tables[$x]`);
	$query_output=$db->query($statement);
	while((@tablefields)=$query_output->fetchrow_array)
		{
	$exist=0;
		for($i=0;$i<=(@$table-1);$i++)
			{
			if($tablefields[0] eq $dbinfo{$exttables[$x]}[$i]->{'field'}){$exist=1;}
			}
		if(!$exist)
			{
			$statement=qq(ALTER TABLE `$exttables[$x]` DROP `$tablefields[0]`);
			$db->query($statement); 
			}
		}
	}
for($x=0;$x<=$#tables;$x++)
	{
	$table=$tables[$x];
	Loop1:
	$statement=qq(SHOW FULL FIELDS FROM `$tables[$x]`);
	$query_output=$db->query($statement);
	$test=($query_output->execute)+0;
	$i=0;
	while((@tablefields)=$query_output->fetchrow_array)
		{
		$z=$i-1;
		if($tablefields[0] ne $dbinfo{$tables[$x]}[$i]->{'field'})
			{
			my($default);
			if($dbinfo{$tables[$x]}[$i]->{'default'} eq ""){$default="NULL";}
			else{$default="'$dbinfo{$tables[$x]}[$i]->{'default'}'";}
			if(($dbinfo{$tables[$x]}[$i]->{'null'} !~ /^Yes$/i)&&($dbinfo{$tables[$x]}[$i]->{'default'} eq "")){$default="''";}
			$statement=qq(ALTER TABLE `$tables[$x]` ADD `$dbinfo{$tables[$x]}[$i]->{'field'}` $dbinfo{$tables[$x]}[$i]->{'type'} default $default $dbinfo{$tables[$x]}[$i]->{'extra'} AFTER `$dbinfo{$tables[$x]}[$z]->{'field'}`);
			$db->query($statement);
			goto Loop1;
			}
		if(($tablefields[1] ne $dbinfo{$tables[$x]}[$i]->{'type'})||($tablefields[2+$col] ne $dbinfo{$tables[$x]}[$i]->{'null'})||($tablefields[4+$col] ne $dbinfo{$tables[$x]}[$i]->{'default'})||($tablefields[5+$col] ne $dbinfo{$tables[$x]}[$i]->{'extra'}))
			{
			my($default);
			if($dbinfo{$tables[$x]}[$i]->{'default'} eq ""){$default="NULL";}
			else{$default="'$dbinfo{$tables[$x]}[$i]->{'default'}'";}
			if(($dbinfo{$tables[$x]}[$i]->{'null'} !~ /^Yes$/i)&&($dbinfo{$tables[$x]}[$i]->{'default'} eq "")){$default="''";}
			$statement=qq(ALTER TABLE `$tables[$x]` CHANGE `$dbinfo{$tables[$x]}[$i]->{'field'}` `$dbinfo{$tables[$x]}[$i]->{'field'}` $dbinfo{$tables[$x]}[$i]->{'type'});
			if($dbinfo{$tables[$x]}[$i]->{'null'} !~ /^Yes$/i){$statement.=qq( not null);}
			$statement.=qq( default $default $dbinfo{$tables[$x]}[$i]->{'extra'});
			$db->query($statement);
			goto Loop1;
			}
		if(($tablefields[3+$col] ne $dbinfo{$tables[$x]}[$i]->{'key'})&&($dbinfo{$tables[$x]}[$i]->{'key'} eq "PRI"))
			{
			$statement=qq(ALTER TABLE `$tables[$x]` DROP PRIMARY KEY);
			$db->query($statement);
			$statement=qq(ALTER TABLE `$tables[$x]` ADD PRIMARY KEY(`$dbinfo{$tables[$x]}[$i]->{'field'}`));
			$db->query($statement);
			goto Loop1;
			}
		if($tablefields[3+$col] ne $dbinfo{$tables[$x]}[$i]->{'key'})
			{
			if($dbinfo{$tables[$x]}[$i]->{'key'} ne "MUL")
				{
				$statement=qq(ALTER TABLE `$tables[$x]` DROP INDEX `$dbinfo{$tables[$x]}[$i]->{'field'}`);
				}
			if($dbinfo{$tables[$x]}[$i]->{'key'} eq "MUL")
				{
				$statement=qq(ALTER TABLE `$tables[$x]` ADD INDEX(`$dbinfo{$tables[$x]}[$i]->{'field'}`));
				}
			$db->query($statement);
			goto Loop1;
			}
		$i++;
		}
	if($i <= (@$table-1))
		{
		for($z=$i;$z<=(@$table-1);$z++)
			{
			if($dbinfo{$tables[$x]}[$z]->{'default'} eq ""){$default="NULL";}
			else{$default="'$dbinfo{$tables[$x]}[$z]->{'default'}'";}
			if(($dbinfo{$tables[$x]}[$z]->{'null'} !~ /^Yes$/i)&&($dbinfo{$tables[$x]}[$z]->{'default'} eq "")){$default="''";}
			$statement=qq(ALTER TABLE `$tables[$x]` ADD `$dbinfo{$tables[$x]}[$z]->{'field'}` $dbinfo{$tables[$x]}[$z]->{'type'});
			if($dbinfo{$tables[$x]}[$z]->{'null'} !~ /^Yes$/i){$statement.=qq( not null);}
			$statement.=qq( default $default $dbinfo{$tables[$x]}[$z]->{'extra'});
			$db->query($statement);
			}
		goto Loop1;
		}
	}
$statement=qq(INSERT INTO addon (name) VALUES ('forward'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO addon (name) VALUES ('storage'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO addon (name) VALUES ('transfer'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO addon (name) VALUES ('pop'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO addon (name) VALUES ('popspace'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO addon (name) VALUES ('responder'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO addon (name) VALUES ('mysql'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO addon (name) VALUES ('subs'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO addon (name) VALUES ('pointer'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO addon (name) VALUES ('dedicated'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO `packages` (name,storage,transfer,pop,popspace,responder,mysql,subs,price,setup,annual)
VALUES ('Forward','1','0','0','0','0','0','0','0','0','0'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO `template` VALUES (1, 'hosting', 'CentOS', NULL, NULL, NULL, 'yes', 'both', 'local', 'yes',
 'yes', 'yes', 'yes', 'no', 'yes', 'no', 'no', 'yes', NULL, NULL, NULL, NULL, '/etc/httpd/conf/httpd.conf', '/etc/httpd/conf/virtuals',
 '/home', '/var/log/httpd', 'service apache graceful', 'service apache start', 'service apache stop', '/var/run/httpd.pid',
 '/home/email', '/etc/mail/local-host-names', '/etc/mail/virtusertable', 'service sendmail restart', 'service sendmail start',
 'service sendmail stop', '/var/run/sendmail.pid', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '/sbin', 'yes', NULL,
 '/var/log/xferlog', 'service proftpd restart', 'service proftpd start', 'service proftpd stop', '/var/run/proftpd.pid', '2x',
 'yes', 'sendmail','','','','','','','/etc/mail/access','no','22','service sshd start','service sshd stop','service sshd restart','/var/run/sshd.pid'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Administration database created</td></tr>
</table>);
&Bottom;
}

##

sub Setup_Database_Form
{
&Check_Password;
if($Cookies{'level'} ne "1"){&Error('This function requires top level administrative access');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Create Database</td></tr>
<tr><td class="prgout" align=left>Database Hostname</td>
<td class="prgout" align=left><input name="dbhost" type="text" value="localhost" size=20,1></td></tr>
<tr><td class="prgout" align=left>Database Root Username</td>
<td class="prgout" align=left><input name="dbruser" type="text" value="$system{'mysqlroot'}" size=20,1></td></tr>
<tr><td class="prgout" align=left>Database Root Password</td>
<td class="prgout" align=left><input name="dbrpass" type="text" value="$system{'mysqlpass'}" size=20,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Create Database"></td></tr>
</table>
<input name="do" type="hidden" value="Create Database">
</form>\n);
&Bottom;
}

##

sub Save_Variables
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SC4'} ne "yes")){&Error('Insufficient access for this function');}
my(@saltchars)=('a'..'z','A'..'Z','0'..'9','.','/');
if(!$system{'enckey'})
	{
	srand($$|time);
	for(1..20)
		{
		$system{'enckey'}.=$saltchars[int(rand($#saltchars+1))];
		}
	}
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($dbpass)=&encode_base64($cipher->encrypt($FORM{'dbpass'}));
chomp($dbpass);
my($mysqlpass)=&encode_base64($cipher->encrypt($FORM{'mysqlpass'}));
chomp($mysqlpass);
my($srsmanpass)=&encode_base64($cipher->encrypt($FORM{'srsmanpass'}));
chomp($srsmanpass);
open(FILE,">program.cfg");
if($FORM{'hostname'}){print FILE qq(hostname||$FORM{'hostname'}\n);}
if($FORM{'cgipath'}){print FILE qq(cgipath||$FORM{'cgipath'}\n);}
if($FORM{'imageurl'}){print FILE qq(imageurl||$FORM{'imageurl'}\n);}
if($FORM{'idletime'}){print FILE qq(idletime||$FORM{'idletime'}\n);}
print FILE qq(useframes||$FORM{'useframes'}\n);
if($FORM{'adminemail'}){print FILE qq(adminemail||$FORM{'adminemail'}\n);}
if($FORM{'logattempt'}){print FILE qq(logattempt||$FORM{'logattempt'}\n);}
if($FORM{'logtime'}){print FILE qq(logtime||$FORM{'logtime'}\n);}
if($FORM{'clienturl'}){print FILE qq(clienturl||$FORM{'clienturl'}\n);}
if($FORM{'dbhost'}){print FILE qq(dbhost||$FORM{'dbhost'}\n);}
if($FORM{'dbname'}){print FILE qq(dbname||$FORM{'dbname'}\n);}
if($FORM{'dbuser'}){print FILE qq(dbuser||$FORM{'dbuser'}\n);}
if($FORM{'dbpass'}){print FILE qq(dbpass||$dbpass\n);}
if($FORM{'mysqlroot'}){print FILE qq(mysqlroot||$FORM{'mysqlroot'}\n);}
if($FORM{'mysqlpass'}){print FILE qq(mysqlpass||$mysqlpass\n);}
print FILE qq(resourcemethod||$FORM{'resourcemethod'}
usens1||$FORM{'usens1'}
usens2||$FORM{'usens2'}
useauthnet||$FORM{'useauthnet'}
usesignup||$FORM{'usesignup'}
allowforward||$FORM{'allowforward'}
reviewsignup||$FORM{'reviewsignup'}\n);
if($FORM{'ns1'}){print FILE qq(ns1||$FORM{'ns1'}\n);}
if($FORM{'ns2'}){print FILE qq(ns2||$FORM{'ns2'}\n);}
if($FORM{'setperiod'}){print FILE qq(setperiod||$FORM{'setperiod'}\n);}
if(length($FORM{'latefee'}) > 0){print FILE qq(latefee||$FORM{'latefee'}\n);}
if($FORM{'useauthnet'} eq "yes")
	{
	print FILE qq(authnetver||$FORM{'authnetver'}
emailcust||$FORM{'emailcust'}
mastercard||$FORM{'mastercard'}
visa||$FORM{'visa'}
discover||$FORM{'discover'}
americanexpress||$FORM{'americanexpress'}\n);
	}
print FILE qq(autobill||$FORM{'autobill'}\n);
if($FORM{'authnetlogin'}){print FILE qq(authnetlogin||$FORM{'authnetlogin'}\n);}
if($FORM{'authnetkey'}){print FILE qq(authnetkey||$FORM{'authnetkey'}\n);}
print FILE qq(usesrs||$FORM{'usesrs'}\n);
if($FORM{'srsuser'}){print FILE qq(srsuser||$FORM{'srsuser'}\n);}
if($FORM{'srskey'}){print FILE qq(srskey||$FORM{'srskey'}\n);}
if($FORM{'srsemail'}){print FILE qq(srsemail||$FORM{'srsemail'}\n);}
if($FORM{'srsrenew'}){print FILE qq(srsrenew||$FORM{'srsrenew'}\n);}
if($FORM{'srsmanuser'}){print FILE qq(srsmanuser||$FORM{'srsmanuser'}\n);}
if($FORM{'srsmanpass'}){print FILE qq(srsmanpass||$srsmanpass\n);}
if($FORM{'srshost'}){print FILE qq(srshost||$FORM{'srshost'}\n);}
if($FORM{'srsprocess'}){print FILE qq(srsprocess||$FORM{'srsprocess'}\n);}
if($FORM{'regfee'}){print FILE qq(regfee||$FORM{'regfee'}\n);}
if($FORM{'regdiscount'}){print FILE qq(regdiscount||$FORM{'regdiscount'}\n);}
if($FORM{'supdoms'}){print FILE qq(supdoms||$FORM{'supdoms'}\n);}
if($FORM{'contact_firstname'}){print FILE qq(contact_firstname||$FORM{'contact_firstname'}\n);}
if($FORM{'contact_lastname'}){print FILE qq(contact_lastname||$FORM{'contact_lastname'}\n);}
if($FORM{'contact_organization'}){print FILE qq(contact_organization||$FORM{'contact_organization'}\n);}
if($FORM{'contact_address1'}){print FILE qq(contact_address1||$FORM{'contact_address1'}\n);}
if($FORM{'contact_address2'}){print FILE qq(contact_address2||$FORM{'contact_address2'}\n);}
if($FORM{'contact_address3'}){print FILE qq(contact_address3||$FORM{'contact_address3'}\n);}
if($FORM{'contact_city'}){print FILE qq(contact_city||$FORM{'contact_city'}\n);}
if($FORM{'contact_state'}){print FILE qq(contact_state||$FORM{'contact_state'}\n);}
if($FORM{'contact_zip'}){print FILE qq(contact_zip||$FORM{'contact_zip'}\n);}
if($FORM{'contact_country'}){print FILE qq(contact_country||$FORM{'contact_country'}\n);}
if($FORM{'contact_phone'}){print FILE qq(contact_phone||$FORM{'contact_phone'}\n);}
if($FORM{'contact_fax'}){print FILE qq(contact_fax||$FORM{'contact_fax'}\n);}
if($FORM{'contact_email'}){print FILE qq(contact_email||$FORM{'contact_email'}\n);}
print FILE qq(usemm||$FORM{'usemm'}\n);
if($FORM{'mmkey'}){print FILE qq(mmkey||$FORM{'mmkey'}\n);}
if($FORM{'mmcountry'}){print FILE qq(mmcountry||$FORM{'mmcountry'}\n);}
if($FORM{'mmphone'}){print FILE qq(mmphone||$FORM{'mmphone'}\n);}
if($FORM{'mmfreemail'}){print FILE qq(mmfreemail||$FORM{'mmfreemail'}\n);}
if($FORM{'mmcarderemail'}){print FILE qq(mmcarderemail||$FORM{'mmcarderemail'}\n);}
if($FORM{'mmhighriskcountry'}){print FILE qq(mmhighriskcountry||$FORM{'mmhighriskcountry'}\n);}
print FILE qq(enckey||$system{'enckey'}\n);
close(FILE);
chmod(0600,"program.cfg");
&Parse_Variables;
my($db,$statement,$query_output,$error,$usedb);
if($db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'})){$usedb="yes";}
if(($system{'dbuser'} eq "")||($system{'dbpass'} eq "")||($system{'dbhost'} eq "")||($system{'dbname'} eq "")){$usedb="no";}
if($usedb eq "yes")
	{
	$statement=qq(SELECT id FROM server WHERE type='client');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($id);
	while(($id)=$query_output->fetchrow)
		{
		if(($access{'MCI4'} eq "yes")||($Cookies{'level'} eq "1"))
			{
			require "mods/client.pl";&Config_Client($id);
			}
		}
	$statement=qq(SELECT id FROM server WHERE type='signup');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($id);
	while(($id)=$query_output->fetchrow)
		{
		if(($access{'MSS4'} eq "yes")||($Cookies{'level'} eq "1"))
			{
			require "mods/signup.pl";&Config_Signup($id);
			}
		}
	}
&Top;
print qq(<script language="javascript">
<!--
if(parent){parent.location.href='$script';}
else{self.location.href='$script';}
// -->
</script>\n);
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>System variables updated</td></tr>
</table>);
&Bottom;
}

##

sub Variables
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SC4'} ne "yes")){&Error('Insufficient access for this function');}
if(!$system{'cgipath'})
	{
	use File::Basename;
	$system{'cgipath'}=dirname($ENV{'SCRIPT_FILENAME'});
	}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
function ChkInfo() {
if(document.forms[0].useauthnet.selectedIndex == 0)
	{
	document.forms[0].authnetver.disabled=false;
	document.forms[0].emailcust.disabled=false;
	document.forms[0].authnetlogin.disabled=false;
	document.forms[0].mastercard.disabled=false;
	document.forms[0].visa.disabled=false;
	document.forms[0].discover.disabled=false;
	document.forms[0].americanexpress.disabled=false;
	ShowIt('el1');
	}
else
	{
	document.forms[0].authnetver.disabled=true;
	document.forms[0].emailcust.disabled=true;
	document.forms[0].authnetlogin.disabled=true;
	document.forms[0].mastercard.disabled=true;
	document.forms[0].visa.disabled=true;
	document.forms[0].discover.disabled=true;
	document.forms[0].americanexpress.disabled=true;
	document.forms[0].autobill.selectedIndex=0;
	HideIt('el1');
	}
if(document.forms[0].usesrs.selectedIndex == 0)
	{
	document.forms[0].srsuser.disabled=false;
	document.forms[0].srskey.disabled=false;
	document.forms[0].srsemail.disabled=false;
	document.forms[0].srsrenew.disabled=false;
	document.forms[0].srsmanuser.disabled=false;
	document.forms[0].srsmanpass.disabled=false;
	document.forms[0].srshost.disabled=false;
	document.forms[0].srsprocess.disabled=false;
	document.forms[0].contact_firstname.disabled=false;
	document.forms[0].contact_lastname.disabled=false;
	document.forms[0].contact_organization.disabled=false;
	document.forms[0].contact_address1.disabled=false;
	document.forms[0].contact_address2.disabled=false;
	document.forms[0].contact_address3.disabled=false;
	document.forms[0].contact_city.disabled=false;
	document.forms[0].contact_state.disabled=false;
	document.forms[0].contact_zip.disabled=false;
	document.forms[0].contact_country.disabled=false;
	document.forms[0].contact_phone.disabled=false;
	document.forms[0].contact_fax.disabled=false;
	document.forms[0].contact_email.disabled=false;
	ShowIt('el2');
	}
else
	{
	document.forms[0].srsuser.disabled=true;
	document.forms[0].srskey.disabled=true;
	document.forms[0].srsemail.disabled=true;
	document.forms[0].srsrenew.disabled=true;
	document.forms[0].srsmanuser.disabled=true;
	document.forms[0].srsmanpass.disabled=true;
	document.forms[0].srshost.disabled=true;
	document.forms[0].srsprocess.disabled=true;
	document.forms[0].contact_firstname.disabled=true;
	document.forms[0].contact_lastname.disabled=true;
	document.forms[0].contact_organization.disabled=true;
	document.forms[0].contact_address1.disabled=true;
	document.forms[0].contact_address2.disabled=true;
	document.forms[0].contact_address3.disabled=true;
	document.forms[0].contact_city.disabled=true;
	document.forms[0].contact_state.disabled=true;
	document.forms[0].contact_zip.disabled=true;
	document.forms[0].contact_country.disabled=true;
	document.forms[0].contact_phone.disabled=true;
	document.forms[0].contact_fax.disabled=true;
	document.forms[0].contact_email.disabled=true;
	HideIt('el2');
	}
if(document.forms[0].usesignup.selectedIndex == 0)
	{
	document.forms[0].allowforward.disabled=false;
	document.forms[0].reviewsignup.disabled=false;
	}
else
	{
	document.forms[0].allowforward.selectedIndex=1;
	document.forms[0].allowforward.disabled=true;
	document.forms[0].reviewsignup.selectedIndex=0;
	document.forms[0].reviewsignup.disabled=true;
	}
if(document.forms[0].usemm.selectedIndex == 0)
	{
	document.forms[0].mmkey.disabled=true;
	document.forms[0].mmcountry.disabled=true;
	document.forms[0].mmphone.disabled=true;
	document.forms[0].mmfreemail.disabled=true;
	document.forms[0].mmcarderemail.disabled=true;
	document.forms[0].mmhighriskcountry.disabled=true;
	HideIt('el3');
	}
else
	{
	document.forms[0].mmkey.disabled=false;
	document.forms[0].mmcountry.disabled=false;
	document.forms[0].mmphone.disabled=false;
	document.forms[0].mmfreemail.disabled=false;
	document.forms[0].mmcarderemail.disabled=false;
	document.forms[0].mmhighriskcountry.disabled=false;
	ShowIt('el3');
	}
}
var AgntUsr=navigator.userAgent.toLowerCase();
var bV=parseInt(navigator.appVersion);
NS4=(document.layers) ? true : false;
IE4=((document.all)&&(bV>=4))?true:false;
NS6=(document.getElementById && !document.all) ? true : false;
ver4 = (NS4 || IE4 || NS6) ? true : false;

function ShowIt(){return}
function ShowAll(){return}

isShown = false;

function getIndex(el) {
	ind = null;
	for (i=0; i<document.layers.length; i++) {
		whichEl = document.layers[i];
		if (whichEl.id == el) {
			ind = i;
			break;
		}
	}
	return ind;
}

function initIt(){
	if (NS4) {
		for (i=0; i<document.layers.length; i++) {
			whichEl = document.layers[i];
			if (whichEl.id.indexOf("Child") != -1)
				{
				whichEl.visibility = "hide";
				}
		}
	}
	else if (IE4) {
		tempColl = document.all.tags("DIV");
		for (i=0; i<tempColl.length; i++) {
			if (tempColl(i).className == "child")
				{
				tempColl(i).style.display = "none";
				}
		}
	}
	else if (NS6) {
		tempColl = document.getElementsByTagName("DIV");
		for (i=0;i<tempColl.length;i++) {
			if (tempColl[i].className == "child")
				{
				tempColl[i].style.display = "none";
				}
		}
	}
}

function ShowIt(el) {
	if (!ver4) return;
	if (IE4) {ShowIE(el)}
	else if (NS4) {ShowNS(el)}
	else {ShowDOM(el)}
}

function HideIt(el) {
	if (!ver4) return;
	if (IE4) {HideIE(el)}
	else if (NS4) {HideNS(el)}
	else {HideDOM(el)}
}

function ShowIE(el) { 
	whichEl = eval(el + "Child");
	if (whichEl.style.display == "none") {
		whichEl.style.display = "block";
	}
}

function HideIE(el) {
	whichEl = eval(el + "Child");
	if (whichEl.style.display == "block") {
		whichEl.style.display = "none";
	}
}

function ShowDOM(el) {
//DOM support for NS6
	whichEl=document.getElementById(el + "Child");
	if(whichEl.style.display == "none") {
		whichEl.style.display="block";
		}
	}

function HideDOM(el) {
	whichEl=document.getElementById(el + "Child");
	if(whichEl.style.display == "block") {
		whichEl.style.display = "none";
		}
	}

function ShowNS(el) {
	whichEl = eval("document." + el + "Child");
	if (whichEl.visibility == "hide") {
		whichEl.visibility = "show";
		}
	}

function HideNS(el) {
	whichEl = eval("document." + el + "Child");
	if (whichEl.visibility == "show") {
		whichEl.visibility = "hide";
		}
	}
//-->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure System Variables</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=hostname')" class="prgout">Admin Server Hostname</a></td>
<td class="prgout" align=left><input name="hostname" type="text" value="$system{'hostname'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=cgipath');" class="prgout">Admin Program Path</a></td>
<td class="prgout" align=left><input name="cgipath" type="text" value="$system{'cgipath'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=imageurl');" class="prgout">Image URL</a></td>
<td class="prgout" align=left><input name="imageurl" type="text" value="$system{'imageurl'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=idletime');" class="prgout">Idle Timeout</a></td>
<td class="prgout" align=left><input name="idletime" type="text" value="$system{'idletime'}" size=5,1 maxlength=5> Min</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=useframes');" class="prgout">Use Frames?</a></td>
<td class="prgout" align=left><select name="useframes" size=1><option value="no">No<option value="yes");
if($system{'useframes'} eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=adminemail');" class="prgout">Administrators Email</a></td>
<td class="prgout" align=left><input name="adminemail" type="text" value="$system{'adminemail'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=logattempt');" class="prgout">Login Lockout After </a></td>
<td class="prgout" align=left><input name="logattempt" type="text" value="$system{'logattempt'}" size=5,1> Attempts</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=logtime');" class="prgout">Login Lockout Timer</a></td>
<td class="prgout" align=left><input name="logtime" type="text" value="$system{'logtime'}" size=5,1> Minutes</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=clienturl');" class="prgout">Client URL</a></td>
<td class="prgout" align=left><input name="clienturl" type="text" value="$system{'clienturl'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dbhost');" class="prgout">Database Hostname</a></td>
<td class="prgout" align=left><input name="dbhost" type="text" value="$system{'dbhost'}" size=20,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dbname'):" class="prgout">Database Name</a></td>
<td class="prgout" align=left><input name="dbname" type="text" value="$system{'dbname'}" size=20,1 maxlength=64></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dbuser');" class="prgout">Database Username</a></td>
<td class="prgout" align=left><input name="dbuser" type="text" value="$system{'dbuser'}" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=dbpass');" class="prgout">Database Password</a></td>
<td class="prgout" align=left><input name="dbpass" type="text" value="$system{'dbpass'}" size=20,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqlroot')" class="prgout">MySQL Root Username</a></td>
<td class="prgout" align=left><input name="mysqlroot" type="text" value="$system{'mysqlroot'}" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqlpass')" class="prgout">MySQL Root Password</a></td>
<td class="prgout" align=left><input name="mysqlpass" type="text" value="$system{'mysqlpass'}" size=20,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=resourcemethod')" class="prgout">Resource Allocation Method</a></td>
<td class="prgout" align=left><select name="resourcemethod" size=1><option value="stack">Stack Method<option value="float");
if($system{'resourcemethod'} eq "float"){print qq( selected);}
print qq(>Float Method</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usens1');" class="prgout">Use Primary Nameserver?</a></td>
<td class="prgout" align=left><select name="usens1" size=1 onChange="return CheckVals();"><option value="yes">Yes<option value="no");
if($system{'usens1'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ns1');" class="prgout">Primary Name Server Name</a></td>
<td class="prgout" align=left><input name="ns1" type="text" value="$system{'ns1'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usens2');" class="prgout">Use Secondary Name Server?</a></td>
<td class="prgout" align=left><select name="usens2" size=1 onChange="return CheckVals();"><option value="yes">Yes<option value="no");
if($system{'usens2'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ns2');" class="prgout">Secondary Name Server Name</a></td>
<td class="prgout" align=left><input name="ns2" type="text" value="$system{'ns2'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=setperiod');" class="prgout">Payment Settlement Period</a></td>
<td class="prgout" align=left><input name="setperiod" type="text" value="$system{'setperiod'}" size=5,1> Days</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=latefee');" class="prgout">Late Fee</a></td>
<td class="prgout" align=left>\$<input name="latefee" type="text" value="$system{'latefee'}" size=5,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesignup');" class="prgout">Use Online Signup?</a></td>
<td class="prgout" align=left><select name="usesignup" size=1 onChange="return ChkInfo();"><option value="yes">Yes<option value="no");
if($system{'usesignup'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=allowforward');" class="prgout">Allow online signup for Forwards?</a></td>
<td class="prgout" align=left><select name="allowforward" size=1><option value="yes">Yes<option value="no");
if($system{'allowforward'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=reviewsignup');" class="prgout">What Signups require review?</a></td>
<td class="prgout" align=left><select name="reviewsignup" size=1><option value="all">All<option value="flagged");
if($system{'reviewsignup'} eq "flagged"){print qq( selected);}
print qq(>Flagged</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=useauthnet');" class="prgout">Use Authorize.net Gateway?</a></td>
<td class="prgout" align=left><select name="useauthnet" size=1 onChange="return ChkInfo();"><option value="yes">Yes<option value="no");
if($system{'useauthnet'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesrs');" class="prgout">Use OpenSRS</a></td>
<td class="prgout" align=left><select name="usesrs" size=1 onChange="return ChkInfo();"><option value="yes">Yes<option value="no");
if($system{'usesrs'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usemm');" class="prgout">Use MaxMind Credit Card Screening?</a></td>
<td class="prgout" align=left><select name="usemm" size=1 onChange="return ChkInfo();"><option value="no">No<option value="yes");
if($system{'usemm'} eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td align=center colspan=2>
<div id="el1Child" class="child">
<table align=center border=0 cellpadding=2 cellspacing=2 width="100%">
<tr><td class="headb" align=center colspan=2>Authorize.net Gateway Settings</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=authnetver');" class="prgout">Authorize.net version</a></td>
<td class="prgout" align=left><select name="authnetver" size=1><option value="3.1">3.1</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=emailcust');" class="prgout">Authorize.net email customer?</a></td>
<td class="prgout" align=left><select name="emailcust" size=1><option value="yes">Yes<option value="no");
if($system{'emailcust'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=authnetlogin');" class="prgout">Authorize.net Login Name</a></td>
<td class="prgout" align=left><input name="authnetlogin" type="text" value="$system{'authnetlogin'}" size=20,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=authnetkey');" class="prgout">Authorize.net Transaction Key</a></td>
<td class="prgout" align=left><input name="authnetkey" type="password" value="$system{'authnetkey'}" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left>Accepted Credit Cards</td>
<td class="prgout" align=left><input name="mastercard" type="checkbox" value="yes");
if($system{'mastercard'} eq "yes"){print qq( checked);}
print qq(>MasterCard <input name="visa" type="checkbox" value="yes");
if($system{'visa'} eq "yes"){print qq( checked);}
print qq(>Visa <input name="discover" type="checkbox" value="yes");
if($system{'discover'} eq "yes"){print qq( checked);}
print qq(>Discover <input name="americanexpress" type="checkbox" value="yes");
if($system{'americanexpress'} eq "yes"){print qq( checked);}
print qq(>American Express</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autobill');" class="prgout">Support Automatic Billing?</a></td>
<td class="prgout" align=left><select name="autobill" size=1 onChange="return ChkInfo();"><option value="no">No<option value="yes");
if($system{'autobill'} eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
</table>
</div>
<div id="el2Child" class="child">
<table align=center border=0 cellpadding=2 cellspacing=2 width="100%">
<tr><td class="headb" align=center colspan=2>OpenSRS Registrar Variables</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=srsuser');" class="prgout">OpenSRS User</a></td>
<td class="prgout" align=left><input name="srsuser" type="text" value="$system{'srsuser'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=srskey');" class="prgout">OpenSRS Key</a></td>
<td class="prgout" align=left><input name="srskey" type="password" value="$system{'srskey'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=srsemail');" class="prgout">OpenSRS Admin Email</a></td>
<td class="prgout" align=left><input name="srsemail" type="text" value="$system{'srsemail'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=srsrenew');" class="prgout">OpenSRS Renewal Notification Email</a></td>
<td class="prgout" align=left><input name="srsrenew" type="text" value="$system{'srsrenew'}" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=srsmanuser');" class="prgout">OpenSRS Manager Username</a></td>
<td class="prgout" align=left><input name="srsmanuser" type="text" value="$system{'srsmanuser'}" size=20,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=srsmanpass');" class="prgout">OpenSRS Manager Password</td>
<td class="prgout" align=left><input name="srsmanpass" type="text" value="$system{'srsmanpass'}" size=20,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=srshost');" class="prgout">OpenSRS Host Server</a></td>
<td class="prgout" align=left><select name="srshost" size=1><option value="horizon.opensrs.net">horizone.opensrs.net (Test)<option value="rr-n1-tor.opensrs.net");
if($system{'srshost'} eq "rr-n1-tor.opensrs.net"){print qq( selected);}
print qq(>rr-n1-tor.opensrs.net (Live)</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=srsprocess');" class="prgout">Registration Handle</a></td>
<td class="prgout" align=left><select name="srsprocess" size=1><option value="save">Save<option value="process");
if($system{'srsprocess'} eq "process"){print qq( selected);}
print qq(>Process</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=regfee');" class="prgout">Domain Registration Fee</a></td>
<td class="prgout" align=left>\$<input name="regfee" type="text" value="$system{'regfee'}" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=regdiscount');" class="prgout">Registration Discount</a></td>
<td class="prgout" align=left><input name="regdiscount" type="text" value="$system{'regdiscount'}" size=3,1 maxlength=3>\%</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=supdoms');" class="prgout">Supported Top Level Domains</a></td>
<td class="prgout" align=left><input name="supdoms" type="text" value="$system{'supdoms'}" size=20,1></td></tr>
<tr><td class="headb" align=center colspan=2>OpenSRS Technical Contact Information</td></tr>
<tr><td class="prgout" align=left>First Name</td>
<td class="prgout" align=left><input name="contact_firstname" type="text" value="$system{'contact_firstname'}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Last Name</td>
<td class="prgout" align=left><input name="contact_lastname" type="text" value="$system{'contact_lastname'}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Organization</td>
<td class="prgout" align=left><input name="contact_organization" type="text" value="$system{'contact_organization'}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Address Line 1</td>
<td class="prgout" align=left><input name="contact_address1" type="text" value="$system{'contact_address1'}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Address Line 2</td>
<td class="prgout" align=left><input name="contact_address2" type="text" value="$system{'contact_address2'}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Address Line 3</td>
<td class="prgout" align=left><input name="contact_address3" type="text" value="$system{'contact_address3'}" size=30,1></td></tr>
<tr><td class="prgout" align=left>City</td>
<td class="prgout" align=left><input name="contact_city" type="text" value="$system{'contact_city'}" size=30,1></td></tr>
<tr><td class="prgout" align=left>State</td>
<td class="prgout" align=left><input name="contact_state" type="text" value="$system{'contact_state'}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Zip/Postal Code</td>
<td class="prgout" align=left><input name="contact_zip" type="text" value="$system{'contact_zip'}" size=15,1></td></tr>
<tr><td class="prgout" align=left>Country</td>
<td class="prgout" align=left><select name="contact_country" size=1>);
open(FILE,"countries.dat");
while(<FILE>)
	{
	my(@info)=split(/:/,$_);
	print qq(<option value="$info[0]");
	if($info[0] eq "$system{'contact_country'}"){print qq( selected);}
	print qq(>$info[1]);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left>Phone</td>
<td class="prgout" align=left><input name="contact_phone" type="text" value="$system{'contact_phone'}" size=15,1><br>
<font size=-2>+1.1234567890</font></td></tr>
<tr><td class="prgout" align=left>Fax</td>
<td class="prgout" align=left><input name="contact_fax" type="text" value="$system{'contact_fax'}" size=15,1><br>
<font size=-2>+1.1234567890</font></td></tr>
<tr><td class="prgout" align=left>Email</td>
<td class="prgout" align=left><input name="contact_email" type="text" value="$system{'contact_email'}" size=30,1></td></tr>
</table>
</div>
<div id="el3Child" class="child">
<table align=center border=0 cellpadding=2 cellspacing=2 width=100%>
<tr><td class="headb" align=center colspan=2>MaxMind Credit Card Screening Settings</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mmkey');" class="prgout">MaxMind License Key</a></td>
<td class="prgout" align=left><input name="mmkey" type="text" value="$system{'mmkey'}" size=20,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mmcountry');" class="prgout">Country Match</a></td>
<td class="prgout" align=left><select name="mmcountry" size=1><option value="yes">Yes<option value="no");
if($system{'mmcountry'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mmphone');" class="prgout">Phone Match</a></td>
<td class="prgout" align=left><select name="mmphone" size=1><option value="yes">Yes<option value="no");
if($system{'mmphone'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mmfreemail');" class="prgout">Free Mail Check</a></td>
<td class="prgout" align=left><select name="mmfreemail" size=1><option value="yes">Yes<option value="no");
if($system{'mmfreemail'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mmcarderemail');" class="prgout">Carder Email Check</a></td>
<td class="prgout" align=left><select name="mmcarderemail" size=1><option value="yes">Yes<option value="no");
if($system{'mmcarderemail'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mmhighriskcountry');" class="prgout">High Risk Country Check</a></td>
<td class="prgout" align=left><select name="mmhighriskcountry" size=1><option value="yes">Yes<option value="no");
if($system{'mmhighriskcountry'} eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
</table>
</div>
</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Variables"></td></tr>
</table>
<input name="do" type="hidden" value="Save Variables">
</form>
<script language="javascript">
<!--
initIt();
ChkInfo();
//-->
</script>\n);
&Bottom;
}

##

sub Update_DB
{
&Check_Password;
if(($Cookies{'level'} ne "1")&($access{'SC6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
require "fields.pl";
my(@tablefields);
my($col)=0;
$statement=qq(SHOW VARIABLES LIKE 'version');
$query_output=$db->query($statement);
my($null,$vers)=$query_output->fetchrow;
if(substr($vers,0,3) eq "4.1"){$col=1;}
my(@exttables)=$db->listtables;
foreach(@exttables){$_=~s/\`//g;}
for($x=0;$x<=$#tables;$x++)
	{
	$exist=0;
	foreach(@tables)
		{
		if($exttables[$z] eq $_){$exist=1;}
		}
	if((!$exist)&&($exttables[$x]))
		{
		$statement=qq(DROP TABLE `$exttables[$x]`);
		$db->query($statement);
		}
	}
my(@exttables)=$db->listtables;
foreach(@exttables){$_=~s/\`//g;}
$y=0;
for($x=0;$x<=$#tables;$x++)
	{
	if($exttables[$y] ne $tables[$x])
		{
		if($dbinfo{$table}[$x]->{'default'} eq ""){$default="NULL";}
		else{$default="'$dbinfo{$tables[$x]}[0]->{'default'}'";}
		if(($dbinfo{$table}[$x]->{'null'} !~ /^Yes$/i)&&($dbinfo{$table}[$x]->{'default'} eq "")){$default="''";}
		$statement=qq(CREATE TABLE `$tables[$x]` \(`$dbinfo{$tables[$x]}[0]->{'field'}` $dbinfo{$tables[$x]}[0]->{'type'});
		if($dbinfo{$table}[$x]->{'null'} !~ /^Yes$/i){$statement.=qq( not null);}
		if($dbinfo{$tables[$x]}[0]->{'extra'} ne "auto_increment"){$statement.=qq( default $default);}
		$statement.=qq( $dbinfo{$tables[$x]}[0]->{'extra'});
		if($dbinfo{$tables[$x]}[0]->{'key'} eq "PRI"){$statement.=qq(, PRIMARY KEY (`$dbinfo{$tables[$x]}[0]->{'field'}`));}
		if($dbinfo{$tables[$x]}[0]->{'key'} eq "MUL"){$statement.=qq(, INDEX (`$dbinfo{$tables[$x]}[0]->{'field'}`));}
		$statement.=qq(\));
		$db->query($statement);
		}
	else{$y++;}
	}
my(@exttables)=$db->listtables;
foreach(@exttables){$_=~s/\`//g;}
for($x=0;$x<=$#exttables;$x++)
	{
	$table=$exttables[$x];
	$statement=qq(SHOW FULL FIELDS FROM `$tables[$x]`);
	$query_output=$db->query($statement);
	while((@tablefields)=$query_output->fetchrow_array)
		{
	$exist=0;
		for($i=0;$i<=(@$table-1);$i++)
			{
			if($tablefields[0] eq $dbinfo{$exttables[$x]}[$i]->{'field'}){$exist=1;}
			}
		if(!$exist)
			{
			$statement=qq(ALTER TABLE `$exttables[$x]` DROP `$tablefields[0]`);
			$db->query($statement); 
			}
		}
	}
for($x=0;$x<=$#tables;$x++)
	{
	$table=$tables[$x];
	Loop1:
	$statement=qq(SHOW FULL FIELDS FROM `$tables[$x]`);
	$query_output=$db->query($statement);
	$test=($query_output->execute)+0;
	$i=0;
	while((@tablefields)=$query_output->fetchrow_array)
		{
		$z=$i-1;
		if($tablefields[0] ne $dbinfo{$tables[$x]}[$i]->{'field'})
			{
			my($default);
			if($dbinfo{$tables[$x]}[$i]->{'default'} eq ""){$default="NULL";}
			else{$default="'$dbinfo{$tables[$x]}[$i]->{'default'}'";}
			if(($dbinfo{$tables[$x]}[$i]->{'null'} !~ /^Yes$/i)&&($dbinfo{$tables[$x]}[$i]->{'default'} eq "")){$default="''";}
			$statement=qq(ALTER TABLE `$tables[$x]` ADD `$dbinfo{$tables[$x]}[$i]->{'field'}` $dbinfo{$tables[$x]}[$i]->{'type'} default $default $dbinfo{$tables[$x]}[$i]->{'extra'} AFTER `$dbinfo{$tables[$x]}[$z]->{'field'}`);
			$db->query($statement);
			goto Loop1;
			}
		if(($tablefields[1] ne $dbinfo{$tables[$x]}[$i]->{'type'})||($tablefields[2+$col] ne $dbinfo{$tables[$x]}[$i]->{'null'})||($tablefields[4+$col] ne $dbinfo{$tables[$x]}[$i]->{'default'})||($tablefields[5+$col] ne $dbinfo{$tables[$x]}[$i]->{'extra'}))
			{
			my($default);
			if($dbinfo{$tables[$x]}[$i]->{'default'} eq ""){$default="NULL";}
			else{$default="'$dbinfo{$tables[$x]}[$i]->{'default'}'";}
			if(($dbinfo{$tables[$x]}[$i]->{'null'} !~ /^Yes$/i)&&($dbinfo{$tables[$x]}[$i]->{'default'} eq "")){$default="''";}
			$statement=qq(ALTER TABLE `$tables[$x]` CHANGE `$dbinfo{$tables[$x]}[$i]->{'field'}` `$dbinfo{$tables[$x]}[$i]->{'field'}` $dbinfo{$tables[$x]}[$i]->{'type'});
			if($dbinfo{$tables[$x]}[$i]->{'null'} !~ /^Yes$/i){$statement.=qq( not null);}
			$statement.=qq( default $default $dbinfo{$tables[$x]}[$i]->{'extra'});
			$db->query($statement);
			goto Loop1;
			}
		if(($tablefields[3+$col] ne $dbinfo{$tables[$x]}[$i]->{'key'})&&($dbinfo{$tables[$x]}[$i]->{'key'} eq "PRI"))
			{
			$statement=qq(ALTER TABLE `$tables[$x]` DROP PRIMARY KEY);
			$db->query($statement);
			$statement=qq(ALTER TABLE `$tables[$x]` ADD PRIMARY KEY(`$dbinfo{$tables[$x]}[$i]->{'field'}`));
			$db->query($statement);
			goto Loop1;
			}
		if($tablefields[3+$col] ne $dbinfo{$tables[$x]}[$i]->{'key'})
			{
			if($dbinfo{$tables[$x]}[$i]->{'key'} ne "MUL")
				{
				$statement=qq(ALTER TABLE `$tables[$x]` DROP INDEX `$dbinfo{$tables[$x]}[$i]->{'field'}`);
				}
			if($dbinfo{$tables[$x]}[$i]->{'key'} eq "MUL")
				{
				$statement=qq(ALTER TABLE `$tables[$x]` ADD INDEX(`$dbinfo{$tables[$x]}[$i]->{'field'}`));
				}
			$db->query($statement);
			goto Loop1;
			}
		$i++;
		}
	if($i <= (@$table-1))
		{
		for($z=$i;$z<=(@$table-1);$z++)
			{
			if($dbinfo{$tables[$x]}[$z]->{'default'} eq ""){$default="NULL";}
			else{$default="'$dbinfo{$tables[$x]}[$z]->{'default'}'";}
			if(($dbinfo{$tables[$x]}[$z]->{'null'} !~ /^Yes$/i)&&($dbinfo{$tables[$x]}[$z]->{'default'} eq "")){$default="''";}
			$statement=qq(ALTER TABLE `$tables[$x]` ADD `$dbinfo{$tables[$x]}[$z]->{'field'}` $dbinfo{$tables[$x]}[$z]->{'type'});
			if($dbinfo{$tables[$x]}[$z]->{'null'} !~ /^Yes$/i){$statement.=qq( not null);}
			$statement.=qq( default $default $dbinfo{$tables[$x]}[$z]->{'extra'});
			$db->query($statement);
			}
		goto Loop1;
		}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Administration database updated</td></tr>
</table>);
&Bottom;
}

1;
