sub Remove_Cron
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=remove+root+cron&cron=$FORM{'cron'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&Root_Cron_Form;}
else{&Error("$remote{'status'}");}
}

##

sub Save_Cron
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
$FORM{$FORM{'cron'}}=&uri_escape($FORM{$FORM{'cron'}});
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=save+root+cron&cron=$FORM{$FORM{'cron'}}&id=$FORM{'cron'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&Root_Cron_Form;}
else{&Error("$remote{'status'}");}
}

##

sub Add_Cron
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
my($newcron)=qq($FORM{'min'} $FORM{'hour'} $FORM{'date'} $FORM{'month'} $FORM{'weekday'} $FORM{'task'});
$newcron=&uri_escape($newcron);
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=add+root+cron&cron=$newcron);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&Root_Cron_Form;}
else{&Error("$remote{'status'}");}
}

##

sub Root_Cron_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+root+cron);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
my($cron,$z);
my(@crons)=split(/\n/,$remote{'cron'});
my($i)=0;
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.AddCron.task.value <= 0)
{
alert("A command to run is required when adding a task to cron. Please enter a command to run");
return false;
}
else
return true;
}
function ConFirm()
{
if(confirm("Do you want to delete this cron job?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=6>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center colspan=6>Manage Root Cronjobs</td></tr>\n);
foreach $cron(@crons)
	{
	chomp($cron);
	$cron=~s/\</&lt;/g;$cron=~s/\>/&gt;/g;$cron=~s/\"/&quot;/g;
	print qq(<form action="$script" method="Post"><tr><td class="prgout" align=left><input name="$i" value="$cron" type="text" size=65,1></td>
<td class="prgout" align=left><input name="do" type="submit" value="Save Cron"> <input name="do" type="submit" value="Remove Cron" onClick="return ConFirm();"></td></tr><input name="cron" type="hidden" value="$i"></form>\n);
	$i++;
	}
print qq(<form action="$script" method="Post" onSubmit="return chkData()" name=AddCron>
<tr><td class="headb" align=center colspan=2>Add Cron Job</td></tr>
<tr><td class="prgout" align=center colspan=2><select name="min" size=1><option value="*">Every);
for($z=0;$z<=59;$z++){print qq(<option value="$z">$z);}
print qq(</select> Minute
<select name="hour" size=1><option value="*">Every);
for($z=0;$z<=23;$z++){print qq(<option value="$z">$z);}
print qq(</select> Hour
<select name="date" size=1><option value="*">Every);
for($z=1;$z<=31;$z++){print qq(<option value="$z">$z);}
print qq(</select> Day of Month
<select name="month" size=1><option value="*">Every);
for($z=1;$z<=12;$z++){print qq(<option value="$z">$z);}
print qq(</select> Month
<select name="weekday" size=1><option value="*">Every<option value="mon">Mon<option value="tue">Tue
<option value="wen">Wen<option value="thu">Thu<option value="fri">Fri<option value="sat">Sat
<option value="sun">Sun</select> Day of Week<br>
<input name="task" type="text" size=40,1> Command to run</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Cron"></td></tr>
</table>
<input name="do" type="hidden" value="Add Cron">
</form>\n);
&Bottom;
}

##

sub Remove_IP_Alias
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=remip&ip=$FORM{'ip'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&IP_Aliases_Form;}
else{&Error("$remote{'status'}");}
}

##

sub IFDOWN
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=ifdown&ip=$FORM{'ip'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&IP_Aliases_Form;}
else{&Error("$remote{'status'}");}
}

##

sub IFUP
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=ifup&ip=$FORM{'ip'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&IP_Aliases_Form;}
else{&Error("$remote{'status'}");}
}

##

sub Add_IP_Alias
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
foreach(keys %FORM){$FORM{$_}=&uri_escape($FORM{$_});}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=add+ip+alias&ip=$FORM{'ip'}&netmask=$FORM{'netmask'}&device=$FORM{'device'}&start=$FORM{'start'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&IP_Aliases_Form;}
else{&Error("$remote{'status'}");}
}

##

sub IP_Aliases_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+ips);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
my(%netmask,%gateway,%device,%start,%status);
my(@ips)=split(/::/,$remote{'ips'});
foreach(@ips)
	{
	my(@info)=split(/\|/,$_);
	$netmask{$info[0]}=$info[1];
	$device{$info[0]}=$info[2];
	$start{$info[0]}=$info[3];
	$status{$info[0]}=$info[4];
	}
&Top;
print qq(<script language="javascript">
<!--
function ChgWin(x)
	{
	this.location.href=x;
	}
// -->
</script>
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=6>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center colspan=6>Manage IP Aliases</td></tr>
<tr><td class="headb" align=left>IP</td>
<td class="headb" align=left>Netmask</td>
<td class="headb" align=left>Device</td>
<td class="headb" align=left>Start Option</td>
<td class="headb" align=left>Status</td>
<td class="headb" align=left>Action</td></tr>\n);
foreach(sort {lc($a) cmp lc($b)}(keys %netmask))
	{
	print qq(<tr><td class="prgout" align=left>$_</td>
<td class="prgout" align=left>$netmask{$_}</td>
<td class="prgout" align=left>$device{$_}</td>
<td class="prgout" align=left>$start{$_}</td>
<td class="prgout" align=left>$status{$_}</td>);
	if($status{$_} eq "up"){print qq(<td class="prgout" align=left><input type="button" value="Shutdown" onClick="javascript:ChgWin('$script?do=ifdown&ip=$_')"> <input type="button" value="Remove" onClick="javascript:ChgWin('$script?do=remip&ip=$_');"></td>);}
	else{print qq(<td class="prgout" align=left><input type="button" value="Bring Up" onClick="javascript:ChgWin('$script?do=ifup&ip=$_')"> <input type="button" value="Remove" onClick="javascript:ChgWin('$script?do=remip&ip=$_');"></td>);}
	print qq(</tr>\n);
	}
print qq(<form action="$script" method="Post">
<tr><td class="headb" align=center colspan=6>Add IP Alias</td></tr>
<tr><td class="prgout" align=right colspan=6>IP Address <input name="ip" type="text" size=15,1><br>
Netmask <input name="netmask" type="text" size=15,1><br>
Device <input name="device" type="text" size=8,1><br>
Start Option <select name="start" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=center colspan=6><input type="submit" value="Add IP Alias"></td></tr>
</table>
<input name="do" type="hidden" value="Add IP Alias">
</form>\n);
&Bottom;
}

##

sub Set_Time
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=set+time&mon=$FORM{'mon'}&day=$FORM{'day'}&year=$FORM{'year'}&hour=$FORM{'hour'}&min=$FORM{'min'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&Set_Time_Form;}
else{&Error("$remote{'status'}");}
}

##

sub Set_Time_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($Cookies{'level'} ne "2")){&Error('This function requires top level administrative access');}
my(@days)=('Sun','Mon','Tue','Wen','Thu','Fri','Sat');
my(@months)=('','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+time);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
my(@info)=split(/ /,$remote{'time'});
my($hour,$min,$sec)=split(/:/,$info[4]);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center>Set Server Time/Date</td></tr>
<tr><td class="prgout" align=left>Current Date/Time: $remote{'time'}</td></tr>
<tr><td class="prgout" align=left>Month <select name="mon" size=1>);
for($i=1;$i<=12;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i");
	if($months[$i] eq $info[1]){print qq( selected);}
	print qq(>$months[$i]);
	}
print qq(</select>
Day <select name="day" size=1>);
for($i=1;$i<=31;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i");
	if($i eq $info[2]){print qq( selected);}
	print qq(>$i);
	}
print qq(</select>
Year <select name="year" size=1>);
for($i=2004;$i<=2025;$i++)
	{
	print qq(<option value="$i");
	if($i eq $info[5]){print qq( selected);}
	print qq(>$i);
	}
print qq(</select><br>
Hour <select name="hour" size=1>);
for($i=0;$i<=23;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i");
	if($i eq $hour){print qq( selected);}
	print qq(>$i);
	}
print qq(</select>
Minute <select name="min" size=1>);
for($i=0;$i<=59;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i");
	if($i eq $min){print qq( selected);}
	print qq(>$i);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Set Time"></td></tr>
<input name="do" type="hidden" value="Set Time">
</form>
</table>\n);
&Bottom;
}

1;
