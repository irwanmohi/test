eval "use Net::SSH::Perl";
if($@ =~ /Can't Locate/i){$system{'nossh'} eq "yes";}

##

sub Config_Admin
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MAD3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass,netfilter,nfpath,autofirewall,usefilecheck,includepath,sshstart,sshstop,sshrestart,sshpid 
FROM server WHERE type='admin');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass,$netfilter,$nfpath,$autofirewall,$usefilecheck,$includepath,$sshstart,$sshstop,$sshrestart,$sshpid)=$query_output->fetchrow;
$sshstart=&uri_escape($sshstart);$sshstop=&uri_escape($sshstop);$sshrestart=&uri_escape($sshrestart);$sshpid=&uri_escape($sshpid);
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=config&netfilter=$netfilter&nfpath=$nfpath&autofirewall=$autofirewall&usefilecheck=$usefilecheck&includepath=$includepath);
$command.=qq(&dbhost=$system{'dbhost'}&dbname=$system{'dbname'}&dbuser=$system{'dbuser'}&dbpass=$system{'dbpass'});
$command.=qq(&sshstart=$sshstart&sshstop=$sshstop&sshrestart=$sshrestart&sshpid=$sshpid);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Admin server daemon configured</td></tr>
</table>);
&Bottom;
}

##

sub admindinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MAD2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name,ip,port,serverpass,includepath FROM server WHERE type='admin');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name,$ip,$port,$serverpass,$includepath)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($sserverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
if(!$id){&Error("The admin server must be defined before admind.inc can be created on the admin server.");}
$statement=qq(SELECT ip FROM server);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sip,@ips);
push(@ips,$ENV{'SERVER_ADDR'});
while(($sip)=$query_output->fetchrow)
	{
	if($sip ne $ENV{'SERVER_ADDR'}){push(@ips,$sip);}
	}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the hosting server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>admind.inc File Information For $name</td></tr>
<tr><td class="prgout" align=left colspan=2>\$host=&quot;$ip&quot;;<BR>
\$port=&quot;$port&quot;;<BR>
\$key='$serverpass';<BR>
\@referers=\(');
print join("','",@ips);
print qq('\);<BR>
1;
</td></tr>
<tr><td class="prgout" align=left colspan=2>This file can be created by hand and placed in $includepath,<br>
 or can be sent to server via SSH if root ssh with password access is available.</td></tr>
<tr><td class="heada" align=center colspan=2>Generate admind.inc on $name hosting server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send admind.inc"></td></tr>
</table>
<input name="id" type="hidden" value="$id">
<input name="do" type="hidden" value="Send admindinc">
<form>);
&Bottom;
}

##

sub Send_admindinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MAD2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass,includepath,sshport FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass,$includepath,$sshport)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$statement=qq(SELECT ip FROM server);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sip,@ips);
push(@ips,$ENV{'SERVER_ADDR'});
while(($sip)=$query_output->fetchrow)
	{
	if($sip ne $ENV{'SERVER_ADDR'}){push(@ips,$sip);}
	}
$ENV{HOME}=$system{'cgipath'};
my $ssh=Net::SSH::Perl->new($ip,protocol=>'2',port=>$sshport);
my($root)="root";
eval {$ssh->login($root,$FORM{'pass'});};
if($@ =~ /Permission denied/i){&Error("The root password was incorrect.");}
my($cmd)=qq(mkdir -p $includepath;chmod 700 $includepath;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$host="$ip";' > $includepath/admind.inc;echo '\$port="$port";' >> $includepath/admind.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$key='"'"$serverpass"'"';' >> $includepath/admind.inc;echo "\@referers=\(');
$cmd.=join("','",@ips);
$cmd.=qq('\);" >> $includepath/admind.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo "1;" >> $includepath/admind.inc;chmod 600 $includepath/admind.inc;);
$ssh->cmd($cmd);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>admind.inc File Information For $name</td></tr>
<tr><td class="prgout" align=left>\$host=&quot;$ip&quot;;<BR>
\$port=&quot;$port&quot;;<BR>
\$key='$serverpass';<BR>
\@referers=\(');
print join("','",@ips);
print qq('\);<BR>
1;
</td></tr>
<tr><td class="prgout" align=left>The admind.inc file has been created in $includepath. You can start admind now.</td></tr>
</table>);
&Bottom;
}

##

sub Define_Admin
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MAD1'} ne "yes")){&Error('Insufficient access for this function');}
my($cipher);
#if($system{'cryptver'} < 2.13){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
#else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my $serverpass=&encode_base64($cipher->encrypt($FORM{'pass'}));
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
if($FORM{'id'}){$statement=qq(UPDATE server SET name='$FORM{'name'}',ip='$FORM{'ip'}',port='$FORM{'port'}',serverpass='$serverpass',
netfilter='$FORM{'netfilter'}',nfpath='$FORM{'nfpath'}',autofirewall='$FORM{'autofirewall'}',usefilecheck='$FORM{'usefilecheck'}',
includepath='$FORM{'includepath'}',sshport='$FORM{'sshport'}',sshstart='$FORM{'sshstart'}',sshstop='$FORM{'sshstop'}',
sshrestart='$FORM{'sshrestart'}',sshpid='$FORM{'sshpid'}' WHERE id='$FORM{'id'}');}
else{$statement=qq(INSERT INTO server (type,name,ip,port,serverpass,netfilter,nfpath,autofirewall,usefilecheck,includepath,sshport,
sshstart,sshstop,sshrestart,sshpid)
VALUES ('admin','$FORM{'name'}','$FORM{'ip'}','$FORM{'port'}','$serverpass','$FORM{'netfilter'}','$FORM{'nfpath'}',
'$FORM{'autofirewall'}','$FORM{'usefilecheck'}','$FORM{'includepath'}','$FORM{'sshport'}','$FORM{'sshstart'}','$FORM{'sshstop'}',
'$FORM{'sshrestart'}','$FORM{'sshpid'}'));}
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my $id=$FORM{'id'};
if(!$id)
	{
	$statement=qq(SELECT id FROM server WHERE type='admin');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$id=$query_output->fetchrow;
	}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the hosting server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Generate admind.inc on $FORM{'servername'} admin server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send admind.inc"></td></tr>
</table>
<input name="id" type="hidden" value="$id">
<input name="do" type="hidden" value="Send admindinc">
<form>);
&Bottom;
}

##

sub Define_Admin_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MAD1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM server WHERE type='admin');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@fields)=$query_output->name;
my(@values)=$query_output->fetchrow_array;
if(!$values[74]){$values[74]="/etc/gnuhh/admin";}
if($values[5])
	{
	my($cipher);
	if(&decode_base64($values[5]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$values[5]=$cipher->decrypt(&decode_base64($values[5]));
	}
if(!$values[85]){$values[85] = "22";}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizeable=no,status=no");}
// -->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Define Admin Server</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=servername');" class="prgout">Admin Server Name (FQDN)</a></td>
<td class="prgout" align=left><input name="name" type="text" value="$values[2]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverip');" class="prgout">Admin Server IP Address</a></td>
<td class="prgout" align=left><input name="ip" type="text" value="$values[3]" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverport');" class="prgout">Admin Server Port</a></td>
<td class="prgout" align=left><input name="port" type="text" value="$values[4]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverpass');" class="prgout">Admin Server Password</a></td>
<td class="prgout" align=left><input name="pass" type="text" value="$values[5]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="$values[85]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter?</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no");
if($values[20] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" value="$values[52]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no");
if($values[53] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no");
if($values[23] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">Include Path</a></td>
<td class="prgout" align=left><input name="includepath" type="text" value="$values[74]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" value="$values[86]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" value="$values[87]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" value="$values[88]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" value="$values[89]" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Admin"></td></tr>
</table>
<input name="do" type="hidden" value="Define Admin">
<input name="id" type="hidden" value="$values[0]">
<form>);
#my($i);
#for($i=0;$i<=$#fields;$i++)
#	{
#	print qq($i - $fields[$i]<BR>\n);
#	}
&Bottom;
}

1;
