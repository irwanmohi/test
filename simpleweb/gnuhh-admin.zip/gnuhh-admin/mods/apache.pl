sub Save_Virtconf
{
if(($Cookies{'level'} ne "1")&&($access{'ADM3'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'file'}=&uri_escape($FORM{'file'});
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT server.ip,server.port,server.serverpass FROM server,domain_map WHERE domain_map.domain='$FORM{'domain'}' && domain_map.server=server.id);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=save+virtconf&domain=$FORM{'domain'}&file=$FORM{'file'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Virtual Host Configuration File for $FORM{'domain'} saved.</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Virtconf
{
if(($Cookies{'level'} ne "1")&&($access{'ADM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT server.ip,server.port,server.serverpass FROM server,domain_map WHERE domain_map.domain='$FORM{'domain'}' && domain_map.server=server.id);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+virtconf&domain=$FORM{'domain'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Virtual Host Configuration File for $FORM{'domain'}</td></tr>
<tr><td class="prgout" align=left> <textarea name="file" rows=25 cols=75 wrap=off>$remote{'file'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Changes"></td></tr>
</table>
<input name="domain" type="hidden" value="$FORM{'domain'}">
<input name="do" type="hidden" value="Save Virtconf">
</form>);
&Bottom;
}

##

sub Edit_Virtconf_Select
{
if(($Cookies{'level'} ne "1")&&($access{'ADM3'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Edit Virtconf";
var Extra="apache";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form>
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Virtual Host Configuration File</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
</table>
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

1;
