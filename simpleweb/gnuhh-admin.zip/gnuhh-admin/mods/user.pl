sub Remove_Block_User
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM userblock WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>User block removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Block_User2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM6'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'email'}=~s/\*/\%/g;
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,address,host FROM userblock WHERE address LIKE '$FORM{'email'}' || host LIKE '$FORM{'email'}' ORDER by address,host ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$address,$host);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to delete this block?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove Block Email Address or Host</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left> Email Address/Host</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1>--Select--);
while(($id,$address,$host)=$query_output->fetchrow)
	{
	if($address){print qq(<OPTION VALUE="$id">$address);}
	else{print qq(<OPTION VALUE="$id">$host);}
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove Block"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Unblock User">
</FORM>);
&Bottom;
}

##

sub Remove_Block_User_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM6'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Block Email Address or Host</td></tr>
<tr><td class="prgout" align=left>Email Address/Host</td>
<td class="prgout" align=left><input name="email" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<INPUT NAME="do" TYPE="hidden" VALUE="Unblock User2">
</form>);
&Bottom;
}

##

sub Block_User
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM5'} ne "yes")){&Error('Insufficient access for this function');}
if(!$FORM{'email'}){&Error("No information submitted to be added to the user block list");}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
if($FORM{'email'} =~ /\@/){$statement=qq(INSERT INTO userblock (address) VALUES ('$FORM{'email'}'));}
else{$statement=qq(INSERT INTO userblock (host) VALUES ('$FORM{'email'}'));}
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>User block added</td></tr>
</table>);
&Bottom;
}

##

sub Block_User_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM5'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Block Email Addresss or Host from User Accounts</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Email Address/Host</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="email" TYPE="text" SIZE=30,1 MAXLENGTH=75></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Add Block"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Block User">
</FORM>);
&Bottom;
}

##

sub Activate_User
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT email FROM user WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($email)=$query_output->fetchrow;
$email=~s/\'/\\'/g;
$statement=qq(UPDATE user SET suspend='no' WHERE id='$FORM{'id'}');
$db->query($statement);
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
$FORM{'comments'}=~s/\'/\\'/g;
$statement=qq(INSERT INTO actionlog (action,adate,admin,comments)
VALUES ('Reactivated user account, $email','$year-$mon-$mday $hour:$min:$sec','$Cookies{'auser'}','$FORM{'comments'}'));
$db->query($statement);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>User account re-activated</td></tr>
</table>);
&Bottom;
}

##

sub Activate_User2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM4'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'email'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,email FROM user WHERE suspend='yes' && email LIKE '$FORM{'email'}' ORDER BY email ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$email);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a user to reactivate");
return false;
}
if(confirm("Do you want to reactivate this user?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Reactivate User Account</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>User</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select User--);
while(($id,$email)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($email eq $FORM{'email'}){print qq( selected);}
	print qq(>$email);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Comments</TD>
<TD CLASS="prgout" ALIGN=left> <TEXTAREA NAME="comments" ROWS=5 COLS=30></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Reactivate User"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Activate User">
</FORM>);
&Bottom;
}

##

sub Activate_User_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM4'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Activate User2";
var Extra="activate";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+user+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Reactivate User Account</td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><input id="sfield" name="email" type="text" size=30,1 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Activate User2">
</form>
<DIV id="dlist" style="position:absolute;display:none;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Suspend_User
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT email FROM user WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($email)=$query_output->fetchrow;
$email=~s/\'/\\'/g;
$statement=qq(UPDATE user SET suspend='yes' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
$FORM{'comments'}=~s/\'/\\'/g;
$statement=qq(INSERT INTO actionlog (action,adate,admin,comments)
VALUES ('Suspended user account, $email','$year-$mon-$mday $hour:$min:$sec','$Cookies{'auser'}','$FORM{'comments'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>User account suspended</td></tr>
</table>);
&Bottom;
}

##

sub Suspend_User2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM3'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'email'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,email FROM user WHERE suspend='no' && email LIKE '$FORM{'email'}' ORDER BY email ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$email);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a user to suspend");
return false;
}
if(confirm("Do you want to suspend this user?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Suspend User Account</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>User</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select User--);
while(($id,$email)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($email eq $FORM{'email'}){print qq( selected);}
	print qq(>$email);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Comments</TD>
<TD CLASS="prgout" ALIGN=left> <TEXTAREA NAME="comments" ROWS=5 COLS=30></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Suspend User"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Suspend User">
</FORM>);
&Bottom;
}

##

sub Suspend_User_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM3'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Suspend User2";
var Extra="suspend";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+user+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Suspend User Account</td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><input id="sfield" name="email" type="text" size=30,1 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Suspend User2">
</form>
<DIV id="dlist" style="position:absolute;display:none;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Remove_User
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT email FROM user WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($email)=$query_output->fetchrow;
$email=~s/\'/\\'/g;
$statement=qq(DELETE FROM user WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
$FORM{'comments'}=~s/\'/\\'/g;
$statement=qq(INSERT INTO actionlog (action,adate,admin,comments)
VALUES ('Removed user account, $email','$year-$mon-$mday $hour:$min:$sec','$Cookies{'auser'}','$FORM{'comments'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>User account removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_User2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM2'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'email'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,email FROM user WHERE email LIKE '$FORM{'email'}' ORDER BY email ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$email);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select user to remove");
return false;
}
if(confirm("Do you want to delete this user?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm();">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove User Account</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>User</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select User--);
while(($id,$email)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($email eq $FORM{'email'}){print qq( selected);}
	print qq(>$email);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Comments</TD>
<TD CLASS="prgout" ALIGN=left> <TEXTAREA NAME="comments" ROWS=5 COLS=30></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove User"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Remove User">
</FORM>);
&Bottom;
}

##

sub Remove_User_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM2'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Remove User2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+user+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove User Account</td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><input id="sfield" name="email" type="text" size=30,1 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Remove User2">
</form>
<DIV id="dlist" style="position:absolute;display:none;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Add_User
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
if($FORM{'email'} !~ /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,6}|[0-9]{1,3})(\]?)$/){&Error("The email address, $FORM{'email'}, is not a valid email address");}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($null,$host)=split(/\@/,$FORM{'email'});
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id FROM user WHERE email='$FORM{'email'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id)=$query_output->fetchrow;
if($id){&Error("The email address, $FORM{'email'}, is already in the system");}
$statement=qq(SELECT id FROM userblock WHERE address='$FORM{'email'}' or host='$host');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$id=$query_output->fetchrow;
if($id){&Error("The email address or host has been blocked from user account system.");}
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($password)=&encode_base64($cipher->encrypt($FORM{'password'}));
$statement=qq(INSERT INTO user (firstname,lastname,password,email,company,address1,address2,address3,city,state,zip,country,phone,fax)
VALUES ('$FORM{'firstname'}','$FORM{'lastname'}','$password','$FORM{'email'}','$FORM{'company'}','$FORM{'address1'}',
'$FORM{'address2'}','$FORM{'address3'}','$FORM{'city'}','$FORM{'state'}','$FORM{'zip'}','$FORM{'country'}','$FORM{'phone'}','$FORM{'fax'}'));
$db->query($statement);
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
$statement=qq(INSERT INTO actionlog (action,adate,admin)
VALUES ('Created user $FORM{'email'}','$year-$mon-$mday $hour:$min:$sec','$Cookies{'auser'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>User account added</td></tr>
</table>);
&Bottom;
}

##

sub Add_User_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'UM1'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].firstname.value <= 0)
{
alert("fill in the first name please");
return false;
}
if(document.forms[0].lastname.value <= 0) 
{
alert("fill in the last name please");
return false;
}
if(document.forms[0].password.value <= 0)
{
alert("fill in the password");
return false;
}
if(document.forms[0].email.value <= 0) 
{
alert("fill in the E-mail address please");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Add User Account</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>First Name</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="firstname" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Last Name</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="lastname" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Password</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="password" TYPE="text" SIZE=30,1></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Email Address</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="email" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Company</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="company" TYPE="text" SIZE=30,1 MAXLENGTH=100></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Address 1</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="address1" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Address 2</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="address2" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Address 3</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="address3" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>City</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="city" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>State</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="state" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Zip/Postal Code</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="zip" TYPE="text" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Country</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="country" SIZE=1>);
open(FILE,"countries.dat");
while(<FILE>)
	{
	chomp($_);
	my(@info)=split(/:/,$_);
	print qq(<OPTION VALUE="$info[0]");
	if($info[0] eq "us"){print qq( SELECTED);}
	print qq(>$info[1]);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Phone</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="phone" TYPE="text" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Fax</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="fax" TYPE="text" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Add User"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Add User">
</FORM>);
&Bottom;
}

1;
