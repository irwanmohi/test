sub Adjust_Discount
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id FROM recur_charge WHERE domain='$FORM{'id'}' && description='Discount');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id)=$query_output->fetchrow;
if($id)
	{
	if($FORM{'discount'}){$statement=qq(UPDATE recur_charge SET amount='-$FORM{'discount'}',cycle='$FORM{'cycle'}' WHERE id='$id');}
	else{$statement=qq(DELETE FROM recur_charge WHERE id='$id');}
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
else
	{
	if($FORM{'discount'})
		{
		$statement=qq(INSERT INTO recur_charge (domain,description,amount,cycle) VALUES ('$FORM{'id'}','Discount','-$FORM{'discount'}','$FORM{'cycle'}'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	}
&Start;
}

##

sub Adjust_Discount2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA6'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE domain like '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Adjust Discount</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><select name="id" size=1 onChange="ChgVal(this.options.selectedIndex);"><option value="">--Select Domain);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<option value="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left>Discount</td>
<td class="prgout" align=left>\$<input name="discount" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left>Cycles</td>
<td class="prgout" align=left><input name="cycle" type="text" size=5,1> * Number of billing cycles to include discount.<br>(empty means every cycle)</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Adjust Discount"></td></tr>
</table>
<input name="do" type="hidden" value="Adjust Discount">
</form>
<script language="javascript">
<!--
function ChgVal(x)
	{
	document.forms[0].discount.value=eval(group[x][1]);
	document.forms[0].cycle.value=eval(group[x][2]);
	}
var groups=document.forms[0].id.options.length
var group=new Array(groups)
for (i=0; i<groups; i++)
group[i]=new Array()
group[0][1]=new Number(0);
group[0][2]=new Number(0);\n);
my($idcount)=1;
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
while(($id,$domain)=$query_output->fetchrow)
	{
	$statement=qq(SELECT amount,cycle FROM recur_charge WHERE domain='$id' && description='Discount');
	my($query_output2)=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($amount,$cycle)=$query_output2->fetchrow;
	if($amount){$amount*=-1;}
	else{$amount=0;}
	if(!$cycle){$cycle=0;}
	print qq(group[$idcount][1]=new Number($amount);
group[$idcount][2]=new Number($cycle);\n);
	$idcount++;
	}
print qq(ChgVal(document.forms[0].id.options.selectedIndex);
// -->
</script>\n);
&Bottom;
}

##

sub Adjust_Discount_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA6'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Adjust Discount2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Adjust Discount</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Adjust Discount2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Post_Payment
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain FROM domain_map WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain)=$query_output->fetchrow;
$statement=qq(SELECT id,invbal FROM invoice WHERE domid='$FORM{'id'}' && invbal > 0 ORDER BY id ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($invoice,$invbal);
my($credit)=$FORM{'amount'};
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
while(($invoice,$invbal)=$query_output->fetchrow)
	{
	my($newpay);
	if($credit-$invbal > 0){$statement=qq(UPDATE invoice SET invbal=0 WHERE id='$invoice');$credit-=$invbal;$newpay=$invbal;}
	else{$statement=qq(UPDATE invoice SET invbal=invbal-$credit WHERE id='$invoice');$newpay=$credit;$credit=0;}
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(INSERT INTO payments (invoice,transtype,descr,amount,pdate) VALUES ('$invoice','Other','$FORM{'notes'}','$newpay','$year-$mon-$mday'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE accounting SET amount=amount-$newpay WHERE domid='$FORM{'id'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	if($credit <= 0){last;}
	}
if($credit > 0)
	{
	$statement=qq(SELECT amount FROM accounting WHERE domid='$FORM{'id'}');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($prevbal)=$query_output->fetchrow;
	$statement=qq(INSERT INTO invoice (domid,domain,prevbal,amount,cdate,invbal) VALUES ('$FORM{'id'}','$domain','$prevbal','$credit','$year-$mon-$mday','$credit'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(SELECT LAST_INSERT_ID());
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($nid)=$query_output->fetchrow;
	$statement=qq(INSERT INTO payments (invoice,transtype,descr,amount,pdate) VALUES ('$nid','Other','$FORM{'notes'}','$credit','$year-$mon-$mday'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE accounting SET amount=amount-$credit WHERE domid='$FORM{'id'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Payment posted</td></tr>
</table>);
&Bottom;
}

##

sub Post_Payment2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA2'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE domain LIKE '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a domain to post to");
return false;
}
if(document.forms[0].type.selectedIndex <= 0)
{
alert("Select a transaction type");
return false;
}
if(document.forms[0].amount.value <= 0) 
{
alert("Enter an amount to be posted");
return false;
}
if(document.forms[0].notes.value <= 0) 
{
alert("Enter description");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Post Payment</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Type</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="type" SIZE=1><OPTION VALUE="">--Transaction Type--<OPTION VALUE="Cash">Cash<OPTION VALUE="Check">Check<OPTION VALUE="Credit Card">Credit Card<OPTION VALUE="Other">Other</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Amount</TD>
<TD CLASS="prgout" ALIGN=left>\$<INPUT NAME="amount" TYPE="text" SIZE=10,1></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Description/Notes</TD>
<TD CLASS="prgout" ALIGN=left><TEXTAREA NAME="notes" ROWS=6 COLS=25 WRAP=off></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Post Transaction"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Post Payment">
</FORM>\n);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom;
}

##

sub Payment_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA2'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Post Payment2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Post Payment</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Post Payment2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Export_Billing
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA5'} ne "yes")){&Error('Insufficient access for this function');}
my(@months)=('','January','February','March','April','May','June','July','August','September','October','November','December');
my(%months)=('1','31','2','29','3','31','4','30','5','31','6','30','7','31','8','31','9','30','10','31','11','30','12','31');
if($FORM{'emon'} =~ /^0/){$FORM{'emon'}=~s/^0//;}
my($edate)=$months{$FORM{'emon'}};
if(length($FORM{'smon'})==1){$FORM{'smon'}="0".$FORM{'smon'};}
if(length($FORM{'emon'})==1){$FORM{'emon'}="0".$FORM{'emon'};}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
#$statement=qq(SELECT id,domain,amount,pdate FROM payments WHERE
#payments.pdate >= '$FORM{'syear'}/$FORM{'smon'}/01' && payments.pdate <= '$FORM{'eyear'}/$FORM{'emon'}/$edate'
#ORDER BY payments.pdate ASC);
$statement=qq(SELECT payments.invoice,invoice.domain,payments.amount,payments.pdate FROM payments,invoice,domain_map WHERE
payments.pdate >= '$FORM{'syear'}/$FORM{'smon'}/01' && payments.pdate <= '$FORM{'eyear'}/$FORM{'emon'}/$edate'
&& payments.invoice=invoice.id && payments.descr not like 'Credit %' && domain_map.reseller='0' && invoice.domid=domain_map.id
ORDER BY payments.pdate ASC);
my($id,$domain,$amount,$pdate);
my($mtotal,$total);
$|=1;
#$ENV{'SCRIPT_NAME'}="IncomeReport.csv";
#$ENV{'SCRIPT_FILENAME'}="IncomeReport.csv";
my($crlf)="\015\012";
print qq(Content-Disposition: attachment; filename=IncomeReport.csv\nContent-type: application/download\n\n);
my($output)=qq(Monthly Income Report for $months[$FORM{'smon'}] $FORM{'syear'} to $months[$FORM{'emon'}] $FORM{'eyear'} for server $Cookies{'server'}
Domain,Payment Date,Amount\n);
my($m,$y,$total,$mtotal);
for($y=$FORM{'syear'};$y<=$FORM{'eyear'};$y++)
	{
	for($m=1;$m<=12;$m++)
		{
		if(($y == $FORM{'eyear'})&&($m > $FORM{'emon'})){$m=12;}
		elsif(($y == $FORM{'syear'})&&($m < $FORM{'smon'})){next;}
		else
			{
			$output.=qq($months[$m] $y\n);
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			while(($id,$domain,$amount,$pdate)=$query_output->fetchrow)
				{
				my(@info)=split(/-/,$pdate);
				if(($info[0] == $y)&&($info[1] == $m))
					{
					$output.=qq($domain,$pdate,\$$amount\n);
					$mtotal+=$amount;
					}
				}
			$mtotal=sprintf("%.2f",$mtotal);
			$output.=qq(,Total for $months[$m] $y,\$$mtotal\n);
			$total+=$mtotal;$mtotal=0;
			}
		}
	}
$total=sprintf("%.2f",$total);
$output.=qq(,Total for report period of $months[$FORM{'smon'}] $FORM{'syear'} to $months[$FORM{'emon'}] $FORM{'eyear'},\$$total\n);
$output=~s/\n/$crlf/g;
print $output;
exit;
}

##

sub Show_Income_Report
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA5'} ne "yes")){&Error('Insufficient access for this function');}
my(@months)=('','January','February','March','April','May','June','July','August','September','October','November','December');
my(%months)=('1','31','2','29','3','31','4','30','5','31','6','30','7','31','8','31','9','30','10','31','11','30','12','31');
my($edate)=$months{$FORM{'emon'}};
if(length($FORM{'smon'})==1){$FORM{'smon'}="0".$FORM{'smon'};}
if(length($FORM{'emon'})==1){$FORM{'emon'}="0".$FORM{'emon'};}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT payments.invoice,invoice.domain,payments.amount,payments.pdate FROM payments,invoice,domain_map WHERE
payments.pdate >= '$FORM{'syear'}/$FORM{'smon'}/01' && payments.pdate <= '$FORM{'eyear'}/$FORM{'emon'}/$edate'
&& payments.invoice=invoice.id && payments.descr not like 'Credit %'  && domain_map.reseller='0' && domain_map.id=invoice.domid
ORDER BY payments.pdate ASC);
my($id,$domain,$amount,$pdate);
my($mtotal,$total);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=3>Monthly Income Report for $months[$FORM{'smon'}] $FORM{'syear'} to $months[$FORM{'emon'}] $FORM{'eyear'}</TD></TR>
<TR><TD CLASS="headb" ALIGN=left>Domain</TD>
<TD CLASS="headb" ALIGN=left>Payment Date</TD>
<TD CLASS="headb" ALIGN=left>Amount</TD></TR>\n);
my($m,$y,$total,$mtotal);
for($y=$FORM{'syear'};$y<=$FORM{'eyear'};$y++)
	{
	for($m=1;$m<=12;$m++)
		{
		if(($y == $FORM{'eyear'})&&($m > $FORM{'emon'})){$m=12;}
		elsif(($y == $FORM{'syear'})&&($m < $FORM{'smon'})){next;}
		else
			{
			print qq(<TR><TD CLASS="headb" ALIGN=left COLSPAN=4>$months[$m] $y</TD></TR>\n);
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			while(($id,$domain,$amount,$pdate)=$query_output->fetchrow)
				{
				my(@info)=split(/-/,$pdate);
				if(($info[0] == $y)&&($info[1] == $m))
					{
					print qq(<TR><TD CLASS="prgout" ALIGN=left>$domain</TD>
<TD CLASS="prgout" ALIGN=left>$pdate</TD>
<TD CLASS="prgout" ALIGN=left>\$$amount</TD></TR>\n);
					$mtotal+=$amount;
					}
				}
			$mtotal=sprintf("%.2f",$mtotal);
			print qq(<TR><TD CLASS="total" ALIGN=left COLSPAN=2>Total for $months[$m] $y</TD>
<TD CLASS="total" ALIGN=left>\$$mtotal</TD></TR>\n);
			$total+=$mtotal;$mtotal=0;
			}
		}
	}
$total=sprintf("%.2f",$total);
print qq(<TR><TD CLASS="total" ALIGN=left COLSPAN=2>Total for report period of $months[$FORM{'smon'}], $FORM{'syear'} to $months[$FORM{'emon'}], $FORM{'eyear'}</TD>
<TD CLASS="total" ALIGN=left>\$$total</TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=3><INPUT TYPE="submit" VALUE="Save Report Locally"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Export Billing">
<INPUT NAME="smon" TYPE="hidden" VALUE="$FORM{'smon'}">
<INPUT NAME="syear" TYPE="hidden" VALUE="$FORM{'syear'}">
<INPUT NAME="emon" TYPE="hidden" VALUE="$FORM{'emon'}">
<INPUT NAME="eyear" TYPE="hidden" VALUE="$FORM{'eyear'}">
</FORM>\n);
&Bottom;
}

##

sub Income_Report_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA5'} ne "yes")){&Error('Insufficient access for this function');}
my($i);
my(@months)=('','January','February','March','April','May','June','July','August','September','October','November','December');
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Monthly Income Report</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Start Date</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="smon" SIZE=1>);
for($i=1;$i<=12;$i++){print qq(<OPTION VALUE="$i">$months[$i]);}
print qq(</SELECT> <SELECT NAME="syear" SIZE=1>);
for($i=2004;$i<=2025;$i++){print qq(<OPTION VALUE="$i">$i);}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>End Date</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="emon" SIZE=1>);
for($i=1;$i<=12;$i++){print qq(<OPTION VALUE="$i">$months[$i]);}
print qq(</SELECT> <SELECT NAME="eyear" SIZE=1>);
for($i=2004;$i<=2025;$i++){print qq(<OPTION VALUE="$i">$i);}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Show Report"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Show Income Report">
</FORM>\n);
&Bottom;
}

##

sub Billing_Status
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA4'} ne "yes")){&Error('Insufficient access for this function');}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(!$FORM{'num'}){$FORM{'num'}="0";}
if(!$FORM{'count'}){$FORM{'count'}="25";}
if($FORM{'num'} < $FORM{'count'}){$FORM{'num'}="0";}
$FORM{'sterm'}=~s/\*/\%/g;
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT COUNT(accounting.id) FROM accounting,domain_map WHERE accounting.domain LIKE '$FORM{'sterm'}' && accounting.domid=domain_map.id && domain_map.reseller='0');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=$query_output->fetchrow;
$statement=qq(SELECT accounting.domid,accounting.domain,accounting.amount FROM accounting,domain_map WHERE accounting.domain LIKE '$FORM{'sterm'}' && accounting.domid=domain_map.id && domain_map.reseller='0');
if(!$FORM{'sortby'}){$statement.=qq( ORDER BY accounting.domain ASC);}
elsif($FORM{'sortby'} eq "domaindesc"){$statement.=qq( ORDER BY accounting.domain DESC);}
elsif($FORM{'sortby'} eq "balanceasc"){$statement.=qq( ORDER BY accounting.amount ASC);}
elsif($FORM{'sortby'} eq "balancedesc"){$statement.=qq( ORDER BY accounting.amount DESC);}
$statement.=qq( LIMIT $FORM{'num'},$FORM{'count'});
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$FORM{'sterm'}=~s/\%/\*/g;
my($domid,$domain,$amount);
&Top;
print qq(<script language="javascript">
<!--
var action="billing status";
var Extra="billing";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<script language="javascript">
<!--
function GoTo(x){self.location.href="$script?do=billing+status&num=$FORM{'num'}&start=$FORM{'start'}&sortby=$FORM{'sortby'}&sterm=$FORM{'sterm'}&count="+x;}
// -->
</script>
<form action="$script" method="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=4>Account Billing Status</TD></TR>
<TR><TD CLASS="headb" ALIGN=left>);
if(!$FORM{'sortby'}){print qq(<a href="$script?do=billing+status&sterm=$FORM{'sterm'}&num=$FORM{'num'}&count=$FORM{'count'}&sterm=$FORM{'sterm'}&start=$FORM{'start'}&sortby=domaindesc" class="prgout">);}
else{print qq(<a href="$script?do=billing+status&sterm=$FORM{'sterm'}&num=$FORM{'num'}&count=$FORM{'count'}&start=$FORM{'start'}" class="prgout">);}
print qq(Domain</a></TD>
<TD CLASS="headb" ALIGN=left>);
if($FORM{'sortby'} eq "balanceasc"){print qq(<a href="$script?do=billing+status&sterm=$FORM{'sterm'}&num=$FORM{'num'}&count=$FORM{'count'}&sterm=$FORM{'sterm'}&start=$FORM{'start'}&sortby=balancedesc" class="prgout">);}
else{print qq(<a href="$script?do=billing+status&sterm=$FORM{'sterm'}&num=$FORM{'num'}&count=$FORM{'count'}&start=$FORM{'start'}&sortby=balanceasc" class="prgout">);}
print qq(Current Balance</a></TD>
<TD CLASS="headb" ALIGN=center>Overdue?</TD>
<TD CLASS="headb" ALIGN=left>View History</TD></TR>\n);
while(($domid,$domain,$amount)=$query_output->fetchrow)
	{
	my($overdue)="no";
	if($amount > 0)
		{
		$statement=qq(SELECT COUNT(id) FROM invoice WHERE domid='$domid' && DATE_ADD(cdate, INTERVAL $system{'setperiod'} DAY) < '$year-$mon-$mday');
		my($query_output2)=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($count)=$query_output2->fetchrow;
		if($count > 0){$overdue="yes";}
		}
	print qq(<TR><TD CLASS="prgout" ALIGN=left>$domain</TD>
<TD CLASS="prgout" ALIGN=left>$amount</TD>
<TD CLASS="prgout" ALIGN=center>$overdue</TD>
<TD CLASS="prgout" ALIGN=left><A HREF="$script?do=Billing+History&id=$domid" class="prgout">View</A></TD></TR>\n);
	}
if(($count > ($FORM{'num'}+$FORM{'count'}))||($FORM{'num'} > 0))
	{
	print qq(<tr><td class="prgout" align=left>);
	if($FORM{'num'} > 0)
		{
		my $prev=$FORM{'num'}-$FORM{'count'};
		print qq(<a href="$script?do=billing+status&num=$prev&count=$FORM{'count'}&start=$FORM{'start'}&sterm=$FORM{'sterm'}&sortby=$FORM{'sortby'}" class="prgout">Previous</a>);
		}
	else{print qq(&nbsp;);}
	print qq(</td>
<td class="prgout" align=center colspan=2>show <select name="count" size=1 onChange="GoTo(this.value);"><option value="10");
	if($FORM{'count'} eq "10"){print qq( selected);}
	print qq(>10<option value="25");
	if($FORM{'count'} eq "25"){print qq( selected);}
	print qq(>25<option value="50");
	if($FORM{'count'} eq "50"){print qq( selected);}
	print qq(>50<option value="100");
	if($FORM{'count'} eq "100"){print qq( selected);}
	print qq(>100</select> per page</td>
<td class="prgout" align=right>);
	if($count > ($FORM{'num'}+$FORM{'count'}))
		{
		my $next=$FORM{'num'}+$FORM{'count'};
		print qq(<a href="$script?do=billing+status&num=$next&count=$FORM{'count'}&start=$FORM{'start'}&sterm=$FORM{'sterm'}&sortby=$FORM{'sortby'}" class="prgout">Next</a>);
		}
	else{print qq(&nbsp;)}
	print qq(</td></tr>);
	}
print qq(<tr><td class="prgout" align=center colspan=4><input id="sfield" name="sterm" type="text" value="$FORM{'sterm'}" size=20,1 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"> <input type="submit" value="Search"></td></tr>
<tr><td class="prgout" align=left colspan=4>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
</TABLE>
<input name="num" type="hidden" value="$FORM{'num'}">
<input name="count" type="hidden" value="$FORM{'count'}">
<input name="sortby" type="hidden" value="$FORM{'sortby'}">
<input name="do" type="hidden" value="billing status">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>\n);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Billing_History
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain,amount FROM accounting WHERE domid='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain,$balance)=$query_output->fetchrow;
$balance=sprintf("%.2f",($balance*=-1));
$statement=qq(SELECT id,cdate FROM invoice WHERE domid='$FORM{'id'}' ORDER BY id DESC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$cdate);
&Top;
print qq(<script language="javascript">
<!--\n);
if($system{'useframes'} eq "yes"){print qq(function GoTo(x,y){parent.main.location.href=x+y;}\n);}
else{print qq(function GoTo(x,y){this.location.href=x+y;}\n);}
print qq(//-->
</script>
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Billing History for $domain</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>History Quick Select</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="invoice" SIZE=1 onChange="GoTo('$script?do=Billing+History&id=$FORM{'id'}&invoice=',this.options[this.options.selectedIndex].value);"><OPTION VALUE="">--Select Invoice--);
while(($id,$cdate)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$cdate - $id);
	}
print qq(</SELECT></TD></TR>\n);
$statement=qq(SELECT id,period,prevbal,amount,cdate,DATE_ADD(cdate, INTERVAL $system{'setperiod'} DAY),invbal FROM invoice WHERE domid='$FORM{'id'}');
if($FORM{'invoice'}){$statement.=qq( && id='$FORM{'invoice'}');}
$statement.=qq( ORDER BY id DESC LIMIT 0,1);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$period,$prevbal,$amount,$cdate,$duedate,$invbal)=$query_output->fetchrow;
my($overdue);
use Time::Local;
my(@info)=split(/-/,$duedate);
$info[1]--;
my($testtime)=timelocal(0,0,0,$info[2],$info[1],$info[0]);
my($time)=time;
if($time > $testtime){$overdue=1;}
print qq(<TR><TD CLASS="headb" ALIGN=left COLSPAN=2>Invoice $id for $period Date: $cdate Due: $duedate);
if(($duedate)&&($invbal > 0)){print qq(<BR><div class="highlight">This invoice is overdue</div>);}
print qq(</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Previous Balance</TD>
<TD CLASS="prgout" ALIGN=right>\$$prevbal</TD></TR>\n);
my($subtotal)=$prevbal;
$statement=qq(SELECT amount,descr FROM charges WHERE invoice='$id');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($charge,$desc,$tid);
while(($charge,$desc)=$query_output->fetchrow)
	{
	$desc=~s/\n/<BR>\n/g;
	$desc=~s/,/,<BR>/g;
	print qq(<TR><TD CLASS="prgout" ALIGN=left>$desc</TD>
<TD CLASS="prgout" ALIGN=right VALIGN=bottom>\$$charge</TD></TR>\n);
	$subtotal+=$charge;
	}
$statement=qq(SELECT amount,descr,tid FROM payments WHERE invoice='$id');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
while(($charge,$desc,$tid)=$query_output->fetchrow)
	{
	$desc=~s/\n/<BR>\n/g;
	$desc=~s/,/,<BR>/g;
	print qq(<TR><TD CLASS="highlight" ALIGN=left>);
	if($tid > 0){print qq(<A HREF="$script?do=view+trans&id=$tid" class="prgout">);}
	print qq($desc);
	if($tid > 0){print qq(</A>);}
	print qq(</TD>
<TD CLASS="highlight" ALIGN=right VALIGN=bottom>\$$charge</TD></TR>\n);
	$subtotal-=$charge;
	}		
$subtotal=sprintf("%.2f",$subtotal);
print qq(<TR><TD CLASS="prgout" ALIGN=left>Invoice Total</TD>
<TD CLASS="prgout" ALIGN=right>\$$subtotal</TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=4>Balance: \$$balance</TD></TR>
</TABLE>\n);
&Bottom;
}

##

sub Billing_History2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA3'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE domain LIKE '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>View Billing History</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="View History"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Billing History">
</FORM>\n);
&Bottom;
}

##

sub Billing_History_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA3'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Billing History";
var Extra="id";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>View Billing History</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Billing History2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Add_Billing
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA1'} ne "yes")){&Error('Insufficient access for this function');}
my($time)=time;
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain FROM domain_map WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain)=$query_output->fetchrow;
$statement=qq(SELECT amount FROM accounting WHERE domid='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($prevbal)=$query_output->fetchrow;
$FORM{'amount'}=sprintf("%.2f",$FORM{'amount'});
$statement=qq(INSERT INTO invoice (domid,domain,amount,prevbal,cdate,invbal) VALUES ('$FORM{'id'}','$domain','$FORM{'amount'}','$prevbal','$year/$mon/$mday','$FORM{'amount'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($invoice)=$query_output->fetchrow;
if($prevbal <= 0)
	{
	$statement=qq(UPDATE invoice SET invbal=invbal+$prevbal WHERE id='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','$FORM{'notes'}','$FORM{'amount'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(UPDATE accounting SET amount=amount+$FORM{'amount'} WHERE domid='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Billing charge added</td></tr>
</table>);
&Bottom;
}

##

sub Add_Billing2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA1'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE domain LIKE '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a domain to post to");
return false;
}
if(document.forms[0].amount.value <= 0) 
{
alert("Enter an amount to be posted");
return false;
}
if(document.forms[0].notes.value <= 0) 
{
alert("Enter description");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Add Charge</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Amount</TD>
<TD CLASS="prgout" ALIGN=left>\$<INPUT NAME="amount" TYPE="text" SIZE=10,1></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Description/Notes</TD>
<TD CLASS="prgout" ALIGN=left><TEXTAREA NAME="notes" ROWS=6 COLS=25 WRAP=off></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Post Transaction"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Add Billing">
</FORM>\n);
&Bottom;
}

##

sub Add_Billing_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'BA1'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Add Billing2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Charge</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Add Billing2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

1;
