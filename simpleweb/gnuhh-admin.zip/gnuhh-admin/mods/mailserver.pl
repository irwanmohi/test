use Net::SSH::Perl;

##

sub Send_hhmsinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass,includepath,sshport FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass,$includepath,$sshport)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$statement=qq(SELECT ip FROM server WHERE mailip='$ip');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sip,@ips);
push(@ips,$ENV{'SERVER_ADDR'});
while(($sip)=$query_output->fetchrow)
	{
	if($sip ne $ENV{'SERVER_ADDR'}){push(@ips,$sip);}
	}
$ENV{HOME}=$system{'cgipath'};
my $ssh=Net::SSH::Perl->new($ip,protocol=>'2',port=>$sshport);
my($root)="root";
eval {$ssh->login($root,$FORM{'pass'});};
if($@ =~ /Permission denied/i){&Error("The root password was incorrect.");}
my($cmd)=qq(mkdir -p $includepath;chmod 700 $includepath;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$host="$ip";' > $includepath/hhms.inc;echo '\$port="$port";' >> $includepath/hhms.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$key='"'"'$serverpass'"'"';' >> $includepath/hhms.inc;echo "\@referers=\(');
$cmd.=join("','",@ips);
$cmd.=qq('\);" >> $includepath/hhms.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo "1;" >> $includepath/hhms.inc;chmod 600 $includepath/hhms.inc;);
$ssh->cmd($cmd);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>hhms.inc File Information For $name</td></tr>
<tr><td class="prgout" align=left>\$host=&quot;$name&quot;;<br>
\$port=&quot;$port&quot;;<br>
\$key='$serverpass';<br>
\@referers=\(');
print join("','",@ips);
print qq('\);<br>
1;
</td></tr>
<tr><td class="prgout" align=left>The hhms.inc file has been created in $includepath. You can start hhmsd now.</td></tr>
</table>);
&Bottom;
}

##

sub MSinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass,includepath FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass,$includepath)=$query_output->fetchrow;
if(!$includepath){&Error("The includepath was not defined for this mail server. Please edit this mail server and enter the include path and save the settings.");}
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$statement=qq(SELECT ip FROM server WHERE mailip='$ip');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sip,@ips);
push(@ips,$ENV{'SERVER_ADDR'});
while(($sip)=$query_output->fetchrow)
	{
	if($sip ne $ENV{'SERVER_ADDR'}){push(@ips,$sip);}
	}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the mail server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>hhms.inc File Information For $name</td></tr>
<tr><td class="prgout" align=left colspan=2>\$host=&quot;$name&quot;;<br>
\$port=&quot;$port&quot;;<br>
\$key='$serverpass';<br>
\@referers=\(');
print join("','",@ips);
print qq('\);<br>
1;
</td></tr>
<tr><td class="prgout" align=left colspan=2>This file can be created by hand and placed in $includepath,<br>
or can be sent to server via SSH if root ssh with password access is available.</td></tr>
<tr><td class="heada" align=center colspan=2>Generate hhms.inc on $name mail server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send hhms.inc"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Send hhmsinc">
</form>);
&Bottom;
}

##

sub MSinc_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='mail' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Generate hhms.inc File Information</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Mail Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=MSinc&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Mail Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Generate Informarion"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="MSinc">
</form>);
&Bottom;
}

##

sub Remove_MS_Template
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM template WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Mailserver template removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_MS_Template_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM template WHERE type='mail' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name,$count);
$count=($query_output->execute)+0;
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to delete this template?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<form action="$script" method="Post" onSubmit="return ConFirm()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Mail Server Template</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Template</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Remove+MS+Template&id=$id" onClick="return ConFirm()" class="prgout">$name<br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Template</td>
<td class="prgout" align=left><select name="id" size=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Remove Template"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Remove MS Template">
</form>);
&Bottom;
}

##

sub Save_MS_Template
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS7'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE template SET name='$FORM{'template'}',mailpath='$FORM{'mailpath'}',mailcw='$FORM{'mailcw'}',mailvirtuser='$FORM{'mailvirtuser'}',
mailrestart='$FORM{'mailrestart'}',mailstart='$FORM{'mailstart'}',mailstop='$FORM{'mailstop'}',mailpid='$FORM{'mailpid'}',netfilter='$FORM{'netfilter'}',
nfpath='$FORM{'nfpath'}',autofirewall='$FORM{'autofirewall'}',usefilecheck='$FORM{'usefilecheck'}',mailtype='$FORM{'mailtype'}',
mailaccess='$FORM{'mailaccess'}',sshport='$FORM{'sshport'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Mailserver template updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_MS_Template
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM template WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
my(@values)=$query_output->fetchrow_array;
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
// -->
</script>
<script language="javascript">
<!--
function chkData() {
if(document.forms[0].mailpath.value <= 0)
{
alert("Enter the path to be used for the email account home directories.");
return false;
}
if(document.forms[0].mailcw.value <= 0)
{
alert("Enter the mail cw file.");
return false;
}
if(document.forms[0].mailvirtuser.value <= 0)
{
alert("Enter the virtual user file.");
return false;
}
if(document.forms[0].mailrestart.value <= 0)
{
alert("Enter the command to restart the mail server.");
return false;
}
if(document.forms[0].mailstart.value <= 0)
{
alert("Enter the command to start the mail server.");
return false;
}
if(document.forms[0].mailstop.value <= 0)
{
alert("Enter the command to stop the mail server.");
return false;
}
if(document.forms[0].mailpid.value <= 0)
{
alert("Enter the mail server PID file.");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData();">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Mail Server Template</td></tr>
<tr><td class="prgout" align=left>Template Name</td>
<td class="prgout" align=left><input name="template" type="text" value="$values[2]" size=30,1 maxlength=100></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="$values[85]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailtype');" class="prgout">Mail Server Type</a></td>
<td class="prgout" align=left><select name="mailtype" size=1><option value="sendmail">Sendmail<option value="postfix");
if($values[56] eq "postfix"){print qq( selected);}
print qq(>PostFix</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpath');" class="prgout">Path to email users directory</a></td>
<td class="prgout" align=left><input name="mailpath" type="text" value="$values[30]" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailcw');" class="prgout">Email CW file</a></td>
<td class="prgout" align=left><input name="mailcw" type="text" value="$values[31]" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailvirtuser');" class="prgout">Email virtual user file</a></td>
<td class="prgout" align=left><input name="mailvirtuser" type="text" value="$values[32]" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailaccess');" class="prgout">Email server access file</a></td>
<td class="prgout" align=left><input name="mailaccess" type="text" value="$values[63]" size=20,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailrestart');" class="prgout">Email server restart command</a></td>
<td class="prgout" align=left><input name="mailrestart" type="text" value="$values[33]" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstart');" class="prgout">Email server start command</a></td>
<td class="prgout" align=left><input name="mailstart" type="text" value="$values[34]" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstop');" class="prgout">Email server stop command</a></td>
<td class="prgout" align=left><input name="mailstop" type="text" value="$values[35]" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpid');" class="prgout">Email server PID file</a></td>
<td class="prgout" align=left><input name="mailpid" type="text" value="$values[36]" size=20,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no");
if($values[14] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" value="$values[46]" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no");
if($values[47] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no");
if($values[17] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Template"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save MS Template">
</form>\n);
&Bottom;
}

##

sub Edit_MS_Template_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM template WHERE type='mail' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name,$count);
$count=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Mail Server Template</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Template</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Edit+MS+Template&id=$id" class="prgout">$name<br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Template</td>
<td class="prgout" align=left><select name="id" size=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Template"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Edit MS Template">
</form>);
&Bottom;
}

##

sub Create_MS_Template
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS6'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(INSERT INTO template (type,name,mailpath,mailcw,mailvirtuser,mailrestart,mailstart,mailstop,mailpid,netfilter,nfpath,autofirewall,
usefilecheck,mailtype,mailaccess,sshport)
VALUES ('mail','$FORM{'template'}','$FORM{'mailpath'}','$FORM{'mailcw'}','$FORM{'mailvirtuser'}','$FORM{'mailrestart'}','$FORM{'mailstart'}',
'$FORM{'mailstop'}','$FORM{'mailpid'}','$FORM{'netfilter'}','$FORM{'nfpath'}','$FORM{'autofirewall'}',
'$FORM{'usefilecheck'}','$FORM{'mailtype'}','$FORM{'mailaccess'}','$FORM{'sshport'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Mailserver template created</td></tr>
</table>);
&Bottom;
}

##

sub Create_MS_Template_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS6'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
// -->
</script>
<script language="javascript">
<!--
function chkData() {
if(document.forms[0].sshport.value <= 0)
{
alert("Enter the ssh port for the mail server");
return false;
}
if(document.forms[0].mailpath.value <= 0)
{
alert("Enter the path to be used for the email account home directories.");
return false;
}
if(document.forms[0].mailcw.value <= 0)
{
alert("Enter the mail cw file.");
return false;
}
if(document.forms[0].mailvirtuser.value <= 0)
{
alert("Enter the virtual user file.");
return false;
}
if(document.forms[0].mailrestart.value <= 0)
{
alert("Enter the command to restart the mail server.");
return false;
}
if(document.forms[0].mailstart.value <= 0)
{
alert("Enter the command to start the mail server.");
return false;
}
if(document.forms[0].mailstop.value <= 0)
{
alert("Enter the command to stop the mail server.");
return false;
}
if(document.forms[0].mailpid.value <= 0)
{
alert("Enter the mail server PID file.");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData();">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Create Mail Server Template</td></tr>
<tr><td class="prgout" align=left>Template Name</td>
<td class="prgout" align=left><input name="template" type="text" size=30,1 maxlength=100></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="22" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailtype');" class="prgout">Mail Server Type</a></td>
<td class="prgout" align=left><select name="mailtype" size=1><option value="sendmail">Sendmail<option value="postfix">PostFix</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpath');" class="prgout">Path to email users directory</a></td>
<td class="prgout" align=left><input name="mailpath" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailcw');" class="prgout">Email CW file</a></td>
<td class="prgout" align=left><input name="mailcw" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailvirtuser');" class="prgout">Email virtual user file</a></td>
<td class="prgout" align=left><input name="mailvirtuser" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailaccess');" class="prgout">Email server access file</a></td>
<td class="prgout" align=left><input name="mailaccess" type="text" size=20,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstart');" class="prgout">Email server start command</a></td>
<td class="prgout" align=left><input name="mailstart" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstop');" class="prgout">Email server stop command</a></td>
<td class="prgout" align=left><input name="mailstop" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailrestart');" class="prgout">Email server restart command</a></td>
<td class="prgout" align=left><input name="mailrestart" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpid');" class="prgout">Email server PID file</a></td>
<td class="prgout" align=left><input name="mailpid" type="text" size=20,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Create Template"></td></tr>
</table>
<input name="do" type="hidden" value="Create MS Template">
</form>\n);
&Bottom;
}

##

sub Configure_Mailserver
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass,usequota,netfilter,nfpath,mailpath,mailcw,mailvirtuser,mailrestart,mailstart,mailstop,mailpid,autofirewall,mailtype,mailaccess,
sshstart,sshstop,sshrestart,sshpid FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass,$usequota,$netfilter,$nfpath,$mailpath,$mailcw,$mailvirtuser,$mailrestart,$mailstart,$mailstop,$mailpid,$autofirewall,$mailtype,$mailaccess,$sshstart,$sshstop,$sshrestart,$sshpid)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=save+mailserver+configuration&netfilter=$netfilter&nfpath=$nfpath&mailpath=$mailpath&mailcw=$mailcw&mailvirtuser=$mailvirtuser);
$command.=qq(&mailrestart=$mailrestart&mailstart=$mailstart&mailstop=$mailstop&mailpid=$mailpid&netfilter=$netfilter&nfpath=$nfpath&autofirewall=$autofirewall);
$command.=qq(&mailtype=$mailtype&mailaccess=$mailaccess&usequota=$usequota);
$command.=qq(&sshstart=$sshstart&sshstop=$sshstop&sshrestart=$sshrestart&sshpid=$sshpid);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Mailserver server configured</td></tr>
</table>);
&Bottom;
}

##

sub Configure_Mailserver_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='mail' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Mailserver</td></tr>
<tr><td class="prgout" align=left>Select Server</td>\n);
if($count > 10)
	{
	print qq(<td class="prgout" align=left><select name="id" size=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Configure Server"></td></tr>\n);
	}
else
	{
	print qq(<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Configure+Mailserver&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Configure Mailserver">
</form>);
&Bottom;
}

##

sub Save_Mailserver
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverpass)=&encode_base64($cipher->encrypt($FORM{'serverpass'}));
foreach(keys %FORM){$FORM{$_}=~s/\'/\\\'/g;}
$statement=qq(UPDATE server SET ip='$FORM{'serverip'}',port='$FORM{'serverport'}',serverpass='$serverpass',mailpath='$FORM{'mailpath'}',
mailcw='$FORM{'mailcw'}',mailvirtuser='$FORM{'mailvirtuser'}',mailrestart='$FORM{'mailrestart'}',mailstart='$FORM{'mailstart'}',
mailstop='$FORM{'mailstop'}',mailpid='$FORM{'mailpid'}',netfilter='$FORM{'netfilter'}',nfpath='$FORM{'nfpath'}',mailtype='$FORM{'mailtype'}',
autofirewall='$FORM{'autofirewall'}',usefilecheck='$FORM{'usefilecheck'}',includepath='$FORM{'includepath'}',mailaccess='$FORM{'mailaccess'}',
usequota='$FORM{'usequota'}',sshport='$FORM{'sshport'}',sshstart='$FORM{'sshstart'}',sshstop='$FORM{'sshstop'}',sshrestart='$FORM{'sshrestart'}',
sshpid='$FORM{'sshpid'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Mail server informaion updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Mailserver
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@values)=$query_output->fetchrow_array;
my($cipher);
if(&decode_base64($values[5]) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverpass)=$cipher->decrypt(&decode_base64($values[5]));
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
// -->
</script>
<script language="javascript">
<!--
function chkData() {
if(document.forms[0].servername.value <= 0)
{
alert("Enter a servername for the server being added");
return false;
}
if(document.forms[0].serverip.value <= 0) 
{
alert("Enter an IP address for the server being added");
return false;
}
if(document.forms[0].serverport.value <= 0)
{
alert("Enter a server port for the server being added");
return false;
}
if(document.forms[0].serverpass.value.length <= 7)
{
alert("For security reasons the server password must be at least 8 characters long");
return false;
}
if(document.forms[0].mailpath.value <= 0)
{
alert("Enter the path to be used for the email account home directories.");
return false;
}
if(document.forms[0].mailcw.value <= 0)
{
alert("Enter the mail cw file.");
return false;
}
if(document.forms[0].mailvirtuser.value <= 0)
{
alert("Enter the virtual user file.");
return false;
}
if(document.forms[0].mailrestart.value <= 0)
{
alert("Enter the command to restart the mail server.");
return false;
}
if(document.forms[0].mailstart.value <= 0)
{
alert("Enter the command to start the mail server.");
return false;
}
if(document.forms[0].mailstop.value <= 0)
{
alert("Enter the command to stop the mail server.");
return false;
}
if(document.forms[0].mailpid.value <= 0)
{
alert("Enter the mail server PID file.");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData();">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Mail Server $values[2]</td></tr>
<tr><td class="prgout" align=left>Server Name (FQDN)</td>
<td class="prgout" align=left>$values[2]</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverip');" class="prgout">Server IP</a></td>
<td class="prgout" align=left><input name="serverip" type="text" size=20,1 value="$values[3]" maxlength=20></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverport');" class="prgout">Server Port</a></td>
<td class="prgout" align=left><input name="serverport" type="text" size=5,1 value="$values[4]" maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverpass');" class="prgout">Server Password</a></td>
<td class="prgout" align=left><input name="serverpass" type="text" size=20,1 value="$serverpass" maxlength=56></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="$values[85]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailtype');" class="prgout">Mail Server Type</a></td>
<td class="prgout" align=left><select name="mailtype" size=1><option value="sendmail">Sendmail<option value="postfix");
if($values[73] eq "postfix"){print qq( selected);}
print qq(>PostFix</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usequota');" class="prgout">Use Linux quota management?</a></td>
<td class="prgout" align=left><select name="usequota" size=1><option value="yes">Yes<option value="no");
if($values[10] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpath');" class="prgout">Path to email users directory</a></td>
<td class="prgout" align=left><input name="mailpath" type="text" size=20,1 value="$values[36]" maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailcw');" class="prgout">Email CW file</a></td>
<td class="prgout" align=left><input name="mailcw" type="text" size=20,1 value="$values[37]" maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailvirtuser');" class="prgout">Email virtual user file</a></td>
<td class="prgout" align=left><input name="mailvirtuser" type="text" size=20,1 value="$values[38]" maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailaccess');" class="prgout">Email server access file</a></td>
<td class="prgout" align=left><input name="mailaccess" type="text" value="$values[82]" size=20,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstart');" class="prgout">Email server start command</a></td>
<td class="prgout" align=left><input name="mailstart" type="text" size=20,1 value="$values[40]" maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstop');" class="prgout">Email server stop command</a></td>
<td class="prgout" align=left><input name="mailstop" type="text" size=20,1 value="$values[41]" maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailrestart');" class="prgout">Email server restart command</a></td>
<td class="prgout" align=left><input name="mailrestart" type="text" size=20,1 value="$values[39]" maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpid');" class="prgout">Email server PID file</a></td>
<td class="prgout" align=left><input name="mailpid" type="text" value="$values[42]" size=20,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no");
if($values[20] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" size=20,1 value="$values[52]" maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no");
if($values[53] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no");
if($values[23] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">Include Path</a></td>
<td class="prgout" align=left><input name="includepath" type="text" value="$values[74]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" value="$values[86]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" value="$values[87]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" value="$values[88]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" value="$values[89]" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Mail Server"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Mailserver">
</form>\n);
&Bottom;
}
##

sub Edit_Mailserver_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='mail' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Mail Server</td></tr>
<tr><td class="prgout" align=left>Mail Server</td>\n);
if($count > 10)
	{
	print qq(<td class="prgout" align=left><select name="id" size=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Server"></td></tr>\n);
	}
else
	{
	print qq(<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Edit+Mailserver&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
print qq(
</table>
<input name="do" type="hidden" value="Edit Mailserver">
</form>);
&Bottom;
}

##

sub Add_Mailserver
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id FROM server WHERE name='$FORM{'servername'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
if($query_output->fetchrow)
	{
	&Error("The server, $FORM{'servername'}, already exist");
	}
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverpass)=&encode_base64($cipher->encrypt($FORM{'serverpass'}));
my(@keys)=keys(%FORM);
foreach(@keys){$FORM{$_}=~s/\'/\\\'/g;}
$statement=qq(INSERT INTO server (type,name,ip,port,serverpass,netfilter,nfpath,mailpath,mailcw,mailvirtuser,mailrestart,mailstart,mailstop,mailpid,
autofirewall,usefilecheck,includepath,mailtype,mailaccess,usequota,sshport,sshstart,sshstop,sshrestart,sshpid)
VALUES ('mail','$FORM{'servername'}','$FORM{'serverip'}','$FORM{'serverport'}','$serverpass','$FORM{'netfilter'}','$FORM{'nfpath'}','$FORM{'mailpath'}',
'$FORM{'mailcw'}','$FORM{'mailvirtuser'}','$FORM{'mailrestart'}','$FORM{'mailstart'}','$FORM{'mailstop'}','$FORM{'mailpid'}','$FORM{'autofirewall'}',
'$FORM{'usefilecheck'}','$FORM{'includepath'}','$FORM{'mailtype'}','$FORM{'mailaccess'}','$FORM{'usequota'}','$FORM{'sshport'}',
'$FORM{'sshstart'}','$FORM{'sshstop'}','$FORM{'sshrestart'}','$FORM{'sshpid'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id)=$query_output->fetchrow;
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the mail server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Generate hhms.inc on $name mail server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send hhms.inc"></td></tr>
</table>
<input name="id" type="hidden" value="$id">
<input name="do" type="hidden" value="Send hhmsinc">
</form>);
&Bottom;
}

##

sub Add_Mailserver_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM template WHERE type='mail' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name,$count);
$count=($query_output->execute)+0;
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
// -->
</script>
<script language="javascript">
<!--
function chkData() {
if(document.forms[0].servername.value <= 0)
{
alert("Enter a servername for the server being added");
return false;
}
if(document.forms[0].serverip.value <= 0) 
{
alert("Enter an IP address for the server being added");
return false;
}
if(document.forms[0].serverport.value <= 0)
{
alert("Enter a server port for the server being added");
return false;
}
if(document.forms[0].serverpass.value.length <= 7)
{
alert("For security reasons the server password must be at least 8 characters long");
return false;
}
if(document.forms[0].mailpath.value <= 0)
{
alert("Enter the path to be used for the email account home directories.");
return false;
}
if(document.forms[0].mailcw.value <= 0)
{
alert("Enter the mail cw file.");
return false;
}
if(document.forms[0].mailvirtuser.value <= 0)
{
alert("Enter the virtual user file.");
return false;
}
if(document.forms[0].mailrestart.value <= 0)
{
alert("Enter the command to restart the mail server.");
return false;
}
if(document.forms[0].mailstart.value <= 0)
{
alert("Enter the command to start the mail server.");
return false;
}
if(document.forms[0].mailstop.value <= 0)
{
alert("Enter the command to stop the mail server.");
return false;
}
if(document.forms[0].mailpid.value <= 0)
{
alert("Enter the mail server PID file.");
return false;
}
else
return true;
}
//-->
</script>\n);
if($count > 0)
	{
	print qq(<script language="javascript" src="$script?do=draw+template&template=mail"></script>\n);
	}
print qq(<form action="$script" method="Post" onSubmit="return chkData();">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Mail Server</td></tr>\n);
if($count > 0)
	{
	print qq(<tr><td class="prgout" align=right>Select Mail Server Template</td>
<td class="prgout" align=left><select name="template" size=1 onChange="ChgVal(this.options.selectedIndex);"><option value="">--No Template--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>\n);
	}
print qq(<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=servername');" class="prgout">Server Name (FQDN)</a></td>
<td class="prgout" align=left><input name="servername" type="text" size=20,1 maxlength=75></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverip');" class="prgout">Server IP</a></td>
<td class="prgout" align=left><input name="serverip" type="text" size=20,1 maxlength=20></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverport');" class="prgout">Server Port</a></td>
<td class="prgout" align=left><input name="serverport" type="text" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverpass');" class="prgout">Server Password</a></td>
<td class="prgout" align=left><input name="serverpass" type="text" size=20,1 maxlength=56></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="22" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailtype');" class="prgout">Mail Server Type</a></td>
<td class="prgout" align=left><select name="mailtype" size=1><option value="sendmail">Sendmail<option value="postfix">PostFix</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usequota');" class="prgout">Use Linux quota management?</a></td>
<td class="prgout" align=left><select name="usequota" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpath');" class="prgout">Path to email users directory</a></td>
<td class="prgout" align=left><input name="mailpath" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailcw');" class="prgout">Email CW file</a></td>
<td class="prgout" align=left><input name="mailcw" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailvirtuser');" class="prgout">Email virtual user file</a></td>
<td class="prgout" align=left><input name="mailvirtuser" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailaccess');" class="prgout">Email server access file</a></td>
<td class="prgout" align=left><input name="mailaccess" type="text" size=20,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstart');" class="prgout">Email server start command</a></td>
<td class="prgout" align=left><input name="mailstart" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstop');" class="prgout">Email server stop command</a></td>
<td class="prgout" align=left><input name="mailstop" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailrestart');" class="prgout">Email server restart command</a></td>
<td class="prgout" align=left><input name="mailrestart" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpid');" class="prgout">Email server PID file</a></td>
<td class="prgout" align=left><input name="mailpid" type="text" size=20,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" size=20,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">Include Path</a></td>
<td class="prgout" align=left><input name="includepath" type="text" value="/etc/gnuhh/mailserver" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Mail Server"></td></tr>
</table>
<input name="do" type="hidden" value="Add Mailserver">
</form>\n);
&Bottom;
}

##

sub Remove_Mailserver
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM server WHERE id='$FORM{'id'}');
$db->query($statement);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Mailserver removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Mailserver_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MMS5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='mail' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a mail server to remove");
return false;
}
if(confirm("Do you want to delete this mail server?"))
	{
	return true;
	}
else
return false;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Mail Server</td></tr>
<tr><td class="prgout" align=left Valign=top>Mail Server to remove</td>
<td class="prgout" align=left>);
if($count > 10)
	{
	print qq(<select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select>);
	}
else
	{
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Remove+Mailserver&id=$id" onClick="return chkData();" class="prgout">$name</a><br>);
		}
	}
print qq(</td></tr>\n);
if($count > 10){print qq(<tr><td class="prgout" align=center colspan=2><input type="submit" value="Remove Mail Server"></td></tr>\n);}
print qq(</table>
<input name="do" type="hidden" value="Remove Mailserver">
</form>\n);
&Bottom;
}

1;
