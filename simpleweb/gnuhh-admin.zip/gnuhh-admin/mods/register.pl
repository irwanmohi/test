sub Config_Fraud
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'FM4'} ne "yes")){&Error('Insufficient access for this function');}
my($perlpath)=$^X;
open(FILE,">fraudscreen.cgi");
print FILE qq(#!$perlpath
use vars qw/\$Version \%system \$cgipath \$days/;
\$cgipath="$system{'cgipath'}";
\$days="$FORM{'days'}";\n);
open(TMP,"fraudscreen.txt");
while(<TMP>)
	{
	print FILE $_;
	}
close(TMP);
close(FILE);
chmod(0755,"fraudscreen.cgi");
my(@info)=qx|crontab -l|;
open(TMP,">crontab.tmp");
foreach(@info)
	{
	if($_ !~ m|$system{'cgipath'}/fraudscreen.cgi$|)
		{
		print TMP $_;
		}
	}
print TMP "0 2 * * * $system{'cgipath'}/fraudscreen.cgi\n";
close(TMP);
qx|crontab crontab.tmp|;
unlink("crontab.tmp");
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Fraudscreen cron configured</td></tr>
</table>);
&Bottom;
}

##

sub Config_Fraud_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'FM4'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Fraudscreen Purge Configuration</td></tr>
<tr><td class="prgout" align=left>Expiration Period (in days)</td>
<td class="prgout" align=left><input name="days" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Configure"></td></tr>
</table>
<input name="do" type="hidden" value="Config Fraud">
</form>);
&Bottom;
}

##

sub Lock_Fraud
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'FM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
my($i);
for($i=1;$i<=$FORM{'lock'};$i++)
	{
	$statement=qq(UPDATE fraudscreen SET `lock`='$FORM{"lock$i"}' WHERE id='$FORM{"id$i"}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Fraudscreen entry locked</td></tr>
</table>);
&Bottom;
}

##

sub Lock_Fraud_Search
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'FM3'} ne "yes")){&Error('Insufficient access for this function');}
my($sterm)=$FORM{'sterm'};
$sterm=~s/\'/\\'/g;
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT DISTINCT id,email,ip,domain,phone,reason,pdate,`lock` FROM fraudscreen WHERE);
if($FORM{'option'} eq "email"){$statement.=qq( email LIKE '%$sterm%');}
if($FORM{'option'} eq "ip"){$statement.=qq( ip='$sterm%');}
if($FORM{'option'} eq "ccnum"){$statement.=qq( ccnum=password('$sterm'));}
if($FORM{'option'} eq "domain"){$statement.=qq( domain='$sterm');}
if($FORM{'option'} eq "phone"){$statement.=qq( phone LIKE '%$sterm%');}
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$email,$ip,$domain,$phone,$reason,$pdate,$lock);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class=3"heada" align=center colspan=7>Fraudscreen Lock Management</td></tr>
<tr><td class="headb" align=left>Email Address</td>
<td class="headb" align=left>IP Address</td>
<td class="headb" align=left>Domain</td>
<td class="headb" align=left>Phone</td>
<td class="headb" align=left>Reason</td>
<td class="headb" align=left>Post Date</td>
<td class="headb" align=left>Lock Status</td></tr>\n);
my($i);
while(($id,$email,$ip,$domain,$phone,$reason,$pdate,$lock)=$query_output->fetchrow)
	{
	$i++;
	print qq(<tr><td class="prgout" align=left>$email</td>
<td class="prgout" align=left>$ip</td>
<td class="prgout" align=left>$domain</td>
<td class="prgout" align=left>$phone</td>
<td class="prgout" align=left>$reason</td>
<td class="prgout" align=left>$pdate</td>
<td class="prgout" align=left><select name="lock$i" size=1><option value="y");
	if($lock eq "y"){print qq( selected);}
	print qq(>Yes<option value="no");
	if($lock eq "n"){print qq( selected);}
	print qq(>No</select><input name="id$i" type="hidden" value="$id"></td></tr>\n);
	}
print qq(<tr><td class="prgout" align=center colspan=8><input type="submit" value="Update"></td></tr>
</table>
<input name="lock" type="hidden" value="$i">
<input name="do" type="hidden" value="Lock Fraud">
</form>);
&Bottom;
}

##

sub Lock_Fraud_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'FM3'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Fraudscreen Lock Management</td></tr>
<tr><td class="prgout" align=left>Search Term</td>
<td class="prgout" align=left><input name="sterm" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left>Search Options</td>
<td class="prgout" align=left><select name="option" size=1><option value="email">Email<option value="ip">IP<option value="ccnum">Credit Card Number
<option value="domain">Domain<option value="phone">Phone</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Search"></td></tr>
</table>
<input name="do" type="hidden" value="Lock Fraud Search">
</form>);
&Bottom;
}

##

sub Remove_Fraud
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'FM2'} ne "yes")){&Error('Insufficient access for this function');}
my($i,@rem);
for($i=1;$i<=$FORM{'rem'};$i++)
	{
	if($FORM{"rem$i"}){push(@rem,$FORM{"rem$i"});}
	}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM fraudscreen WHERE id=');
$statement.=join("' || id='",@rem);
$statement.=qq(');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Fraudscreen entry removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Fraud_Search
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'FM2'} ne "yes")){&Error('Insufficient access for this function');}
my($sterm)=$FORM{'sterm'};
$sterm=~s/\'/\\'/g;
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT DISTINCT id,email,ip,domain,phone,reason,pdate,`lock` FROM fraudscreen WHERE);
if($FORM{'option'} eq "email"){$statement.=qq( email LIKE '%$sterm%');}
if($FORM{'option'} eq "ip"){$statement.=qq( ip='$sterm%');}
if($FORM{'option'} eq "ccnum"){$statement.=qq( ccnum=password('$sterm'));}
if($FORM{'option'} eq "domain"){$statement.=qq( domain='$sterm');}
if($FORM{'option'} eq "phone"){$statement.=qq( phone LIKE '%$sterm%');}
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$email,$ip,$domain,$phone,$reason,$pdate,$lock);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to delete these fraudscreen entries?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<form action="$script" method="Post" onSubmit="return ConFirm()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=8>Remove Fraudscreen Flag Entry</td></tr>
<tr><td class="headb" align=left>Email Address</td>
<td class="headb" align=left>IP Address</td>
<td class="headb" align=left>Domain</td>
<td class="headb" align=left>Phone</td>
<td class="headb" align=left>Reason</td>
<td class="headb" align=left>Post Date</td>
<td class="headb" align=left>Lock Status</td>
<td class="headb" align=left>Remove?</td></tr>\n);
my($i);
while(($id,$email,$ip,$domain,$phone,$reason,$pdate,$lock)=$query_output->fetchrow)
	{
	$i++;
	print qq(<tr><td class="prgout" align=left>$email</td>
<td class="prgout" align=left>$ip</td>
<td class="prgout" align=left>$domain</td>
<td class="prgout" align=left>$phone</td>
<td class="prgout" align=left>$reason</td>
<td class="prgout" align=left>$pdate</td>
<td class="prgout" align=left>);
	if($lock eq "y"){print qq(Yes);}
	else{print qq(No);}
	print qq(</td>
<td class="prgout" align=left><input name="rem$i" type="checkbox" value="$id"></td></tr>\n);
	}
print qq(<tr><td class="prgout" align=center colspan=8><input type="submit" value="Remove"></td></tr>
</table>
<input name="rem" type="hidden" value="$i">
<input name="do" type="hidden" value="Remove Fraud">
</form>);
&Bottom;
}

##

sub Remove_Fraud_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'FM2'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center BORDER cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Fraudscreen Flag Entry</td></tr>
<tr><td class="prgout" align=left>Search Term</td>
<td class="prgout" align=left><input name="sterm" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left>Search Options</td>
<td class="prgout" align=left><select name="option" size=1><option value="email">Email<option value="ip">IP<option value="ccnum">Credit Card Number
<option value="domain">Domain<option value="phone">Phone</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Search"></td></tr>
</table>
<input name="do" type="hidden" value="Remove Fraud Search">
</form>);
&Bottom;
}

##

sub Add_Fraud
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'FM1'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'reason'}=~s/\'/\\'/g;
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($sec) == 1){$sec="0".$sec;}
if(length($min) == 1){$min="0".$min;}
if(length($mon) == 1){$mon="0".$mon;}
if(length($mday) == 1){$mday="0".$mday;}
my($date)=qq($year-$mon-$mday $hour:$min:$sec);
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(INSERT INTO fraudscreen (email,ip,ccnum,domain,phone,pdate,reason,`lock`) VALUES 
('$FORM{'email'}','$FORM{'ip'}',password('$FORM{'ccnum'}'),'$FORM{'domain'}','$FORM{'phone'}','$date','$FORM{'reason'}','$FORM{'lock'}'));
#print "content-type:  text/plain\n\n";
#print $statement;
#exit;
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Fraudscreen entry added</td></tr>
</table>);
&Bottom;
}

##

sub Add_Fraud_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'FM1'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Fraudscreen Flag Entry</td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><input name="email" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left>IP Address</td>
<td class="prgout" align=left><input name="ip" type="text" size=15,1 maxlength=15></td></tr>
<tr><td class="prgout" align=left>Credit Card Number</td>
<td class="prgout" align=left><input name="ccnum" type="text" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input name="domain" type="text" size=50,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left>Phone</td>
<td class="prgout" align=left><input name="phone" type="text" size=20,1></td></tr>
<tr><td class="prgout" align=left Valign="top">Reason</td>
<td class="prgout" align=left Valign=top> <textarea name="reason" rows=15 cols=30></textarea></td></tr>
<tr><td class="prgout" align=left>Lock Entry?</td>
<td class="prgout" align=left><input name="lock" type="radio" value="n" checked>No <input name="lock" type="radio" value="y">Yes</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Entry"></td></tr>
</table>
<input name="do" type="hidden" value="Add Fraud">
</form>);
&Bottom;
}

##

sub Accept_Registration
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT registryid FROM `registry_pending` WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($registryid)=$query_output->fetchrow;
my($form_data);
require "opensrs.pl";
&Delete_Pending($db,$FORM{'domain'});
&Register_Domain($db);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Domain registration accepted</td></tr>
</table>);
&Bottom;
}

##

sub Reject_Registration
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
do "opensrs.pl";
&Delete_Pending($db,$FORM{'domain'});
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Domain registration rejected</td></tr>
</table>);
&Bottom;
}

##

sub View_Pending_Reg
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT registryid FROM `registry_pending` WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($registryid)=$query_output->fetchrow;
do "opensrs.pl";
my($response)=&Retrieve_Pending($registryid);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to delete domain registration?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Pending Domain Registration</td></tr>
<tr><td class="prgout" align=left>Domain Name</td>
<td class="prgout" align=left>$response->{attributes}->{field_hash}->{domain}<input name="domain" type="hidden" value="$response->{attributes}->{field_hash}->{domain}"></td></tr>
<tr><td class="prgout" align=left>First Name</td>
<td class="prgout" align=left><input name="firstname" type="text" value="$response->{attributes}->{field_hash}->{owner_first_name}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Last Name</td>
<td class="prgout" align=left><input name="lastname" type="text" value="$response->{attributes}->{field_hash}->{owner_last_name}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Organization</td>
<td class="prgout" align=left><input name="organization" type="text" value="$response->{attributes}->{field_hash}->{owner_org_name}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Address 1</td>
<td class="prgout" align=left><input name="address1" type="text" value="$response->{attributes}->{field_hash}->{owner_address1}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Address 2</td>
<td class="prgout" align=left><input name="address2" type="text" value="$response->{attributes}->{field_hash}->{owner_address2}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Address 3</td>
<td class="prgout" align=left><input name="address3" type="text" value="$response->{attributes}->{field_hash}->{owner_address3}" size=30,1></td></tr>
<tr><td class="prgout" align=left>City</td>
<td class="prgout" align=left><input name="city" type="text" value="$response->{attributes}->{field_hash}->{owner_city}" size=30,1></td></tr>
<tr><td class="prgout" align=left>State</td>
<td class="prgout" align=left><input name="state" type="text" value="$response->{attributes}->{field_hash}->{owner_state}" size=30,1></td></tr>
<tr><td class="prgout" align=left>Country</td>
<td class="prgout" align=left><select name="country" size=1>);
open(FILE,"countries.dat");
while(<FILE>)
	{
	chomp($_);
	my(@info)=split(/:/,$_);
	print qq(<option value="$info[0]");
	if($info[0] eq $response->{attributes}->{field_hash}->{owner_country}){print qq ( selected);}
	print qq(>$info[1]);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left>Postal Code</td>
<td class="prgout" align=left><input name="zip" type="text" value="$response->{attributes}->{field_hash}->{owner_postal_code}" size=15,1></td></tr>
<tr><td class="prgout" align=left>Phone Number</td>
<td class="prgout" align=left><input name="phone" type="text" value="$response->{attributes}->{field_hash}->{owner_phone}" size=20,1></td></tr>
<tr><td class="prgout" align=left>Fax Number</td>
<td class="prgout" align=left><input name="fax" type="text" value="$response->{attributes}->{field_hash}->{owner_fax}" size=20,1></td></tr>
<tr><td class="prgout" align=left>Email</td>
<td class="prgout" align=left><input name="email" type="text" value="$response->{attributes}->{field_hash}->{owner_email}" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input name="do" type="submit" value="Reject Registration" onClick="return ConFirm()"> * <input name="do" type="submit" value="Accept Registration"></td></tr>
</table>
<input name="years" type="hidden" value="$response->{attributes}->{field_hash}->{period}">
<input name="id" type="hidden" value="$FORM{'id'}">
</form>);
&Bottom;
}

##

sub Pending_Registrations
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain,regtext FROM `registry_pending` WHERE error='y' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain,$regtext);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Pending Domain Registrations</td></tr>
<tr><td class="headb" align=left>Domain</td>
<td class="headb" align=left>Registration Text</td></tr>\n);
while(($id,$domain,$regtext)=$query_output->fetchrow)
	{
	print qq(<tr><td class="prgout" align=left><a href="$script?do=view+pending+reg&id=$id" class="prgout">$domain</a></td>
<td class="prgout" align=left>$regtext</td></tr>\n);
	}
print qq(</table>);
&Bottom;
}

##

sub Accept_Pending
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT admin,domain,package,storage,transfer,pop,popspace,responder,mysql,subs,billing,forward,forwardto,dedicated,regyear,ccfname,
cclastname,ccaddress,cccity,ccstate,cczip,cccountry,ccphone,ccemail,ccnum,ccexp,cvv2,amount,pools FROM pending WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($admin,$domain,$package,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$billing,$forward,$forwardto,$dedicated,$regyear,$ccfname,$cclname,$ccaddress,$cccity,$ccstate,$cczip,$cccountry,$ccphone,$ccemail,$ccnum,$ccexp,$cvv2,$amount,$pools)=$query_output->fetchrow;
my($cipher);
if($ccnum)
	{
	if(&decode_base64($ccnum) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$ccnum=$cipher->decrypt(&decode_base64($ccnum));
	}
if($cvv2)
	{
	if(&decode_base64($cvv2) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$cvv2=$cipher->decrypt(&decode_base64($cvv2));
	}
my($ua,$h,$c,$req,$res,$response,$error);
use LWP::UserAgent;
$ua = new LWP::UserAgent;
$h = new HTTP::Headers;
$c = qq(x_Login=$system{'authnetlogin'}&x_Version=$system{'authnetver'}&x_ADC_Relay_Response=TRUE&x_ADC_URL=FALSE&&x_ADC_Delim_Data=TRUE&x_ADC_Delim_Character=|);
$c .= qq(&x_Email_Customer=$system{'emailcust'}&x_Method=CC&x_Type=AUTH_CAPTURE);
$c .= qq(&x_Card_Num=$ccnum&x_Exp_Date=$ccexp&x_First_Name=$ccfname);
$c .= qq(&x_Last_Name=$cclname&x_Address=$ccaddress&x_City=$cccity&x_State=$ccstate);
$c .= qq(&x_Zip=$cczip&x_Description=Web+Hosting+signup+for+domain+$domain&x_Amount=$amount&x_Email=$ccemail);
#$c .= qq(&x_Test_Request=TRUE);
$h->content_type('application/x-www-form-urlencoded');
$h->content_length(length($c));
$req = new HTTP::Request('POST', 'https://secure.authorize.net/gateway/transact.dll', $h, $c);
#$q=new HTTP::Request('POST','https://dev.red-dragon.com/hosting/trans.cgi',$h,$c);
$res=$ua->request($req);
if(!$res->is_success)
	{
	$error=$res->status_line;
	&Error($error);
	}
$response = $res->content;
my(@info)=split(/\|/,$response);
my($time)=time;
$statement=qq(INSERT INTO transaction (transtime,status,statustext,authcode,avscode,transid,firstname,lastname,street,city,state,zip,amount,description,domain) VALUES
('$time','$info[0]','$info[3]','$info[4]','$info[5]','$info[6]','$info[13]','$info[14]','$info[16]','$info[17]','$info[18]','$info[19]','$info[9]','$info[8]','$Cookies{'domain'}'));
$db->query($statement);
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
my($tid)=$query_output->fetchrow;
if($error=$db->errmsg){&Error($error);}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min) ==1){$min="0".$min;}
if(length($sec) ==1){$sec="0".$sec;}
my($date)=qq($year-$mon-$mday);
$time=qq($hour:$min:$sec);
if($info[0] ne "1")
	{
	&Top;
	print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Credit card processing declined: $response</td></tr>
</table>\n);
	&Bottom;
	}
#if(($system{'usesrs'} eq "yes")&&($regyear > 0)){do "opensrs.pl";&Register_Pending($db,$domain);}
$statement=qq(SELECT server FROM resource_list WHERE pools LIKE 
'%|$pools|%' && maxaccounts > usedaccounts && maxspace > usedspace+$storage+($pop*$popspace) && maxspace > totspace
&& maxbandwidth > usedbandwidth && maxbandwidth > usedbandwidth+$transfer && maxbandwidth > totbandwidth);
if($package ne "1"){$statement.=qq( && mail='yes');}
if($dedicated eq "yes"){$statement.=qq( && availdedips > 0);}
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@servers)=$query_output->fetchrow_array;
serverstart:
if(!$servers[0])
	{
	$statement=qq(SELECT server FROM resource_list WHERE pools LIKE '%|$pools|%' && maxaccounts > usedaccounts LIMIT 0,1);
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($test)=$query_output->fetchrow;
	if(!$test){&Error("Unable to add account. Servers max accounts have been exceeded");}
	$statement=qq(SELECT server FROM resource_list WHERE pools LIKE '%|$pools|%' && (maxspace > usedspace+$storage+($pop*$popspace) || maxspace > totspace) LIMIT 0,1);
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($test)=$query_output->fetchrow;
	if(!$test){&Error("Unable to add account. Servers max allocated space has been exceeded");}
	$statement=qq(SELECT server FROM resource_list WHERE pools LIKE '%|$pools|%' && (maxbandwidth > usedbandwidth || maxbandwidth > totbandwidth) LIMIT 0,1);
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($test)=$query_output->fetchrow;
	if(!$test){&Error("Unable to add account. Servers max allocated bandwidth has been exceeded");}
	$statement=qq(SELECT server FROM resource_list WHERE pools LIKE '%|$pools|%' && availdedips > 0 LIMIT 0,1);
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($test)=$query_output->fetchrow;
	if(!$test){&Error("Unable to add account. There are no availble dedicated IPs");}
	}
my($newip);
if($dedicated eq "yes")
	{
	$statement=qq(SELECT dedips FROM server WHERE id='$servers[0]');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($dedips)=$query_output->fetchrow;
	my(@dedips)=split(/\n/,$dedips);
	my(@availips);
	my($i);
	foreach(@dedips)
		{
		chomp($_);
		if($_ =~ /-/)
			{
			my($start,$stop)=split(/-/,$_);
			my(@info)=split(/\./,$start);
			for($i=$info[3];$i<=$stop;$i++)
				{
				push(@availips,"$info[0].$info[1].$info[2].$i");
				}
			}
		else
			{
			push(@availips,$_);
			}
		}
	my($newavail);
	for($i=1;$i<=$#availips;$i++){$newavail.=qq($availips[$i]\n);}
	chomp($newavail);
	$statement=qq(UPDATE server SET dedips='$newavail' WHERE id='$servers[0]');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$newip=$availips[0];
	}
else
	{
	$statement=qq(SELECT sharedip FROM server WHERE id='$servers[0]');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$newip=$query_output->fetchrow;
	}
my($shared)="yes";
if($dedicated eq "yes"){$shared="no";}
my($totspace)=$storage+($pop*$popspace);
$statement=qq(SELECT storage,transfer,pop,popspace,responder,mysql,subs,price,setup,annual FROM packages WHERE id='$package');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($defstorage,$deftransfer,$defpop,$defpopspace,$defresponder,$defmysql,$defsubs,$realprice,$realsetup,$realannual)=$query_output->fetchrow;
$statement=qq(SELECT mailip FROM server WHERE id='$servers[0]');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($mailip)=$query_output->fetchrow;
$statement=qq(INSERT INTO domain_map (domain,server,billing,amount,billdate,ip,forward,forwardto,mx,mxip,enmail,enapache,
endns,ipshared,package,storage,transfer,pop,popspace,responder,mysql,subs,totspace)
VALUES \('$domain','$servers[0]','$billing',);
if($billing eq "M"){$statement.=qq('$realprice',DATE_ADD('$date', INTERVAL 1 MONTH),);}
else{$statement.=qq('$realannual',DATE_ADD('$date', INTERVAL 1 YEAR),);}
$statement.=qq('$newip','$forward','$'forwardto','','$mailip',);
if($package eq "1"){$statement.=qq('no','no',);}
else{$statement.=qq('yes','yes',);}
$statement.=qq('yes','$shared','$package','$storage','$transfer','$pop','$popspace','$responder','$mysql','$subs','$totspace'\));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id)=$query_output->fetchrow;
$statement=qq(UPDATE resource_list SET );
if($dedicated eq "yes"){$statement.=qq(availdedips=availdedips-1,);}
$statement.=qq(usedaccounts=usedaccounts+1,usedspace=usedspace+$storage+($pop*$popspace),usedbandwidth=usedbandwidth+$transfer WHERE server='$servers[0]');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO user_map (user,domain,server,admin,email,billing,ftp,web)
VALUES ('$admin','$id','$servers[0]','yes','yes','yes','yes','yes'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT price,annual FROM addon WHERE name='dedicated');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($dedprice,$anndedprice)=$query_output->fetchrow;
$statement=qq(INSERT INTO invoice (domid,domain,cdate) VALUES ('$id','$FORM{'domain'}','$date'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($invoice)=$query_output->fetchrow;
my($invtot);
if($billing eq "M")
	{
	$invtot=$realprice;
	if($package ne "1")
		{
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Web Hosting with $defstorage Meg Storage, $deftransfer Meg Transfer, $defpop Pop email accounts, $defpopspace disk space per pop account, $defresponder email autoresponders, $defmysql MySQL databases, $defsubs sub domains','$realprice'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		if($storage > $defstorage)
			{
			$statement=qq(SELECT price FROM addon WHERE name='storage');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($storage-$defstorage));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Disk Storage for Website - ).($storage-$defstorage).qq( Meg','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Disk Storage for Website - ).($storage-$defstorage).qq( Meg','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($transfer > $deftransfer)
			{
			$statement=qq(SELECT price FROM addon WHERE name='transfer');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($transfer-$deftransfer));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Transfer for Website - ).($transfer-$deftransfer).qq( Meg','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Transfer for Website - ).($transfer-$deftransfer).qq( Meg','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($pop > $defpop)
			{
			$statement=qq(SELECT price FROM addon WHERE name='pop');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($pop-$defpop));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Pop Accounts - ).($pop-$defpop).qq( account(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Pop Accounts - ).($pop-$defpop).qq( account(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($popspace > $defpopspace)
			{
			$statement=qq(SELECT price FROM addon WHERE name='popspace');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",($addonprice*($popspace-$defpopspace))*$pop);
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Pop Account Disk Space - ).($popspace-$defpopspace).qq( Meg per account','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Pop Account Disk Space - ).($popspace-$defpopspace).qq( Meg per account','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($responder > $defresponder)
			{
			$statement=qq(SELECT price FROM addon WHERE name='responder');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($responder-$defresponder));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Auto Responders - ).($responder-$defresponder).qq( account(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Auto Responders - ).($responder-$defresponder).qq( account(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($mysql > $defmysql)
			{
			$statement=qq(SELECT price FROM addon WHERE name='mysql');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($mysql-$defmysql));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra MySQL Database(s) - ).($mysql-$defmysql).qq( database(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra MySQL Database(s) - ).($mysql-$defmysql).qq( database(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($subs > $defsubs)
			{
			$statement=qq(SELECT price FROM addon WHERE name='subs');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($subs-$defsubs));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Sub Domain(s) - ).($subs-$defsubs).qq( sub domain(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Sub Domain(s) - ).($subs-$defsubs).qq( sub domain(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($dedicated eq "yes")
			{
			$statement=qq(SELECT price FROM addon WHERE name='dedicated');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Dedicated IP','$addonprice'));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Dedicated IP','$addonprice'));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$addonprice;
			}
		}
	elsif($package eq "1")
		{
		$statement=qq(SELECT price FROM addon WHERE name='Forward');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($price)=$query_output->fetchrow;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Domain Forward','$price'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Domain Forward','$price'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$invtot+=$price;
		}
	if($realsetup > 0)
		{
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Setup Fee','$realsetup'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$invtot+=$realsetup;
		}
	if($regyear == 1)
		{
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Domain Registration of $domain','$system{'regfee'}'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$invtot+=$system{'regfee'};
		}
	elsif($regyear > 1)
		{
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Domain Registration of $domain',').((($regyear*$system{'regfee'})*(100-$system{'regdiscount'}))/100).qq('\));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$invtot+=((($regyear*$system{'regfee'})*(100-$system{'regdiscount'}))/100);
		}
	$statement=qq(INSERT INTO accounting (domid,domain,amount) VALUES ('$id','$domain','0'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($statement);}
	$statement=qq(UPDATE invoice SET period=concat('$date to ',date_add('$date', INTERVAL 1 MONTH)),amount=$invtot,invbal='0' WHERE id='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(INSERT INTO payments (invoice,transtype,descr,amount,pdate,tid) VALUES ('$invoice','Credit Card','Online Payment','$amount','$date','$tid'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
else
	{
	$invtot=$realannual;
	if($package ne "1")
		{
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Web Hosting with $defstorage Meg Storage, $deftransfer Meg Transfer, $defpop Pop email accounts, $defpopspace disk space per pop account, $defresponder email autoresponders, $defmysql MySQL databases, $defsubs sub domains','$realannual'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		if($storage > $defstorage)
			{
			$statement=qq(SELECT annual FROM addon WHERE name='storage');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($storage-$defstorage));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Disk Storage for Website - ).($storage-$defstorage).qq( Meg','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Disk Storage for Website - ).($storage-$defstorage).qq( Meg','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($transfer > $deftransfer)
			{
			$statement=qq(SELECT annual FROM addon WHERE name='transfer');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($transfer-$deftransfer));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Transfer for Website - ).($transfer-$deftransfer).qq( Meg','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Transfer for Website - ).($transfer-$deftransfer).qq( Meg','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($pop > $defpop)
			{
			$statement=qq(SELECT annual FROM addon WHERE name='pop');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($pop-$defpop));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Pop Accounts - ).($pop-$defpop).qq( account(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Pop Accounts - ).($pop-$defpop).qq( account(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($popspace > $defpopspace)
			{
			$statement=qq(SELECT annual FROM addon WHERE name='popspace');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",($addonprice*($popspace-$defpopspace))*$pop);
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Pop Account Disk Space - ).($popspace-$defpopspace).qq( Meg per account','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Pop Account Disk Space - ).($popspace-$defpopspace).qq( Meg per account','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($responder > $defresponder)
			{
			$statement=qq(SELECT annual FROM addon WHERE name='responder');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($responder-$defresponder));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Auto Responders - ).($responder-$defresponder).qq( account(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Auto Responders - ).($responder-$defresponder).qq( account(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($mysql > $defmysql)
			{
			$statement=qq(SELECT annual FROM addon WHERE name='mysql');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($mysql-$defmysql));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra MySQL Database(s) - ).($mysql-$defmysql).qq( database(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra MySQL Database(s) - ).($mysql-$defmysql).qq( database(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($subs > $defsubs)
			{
			$statement=qq(SELECT annual FROM addon WHERE name='subs');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			my($totaladdon)=sprintf("%.2f",$addonprice*($subs-$defsubs));
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES \('$id','Extra Sub Domain(s) - ).($subs-$defsubs).qq( sub domain(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Extra Sub Domain(s) - ).($subs-$defsubs).qq( sub domain(s)','$totaladdon'\));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$totaladdon;
			}
		if($dedicated eq "yes")
			{
			$statement=qq(SELECT annual FROM addon WHERE name='dedicated');
			$query_output=$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			my($addonprice)=$query_output->fetchrow;
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Dedicated IP','$addonprice'));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Dedicated IP','$addonprice'));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$invtot+=$addonprice;
			}
		}
	if($package eq "1")
		{
		$statement=qq(SELECT annual FROM addon WHERE name='Forward');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($price)=$query_output->fetchrow;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Domain Forward','$price'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Domain Forward','$price'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$invtot+=$price;
		}
	if($realsetup > 0)
		{
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Setup Fee','$realsetup'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($regyear == 1)
		{
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Domain Registration of $domain','$system{'regfee'}'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$invtot+=$system{'regfee'};
		}
	elsif($regyear > 1)
		{
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES \('$invoice','Domain Registration of $domain',').((($regyear*$system{'regfee'})*(100-$system{'regdiscount'}))/100).qq('\));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$invtot+=((($regyear*$system{'regfee'})*(100-$system{'regdiscount'}))/100);
		}
	$statement=qq(INSERT INTO accounting (domid,domain,amount) VALUES ('$id','$domain','0'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE invoice SET period=concat('$date to ',DATE_ADD('$date', INTERVAL 1 YEAR)),amount=$invtot,invbal='0' WHERE id='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(INSERT INTO payments (invoice,transtype,descr,amount,pdate,tid) VALUES ('$invoice','Credit Card','Online Payment','$amount','$date','$tid'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$servers[0]');
$query_output=$db->query($statement);
my($ip,$port,$serverpass)=$query_output->fetchrow;
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$statement=qq(SELECT password,email,firstname,lastname FROM user WHERE id='$admin');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($password,$email,$firstname,$lastname)=$query_output->fetchrow;
if(&decode_base64($password) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$password=$cipher->decrypt(&decode_base64($password));
my($command)=qq(do=add+account&id=$id&domain=$domain&ip=$newip&password=$password&email=$email&package=$package&storage=$storage);
$command.=qq(&transfer=$transfer&pop=$pop&popspace=$popspace&responder=$responder&mysql=$mysql&subs=$subs);
if($package eq "1"){$command.=qq(&forward=$forward&forwardto=$forwardto&enmail=no&enapache=no);}
else{$command.=qq(&forward=no&enmail=yes&enapache=yes);}
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done")
	{
	if($dedicated eq "yes")
		{
		$statement=qq(SELECT dedips FROM server WHERE id='$servers[0]');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($oldinfo)=$query_output->fetchrow;
		if($oldinfo){$oldinfo.=qq(\n$newip);}
		else{$oldinfo=$newip;}
		$statement=qq(UPDATE server SET dedips='$oldinfo' WHERE id='$servers[0]');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	$statement=qq(DELETE FROM domain_map WHERE id='$id');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE resource_list SET );
	if($dedicated eq "yes"){$statement.=qq(availdedips=availdedips+1,);}
	$statement.=qq(usedaccounts=usedaccounts-1,usedspace=usedspace-$storage-($pop*$popspace),usedbandwidth=usedbandwidth-$transfer WHERE server='$servers[0]');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM recur_charge WHERE domain='$id');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM invoice WHERE domain='$id');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM charges WHERE invoice='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM payments WHERE invoice='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM accounting WHERE domid='$id');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	splice(@servers,0,1);
	&Error($remote{'status'});
#	goto serverstart;
	}
if(!$mailip){$mailip=$newip;}
if($system{'usens1'} eq "yes")
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns1');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=add+domain&domain=$domain&ip=$newip&mailip=$mailip);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done")
		{
		&Error("Account created on hosting server but unable to update name server, $remote{'status'}");
		}
	}
if($system{'usens2'} eq "yes")
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns2');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=add+domain&domain=$domain);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done")
		{
		&Error("Account created on hosting server but unable to update name server, $remote{'status'}");
		}
	}
$statement=qq(INSERT INTO billing_info (name,address,city,state,zip,domain,email,phone) VALUES ('$ccfname $cclname','$ccaddress',
'$cccity','$ccstate','$cczip','$id','$ccemail','$ccphone'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO actionlog (action,adate,admin,comments) VALUES ('Domain $domain: added','$date $time','Online signup','Online signup'));
$db->query($statement);
if($error=$db->errmsg){return("status=$error");}
my($message)=qq($firstname $lastname,
Your domain, $domain, has been setup on the server.
You can log into the client control panel at $system{'clienturl'} to manage this domain.\n);
if($regyear > 0)
	{
	$message.=qq(This domain is newly registered and will take 12-24 hours before the internet knows of the new domain.\n);
	}
&send_mail($system{'adminemail'},"$firstname $lastname <$email>","Domain signup for $domain",$message);
$statement=qq(DELETE FROM pending WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Pending_Signups;
}

##

sub Reject_Pending
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain FROM pending WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain)=$query_output->fetchrow;
if($system{'usesrs'} eq "yes"){do "opensrs.pl";&Delete_Pending($db,$domain);}
$statement=qq(DELETE FROM pending WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Pending_Signups;
}

##

sub Review_Domain
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT user.email,user.firstname,user.lastname,pending.domain,packages.name,pending.storage,pending.transfer,pending.pop,pending.popspace,
pending.responder,pending.mysql,pending.subs,pending.billing,pending.forward,pending.forwardto,pending.dedicated,pending.regyear,pending.fraudid,
pending.ip,pending.ccfname,pending.cclastname,pending.ccaddress,pending.cccity,pending.ccstate,pending.cczip,pending.cccountry,pending.ccphone,
pending.ccemail,pending.amount,pending.ccnum FROM user,pending,packages WHERE pending.id='$FORM{'id'}' && pending.package=packages.id);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($email,$firstname,$lastname,$domain,$package,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$billing,$forward,$forwardto,$dedicated,$regyear,$fraudid,$ip,$ccfname,$cclname,$ccaddress,$cccity,$ccstate,$cczip,$cccountry,$ccphone,$ccemail,$amount,$ccnum)=$query_output->fetchrow;
my($cipher);
if($ccnum)
	{
	if(&decode_base64($ccnum) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$ccnum=$cipher->decrypt(&decode_base64($ccnum));
	}
eval "use Geo::IP";
my($ipcountry,$ipcity);
if($@ !~ /Can't Locate/)
	{
	my $gi = Geo::IP->new("GEOIP_STANDARD");
	$ipcountry=$gi->country_name_by_addr($ip);
	eval("$ipcity=$gi->record_by_addr($ip)");
	}
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to reject this signup?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Review Signup for Domain, $domain</td></tr>
<tr><td class="prgout" align=left>Administrator</td>
<td class="prgout" align=left><a href="mailto:$firstname $lastname &lt;$email&gt;" class="prgout">$firstname $lastname</a></td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left>$domain</td></tr>
<tr><td class="prgout" align=left>Hosting Package</td>
<td class="prgout" align=left>$package</td></tr>
<tr><td class="prgout" align=left>Web Storage</td>
<td class="prgout" align=left>$storage Meg</td></tr>
<tr><td class="prgout" align=left>Web Transfer</td>
<td class="prgout" align=left>$transfer Meg</td></tr>
<tr><td class="prgout" align=left>POP3 Email Account(s)</td>
<td class="prgout" align=left>$pop</td></tr>
<tr><td class="prgout" align=left>POP3 Disk Space (per account)</td>
<td class="prgout" align=left>$popspace Meg</td></tr>
<tr><td class="prgout" align=left>Email Auto Responder(s)</td>
<td class="prgout" align=left>$responder</td></tr>
<tr><td class="prgout" align=left>MySQL Database(s)</td>
<td class="prgout" align=left>$mysql</td></tr>
<tr><td class="prgout" align=left>Sub Domain(s)</td>
<td class="prgout" align=left>$subs</td></tr>
<tr><td class="prgout" align=left>Billing Cycle</td>
<td class="prgout" align=left>);
if($billing eq "M"){print qq(Monthly);}
else{print qq(Annually);}
print qq(</td></tr>\n);
if($package eq "1")
	{
	print qq(<tr><td class="prgout" align=left>Forward Style</td>
<td class="prgout" align=left>$forward</td></tr>
<tr><td class="prgout" align=left>Forward To</td>
<td class="prgout" align=left>$forwardto</td></tr>\n);
	}
print qq(<tr><td class="prgout" align=left>Dedicated IP?</td>
<td class="prgout" align=left>);
if($dedicated eq "yes"){print qq(Yes);}
else{print qq(No);}
print qq(</td></tr>\n);
if($regyear > 0)
	{
	print qq(<tr><td class="prgout" align=left>Domain Registration Term</td>
<td class="prgout" align=left>$regyear</td></tr>\n);
	}
print qq(<tr><td class="prgout" align=left Valign=top>Fraud ID Flags</td>
<td class="prgout" align=left>);
my(@flags)=split(/\|/,$fraudid);
$statement=qq(SELECT email,ip,ccnum,domain,phone,reason FROM fraudscreen WHERE id=');
$statement.=join("' && id='",@flags);
$statement.=qq(');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($femail,$fip,$fccnum,$fdomain,$fphone,$freason);
while(($femail,$fip,$fccnum,$fdomain,$fphone,$freason)=$query_output->fetchrow)
	{
	if($femail){print qq(Email match - $femail<br>\n);}
	if($fip){print qq(IP match - $fip<br>\n);}
#	$fccnum=$cipher->decrypt(&decode_base64($fccnum));
	if($fccnum){print qq(CC Num match - $ccnum<br>\n);}
	if($fdomain){print qq(Domain match - $fdomain<br>\n);}
	if($fphone){print qq(Phone match - $fphone<br>\n);}
	if($freason){print qq(Reason - $freason\n);}
	print qq(<br><br>\n);
	}
print qq(</td></tr>
<tr><td class="prgout" align=left>Submitters IP</td>
<td class="prgout" align=left>$ip);
if($ipcountry)
	{
	print qq( in);
	if($ipcity){print qq( $ipcity,);}
	print qq( $ipcountry);
	}
else
	{
	print qq(<br><font size=-2>Install <a href="http://www.maxmind.com/" target="_new" class="prgout">GeoIP</a> for geographic information about IP address.</font>);
	}
print qq(</td></tr>
<tr><td class="prgout" align=left>Name on Credit Card</td>
<td class="prgout" align=left>$ccfname $cclname</td></tr>
<tr><td class="prgout" align=left>Address on Credit Card</td>
<td class="prgout" align=left>$ccaddress</td></tr>
<tr><td class="prgout" align=left>City on Credit Card</td>
<td class="prgout" align=left>$cccity</td></tr>
<tr><td class="prgout" align=left>State on Credit Card</td>
<td class="prgout" align=left>$ccstate</td></tr>
<tr><td class="prgout" align=left>Zip/Postal Code on Credit Card</td>
<td class="prgout" align=left>$cczip</td></tr>
<tr><td class="prgout" align=left>Country on Credit Card</td>
<td class="prgout" align=left>$cccountry</td></tr>
<tr><td class="prgout" align=left>Phone on Credit Card</td>
<td class="prgout" align=left>$ccphone</td></tr>
<tr><td class="prgout" align=left>Amount of Transaction</td>
<td class="prgout" align=left>$amount</td></tr>
<tr><td class="prgout" align=center colspan=2><input name="do" type="submit" value="Reject Pending" onClick="return ConFirm()"> * <input name="do" type="submit" value="Accept Pending"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
</form>);
&Bottom;
}

##

sub Pending_Signups
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT user.firstname,user.lastname,user.email,pending.domain,pending.id FROM user,pending WHERE pending.admin=user.id ORDER BY pending.domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($test)=($query_output->execute)+0;
my($firstname,$lastname,$email,$domain,$id);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=3>Pending Online Signups</td></tr>
<tr><td class="headb" align=left>Domain</td>
<td class="headb" align=left>Name</td>
<td class="headb" align=left>Email</td></tr>\n);
while(($firstname,$lastname,$email,$domain,$id)=$query_output->fetchrow)
	{
	print qq(<tr><td class="prgout" align=left><a href="$script?do=review+domain&id=$id" class="prgout">$domain</a></td>
<td class="prgout" align=left>$firstname $lastname</td>
<td class="prgout" align=left><a href="mailto:$email" class="prgout">$email</a></td></tr>\n);
	}
if(!$test){print qq(<tr><td class="prgout" align=left colspan=3>There are no pending signups</td></tr>\n);}
print qq(</table>);
&Bottom;
}

1;
