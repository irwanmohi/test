sub Change_Package
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM14'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT server,domain,package,storage,transfer,pop,popspace,responder,mysql,subs,amount,billing,billdate FROM domain_map WHERE id='$FORM{'id'}' && reseller='0');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($server,$domain,$package,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$amount,$billing,$billdate)=$query_output->fetchrow;
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$server');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$statement=qq(SELECT amount FROM recur_charge WHERE description like 'Extra%' && domain='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($credit)=$amount;
my($addcredit);
while(($addcredit)=$query_output->fetchrow)
	{
	$credit+=$addcredit;
	}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if($billing eq "M")
	{
	my(@date)=split(/-/,$billdate);
	if($date[2] > $mday){$credit=sprintf("%.2f",($date[2]-$mday)/30*$credit);}
	else{$credit=sprintf("%.2f",(30-($mday-$date[2]))/30*$credit);}
	}
else
	{
	use Time::Local;
	my($year,$mon,$mday)=split(/-/,$billdate);
	$mon--;
	my($time)=time;
	my($unixbilldate)=timelocal(0,0,0,$mday,$mon,$year);
	my($credittime)=($unixbilldate-$time)/86400;
	$credit=sprintf("%.2f",(($credittime/365.24)*$credit));
	}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
my($command)=qq(do=update+package&domain=$domain&domid=$FORM{'id'}&package=$FORM{'pac'}&storage=$FORM{'storage'});
$command.=qq(&transfer=$FORM{'transfer'}&pop=$FORM{'pop'}&popspace=$FORM{'popspace'}&responder=$FORM{'responder'}&mysql=$FORM{'mysql'});
$command.=qq(&subs=$FORM{'subs'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$statement=qq(UPDATE domain_map SET package='$FORM{'pac'}',storage='$FORM{'storage'}',transfer='$FORM{'transfer'}',pop='$FORM{'pop'}',popspace='$FORM{'popspace'}',
responder='$FORM{'responder'}',mysql='$FORM{'mysql'}',subs='$FORM{'subs'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($command)=qq(do=get+email+quota&domid=${'id'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
my(@popspace)=split(/:/,$remote{'emails'});
$statement=qq(SELECT storage,transfer,pop,popspace,responder,mysql,subs,price,annual FROM packages WHERE id='$FORM{'pac'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($cstorage,$ctransfer,$cpop,$cpopspace,$cresponder,$cmysql,$csubs,$cprice,$cannual)=$query_output->fetchrow;
my($total,$chargenotes);
my($time)=time;
$statement=qq(SELECT amount FROM accounting WHERE domid='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($prevbal)=$query_output->fetchrow;
if($FORM{'billing'} eq "M")
	{
	my($unitcost);
	$total+=$cprice;
	my($curdate)=qq($year-$mon-$mday);
	$mon++;
	if($mon > 12){$mon="01";$year++};
	my($newdate)=qq($year-$mon-$mday);
	$statement=qq(INSERT INTO invoice (domid,domain,period,prevbal,cdate) VALUES ('$FORM{'id'}','$domain','$curdate to $newdate','$prevbal','$curdate'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(SELECT LAST_INSERT_ID());
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($invoice)=$query_output->fetchrow;
	$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Hosting for $domain with $cstorage Meg Storage, $ctransfer Meg Transfer, $cpop Pop email account(s), $popspace disk space per pop account, $cresponder email autoresponder(s), $cmysql MySQL database(s), $csubs sub domain(s)','$cprice'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM recur_charge WHERE description like 'Extra%' && domain='$domain');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	if($FORM{'storage'} > $cstorage)
		{
		$statement=qq(SELECT price FROM addon WHERE name='storage');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'storage'}-$cstorage)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'storage'}-$cstorage;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Storage for website - $addon Meg','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Storage for website - $addon Meg','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'transfer'} > $ctransfer)
		{
		$statement=qq(SELECT price FROM addon WHERE name='transfer');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'transfer'}-$ctransfer)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'transfer'}-$ctransfer;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Transfer for Website - $addon Meg','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Transfer for Website - $addon Meg','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'pop'} > $cpop)
		{
		$statement=qq(SELECT price FROM addon WHERE name='pop');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'pop'}-$cpop)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'pop'}-$cpop;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Pop Accounts - $addon account(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Pop Accounts - $addon account(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'popspace'} > $cpopspace)
		{
		$statement=qq(SELECT price FROM addon WHERE name='popspace');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'popspace'}-$cpopspace)*$unitcost*$FORM{'pop'};
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'popspace'}-$cpopspace;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Pop Account Disk Space - $addon Meg per account','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Pop Account Disk Space - $addon Meg per account','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	$statement=qq(SELECT price FROM addon WHERE name='popspace');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$unitcost=$query_output->fetchrow;
	foreach(@popspace)
		{
		my(@info)=split(/\|/,$_);
		if($info[3] > $FORM{'popspace'})
			{
			my($extra)=($info[3]-$FORM{'popspace'})*$unitcost;
			$total+=$extra;
			$extra=sprintf("%.2f",$extra);
			my($addon)=$info[3]-$FORM{'popspace'};
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra email disk space for $info[2] - $addon Meg','$extra'));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra email disk space for $info[2] - $addon Meg','$extra'));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			}
		}
	if($FORM{'responder'} > $cresponder)
		{
		$statement=qq(SELECT price FROM addon WHERE name='responder');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'responder'}-$cresponder)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'responder'}-$cresponder;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Auto Responders - $addon account(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Auto Responders - $addon account(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'mysql'} > $cmysql)
		{
		$statement=qq(SELECT price FROM addon WHERE name='mysql');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'mysql'}-$cmysql)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'mysql'}-$cmysql;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra MySQL Database(s) - $addon database(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra MySQL Database(s) - $addon database(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'subs'} > $csubs)
		{
		$statement=qq(SELECT price FROM addon WHERE name='subs');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'subs'}-$csubs)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'subs'}-$csubs;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Sub Domain - $addon sub domain(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Sub Domain - $addon sub domain(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	$statement=qq(UPDATE domain_map SET billdate='$newdate',amount='$cprice',billing='M' WHERE id='$FORM{'id'}}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE invoice SET amount='$total',invbal='$total' WHERE id='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE accounting SET amount=amount+$total WHERE domid='$FORM{'id'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(SELECT id,invbal FROM invoice WHERE domid='$FORM{'id'}' && invbal > 0 ORDER BY id ASC);
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($invid,$invbal);
	while(($invid,$invbal)=$query_output->fetchrow)
		{
		my($newpay);
		if($credit-$invbal > 0){$statement=qq(UPDATE invoice SET invbal=0 WHERE id='$invid');$credit-=$invbal;$newpay=$invbal;}
		else{$statement=qq(UPDATE invoice SET invbal=invbal-$credit WHERE id='$invid');$newpay=$credit;$credit=0;}
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO payments (invoice,transtype,descr,amount,pdate) VALUES ('$invid','Other','Credit for remaining hosting on package change','$newpay','$curdate'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(UPDATE accounting SET amount=amount-$newpay WHERE domid='$FORM{'id'}');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		if($credit <= 0){last;}
		}
	if($credit > 0)
		{
		$statement=qq(INSERT INTO invoice (domid,domain,amount,cdate,invbal) VALUES ('$FORM{'id'}','$domain','-$credit','$curdate','-$credit'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(SELECT LAST_INSERT_ID());
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($nid)=$query_output->fetchrow;
		$statement=qq(INSERT INTO payments (invoice,transtype,descr,amount,pdate) VALUES ('$nid','Other','Credit for remaining hosting on package change','$credit','$curdate'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(UPDATE accounting SET amount=amount-$credit WHERE domid='$FORM{'id'}');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	$statement=qq(UPDATE invoice SET amount='$total',invbal='$total' WHERE id='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	if($prevbal < 0)
		{
		$statement=qq(UPDATE invoice SET invbal=invbal+$prevbal WHERE id='$invoice');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	}
else
	{
	my($unitcost);
	$total+=$cannual;
	my($curdate)=qq($year-$mon-$mday);
	$year++;
	my($newdate)=qq($year-$mon-$mday);
	$statement=qq(INSERT INTO invoice (domid,domain,period,prevbal,cdate) VALUES ('$FORM{'id'}','$domain','$curdate to $newdate','$prevbal','$curdate'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(SELECT LAST_INSERT_ID());
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($invoice)=$query_output->fetchrow;
	$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Hosting for $domain with $cstorage Meg Storage, $ctransfer Meg Transfer, $cpop Pop email account(s), $popspace disk space per pop account, $cresponder email autoresponder(s), $cmysql MySQL database(s), $csubs sub domain(s)','$cannual'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM recur_charge WHERE description like 'Extra%' && domain='$FORM{'id'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	if($FORM{'storage'} > $cstorage)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='storage');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'storage'}-$cstorage)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'storage'}-$cstorage;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Disk Storage for Website - $addon Meg','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Disk Storage for Website - $addon Meg','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'transfer'} > $ctransfer)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='transfer');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'transfer'}-$ctransfer)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'transfer'}-$ctransfer;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Transfer for Website - $addon Meg','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Transfer for Website - $addon Meg','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'pop'} > $cpop)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='pop');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'pop'}-$cpop)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'pop'}-$cpop;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Pop Accounts - $addon account(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Pop Accounts - $addon account(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'popspace'} > $cpopspace)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='popspace');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'popspace'}-$cpopspace)*$unitcost*$FORM{'pop'};
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'popspace'}-$cpopspace;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Pop Account Disk Space - $addon Meg per account','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Pop Account Disk Space - $addon Meg per account','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	$statement=qq(SELECT annual FROM addon WHERE name='popspace');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$unitcost=$query_output->fetchrow;
	foreach(@popspace)
		{
		my(@info)=split(/\|/,$_);
		if($info[3] > $FORM{'popspace'})
			{
			my($extra)=($info[3]-$FORM{'popspace'})*$unitcost;
			$extra=sprintf("%.2f",$extra);
			$total+=$extra;
			my($addon)=$info[3]-$FORM{'popspace'};
			$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra email disk space for $info[2] - $addon Meg','$extra'));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra email disk space for $info[2] - $addon Meg','$extra'));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			}
		}
	if($FORM{'responder'} > $cresponder)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='responder');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'responder'}-$cresponder)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'responder'}-$cresponder;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Auto Responders - $addon account(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Auto Responders - $addon account(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'mysql'} > $cmysql)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='mysql');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'mysql'}-$cmysql)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'mysql'}-$cmysql;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra MySQL Database(s) - $addon database(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra MySQL Database(s) - $addon database(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'subs'} > $csubs)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='subs');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$unitcost=$query_output->fetchrow;
		my($extra)=($FORM{'subs'}-$csubs)*$unitcost;
		$extra=sprintf("%.2f",$extra);
		$total+=$extra;
		my($addon)=$FORM{'subs'}-$csubs;
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Extra Sub Domain - $addon sub domain(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Sub Domain - $addon sub domain(s)','$extra'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	$year++;
	$statement=qq(UPDATE domain_map SET billdate='$newdate',amount='$cannual',billing='A' WHERE id='$FORM{'id'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE invoice SET amount='$total',invbal='$total' WHERE id='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE accounting SET amount=amount+$total WHERE domid='$FORM{'id'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(SELECT id,invbal FROM invoice WHERE domid='$FORM{'id'}' && invbal > 0 ORDER BY id ASC);
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($invid,$invbal);
	while(($invid,$invbal)=$query_output->fetchrow)
		{
		my($newpay);
		if($credit-$invbal > 0){$statement=qq(UPDATE invoice SET invbal=0 WHERE id='$invid');$credit-=$invbal;$newpay=$invbal;}
		else{$statement=qq(UPDATE invoice SET invbal=invbal-$credit WHERE id='$invid');$newpay=$credit;$credit=0;}
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO payments (invoice,transtype,descr,amount,pdate) VALUES ('$invid','Other','Credit for remaining hosting on package change','$newpay','$curdate'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(UPDATE accounting SET amount=amount-$newpay WHERE domid='$FORM{'id'}');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		if($credit <= $credit){last;}
		}
	if($credit > 0)
		{
		$statement=qq(INSERT INTO invoice (domid,domain,amount,cdate,invbal) VALUES ('$FORM{'id'}','$domain','-$credit','$curdate','-$credit'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(SELECT LAST_INSERT_ID());
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($nid)=$query_output->fetchrow;
		$statement=qq(INSERT INTO payments (invoice,transtype,descr,amount,pdate) VALUES ('$nid','Other','Credit for remaining hosting on package change','$credit','$curdate'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(UPDATE accounting SET amount=amount-$credit WHERE domid='$FORM{'id'}');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	$statement=qq(UPDATE invoice SET amount='$total',invbal='$total' WHERE id='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	if($prevbal < 0)
		{
		$statement=qq(UPDATE invoice SET invbal=invbal+$prevbal WHERE id='$invoice');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	}
$statement=qq(SELECT id FROM recur_charge WHERE domain='$FORM{'id'}' && description="Discount");
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($did)=$query_output->fetchrow;
if($did)
	{
	if($FORM{'discount'}){$statement=qq(UPDATE recur_charge SET amount='-$FORM{'discount'}',cycle='$FORM{'cycle'}' WHERE id='$did');}
	else{$statement=qq(DELETE FROM recur_charge WHERE id='$did');}
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
else
	{
	if($FORM{'discount'}){$statement=qq(INSERT INTO recur_charge (domain,description,amount,cycle)  VALUES ('$FORM{'id'}','Discount','-$FORM{'discount'}','$FORM{'cycle'}'));}
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
&Start;
}

##

sub Change_Package2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM14'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$erro);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain,server,package,storage,transfer,pop,popspace,responder,mysql,subs,amount,billing,billdate FROM domain_map WHERE domain='$FORM{'domain'}' && reseller='0');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain,$server,$package,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$amount,$billing,$billdate)=$query_output->fetchrow;
if(!$id){&Error("$FORM{'domain'} isn't found");}
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$server');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$statement=qq(SELECT storage,transfer,pop,popspace,responder,mysql,subs,price,annual FROM packages WHERE id='$package');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($cstorage,$ctransfer,$cpop,$cpopspace,$cresponder,$cmysql,$csubs,$cprice,$cannual)=$query_output->fetchrow;
$statement=qq(SELECT amount,cycle FROM recur_charge WHERE domain='$id' && description="Discount");
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($discount,$discdur)=$query_output->fetchrow;
if($discount){$discount*=-1;}
&Top;
my($command)=qq(do=package+usage&domid=$id&domain=$FORM{'domain'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$command=qq(do=get+extra+pop+quota&id=$id);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
my(@popspace)=split(/\|/,$remote{'popspace'});
my($creditamount);
$statement=qq(SELECT id,name,storage,transfer,pop,popspace,responder,mysql,subs,price,annual FROM packages ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT description,amount FROM recur_charge WHERE domain='$id');
my($query_output2)=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT id,name,storage,transfer,pop,popspace,responder,mysql,subs,price,annual FROM packages ORDER BY name ASC);
my($query_output3)=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT name,price,annual FROM addon);
my($query_output4)=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
print qq(<script language="javascript">
<!--
var popcounts=new Array();
var popquota=new Array();
var poparray=$#popspace;\n);
my($i);
for($i=0;$i<=$#popspace;$i++)
	{
	print qq(popcounts[$i]=new Number($popspace[$i]);\n);
	}
print qq(var info=new Array();
info[0]=new Number\().(int($remote{'used'}/1024)+1).qq(\);
info[1]=new Number\().(int($remote{'bandwidth'}/1024)).qq(\);
info[2]=new Number($remote{'email'});
info[3]=new Number($remote{'responder'});
info[4]=new Number($remote{'dbase'});
info[5]=new Number($remote{'subdomain'});
info[6]=new Number($remote{'maxused'});

function CheckVals() {
var x=document.Upgrade.pac.options.selectedIndex;
if(x > 0)
	{
	document.Upgrade.storage.value = eval(group[x][1]);
	document.Upgrade.transfer.value = eval(group[x][2]);
	document.Upgrade.pop.value = eval(group[x][3]);
	document.Upgrade.popspace.value = eval(group[x][4]);
	document.Upgrade.responder.value = eval(group[x][5]);
	document.Upgrade.mysql.value = eval(group[x][6]);
	document.Upgrade.subs.value = eval(group[x][7]);
	}
else
	{
	document.Upgrade.storage.value = "$storage";
	document.Upgrade.transfer.value = "$transfer";
	document.Upgrade.pop.value = "$pop";
	document.Upgrade.popspace.value = "$popspace";
	document.Upgrade.responder.value = "$responder";
	document.Upgrade.mysql.value = "$mysql";
	document.Upgrade.subs.value = "$subs";
	}
if(document.Upgrade.storage.value < info[0]){document.Upgrade.storage.value=info[0];}
if(document.Upgrade.pop.value < info[2]){document.Upgrade.pop.value=info[2];}
if(document.Upgrade.responder.value < info[3]){document.Upgrade.responder.value=info[3];}
if(document.Upgrade.mysql.value < info[4]){document.Upgrade.mysql.value=info[4];}
if(document.Upgrade.subs.value < info[5]){document.Upgrade.subs.value=info[5];}
CalcIt();
}

function CalcIt() {
var x=document.Upgrade.pac.options.selectedIndex;
if(document.Upgrade.storage.value < info[0])
	{
	document.Upgrade.storage.value=info[0];
	alert("Storage amount can not be less than currently used on server.");
	}
if(document.Upgrade.storage.value < eval(group[x][1]))
	{
	document.Upgrade.storage.value=eval(group[x][1]);
	alert("Storage amount can not be lower than package selected amount.\\nThis package minimum value is "+eval(group[x][1])+".");
	}
if(document.Upgrade.transfer.value < eval(group[x][2]))
	{
	document.Upgrade.transfer.value=eval(group[x][2]);
	alert("Transfer amount can not be lower than package selected amount.\\nThis package minimum value is "+eval(group[x][2])+".");
	}
if(document.Upgrade.pop.value < info[2])
	{
	document.Upgrade.pop.value=info[2];
	alert("Pop accounts can not be less than currently used on server.");
	}
if(document.Upgrade.pop.value < eval(group[x][3]))
	{
	document.Upgrade.pop.value=eval(group[x][3]);
	alert("Pop email account value can not be lower than the package selected amount.\\nThis package minimum value is "+eval(group[x][3])+".");
	}
if(document.Upgrade.popspace.value < eval(group[x][4]))
	{
	document.Upgrade.popspace.value=eval(group[x][4]);
	alert("Pop account disk quota can not be lower than the package selected amount.\\nThis package minimum value is "+eval(group[x][4])+".");
	}
if(document.Upgrade.responder.value < info[3])
	{
	document.Upgrade.responder.value=info[3];
	alert("Auto Responders can not be less than currently used on server.");
	}
if(document.Upgrade.responder.value < eval(group[x][5]))
	{
	document.Upgrade.responder.value=eval(group[x][5]);
	alert("Auto responder value can not be lower than the package selected amount.\\nThis package minimum value is "+eval(group[x][5])+".");
	}
if(document.Upgrade.mysql.value < info[4])
	{
	document.Upgrade.mysql.value=info[4];
	alert("MySQL Databases can not be less than currently used on server.");
	}
if(document.Upgrade.mysql.value < eval(group[x][6]))
	{
	document.Upgrade.mysql.value=eval(group[x][6]);
	alert("MySQL databases can not be lower than the package selected amount.\\nThis package minimum value is "+eval(group[x][6])+".");
	}
if(document.Upgrade.subs.value < info[5])
	{
	document.Upgrade.subs.value=info[5];
	alert("Subdomains can not be less than currently used on server.");
	}
if(document.Upgrade.subs.value < eval(group[x][7]))
	{
	document.Upgrade.subs.value=eval(group[x][7]);
	alert("Subdomains can not be lower than the package selected amount.\\nThis package minimum value is "+eval(group[x][7])+".");
	}
var z=document.Upgrade.pac.options.selectedIndex;
var subtot;
var annsubtot;
var price=eval(group[z][8]);
var annual=eval(group[z][9]);
subtot=(document.Upgrade.storage.value * storage)-(eval(group[z][1]) * storage);
document.Upgrade.extrastorage.value=(document.Upgrade.storage.value * storage)-(eval(group[z][1]) * storage);
subtot=subtot + (document.Upgrade.transfer.value * transfer)-(eval(group[z][2]) * transfer);
document.Upgrade.extratransfer.value=(document.Upgrade.transfer.value * transfer)-(eval(group[z][2]) * transfer);
subtot=subtot + (document.Upgrade.pop.value * pop)-(eval(group[z][3]) * pop);
document.Upgrade.extrapop.value=(document.Upgrade.pop.value * pop)-(eval(group[z][3]) * pop);
subtot=subtot + ((document.Upgrade.popspace.value - eval(group[z][4])) * popspace * document.Upgrade.pop.value);
document.Upgrade.extrapopspace.value=((document.Upgrade.popspace.value - eval(group[z][4])) * popspace * document.Upgrade.pop.value);
subtot=subtot + (document.Upgrade.responder.value * responder)-(eval(group[z][5]) * responder);
document.Upgrade.extraresponder.value=(document.Upgrade.responder.value * responder)-(eval(group[z][5]) * responder);
subtot=subtot + (document.Upgrade.mysql.value * mysql)-(eval(group[z][6]) * mysql);
document.Upgrade.extramysql.value=(document.Upgrade.mysql.value * mysql)-(eval(group[z][6]) * mysql);
subtot=subtot + (document.Upgrade.subs.value * subs)-(eval(group[z][7]) * subs);
document.Upgrade.extrasubs.value=(document.Upgrade.subs.value * subs)-(eval(group[z][7]) * subs);
for(i=0;i<=poparray;i++)
	{
	test=document.Upgrade.eval(i);
	if(popcounts[i] > document.Upgrade.popspace.value){subtot=subtot + ((popcounts[i] - document.Upgrade.popspace.value) * popspace);}
	}
document.Upgrade.price.value=Math.round((eval(subtot) + eval(price))*100)/100;
annsubtot=(document.Upgrade.storage.value * annstorage)-(eval(group[z][1]) * annstorage);
document.Upgrade.annextrastorage.value=(document.Upgrade.storage.value * annstorage)-(eval(group[z][1]) * annstorage);
annsubtot=annsubtot + (document.Upgrade.transfer.value * anntransfer)-(eval(group[z][2]) * anntransfer);
document.Upgrade.annextratransfer.value=(document.Upgrade.transfer.value * anntransfer)-(eval(group[z][2]) * anntransfer)
annsubtot=annsubtot + (document.Upgrade.pop.value * annpop)-(eval(group[z][3]) * annpop);
document.Upgrade.annextrapop.value=(document.Upgrade.pop.value * annpop)-(eval(group[z][3]) * annpop);
annsubtot=annsubtot + ((document.Upgrade.popspace.value - eval(group[z][4]))* annpopspace * document.Upgrade.pop.value);
document.Upgrade.annextrapopspace.value=((document.Upgrade.popspace.value - eval(group[z][4])) * annpopspace * document.Upgrade.pop.value);
annsubtot=annsubtot + (document.Upgrade.responder.value * annresponder)-(eval(group[z][5]) * annresponder);
document.Upgrade.annextraresponder.value=(document.Upgrade.responder.value * annresponder)-(eval(group[z][5]) * annresponder)
annsubtot=annsubtot + (document.Upgrade.mysql.value * annmysql)-(eval(group[z][6]) * annmysql);
document.Upgrade.annextramysql.value=(document.Upgrade.mysql.value * annmysql)-(eval(group[z][6]) * annmysql)
annsubtot=annsubtot + (document.Upgrade.subs.value * annsubs)-(eval(group[z][7]) * annsubs);
document.Upgrade.annextrasubs.value=(document.Upgrade.subs.value * annsubs)-(eval(group[z][7]) * annsubs)
for(i=0;i<=poparray;i++)
	{
	if(popcounts[i] > document.Upgrade.popspace.value){annsubtot=annsubtot + ((popcounts[i] - document.Upgrade.popspace.value) * annpopspace);}
	}
document.Upgrade.annual.value=Math.round((eval(annsubtot) + eval(annual))*100)/100;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" NAME="Upgrade">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 class="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Change Hosting Package</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Package</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="pac" SIZE=1 onChange="CheckVals();"><OPTION VALUE="$package">--Current--);
my(@info);
while((@info)=$query_output->fetchrow)
	{
	if($info[0] ne "1"){print qq(<OPTION VALUE="$info[0]">$info[1]);}
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Storage</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="storage" TYPE="text" VALUE="$storage" onChange="CalcIt();" SIZE=5,1 MAXLENGTH=10> M</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Transfer</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="transfer" TYPE="text" VALUE="$transfer" onChange="CalcIt();" SIZE=5,1 MAXLENGTH=10> M</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Pop Accounts</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="pop" TYPE="text" VALUE="$pop" onChange="CalcIt();" SIZE=5,1 MAXLENGTH=10></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Pop Disk Space<BR>(Per account)</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="popspace" TYPE="text" VALUE="$popspace" onChange="CalcIt();" SIZE=5,1 MAXLENGTH=10> M</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Auto Responders</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="responder" TYPE="text" VALUE="$responder" onChange="CalcIt();" SIZE=5,1 MAXLENGTH=10></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>MySQL Databases</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="mysql" TYPE="text" VALUE="$mysql" onChange="CalcIt();" SIZE=5,1 MAXLENGTH=10></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Sub Domains</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="subs" TYPE="text" VALUE="$subs" onChange="CalcIt();" SIZE=5,1 MAXLENGTH=10></TD></TR>
<tr><td class="prgout" align=left>Discount</td>
<td class="prgout" align=left>\$<input name="discount" type="text" value="$discount" size=5,1> *Applied Each Billing<br>
<input name="cycle" type="text" value="$discdur" size=5,1> Number of Cycles to apply discount. (empty means every cycle)</td></tr>
<TR><TD CLASS="prgout" ALIGN=left>Monthly Price</TD>
<TD CLASS="prgout" ALIGN=left>\$<INPUT NAME="price" TYPE="text" SIZE=5,1 MAXLENGTH=10 DISABLED></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Annual Price</TD>
<TD CLASS="prgout" ALIGN=left>\$<INPUT NAME="annual" TYPE="text" SIZE=5,1 MAXLENGTH=10 DISABLED></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Billing Cycle</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="billing" SIZE=1><OPTION VALUE="M">Monthly<OPTION VALUE="A");
if($billing eq "A"){print qq( SELECTED);}
print qq(>Annually</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Current Charges</TD>
<TD CLASS="prgout" ALIGN=left>);
my($desc,$charge,$total);
$amount=sprintf("%.2f",$amount);
print qq(Hosting Package - \$$amount<BR>\n);
$total+=$amount;
while(($desc,$charge)=$query_output2->fetchrow)
	{
	if($desc !~ /Discount/)
		{
		$charge=sprintf("%.2f",$charge);
		print qq($desc<BR>\n);
		$total+=$charge;
		}
	}
$total=sprintf("%.2f",$total);
print qq(Total - \$$total<BR>\n);
if($billing eq "M"){print qq(Monthly Billing);}
else{print qq(Annual Billing);}
print qq(</TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Change Hosting Package"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Change Package">
<input name="id" type="hidden" value="$id">
<INPUT NAME="extrastorage" TYPE="hidden">
<INPUT NAME="extratransfer" TYPE="hidden">
<INPUT NAME="extrapop" TYPE="hidden">
<INPUT NAME="extrapopspace" TYPE="hidden">
<INPUT NAME="extraresponder" TYPE="hidden">
<INPUT NAME="extramysql" TYPE="hidden">
<INPUT NAME="extrasubs" TYPE="hidden">
<INPUT NAME="annextrastorage" TYPE="hidden">
<INPUT NAME="annextratransfer" TYPE="hidden">
<INPUT NAME="annextrapop" TYPE="hidden">
<INPUT NAME="annextrapopspace" TYPE="hidden">
<INPUT NAME="annextraresponder" TYPE="hidden">
<INPUT NAME="annextramysql" TYPE="hidden">
<INPUT NAME="annextrasubs" TYPE="hidden">
</FORM>);
print qq(<script language="javascript">
<!--
//var credit=new Number($creditamount);
var groups=document.Upgrade.pac.options.length;
var group=new Array();
for(i=0;i<groups;i++)
group[i]=new Array();
group[0][1]=new Number($cstorage);
group[0][2]=new Number($ctransfer);
group[0][3]=new Number($cpop);
group[0][4]=new Number($cpopspace);
group[0][5]=new Number($cresponder);
group[0][6]=new Number($cmysql);
group[0][7]=new Number($csubs);
group[0][8]=new Number($cprice);
group[0][9]=new Number($cannual);\n);
$i=0;
while((@info)=$query_output3->fetchrow)
	{
	if($info[0] ne "1")
		{
		$i++;
		print qq(group[$i][1]=new Number($info[2]);
group[$i][2]=new Number($info[3]);
group[$i][3]=new Number($info[4]);
group[$i][4]=new Number($info[5]);
group[$i][5]=new Number($info[6]);
group[$i][6]=new Number($info[7]);
group[$i][7]=new Number($info[8]);
group[$i][8]=new Number($info[9]);
group[$i][9]=new Number($info[10]);\n);
		}
	}
my($name,$price,$annual);
while(($name,$price,$annual)=$query_output4->fetchrow)
	{
	print qq(var $name=new Number($price);
var ann$name=new Number($annual);\n);
	}
print qq(CheckVals();
//-->
</script>);
&Bottom;
}

##

sub Change_Package_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM14'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Change Package2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Change Hosting Package</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Change Package2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub View_Domain_Info
{
&Check_Password;
my($db,$statement,$query_output,$erro);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain_map.domain,server.name,server.ip,packages.name,user.firstname,user.lastname,user.email,accounting.amount
FROM domain_map,server,packages,user,user_map,accounting
WHERE domain_map.id='$FORM{'domain'}' && server.id=domain_map.server && packages.id=domain_map.package &&
user_map.admin='yes' && user_map.domain='$FORM{'domain'}' && user_map.user=user.id && accounting.domid='$FORM{'domain'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain,$server,$ip,$package,$firstname,$lastname,$email,$balance)=$query_output->fetchrow;
&Top;
print qq(<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Domain Information for $domain</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Server</TD>
<TD CLASS="prgout" ALIGN=left>$server</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>IP Address</TD>
<TD CLASS="prgout" ALIGN=left>$ip</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Hosting Package</TD>
<TD CLASS="prgout" ALIGN=left>$package</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain Administrator</TD>
<TD CLASS="prgout" ALIGN=left>$firstname $lastname</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Admin Email</TD>
<TD CLASS="prgout" ALIGN=left><A HREF="mailto:$email" class="prgout">$email</A></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Account Balance</TD>
<TD CLASS="prgout" ALIGN=left>\$$balance</TD></TR>
</TABLE>);
&Bottom;
}

##

sub Set_Locking
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE domain_map SET shelllock='$FORM{'lock'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Shell locking updated</td></tr>
</table>);
&Bottom;
}

##

sub Set_Locking2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM8'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/%/g;
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain,shelllock FROM domain_map WHERE domain_map.domain LIKE '$FORM{'domain'}' && domain_map.reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain,$shelllock);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a manager to manage shell access lock");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData();">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Shell Access Locking</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1 onChange="ChgVal(this.options.selectedIndex);"><OPTION VALUE="">--Select Domain--);
while(($id,$domain,$shelllock)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Access</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="lock" SIZE=1><OPTION VALUE="yes">Yes<OPTION VALUE="no">No</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Set Locking"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Set Locking">
</FORM>
<script language="javascript">
<!--
function ChgVal(x)
	{
	document.forms[0].lock.selectedIndex=eval(group[x]);
	}
var groups=document.forms[0].id.options.length
var group=new Array(groups)
for (i=0; i<groups; i++)
group[i]=new Array()
group[0]=new Number(0);\n);
my($idcount)=1;
$query_output->dataseek();
while(($id,$domain,$shelllock)=$query_output->fetchrow)
	{
	if($shelllock eq "yes"){print qq(group[$idcount]=new Number(0);\n);}
	else{print qq(group[$idcount]=new Number(1);\n);}
	$idcount++;
	}
print qq(ChgVal(document.forms[0].id.options.selectedIndex);
// -->
</script>\n);
&Bottom;
}

##

sub Shell_Lock_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM8'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Set Locking2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Shell Access Locking</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Set Locking2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Set_Shell
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain_map.domain,server.ip,server.port,server.serverpass FROM server,domain_map WHERE server.id=domain_map.server && domain_map.id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=set+shell&domain=$domain&shell=$FORM{'shell'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$statement=qq(UPDATE domain_map SET shell='$FORM{'shell'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Domain shell set</td></tr>
</table>);
&Bottom;
}

##

sub Set_Shell2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM7'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain,shell FROM domain_map WHERE domain LIKE '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain,$shell);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].username.selectedIndex <= 0)
{
alert("Select a username to manage shell access");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Manage Shell Access</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1 onChange="ChgVal(this.options.selectedIndex);"><OPTION VALUE="">--Select Domain--);
while(($id,$domain,$shell)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Shell Access</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="shell" SIZE=1><OPTION VALUE="no">No<OPTION VALUE="yes">Yes</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Set Shell Access"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Set Shell">
</FORM>
<script language="javascript">
<!--
function ChgVal(x)
	{
	document.forms[0].shell.selectedIndex=eval(group[x]);
	}
var groups=document.forms[0].id.options.length
var group=new Array(groups)
for (i=0; i<groups; i++)
group[i]=new Array()
group[0]=new Number(0);\n);
my($idcount)=1;
$query_output->dataseek();
while(($id,$domain,$shell)=$query_output->fetchrow)
	{
	if($shell eq "no"){print qq(group[$idcount]=new Number(0);\n);}
	else{print qq(group[$idcount]=new Number(1);\n);}
print qq(// $shell\n);
	$idcount++;
	}
print qq(ChgVal(document.forms[0].id.options.selectedIndex);
// -->
</script>\n);
&Bottom;
}

##

sub Client_Shell_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM7'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Set Shell2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Manage Shell Access</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Set Shell2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Remove_DNS
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM13'} ne "yes")){&Error('Insufficient access for this function');}
my($cipher);
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain FROM dns WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain)=$query_output->fetchrow;
if($system{'usens1'} eq "yes")
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns1');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=remove+domain&domain=$domain);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to update primary dns, $remote{'status'}");}
	}
if($system{'usens2'} eq "yes")
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns2');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=remove+domain&domain=$domain);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to update secondary dns, $remote{'status'}");}
	}
$statement=qq(DELETE FROM dns WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min) ==1)
	{
	$min="0".$min;
	}
my($date)=qq($year-$mon-$mday $hour:$min);
$FORM{'comments'}=~s/\n//g;
$statement=qq(INSERT INTO actionlog (action,adate,admin,comments) VALUES ('$domain: DNS entry removed','$date','$Cookies{'auser'}','$FORM{'comments'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>DNS entry removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_DNS2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM13'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM dns WHERE domain LIKE '$FORM{'domain'}' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove DNS Only Entry</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Comments</TD>
<TD CLASS="prgout" ALIGN=left> <TEXTAREA NAME="comments" ROWS=5 COLS=30></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove DNS Entry"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Remove DNS">
</FORM>);
&Bottom;
}

##

sub Remove_DNS_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM13'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Remove DNS2";
var Extra="dns";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove DNS Only Entry</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Remove DNS2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Add_DNS
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM12'} ne "yes")){&Error('Insufficient access for this function');}
my($cipher);
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id FROM domain_map WHERE domain='$FORM{'domain'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($test)=$query_output->fetchrow;
if($test){&Error("The domain, $FORM{'domain'}, is already in the system");}
$statement=qq(SELECT id FROM dns WHERE domain='$FORM{'domain'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$test=$query_output->fetchrow;
if($test){&Error("The domain, $FORM{'domain'}, is already in the system");}
$statement=qq(SELECT id FROM pointer WHERE name='$FORM{'domain'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$test=$query_output->fetchrow;
if($test){&Error("The domain, $FORM{'domain'}, is already in the system");}
if($system{'usens1'} eq "yes")
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns1');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=add+domain&domain=$FORM{'domain'}&ip=$FORM{'ip'}&mailip=$FORM{'ip'}&mx=$FORM{'mx'}&mxip=$FORM{'mxip'});
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to update primary dns, $remote{'status'}");}
	}
if($system{'usens2'} eq "yes")
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns2');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=add+domain&domain=$FORM{'domain'}&ip=$FORM{'ip'}&mailip=$FORM{'ip'}&mx=$FORM{'mx'}&mxip=$FORM{'mxip'});
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to update secondary dns, $remote{'status'}");}
	}
$statement=qq(INSERT INTO dns (domain,mx,mxip,ip) VALUES ('$FORM{'domain'}','$FORM{'mx'}','$FORM{'mxip'}','$FORM{'ip'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min) ==1)
	{
	$min="0".$min;
	}
my($date)=qq($year-$mon-$mday $hour:$min);
$FORM{'comments'}=~s/\n//g;
$statement=qq(INSERT INTO actionlog (action,adate,admin) VALUES ('$FORM{'domain'}: DNS entry added','$date','$Cookies{'auser'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>DNS entry added</td></tr>
</table>);
&Bottom;
}

##

sub Add_DNS_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM12'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].domain.value <= 0)
{
alert("Enter a domain name to add to dns.");
return false;
}
if(document.forms[0].ip.value <= 0) 
{
alert("Enter an IP address to add to dns.");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Add DNS Only Entry</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="domain" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>MX Server (if required)</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="mx" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>MX IP (if required)</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="mxip" TYPE="text" SIZE=15,1 MAXLENGTH=15></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>IP Address</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="ip" TYPE="text" SIZE=15,1 MAXLENGTH=15></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Add DNS Entry"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Add DNS">
</FORM>);
&Bottom;
}

##

sub Remove_Pointer
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM11'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,server,endns FROM pointer WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$server,$endns)=$query_output->fetchrow;
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$server');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=remove+pointer&pointer=$name&id=$FORM{'id'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$statement=qq(DELETE FROM recur_charge WHERE description='Pointer $name');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(DELETE FROM pointer WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
if($system{'usens1'} eq "yes")
	{
	if($endns eq "yes")
		{
		$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns1');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($ip,$port,$serverpass)=$query_output->fetchrow;
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		my($command)=qq(do=remove+domain&domain=$name);
		&Connect($ip,$port,$serverpass,$command);
		if($remote{'status'} ne "done"){&Error("primary name server reports $remote{'status'}");}
		}
	}
if($system{'usens2'} eq "yes")
	{
	if($endns eq "yes")
		{
		$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns2');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($ip,$port,$serverpass)=$query_output->fetchrow;
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		my($command)=qq(do=remove+domain&domain=$name);
		&Connect($ip,$port,$serverpass,$command);
		if($remote{'status'} ne "done"){&Error("secondary name server reports $remote{'status'}");}
		}
	}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min) ==1)
	{
	$min="0".$min;
	}
my($date)=qq($year-$mon-$mday $hour:$min);
$FORM{'comments'}=~s/\n//g;
$statement=qq(INSERT INTO actionlog (action,adate,admin,comments) VALUES ('$name: pointer removed','$date','$Cookies{'auser'}','$FORM{'comments'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Domain pointer removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Pointer2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM11'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'pointer'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM pointer WHERE name LIKE '$FORM{'pointer'}' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a pointer to remove.");
return false;
}
if(confirm("Do you want to delete this pointer?"))
	{
	return true;
	}
else
return false;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove Domain Pointer</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Pointer to remove</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Pointer--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'pointer'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Comments</TD>
<TD CLASS="prgout" ALIGN=left> <TEXTAREA NAME="comments" ROWS=5 COLS=30></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove Pointer"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Remove Pointer">
</FORM>);
&Bottom;
}

##

sub Remove_Pointer_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM11'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Remove Pointer2";
var Extra="pointer";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Domain Pointer</td></tr>
<tr><td class="prgout" align=left>Pointer Name</td>
<td class="prgout" align=left><input id="sfield" name="pointer" type="text" size=20,1 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Remove Pointer2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Add_Pointer
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM10'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id FROM domain_map WHERE domain='$FORM{'pointer'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($test)=$query_output->fetchrow;
if($test){&Error("The domain, $FORM{'pointer'}, is already in the system as a domain.");}
$statement=qq(SELECT id FROM pointer WHERE name='$FORM{'pointer'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$test=$query_output->fetchrow;
if($test){&Error("The domain, $FORM{'pointer'}, is already in the system as a domain pointer.");}
$statement=qq(SELECT id FROM dns WHERE domain='$FORM{'pointer'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$test=$query_output->fetchrow;
if($test){&Error("The domain, $FORM{'pointer'}, is already in the system as a DNS only entry.");}
$statement=qq(SELECT id,domain,server,ip,mx,mxip,billing FROM domain_map WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($did,$domain,$server,$ip,$mx,$mxip,$billing)=$query_output->fetchrow;
$statement=qq(INSERT INTO pointer (domain,name,server,ip,mx,mxip,endns) VALUES ('$did','$FORM{'pointer'}','$server',
'$ip','$mx','$mxip','$FORM{'endns'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id)=$query_output->fetchrow;
##billing
$statement=qq(SELECT price,annual FROM addon WHERE name='pointer');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($price,$annual)=$query_output->fetchrow;
if($billing eq "M")
	{
	$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Pointer $FORM{'pointer'}','$price'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
else
	{
	$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$FORM{'id'}','Pointer $FORM{'pointer'}','$annual'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$server');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=add+pointer&id=$FORM{'id'}&domain=$domain&pointer=$FORM{'pointer'}&pid=$id&ip=$ip);
&Connect($sip,$port,$serverpass,$command);
if($remote{'status'} ne "done")
	{
	$statement=qq(DELETE FROM pointer WHERE id='$id');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM recur_charge WHERE description='Pointer $FORM{'pointer'}' && domain='$FORM{'id'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	&Error($remote{'status'});
	}
if($FORM{'endns'} eq "yes")
	{
	if($system{'usens1'} eq "yes")
		{
		$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns1');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($ip,$port,$serverpass)=$query_output->fetchrow;
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		my($command)=qq(do=add+domain&domain=$FORM{'pointer'}&ip=$ip);
		&Connect($ip,$port,$serverpass,$command);
		if($remote{'status'} ne "done")
			{
			&Error("Pointer created on hosting server but unable to update name server, $remote{'status'}");
			}
		}
	if($system{'usens2'} eq "yes")
		{
		$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns2');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($ip,$port,$serverpass)=$query_output->fetchrow;
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		my($command)=qq(do=add+domain&domain=$FORM{'pointer'});
		&Connect($ip,$port,$serverpass,$command);
		if($remote{'status'} ne "done")
			{
			&Error("Pointer created on hosting server but unable to update name server, $remote{'status'}");
			}
		}
	}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min) ==1)
	{
	$min="0".$min;
	}
my($date)=qq($year-$mon-$mday $hour:$min);
$statement=qq(INSERT INTO actionlog (action,adate,admin) VALUES ('$FORM{'pointer'}: pointer added','$date','$Cookies{'auser'}'));
$db->query($statement);
if($error=$db->errmsg){return("status=$error");}
if($FORM{'endns'} ne "yes")
	{
	&Top;
	print qq(<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Add Domain Pointer</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>The pointer, $FORM{'pointer'}, has been added.  Because DNS management was not selected you will need the IP address for outside DNS management.
The IP address assigned to the pointer is $ip</TD></TR>
</TABLE>);
	&Bottom;
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Domain pointer added</td></tr>
</table>);
&Bottom;
}

##

sub Add_Pointer2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM10'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE domain LIKE '$FORM{'domain'}' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select the domain to add the pointer to.");
return false;
}
if(document.forms[0].pointer.value <= 0)
{
alert("Enter the pointer domain name.");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Add Domain Pointer</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain to point to</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>New Domain</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="pointer" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Update DNS for New Domain?</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="endns" TYPE="checkbox" VALUE="yes" CHECKED></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Add Pointer"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Add Pointer">
</FORM>);
&Bottom;
}

##

sub Add_Pointer_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM10'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Add Pointer2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Domain Pointer</td></tr>
<tr><td class="prgout" align=left>Domain to point to</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Add Pointer2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Change_Domain_Admin
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM9'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,user FROM user_map WHERE domain='$FORM{'id'}' && admin='yes');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($oldid,$test)=$query_output->fetchrow;
if($test eq $FORM{'uid'}){&Error("The user selected is already the administrator for this domain");}
$statement=qq(UPDATE user_map SET admin='no' WHERE id='$oldid');
$db->query($statement);
if($FORM{'uid'})
	{
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(SELECT id FROM user_map WHERE domain='$FORM{'id'}' && user='$FORM{'uid'}');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($id)=$query_output->fetchrow;
	if($id)
		{
		$statement=qq(UPDATE user_map SET admin='yes',email='yes',billing='yes',ftp='yes',web='yes' WHERE id='$id');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	else
		{
		$statement=qq(SELECT server FROM domain_map WHERE id='$FORM{'id'}');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($server)=$query_output->fetchrow;
		$statement=qq(INSERT INTO user_map (user,domain,server,admin,email,billing,ftp,web) VALUES ('$FORM{'uid'}','$FORM{'id'}','$server','yes','yes','yes','yes','yes'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
if(!$FORM{'uid'})
	{
	$statement=qq(SELECT id FROM user WHERE email='$FORM{'email'}');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($test)=$query_output->fetchrow;
	if($test){&Error("The email address, $FORM{'email'}, is already in use");}
	my($null,$host)=split(/\@/,$FORM{'email'});
	$statement=qq(SELECT id FROM userblock WHERE address='$FORM{'email'}' or host='$host');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($id)=$query_output->fetchrow;
	if($id){&Error("The email address or host has been blocked from user account system.");}
	my($cipher);
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	my($pass)=&encode_base64($cipher->encrypt($FORM{'password'}));
	$statement=qq(INSERT INTO user (firstname,lastname,password,email,company,address1,address2,address3,city,state,zip,country,phone,fax)
VALUES ('$FORM{'firstname'}','$FORM{'lastname'}','$pass','$FORM{'email'}','$FORM{'company'}','$FORM{'address1'}','$FORM{'address2'}','$FORM{'address3'}',
'$FORM{'city'}','$FORM{'state'}','$FORM{'zip'}','$FORM{'country'}','$FORM{'phone'}','$FORM{'fax'}'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(SELECT LAST_INSERT_ID());
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($id)=$query_output->fetchrow;
	$statement=qq(SELECT server FROM domain_map WHERE id='$FORM{'id'}');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($server)=$query_output->fetchrow;
	$statement=qq(INSERT INTO user_map (user,domain,server,admin,email,billing,ftp,web) VALUES ('$id','$FORM{'id'}','$server','yes','yes','yes','yes','yes'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Domain administrator changed</td></tr>
</table>);
&Bottom;
}

##

sub Get_User_Info2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM3'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'email'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,firstname,lastname,email,company,address1,address2,address3,city,state,zip,country,phone,fax FROM user WHERE email like '$FORM{'email'}' ORDER BY email ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$firstname,$lastname,$email,$company,$address1,$address2,$address3,$city,$state,$zip,$country,$phone,$fax);
print "content-type:  text/html\n\r\n\r";
print qq(<html>
<head>
<title>Get User Info</title>
<style type="text/css">
<!--
body { scrollbar-arrow-color:#C0C0C0;
	scrollbar-base-color:#5C5C5C;
	scrollbar-shadow-color:#C0C0C0;
	scrollbar-face-color:#808080;
	scrollbar-highlight-color:#C0C0C0;
	scrollbar-dark-shadow-color:#5C5C5C;
	scrollbar-3d-light-color:#808080;
	margin-top: 0px; margin-left: 0px;  color: #C0C0C0 }
a { text-decoration: none}
a:active {  color: #000000}
a:hover {  color: #000000}
a:link {  color: #000000}
a:visited {  color: #000000}
body {  background-image: url(/images/bg.gif)}
body { width:100%;height:100%;color:#000000}
body { margin-top:0;margin-bottom:0;margin-left:0;margin-right:0; }
body { padding-top:0;padding-bottom:0;padding-left:0;padding-right:0;}
body {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; color: #000000;}
td {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
td.heada {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-weight: bold; background-color: #808080}
td.heada { border: thin #808080 inset; background-color="#808080"}
td.headb {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-weight: bold;}
td.headb { border: thin #808080 inset;}
td.highlight {  background-color: #C0C0C0; font-family: arial,helvetica,verdana,geneva; font-size: 10pt; color: #FF0000;}
td.highlight { border: thin #808080 inset;}
td.prgout {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
td.prgout { background-color: #C0C0C0; border: thin #808080 inset;}
td.total {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-style: italic; font-weight: bold;}
td.total { background-color: #C0C0C0; border: thin #808080 inset;}
td.filler { background-color: #FFFFE6; border: thin #808080 inset;}
// -->
</style>
</head>
<body>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Get User Info</td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><select name="id" size=1><OPTION VALUE="">--Select User--);
while(($id,$firstname,$lastname,$email,$company,$address1,$address2,$address3,$city,$state,$zip,$country,$phone,$fax)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($email eq $FORM{'email'}){print qq( selected);}
	print qq(>$email);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="button" value="Set Info" onClick="ChgVal(forms[0].id.options.selectedIndex);"></td></tr>
</table>
</form>
<script language="javascript">
<!--
function ChgVal(x)
	{
	if(x > 0)
	{opener.document.forms[0].password.disabled=true;}
	else{opener.document.forms[0].password.disabled=false;}
	opener.document.forms[0].email.value = eval(group[x][1]);
	opener.document.forms[0].firstname.value = eval(group[x][2]);
	opener.document.forms[0].lastname.value = eval(group[x][3]);
	opener.document.forms[0].company.value = eval(group[x][4]);
	opener.document.forms[0].address1.value = eval(group[x][5]);
	opener.document.forms[0].address2.value = eval(group[x][6]);
	opener.document.forms[0].address3.value = eval(group[x][7]);
	opener.document.forms[0].city.value = eval(group[x][8]);
	opener.document.forms[0].state.value = eval(group[x][9]);
	opener.document.forms[0].zip.value = eval(group[x][10]);
	opener.document.forms[0].country.selectedIndex = eval(group[x][11]);
	opener.document.forms[0].phone.value = eval(group[x][12]);
	opener.document.forms[0].fax.value = eval(group[x][13]);
	opener.document.forms[0].uid.value=document.forms[0].id.value;
	window.close();
	}
var groups=document.forms[0].id.options.length;
var group=new Array();
for(i=0;i<groups;i++)
group[i]=new Array();
group[0][1]=new String("");
group[0][2]=new String("");
group[0][3]=new String("");
group[0][4]=new String("");
group[0][5]=new String("");
group[0][6]=new String("");
group[0][7]=new String("");
group[0][8]=new String("");
group[0][9]=new String("");
group[0][10]=new Number(222);
group[0][11]=new String("");
group[0][12]=new String("");
group[0][13]=new String("");\n);
$query_output->dataseek();
$i=0;
while(($id,$firstname,$lastname,$email,$company,$address1,$address2,$address3,$city,$state,$zip,$country,$phone,$fax)=$query_output->fetchrow)
	{
	$i++;
	print qq(group[$i][1]=new String("$email");
group[$i][2]=new String("$firstname");
group[$i][3]=new String("$lastname");
group[$i][4]=new String("$company");
group[$i][5]=new String("$address1");
group[$i][6]=new String("$address2");
group[$i][7]=new String("$address3");
group[$i][8]=new String("$city");
group[$i][9]=new String("$state");
group[$i][10]=new String("$zip");\n);
	open(FILE,"countries.dat");
	my($z)=0;
	while(<FILE>)
		{
		my(@info)=split(/:/,$_);
		if($info[0] eq $country)
			{
			print qq(group[$i][11]=new Number($z);\n);
			}
		$z++;
		}
	print qq(group[$i][12]=new String("$phone");
group[$i][13]=new String("$fax");\n);
	}
print qq(// -->
</script>
</body>
</html>);
exit;
}

##

sub Get_User_Form2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM3'} ne "yes")){&Error('Insufficient access for this function');}
print "content-type:  text/html\n\r\n\r";
print qq(<html>
<head>
<title>Get User Info</title>
<style type="text/css">
<!--
body { scrollbar-arrow-color:#C0C0C0;
	scrollbar-base-color:#5C5C5C;
	scrollbar-shadow-color:#C0C0C0;
	scrollbar-face-color:#808080;
	scrollbar-highlight-color:#C0C0C0;
	scrollbar-dark-shadow-color:#5C5C5C;
	scrollbar-3d-light-color:#808080;
	margin-top: 0px; margin-left: 0px;  color: #C0C0C0 }
a { text-decoration: none}
a:active {  color: #000000}
a:hover {  color: #000000}
a:link {  color: #000000}
a:visited {  color: #000000}
body {  background-image: url(/images/bg.gif)}
body { width:100%;height:100%;color:#000000}
body { margin-top:0;margin-bottom:0;margin-left:0;margin-right:0; }
body { padding-top:0;padding-bottom:0;padding-left:0;padding-right:0;}
body {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; color: #000000;}
td {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
td.heada {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-weight: bold; background-color: #808080}
td.heada { border: thin #808080 inset; background-color="#808080"}
td.headb {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-weight: bold;}
td.headb { border: thin #808080 inset;}
td.highlight {  background-color: #C0C0C0; font-family: arial,helvetica,verdana,geneva; font-size: 10pt; color: #FF0000;}
td.highlight { border: thin #808080 inset;}
td.prgout {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
td.prgout { background-color: #C0C0C0; border: thin #808080 inset;}
td.total {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-style: italic; font-weight: bold;}
td.total { background-color: #C0C0C0; border: thin #808080 inset;}
td.filler { background-color: #FFFFE6; border: thin #808080 inset;}
// -->
</style>
<script language="javascript">
<!--
var action="Get User Info2";
var Extra="suspend";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+user+js"></script>
</head>
<body>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Get User Info</td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><input id="sfield" name="email" type="text" size=30,1 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Get User Info"></td></tr>
</table>
<input name="do" type="hidden" value="Get User Info2">
</form>
<DIV id="dlist" style="position:absolute;display:none;"></DIV>
<script language="javascript">
<!--
StartUp();
// -->
</script>
</body>
</html>);
exit;
}

##

sub Change_Domain_Admin2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM9'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE domain LIKE '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<script language="javascript">
<!--
function GetUser(){
var MainWindow = window.open ("$script?do=get+user2","GetUser","toolbar=no,location=no,menubar=no,scrollbars=yes,width=350,height=175,resizeable=no,status=no");
}
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a domain to change administrator for");
return false;
}
if((document.forms[0].uid.selectedIndex <= 0)&&(document.forms[0].email.value <=0))
{
alert("Email address is required for new user accounts");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Change Domain Administrator</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Domain--);
my($id,$domain);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Email Address</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="email" TYPE="text" SIZE=30,1 MAXLENGTH=50> <input type="button" value="Get Existing User" onClick="GetUser();"></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Password</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="password" TYPE="text" SIZE=30,1></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>First Name</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="firstname" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Last Name</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="lastname" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Company</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="company" TYPE="text" SIZE=30,1 MAXLENGTH=100></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Address 1</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="address1" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Address 2</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="address2" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Address 3</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="address3" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>City</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="city" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>State</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="state" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Zip/Postal Code</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="zip" TYPE="text" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Country</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="country" SIZE=1>);
open(FILE,"countries.dat");
while(<FILE>)
	{
	my(@info)=split(/:/,$_);
	print qq(<OPTION VALUE="$info[0]");
	if($info[0] eq "us"){print qq( SELECTED);}
	print qq(>$info[1]);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Phone Number</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="phone" TYPE="text" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Fax Number</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="fax" TYPE="text" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Change Administrator"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Change Domain Admin">
<input name="uid" type="hidden">
</FORM>);
&Bottom;
}

##

sub Change_Domain_Admin_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM9'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Change Domain Admin2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Change Domain Administrator</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Change Domain Admin2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Activate_Domain
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM6'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'comments'}=~s/\'/\\'/g;
my($cipher);
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain,server,susftp,susweb,susdns,susemail FROM domain_map WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain,$server,$susftp,$susweb,$susdns,$susemail)=$query_output->fetchrow;
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$server');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=activate+account&id=$FORM{'id'}&domain=$domain&susftp=$susftp&susweb=$susweb&susdns=$susdns&susemail=$susemail);
if(($susftp eq "yes")||($susweb eq "yes")||($susemail eq "yes"))
	{
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error($remote{'status'});}
	}
if(($system{'usens1'} eq "yes")&&($susdns eq "yes"))
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns1');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=activate+domain&domain=$domain);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to suspend dns on primary name server, $remote{'status'}");}
	}
if(($system{'usens2'} eq "yes")&&($susdns eq "yes"))
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns2');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=activate+domain&domain=$domain);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to suspend dns on secondary name server, $remote{'status'}");}
	}
$statement=qq(UPDATE domain_map SET suspend='no',susftp='no',susweb='no',susdns='no',susemail='no' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min) ==1)
	{
	$min="0".$min;
	}
my($date)=qq($year-$mon-$mday $hour:$min);
$statement=qq(INSERT INTO actionlog (action,adate,admin,comments) VALUES ('$domain: reactivated','$date','$Cookies{'auser'}','$FORM{'comments'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Domain re-activated</td></tr>
</table>);
&Bottom;
}

##

sub Activate_Domain2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM6'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE suspend='yes' && domain like '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(document.forms[0].id.selectedIndex <= 0)
	{
	alert("Select a domain to be reactivated");
	return false;
	}
if(confirm("Do you want to reactivate this domain?"))
	{
	return true;
	}
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Reactivate Suspended Domain</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Comments</TD>
<TD CLASS="prgout" ALIGN=left> <TEXTAREA NAME="comments" ROWS=5 COLS=30></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Reactivate Domain"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Activate Domain">
</FORM>);
&Bottom;
}

##

sub Activate_Domain_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM6'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Activate Domain2";
var Extra="activate";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Reactivate Suspended Domain</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Activate Domain2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Suspend_Domain
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM5'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'comments'}=~s/\'/\\'/g;
if(!$FORM{'susftp'}){$FORM{'susftp'}="no";}
if(!$FORM{'susweb'}){$FORM{'susweb'}="no";}
if(!$FORM{'susdns'}){$FORM{'susdns'}="no";}
if(!$FORM{'susemail'}){$FORM{'susemail'}="no";}
my($cipher);
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain,server FROM domain_map WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain,$server)=$query_output->fetchrow;
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$server');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=suspend+account&id=$FORM{'id'}&domain=$domain&susftp=$FORM{'susftp'}&susweb=$FORM{'susweb'}&susdns=$FORM{'susdns'}&susemail=$FORM{'susemail'});
if(($FORM{'susftp'} eq "yes")||($FORM{'susweb'} eq "yes")||($FORM{'susemail'} eq "yes"))
	{
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error($remote{'status'});}
	}
if(($system{'usens1'} eq "yes")&&($FORM{'susdns'} eq "yes"))
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns1');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=suspend+domain&domain=$domain);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to suspend dns on primary name server, $remote{'status'}");}
	}
if(($system{'usens2'} eq "yes")&&($FORM{'susdns'} eq "yes"))
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns2');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=suspend+domain&domain=$domain);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to suspend dns on secondary name server, $remote{'status'}");}
	}
$statement=qq(UPDATE domain_map SET suspend='yes',susftp='$FORM{'susftp'}',susweb='$FORM{'susweb'}',
susdns='$FORM{'susdns'}',susemail='$FORM{'susemail'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min) ==1){$min="0".$min;}
my($date)=qq($year-$mon-$mday $hour:$min);
$statement=qq(INSERT INTO actionlog (action,adate,admin,comments) VALUES ('$domain: suspended','$date','$Cookies{'auser'}','$FORM{'comments'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Domain suspended</td></tr>
</table>);
&Bottom;
}

##

sub Suspend_Domain2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM5'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE suspend='no' && domain like '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(document.forms[0].id.selectedIndex <= 0)
	{
	alert("Select a domain to suspend");
	return false;
	}
if(confirm("Do you want to suspend this domain?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Suspend Domain</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Service</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="susftp" TYPE="checkbox" VALUE="yes" CHECKED>FTP
<INPUT NAME="susweb" TYPE="checkbox" VALUE="yes" CHECKED>Website\n);
if(($system{'usens1'} eq "yes")||($system{'usens2'} eq "yes")){print qq(<INPUT NAME="susdns" TYPE="checkbox" VALUE="yes" CHECKED>DNS\n);}
print qq(<INPUT NAME="susemail" TYPE="checkbox" VALUE="yes" CHECKED>Email</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Comments</TD>
<TD CLASS="prgout" ALIGN=left> <TEXTAREA NAME="comments" ROWS=5 COLS=30></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Suspend Domain"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Suspend Domain">
</FORM>);
&Bottom;
}

##

sub Suspend_Domain_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM5'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Suspend Domain2";
var Extra="suspend";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Suspend Domain</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Suspend Domain2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Remove_Domain
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM4'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'comments'}=~s/\'/\\'/g;
my($cipher);
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain,server,ip,endns,ipshared,totspace,transfer FROM domain_map WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain,$server,$dip,$endns,$shared,$totspace,$transfer)=$query_output->fetchrow;
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$server');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=remove+account&id=$FORM{'id'}&archive=$FORM{'archive'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done")
	{
	&Error($remote{'status'});
	}
$statement=qq(SELECT name FROM pointer WHERE domain='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($pointer);
while(($pointer)=$query_output->fetchrow)
	{
	if($system{'usens1'} eq "yes")
		{
		$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns1');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($ip,$port,$serverpass)=$query_output->fetchrow;
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		my($command)=qq(do=remove+domain&domain=$pointer);
		&Connect($ip,$port,$serverpass,$command);
		if($remote{'status'} ne "done")
			{
			&Error("unable to update primary name server, $remote{'status'}");
			}
		}
	if($system{'usens2'} eq "yes")
		{
		$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns2');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($ip,$port,$serverpass)=$query_output->fetchrow;
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		my($command)=qq(do=remove+domain&domain=$pointer);
		&Connect($ip,$port,$serverpass,$command);
		if($remote{'status'} ne "done")
			{
			&Error("unable to update secondary name server, $remote{'status'}");
			}
		}
	}
$statement=qq(DELETE FROM pointer WHERE domain='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
if($system{'usens1'} eq "yes")
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns1');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=remove+domain&domain=$domain);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done")
		{
		&Error("unable to update primary name server, $remote{'status'}");
		}
	}
if($system{'usens2'} eq "yes")
	{
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns2');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($ip,$port,$serverpass)=$query_output->fetchrow;
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	my($command)=qq(do=remove+domain&domain=$domain);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done")
		{
		&Error("unable to update secondary name server, $remote{'status'}");
		}
	}
if($shared eq "no")
	{
	$statement=qq(SELECT dedips FROM server WHERE id='$server');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($oldinfo)=$query_output->fetchrow;
	if($oldinfo){$oldinfo.=qq(\n$dip);}
	else{$oldinfo=$dip;}
	$statement=qq(UPDATE server SET dedips='$oldinfo' WHERE id='$server');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
$statement=qq(DELETE FROM domain_map WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(UPDATE resource_list SET );
if($shared eq "no"){$statement.=qq(availdedips=availdedips+1,);}
$statement.=qq(usedaccounts=usedaccounts-1,usedspace=usedspace-$totspace,usedbandwidth=usedbandwidth-$transfer WHERE server='$server');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(DELETE FROM user_map WHERE domain='$FORM{'id'}' && server='$server');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(DELETE FROM recur_charge WHERE domain='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(DELETE FROM billing_info WHERE domain='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min) ==1)
	{
	$min="0".$min;
	}
my($date)=qq($year-$mon-$mday $hour:$min);
$statement=qq(INSERT INTO actionlog (action,adate,admin,comments) VALUES ('Domain $domain: removed\n$FORM{'comments'}','$date','$Cookies{'auser'}','$FORM{'comments'}'));
$db->query($statement);
if($error=$db->errmsg){return("status=$error");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Domain removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Domain2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM4'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE domain like '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(document.forms[0].id.selectedIndex <= 0)
	{
	alert("Select a domain to remove");
	return false;
	}
if(confirm("Do you want to delete this domain?"))
	{
	return true;
	}
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove Domain</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Archive?</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="archive" TYPE="checkbox" VALUE="yes" CHECKED></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Comments</TD>
<TD CLASS="prgout" ALIGN=left> <TEXTAREA NAME="comments" ROWS=5 COLS=30></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove Domain"></TD></TR>\n);
print qq(</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Remove Domain">
</FORM>);
&Bottom;
}

##

sub Remove_Domain_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM4'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Remove Domain2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Domain</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Remove Domain2">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Add_Domain
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM3'} ne "yes")){&Error('Insufficient access for this function');}
if(!$FORM{'enmail'}){$FORM{'enmail'}="no";}
if(!$FORM{'enapache'}){$FORM{'enapache'}="no";}
if(!$FORM{'endns'}){$FORM{'endns'}="no";}
if(!$FORM{'discount'}){$FORM{'discount'}="0";}
if(!$FORM{'pool'}){&Error("A server pool to add this domain to must be selected");}
my($db,$query_output,$statement,$error);
my($cipher);
$FORM{'domain'}=~tr/A-Z/a-z/;
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,email FROM user WHERE email='$FORM{'email'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($uid,$emailexists)=$query_output->fetchrow;
if(($uid,$emailexists)&&(!$FORM{'id'})){&Error("The email address, $emailexists, is already a registered user");}
my($null,$host)=split(/\@/,$FORM{'email'});
$statement=qq(SELECT id FROM userblock WHERE address='$FORM{'email'}' or host='$host');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id)=$query_output->fetchrow;
if($id){&Error("The email address or host has been blocked from user account system.");}
$statement=qq(SELECT domain FROM domain_map WHERE domain='$FORM{'domain'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domainexists)=$query_output->fetchrow;
if($domainexists){&Error("The domain, $domainexists, is already registered in the database as a hosted domain");}
$statement=qq(SELECT name FROM pointer WHERE name='$FORM{'domain'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$domainexists=$query_output->fetchrow;
if($domainexists){&Error("The domain, $domainexists, is already registered in the database as a domain pointer");}
$statement=qq(SELECT id FROM dns WHERE domain='$FORM{'domain'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$domainexists=$query_output->fetchrow;
if($domainexists){&Error("The domain, $domainexists, is already registered in the database as a dns entry");}
my($pass)=$FORM{'password'};
my($uid)=$FORM{'id'};
if(!$FORM{'id'})
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	my($password)=&encode_base64($cipher->encrypt($FORM{'password'}));
	$statement=qq(INSERT INTO user (firstname,lastname,password,email,company,address1,address2,address3,city,state,zip,country,phone,fax)
VALUES ('$FORM{'firstname'}','$FORM{'lastname'}','$password','$FORM{'email'}','$FORM{'company'}','$FORM{'address1'}','$FORM{'address2'}','$FORM{'address3'}','$FORM{'city'}',
'$FORM{'state'}','$FORM{'zip'}','$FORM{'country'}','$FORM{'phone'}','$FORM{'fax'}'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(SELECT LAST_INSERT_ID());
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$uid=$query_output->fetchrow;
	}
else
	{
	$statement=qq(UPDATE user SET firstname='$FORM{'firstname'}',lastname='$FORM{'lastname'}',email='$FORM{'email'}',company='$FORM{'company'}',
address1='$FORM{'address1'}',address2='$FORM{'address2'}',address3='$FORM{'address3'}',city='$FORM{'city'}',state='$FORM{'state'}',zip='$FORM{'zip'}',country='$FORM{'country'}',
phone='$FORM{'phone'}',fax='$FORM{'fax'}' WHERE id='$FORM{'id'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(SELECT password FROM user WHERE id='$FORM{'id'}');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$pass=$query_output->fetchrow;
	if(&decode_base64($pass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$pass=$cipher->decrypt(&decode_base64($pass));
	}
if(!$FORM{'storage'}){$FORM{'storage'}=0;}
if($FORM{'dforward'} ne "no")
	{
	$FORM{'storage'}=1;
	$FORM{'pac'}=1;
	}
if(!$FORM{'transfer'}){$FORM{'transfer'}=0;}
if(!$FORM{'pop'}){$FORM{'pop'}=0;}
if(!$FORM{'popspace'}){$FORM{'popspace'}=0;}
$statement=qq(SELECT server FROM resource_list WHERE pools LIKE 
'%|$FORM{'pool'}|%' && maxaccounts > usedaccounts && maxspace > usedspace+$FORM{'storage'}+($FORM{'pop'}*$FORM{'popspace'}) && maxspace > totspace
&& maxbandwidth > usedbandwidth+$FORM{'transfer'} && maxbandwidth > totbandwidth);
if($FORM{'enmail'} eq "yes"){$statement.=qq( && mail='yes');}
if($FORM{'ipoptions'} eq "dedicated"){$statement.=qq( && availdedips > 0);}
if($system{'resourcemethod'} eq "float"){$statement.=qq( ORDER BY maxaccounts,maxspace,maxbandwidth ASC);}
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@servers)=$query_output->fetchrow_array;
if(!$servers[0])
	{
	$statement=qq(SELECT server FROM resource_list WHERE pools LIKE '%|$FORM{'pool'}|%' && maxaccounts > usedaccounts LIMIT 0,1);
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($test)=$query_output->fetchrow;
	if(!$test){&Error("Unable to add account. Servers max accounts have been exceeded");}
	$statement=qq(SELECT server FROM resource_list WHERE pools LIKE '%|$FORM{'pool'}|%' && maxspace > usedspace+$FORM{'storage'}+($FORM{'pop'}*$FORM{'popspace'}) && maxspace > totspace LIMIT 0,1);
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($test)=$query_output->fetchrow;
	if(!$test){&Error("Unable to add account. Servers max allocated space has been exceeded");}
	$statement=qq(SELECT server FROM resource_list WHERE pools LIKE '%|$FORM{'pool'}|%' && maxbandwidth > usedbandwidth+$FORM{'transfer'} && maxbandwidth > totbandwidth LIMIT 0,1);
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($test)=$query_output->fetchrow;
	if(!$test){&Error("Unable to add account. Servers max allocated bandwidth has been exceeded");}
	$statement=qq(SELECT server FROM resource_list WHERE pools LIKE '%|$FORM{'pool'}|%' && availdedips > 0 LIMIT 0,1);
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($test)=$query_output->fetchrow;
	if(!$test){&Error("Unable to add account. There are no availble dedicated IPs");}
	}
my($newip);
if($FORM{'ipoptions'} eq "dedicated")
	{
	$statement=qq(SELECT dedips FROM server WHERE id='$servers[0]');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($dedips)=$query_output->fetchrow;
	my(@dedips)=split(/\n/,$dedips);
	my(@availips);
	my($i);
	foreach(@dedips)
		{
		chomp($_);
		if($_ =~ /-/)
			{
			my($start,$stop)=split(/-/,$_);
			my(@info)=split(/\./,$start);
			for($i=$info[3];$i<=$stop;$i++)
				{
				push(@availips,"$info[0].$info[1].$info[2].$i");
				}
			}
		else
			{
			push(@availips,$_);
			}
		}
	my($newavail);
	for($i=1;$i<=$#availips;$i++){$newavail.=qq($availips[$i]\n);}
	chomp($newavail);
	$statement=qq(UPDATE server SET dedips='$newavail' WHERE id='$servers[0]');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$newip=$availips[0];
	}
else
	{
	$statement=qq(SELECT sharedip FROM server WHERE id='$servers[0]');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$newip=$query_output->fetchrow;
	}
my($shared)="yes";
if($FORM{'ipoptions'} eq "dedicated"){$shared="no";}
my($totspace)=$FORM{'storage'}+($FORM{'pop'}*$FORM{'popspace'});
$statement=qq(SELECT storage,transfer,pop,popspace,responder,mysql,subs,price,annual FROM packages WHERE id='$FORM{'pac'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($defstorage,$deftransfer,$defpop,$defpopspace,$defresponder,$defmysql,$defsubs,$realprice,$realannual)=$query_output->fetchrow;
$statement=qq(INSERT INTO domain_map (domain,server,billing,amount,billdate,ip,forward,forwardto,mx,mxip,enmail,enapache,
endns,ipshared,package,storage,transfer,pop,popspace,responder,mysql,subs,totspace)
VALUES \('$FORM{'domain'}','$servers[0]','$FORM{'billing'}',);
if($FORM{'billing'} eq "M"){$statement.=qq('$realprice',);}
else{$statement.=qq('$realannual',);}
$statement.=qq('$FORM{'byear'}-$FORM{'bmon'}-$FORM{'bday'}','$newip','$FORM{'dforward'}','$FORM{'forwardto'}','$FORM{'mx'}','$FORM{'mxip'}','$FORM{'enmail'}','$FORM{'enapache'}',
'$FORM{'endns'}','$shared','$FORM{'pac'}','$FORM{'storage'}','$FORM{'transfer'}','$FORM{'pop'}','$FORM{'popspace'}',
'$FORM{'responder'}','$FORM{'mysql'}','$FORM{'subs'}','$totspace'\));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id)=$query_output->fetchrow;
$statement=qq(UPDATE resource_list SET );
if($FORM{'ipoptions'} eq "dedicated"){$statement.=qq(availdedips=availdedips-1,);}
$statement.=qq(usedaccounts=usedaccounts+1,usedspace=usedspace+$FORM{'storage'}+($FORM{'pop'}*$FORM{'popspace'}),usedbandwidth=usedbandwidth+$FORM{'transfer'} WHERE server='$servers[0]');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO user_map (user,domain,server,admin,email,billing,ftp,web)
VALUES ('$uid','$id','$servers[0]','yes','yes','yes','yes','yes'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
##add billing charges
$statement=qq(SELECT price,annual FROM addon WHERE name='dedicated');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($dedprice,$anndedprice)=$query_output->fetchrow;
my($costnotes);
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min) ==1){$min="0".$min;}
if(length($sec) ==1){$sec="0".$sec;}
my($date)=qq($year-$mon-$mday);
my($time)=qq($hour:$min:$sec);
$statement=qq(INSERT INTO invoice (domid,domain,cdate) VALUES ('$id','$FORM{'domain'}','$date'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($invoice)=$query_output->fetchrow;
if($FORM{'billing'} eq "M")
	{
	$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Web Hosting with $defstorage Meg Storage, $deftransfer Meg Transfer, $defpop Pop email accounts, $defpopspace disk space per pop account, $defresponder email autoresponders, $defmysql MySQL databases, $defsubs sub domains','$realprice'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	if($FORM{'extrastorage'} > 0)
		{
		$statement=qq(SELECT price FROM addon WHERE name='storage');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extrastorage'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Disk Storage for Website - $FORM{'extrastorage'} Meg','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Disk Storage for Website - $FORM{'extrastorage'} Meg','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extratransfer'} > 0)
		{
		$statement=qq(SELECT price FROM addon WHERE name='transfer');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extratransfer'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Transfer for Website - $FORM{'extratransfer'} Meg','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Transfer for Website - $FORM{'extratransfer'} Meg','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extrapop'} > 0)
		{
		$statement=qq(SELECT price FROM addon WHERE name='pop');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extrapop'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Pop Accounts - $FORM{'extrapop'} account(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Pop Accounts - $FORM{'extrapop'} account(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extrapopspace'} > 0)
		{
		$statement=qq(SELECT price FROM addon WHERE name='popspace');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",($addonprice*$FORM{'extrapopspace'})*$FORM{'pop'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Pop Account Disk Space - $FORM{'extrapopspace'} Meg per account','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Pop Account Disk Space - $FORM{'extrapopspace'} Meg per account','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extraresponder'} > 0)
		{
		$statement=qq(SELECT price FROM addon WHERE name='responder');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extraresponder'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Auto Responders - $FORM{'extraresponder'} account(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Auto Responders - $FORM{'extraresponder'} account(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extramysql'} > 0)
		{
		$statement=qq(SELECT price FROM addon WHERE name='mysql');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extramysql'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra MySQL Database(s) - $FORM{'extramysql'} database(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra MySQL Database(s) - $FORM{'extramysql'} database(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extrasubs'} > 0)
		{
		$statement=qq(SELECT price FROM addon WHERE name='subs');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extrasubs'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Sub Domain - $FORM{'extrasubs'} sub domain(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Sub Domain - $FORM{'extrasubs'} sub domain(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'ipoptions'} eq "dedicated")
		{
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Dedicated IP','$dedprice'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Dedicated IP','$dedprice'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'dforward'} ne "no")
		{
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Domain Forward','$FORM{'price'}'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Domain Forward','$FORM{'price'}'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'setup'} > 0)
		{
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Setup Fee','$FORM{'setup'}'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'discount'} > 0)
		{
		if((!$FORM{'dcycle'})||($FORM{'dcycle'} > 1))
			{
			$statement=qq(INSERT INTO recur_charge (domain,description,amount,cycle) VALUES ('$id','Discount','-$FORM{'discount'}','$FORM{'dcycle'}'));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			}
		$statement=qq(INSERT INTO payments (invoice,transtype,descr,amount,pdate) VALUES ('$invoice','Other','Discount','$FORM{'discount'}','$date'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	$statement=qq(INSERT INTO accounting (domid,domain,amount) VALUES ('$id','$FORM{'domain'}',$FORM{'price'}+$FORM{'setup'}-$FORM{'discount'}));
	$db->query($statement);
	if($error=$db->errmsg){&Error($statement);}
	$statement=qq(UPDATE invoice SET period='$date to $FORM{'byear'}-$FORM{'bmon'}-$FORM{'bday'}',amount=$FORM{'price'}+$FORM{'setup'}-$FORM{'discount'},invbal=$FORM{'price'}+$FORM{'setup'}-$FORM{'discount'} WHERE id='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
else
	{
	$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Web Hosting with $defstorage Meg Storage, $deftransfer Meg Transfer, $defpop Pop email accounts, $defpopspace disk space per pop account, $defresponder email autoresponders, $defmysql MySQL databases, $defsubs sub domains','$realannual'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	if($FORM{'extrastorage'} > 0)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='storage');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extrastorage'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Disk Storage for Website - $FORM{'extrastorage'} Meg','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Disk Storage for Website - $FORM{'extrastorage'} Meg','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extratransfer'} > 0)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='transfer');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extratransfer'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Transfer for Website - $FORM{'extratransfer'} Meg','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Transfer for Website - $FORM{'extratransfer'} Meg','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extrapop'} > 0)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='pop');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extrapop'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Pop Accounts - $FORM{'extrapop'} account(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Pop Accounts - $FORM{'extrapop'} account(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extrapopspace'} > 0)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='popspace');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extrapopspace'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Pop Account Disk Space - $FORM{'extrapopspace'} Meg per account','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Pop Account Disk Space - $FORM{'extrapopspace'} Meg per account','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extraresponder'} > 0)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='responder');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extraresponder'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Auto Responders - $FORM{'extraresponder'} account(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Auto Responders - $FORM{'extraresponder'} account(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extramysql'} > 0)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='mysql');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extramysql'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra MySQL Database(s) - $FORM{'extramysql'} database(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra MySQL Database(s) - $FORM{'extramysql'} database(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'extrasubs'} > 0)
		{
		$statement=qq(SELECT annual FROM addon WHERE name='subs');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($addonprice)=$query_output->fetchrow;
		my($totaladdon)=sprintf("%.2f",$addonprice*$FORM{'extrasubs'});
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Extra Sub Domain - $FORM{'extrasubs'} sub domain(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Extra Sub Domain - $FORM{'extrasubs'} sub domain(s)','$totaladdon'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'ipoptions'} eq "dedicated")
		{
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Dedicated IP','$anndedprice'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Dedicated IP','$anndedprice'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'dforward'} ne "no")
		{
		$statement=qq(INSERT INTO recur_charge (domain,description,amount) VALUES ('$id','Domain Forward','$FORM{'annual'}'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Domain Forward','$FORM{'annual'}'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'setup'} > 0)
		{
		$statement=qq(INSERT INTO charges (invoice,descr,amount) VALUES ('$invoice','Setup Fee','$FORM{'setup'}'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'discount'} > 0)
		{
		if((!$FORM{'dcycle'})||($FORM{'dcycle'} > 1))
			{
			$statement=qq(INSERT INTO recur_charge (domain,description,amount,cycle) VALUES ('$id','Discount','-$FORM{'discount'}','$FORM{'dcycle'}'));
			$db->query($statement);
			if($error=$db->errmsg){&Error($error);}
			}
		$statement=qq(INSERT INTO payments (invoice,transtype,descr,amount,pdate) VALUES ('$invoice','Other','Discount','$FORM{'discount'}','$date'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	$statement=qq(INSERT INTO accounting (domid,domain,amount) VALUES ('$id','$FORM{'domain'}',$FORM{'annual'}+$FORM{'setup'}-$FORM{'discount'}));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE invoice SET period='$date to $FORM{'byear'}-$FORM{'bmon'}-$FORM{'bday'}',amount=$FORM{'annual'}+$FORM{'setup'}-$FORM{'discount'},invbal=$FORM{'annual'}+$FORM{'setup'}-$FORM{'discount'} WHERE id='$invoice');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
my($date)=qq($year-$mon-$mday);
##

$statement=qq(SELECT ip,port,serverpass,mailip FROM server WHERE id='$servers[0]');
$query_output=$db->query($statement);
my($ip,$port,$serverpass,$mailip)=$query_output->fetchrow;
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=add+account&id=$id&domain=$FORM{'domain'}&ip=$newip&password=$pass&email=$FORM{'email'}&package=$FORM{'pac'}&storage=$FORM{'storage'});
$command.=qq(&transfer=$FORM{'transfer'}&pop=$FORM{'pop'}&popspace=$FORM{'popspace'}&responder=$FORM{'responder'});
$command.=qq(&mysql=$FORM{'mysql'}&subs=$FORM{'subs'}&enmail=$FORM{'enmail'}&enapache=$FORM{'enapache'});
$command.=qq(&forward=$FORM{'dforward'}&forwardto=$FORM{'forwardto'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done")
	{
	if(!$FORM{'id'})
		{
		$statement=qq(DELETE FROM user WHERE id='$uid');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	if($FORM{'ipoptions'} eq "dedicated")
		{
		$statement=qq(SELECT dedips FROM server WHERE id='$servers[0]');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($oldinfo)=$query_output->fetchrow;
		if($oldinfo){$oldinfo.=qq(\n$newip);}
		else{$oldinfo=$newip;}
		$statement=qq(UPDATE server SET dedips='$oldinfo' WHERE id='$servers[0]');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	$statement=qq(DELETE FROM domain_map WHERE id='$id');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE resource_list SET );
	if($FORM{'ipoptions'} eq "dedicated"){$statement.=qq(availdedips=availdedips+1,);}
	$statement.=qq(usedaccounts=usedaccounts-1,usedspace=usedspace-$FORM{'storage'}-($FORM{'pop'}*$FORM{'popspace'}),usedbandwidth=usedbandwidth-$FORM{'transfer'} WHERE server='$servers[0]');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM user_map WHERE user='$uid' && domain='$id' && server='$servers[0]');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM recur_charge WHERE domain='$id');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM invoice WHERE domain='$id');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	&Error("Unable to add account, hosting server responded with '$remote{'status'}'");
	}
##dns managment
if($FORM{'endns'} eq "yes")
	{
	if(!$mailip){$mailip=$newip;}
	if($system{'usens1'} eq "yes")
		{
		$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns1');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($ip,$port,$serverpass)=$query_output->fetchrow;
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		my($command)=qq(do=add+domain&domain=$FORM{'domain'}&ip=$newip&mailip=$mailip&mx=$FORM{'mx'}&mxip=$FORM{'mxip'});
		&Connect($ip,$port,$serverpass,$command);
		if($remote{'status'} ne "done")
			{
			&Error("Account created on hosting server but unable to update name server, $remote{'status'}");
			}
		}
	if($system{'usens2'} eq "yes")
		{
		$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='ns2');
		$query_output=$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		my($ip,$port,$serverpass)=$query_output->fetchrow;
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		my($command)=qq(do=add+domain&domain=$FORM{'domain'});
		&Connect($ip,$port,$serverpass,$command);
		if($remote{'status'} ne "done")
			{
			&Error("Account created on hosting server but unable to update name server, $remote{'status'}");
			}
		}
	}
$statement=qq(INSERT INTO billing_info (domain,name,address,city,state,zip,email,phone) VALUES ('$id','$FORM{'firstname'} $FORM{'lastname'}','$FORM{'address1'}','$FORM{'city'}','$FORM{'state'}','$FORM{'zip'}','$FORM{'email'}','$FORM{'phone'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(INSERT INTO actionlog (action,adate,admin,comments) VALUES ('Domain $FORM{'domain'}: added','$date','$Cookies{'auser'}','$FORM{'comments'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
if($FORM{'endns'} eq "no")
	{
	&Top;
	print qq(<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center>Add Domain</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>The domain, $FORM{'domain'}, has been added to the system.  Because DNS was not selected you will need the IP address for the domain for outside
DNS management.  The IP address assigned to this domain is $newip.</TD></TR>
</TABLE>);
	&Bottom;
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Domain added</td></tr>
</table>);
&Bottom;
}

##

sub Get_User_Info
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM3'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'email'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,firstname,lastname,email,company,address1,address2,address3,city,state,zip,country,phone,fax FROM user WHERE email like '$FORM{'email'}' ORDER BY email ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$firstname,$lastname,$email,$company,$address1,$address2,$address3,$city,$state,$zip,$country,$phone,$fax);
print "content-type:  text/html\n\r\n\r";
print qq(<html>
<head>
<title>Get User Info</title>
<style type="text/css">
<!--
body { scrollbar-arrow-color:#C0C0C0;
	scrollbar-base-color:#5C5C5C;
	scrollbar-shadow-color:#C0C0C0;
	scrollbar-face-color:#808080;
	scrollbar-highlight-color:#C0C0C0;
	scrollbar-dark-shadow-color:#5C5C5C;
	scrollbar-3d-light-color:#808080;
	margin-top: 0px; margin-left: 0px;  color: #C0C0C0 }
a { text-decoration: none}
a:active {  color: #000000}
a:hover {  color: #000000}
a:link {  color: #000000}
a:visited {  color: #000000}
body {  background-image: url(/images/bg.gif)}
body { width:100%;height:100%;color:#000000}
body { margin-top:0;margin-bottom:0;margin-left:0;margin-right:0; }
body { padding-top:0;padding-bottom:0;padding-left:0;padding-right:0;}
body {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; color: #000000;}
td {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
td.heada {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-weight: bold; background-color: #808080}
td.heada { border: thin #808080 inset; background-color="#808080"}
td.headb {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-weight: bold;}
td.headb { border: thin #808080 inset;}
td.highlight {  background-color: #C0C0C0; font-family: arial,helvetica,verdana,geneva; font-size: 10pt; color: #FF0000;}
td.highlight { border: thin #808080 inset;}
td.prgout {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
td.prgout { background-color: #C0C0C0; border: thin #808080 inset;}
td.total {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-style: italic; font-weight: bold;}
td.total { background-color: #C0C0C0; border: thin #808080 inset;}
td.filler { background-color: #FFFFE6; border: thin #808080 inset;}
// -->
</style>
</head>
<body>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Get User Info</td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><select name="id" size=1><OPTION VALUE="">--Select User--);
while(($id,$firstname,$lastname,$email,$company,$address1,$address2,$address3,$city,$state,$zip,$country,$phone,$fax)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($email eq $FORM{'email'}){print qq( selected);}
	print qq(>$email);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="button" value="Set Info" onClick="ChgVal(forms[0].id.options.selectedIndex);"></td></tr>
</table>
</form>
<script language="javascript">
<!--
function ChgVal(x)
	{
	if(x > 0)
	{opener.document.forms[0].password.disabled=true;}
	else{opener.document.forms[0].password.disabled=false;}
	opener.document.forms[0].email.value = eval(group[x][1]);
	opener.document.forms[0].firstname.value = eval(group[x][2]);
	opener.document.forms[0].lastname.value = eval(group[x][3]);
	opener.document.forms[0].company.value = eval(group[x][4]);
	opener.document.forms[0].address1.value = eval(group[x][5]);
	opener.document.forms[0].address2.value = eval(group[x][6]);
	opener.document.forms[0].address3.value = eval(group[x][7]);
	opener.document.forms[0].city.value = eval(group[x][8]);
	opener.document.forms[0].state.value = eval(group[x][9]);
	opener.document.forms[0].zip.value = eval(group[x][10]);
	opener.document.forms[0].country.selectedIndex = eval(group[x][11]);
	opener.document.forms[0].phone.value = eval(group[x][12]);
	opener.document.forms[0].fax.value = eval(group[x][13]);
	opener.document.forms[0].id.value=document.forms[0].id.value;
	window.close();
	}
var groups=document.forms[0].id.options.length;
var group=new Array();
for(i=0;i<groups;i++)
group[i]=new Array();
group[0][1]=new String("");
group[0][2]=new String("");
group[0][3]=new String("");
group[0][4]=new String("");
group[0][5]=new String("");
group[0][6]=new String("");
group[0][7]=new String("");
group[0][8]=new String("");
group[0][9]=new String("");
group[0][10]=new Number(222);
group[0][11]=new String("");
group[0][12]=new String("");
group[0][13]=new String("");\n);
$query_output->dataseek();
$i=0;
while(($id,$firstname,$lastname,$email,$company,$address1,$address2,$address3,$city,$state,$zip,$country,$phone,$fax)=$query_output->fetchrow)
	{
	$i++;
	print qq(group[$i][1]=new String("$email");
group[$i][2]=new String("$firstname");
group[$i][3]=new String("$lastname");
group[$i][4]=new String("$company");
group[$i][5]=new String("$address1");
group[$i][6]=new String("$address2");
group[$i][7]=new String("$address3");
group[$i][8]=new String("$city");
group[$i][9]=new String("$state");
group[$i][10]=new String("$zip");\n);
	open(FILE,"countries.dat");
	my($z)=0;
	while(<FILE>)
		{
		my(@info)=split(/:/,$_);
		if($info[0] eq $country)
			{
			print qq(group[$i][11]=new Number($z);\n);
			}
		$z++;
		}
	print qq(group[$i][12]=new String("$phone");
group[$i][13]=new String("$fax");\n);
	}
print qq(// -->
</script>
</body>
</html>);
exit;
}

##

sub Get_User_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM3'} ne "yes")){&Error('Insufficient access for this function');}
print "content-type:  text/html\n\r\n\r";
print qq(<html>
<head>
<title>Get User Info</title>
<style type="text/css">
<!--
body { scrollbar-arrow-color:#C0C0C0;
	scrollbar-base-color:#5C5C5C;
	scrollbar-shadow-color:#C0C0C0;
	scrollbar-face-color:#808080;
	scrollbar-highlight-color:#C0C0C0;
	scrollbar-dark-shadow-color:#5C5C5C;
	scrollbar-3d-light-color:#808080;
	margin-top: 0px; margin-left: 0px;  color: #C0C0C0 }
a { text-decoration: none}
a:active {  color: #000000}
a:hover {  color: #000000}
a:link {  color: #000000}
a:visited {  color: #000000}
body {  background-image: url(/images/bg.gif)}
body { width:100%;height:100%;color:#000000}
body { margin-top:0;margin-bottom:0;margin-left:0;margin-right:0; }
body { padding-top:0;padding-bottom:0;padding-left:0;padding-right:0;}
body {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; color: #000000;}
td {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
td.heada {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-weight: bold; background-color: #808080}
td.heada { border: thin #808080 inset; background-color="#808080"}
td.headb {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-weight: bold;}
td.headb { border: thin #808080 inset;}
td.highlight {  background-color: #C0C0C0; font-family: arial,helvetica,verdana,geneva; font-size: 10pt; color: #FF0000;}
td.highlight { border: thin #808080 inset;}
td.prgout {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
td.prgout { background-color: #C0C0C0; border: thin #808080 inset;}
td.total {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt; font-style: italic; font-weight: bold;}
td.total { background-color: #C0C0C0; border: thin #808080 inset;}
td.filler { background-color: #FFFFE6; border: thin #808080 inset;}
// -->
</style>
<script language="javascript">
<!--
var action="Get User Info";
var Extra="suspend";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+user+js"></script>
</head>
<body>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Get User Info</td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><input id="sfield" name="email" type="text" size=30,1 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Get User Info"></td></tr>
</table>
<input name="do" type="hidden" value="Get User Info">
</form>
<DIV id="dlist" style="position:absolute;display:none;"></DIV>
<script language="javascript">
<!--
StartUp();
// -->
</script>
</body>
</html>);
exit;
}

##

sub Add_Domain_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'DM3'} ne "yes")){&Error('Insufficient access for this function');}
my(@months)=('','January','February','March','April','May','June','July','August','September','October','November','December');
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT SUM(availdedips) FROM resource_list);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($dedips)=$query_output->fetchrow;
$statement=qq(SELECT COUNT(id) FROM resource_list WHERE mail > 0);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($mail)=$query_output->fetchrow;
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$statement=qq(SELECT id,name FROM server_pool ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT id,name,storage,transfer,pop,popspace,responder,mysql,subs,price,setup,annual FROM packages WHERE name != 'Forward' ORDER BY name ASC);
my($query_output2)=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT name,price,annual FROM addon);
my($query_output3)=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<script language="javascript">
<!--
function GetUser(){
var MainWindow = window.open ("$script?do=get+user","GetUser","toolbar=no,location=no,menubar=no,scrollbars=yes,width=350,height=175,resizeable=no,status=no");
}
function CalcIt() {
var z=document.forms[0].pac.options.selectedIndex;
var subtot;
var annsubtot;
var price=eval(group2[z][8]);
var annual=eval(group2[z][10]);
document.forms[0].extrastorage.value=document.forms[0].storage.value - eval(group2[z][1]);
document.forms[0].extratransfer.value=document.forms[0].transfer.value - eval(group2[z][2]);
document.forms[0].extrapop.value=document.forms[0].pop.value - eval(group2[z][3]);
document.forms[0].extrapopspace.value=document.forms[0].popspace.value - eval(group2[z][4]);// * document.forms[0].pop.value;
document.forms[0].extraresponder.value=document.forms[0].responder.value - eval(group2[z][5]);
document.forms[0].extramysql.value=document.forms[0].mysql.value - eval(group2[z][6]);
document.forms[0].extrasubs.value=document.forms[0].subs.value - eval(group2[z][7]);

subtot=(document.forms[0].storage.value * storage)-(eval(group2[z][1]) * storage);
subtot=subtot + (document.forms[0].transfer.value * transfer)-(eval(group2[z][2]) * transfer);
subtot=subtot + (document.forms[0].pop.value * pop)-(eval(group2[z][3]) * pop);
subtot=subtot + ((document.forms[0].popspace.value - eval(group2[z][4])) * popspace * document.forms[0].pop.value);//-(eval(group2[z][4]) * popspace * eval(group2[document.forms[0].pac.selectedIndex][3]));
subtot=subtot + (document.forms[0].responder.value * responder)-(eval(group2[z][5]) * responder);
subtot=subtot + (document.forms[0].mysql.value * mysql)-(eval(group2[z][6]) * mysql);
subtot=subtot + (document.forms[0].subs.value * subs)-(eval(group2[z][7]) * subs);
if(document.forms[0].ipoptions.selectedIndex==1){subtot=subtot + dedicated;}
document.forms[0].price.value=Math.round((eval(subtot) + eval(price))*100)/100;
annsubtot=(document.forms[0].storage.value * annstorage)-(eval(group2[z][1]) * annstorage);
annsubtot=annsubtot + (document.forms[0].transfer.value * anntransfer)-(eval(group2[z][2]) * anntransfer);
annsubtot=annsubtot + (document.forms[0].pop.value * annpop)-(eval(group2[z][3]) * annpop);
annsubtot=annsubtot + ((document.forms[0].popspace.value - eval(group2[z][4]))* annpopspace * document.forms[0].pop.value);
annsubtot=annsubtot + (document.forms[0].responder.value * annresponder)-(eval(group2[z][5]) * annresponder);
annsubtot=annsubtot + (document.forms[0].mysql.value * annmysql)-(eval(group2[z][6]) * annmysql);
annsubtot=annsubtot + (document.forms[0].subs.value * annsubs)-(eval(group2[z][7]) * annsubs);
if(document.forms[0].ipoptions.selectedIndex==1){annsubtot=annsubtot + anndedicated;}
document.forms[0].annual.value=Math.round((eval(annsubtot) + eval(annual))*100)/100;
}
function chkData() {
if(document.forms[0].email.value <= 0)
{
alert("A valid email address is required for new user accounts.");
return false;
}
if(document.forms[0].domain.value <= 0) 
{
alert("Enter the domain name for the new account.");
return false;
}
if(document.forms[0].pac.selectedIndex <= 0 && document.forms[0].dforward.selectedIndex <= 0)
{
alert("Select a hosting package for this domain account.");
return false;
}
else
return true;
}
function DoForward(x) {
if(x > 0)
	{
	document.forms[0].ipoptions.disabled=true;
	document.forms[0].pac.disabled=true;
	document.forms[0].storage.disabled=true;
	document.forms[0].transfer.disabled=true;
	document.forms[0].pop.disabled=true;
	document.forms[0].popspace.disabled=true;
	document.forms[0].responder.disabled=true;
	document.forms[0].mysql.disabled=true;
	document.forms[0].subs.disabled=true;
	document.forms[0].enmail.disabled=true;
	document.forms[0].enapache.disabled=true;
	document.forms[0].price.value=forward;
	document.forms[0].annual.value=annforward;
	document.forms[0].forwardto.disabled=false;
	}
else
	{
	document.forms[0].ipoptions.disabled=false;
	document.forms[0].pac.disabled=false;
	document.forms[0].storage.disabled=false;
	document.forms[0].transfer.disabled=false;
	document.forms[0].pop.disabled=false;
	document.forms[0].popspace.disabled=false;
	document.forms[0].responder.disabled=false;
	document.forms[0].mysql.disabled=false;
	document.forms[0].subs.disabled=false;
	document.forms[0].enmail.disabled=false;
	document.forms[0].enapache.disabled=false;
	document.forms[0].forwardto.disabled=true;
	}
}
function Annual() {
var mon=new Number($mon);
var year=new Number(0);
year=year+1;
document.forms[0].bmon.selectedIndex=mon;
document.forms[0].byear.selectedIndex=year;
}
function Mont() {
var mon=new Number($mon);
var year=new Number(0);
mon=mon+1;
if(mon > 11){mon=0;year=1;}
document.forms[0].bmon.selectedIndex=mon;
document.forms[0].byear.selectedIndex=year;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Add Domain Account</TD></TR>\n);
if($dedips eq 1){print qq(<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2>There is $dedips dedicated IP address available for hosting.</TD></TR>\n);}
else{print qq(<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2>There are $dedips dedicated IP addresses available for hosting.</TD></TR>\n);}
print qq(<TR><TD CLASS="prgout" ALIGN=left>Email Address</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="email" TYPE="text" SIZE=30,1 MAXLENGTH=50> <input type="button" value="Get Existing User" onClick="GetUser();"></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Password</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="password" TYPE="text" SIZE=30,1></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>First Name</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="firstname" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Last Name</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="lastname" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Company</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="company" TYPE="text" SIZE=30,1 MAXLENGTH=100></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Address 1</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="address1" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Address 2</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="address2" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Address 3</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="address3" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>City</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="city" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>State/Province</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="state" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Zip/Postal Code</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="zip" TYPE="text" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Country</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="country" SIZE=1>);
open(FILE,"countries.dat");
while(<FILE>)
	{
	chomp($_);
	my(@info)=split(/:/,$_);
	print qq(<OPTION VALUE="$info[0]");
	if($info[0] eq "us"){print qq( SELECTED);}
	print qq(>$info[1]);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Phone</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="phone" TYPE="text" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Fax</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="fax" TYPE="text" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Domain</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="domain" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>MX Server (if required)</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="mx" TYPE="text" SIZE=20,1 MAXLENGTH=75></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>MX IP Address (if required)</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="mxip" TYPE="text" SIZE=15,1 MAXLENGTH=15></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Forward?</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="dforward" SIZE=1 onChange="return DoForward(this.options.selectedIndex);"><OPTION VALUE="no">No<OPTION VALUE="standard">Standard<OPTION VALUE="frame">Frame</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Forward To</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="forwardto" TYPE="text" VALUE="http://" SIZE=20,1 DISABLED></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Hosting Options</TD>
<TD CLASS="prgout" ALIGN=left>);
if(($system{'usens1'} eq "yes")||($system{'usens2'} eq "yes")){print qq(Enable DNS <INPUT NAME="endns" TYPE="checkbox" VALUE="yes" CHECKED> );}
if($mail > 0){print qq(Enable Email <INPUT NAME="enmail" TYPE="checkbox" VALUE="yes" CHECKED> );}
print qq(Enable Webhosting <INPUT NAME="enapache" TYPE="checkbox" VALUE="yes" CHECKED></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>IP Options</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="ipoptions" SIZE=1><OPTION VALUE="shared">Shared IP<OPTION VALUE="dedicated">Dedicated IP</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Server Pool</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="pool" SIZE=1><OPTION VALUE="">--Select Pool--);
my($id,$name);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Hosting Package</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="pac" SIZE=1 onChange="ChgVal2(this.options.selectedIndex);"><OPTION VALUE="">--Select Package--\n);
my($storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$price,$setup,$annual);
while(($id,$name,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$price,$setup,$annual)=$query_output2->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Storage</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="storage" TYPE="text" SIZE=5,1 MAXLENGTH=10 onChange="return CalcIt();"> MB</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Transfer</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="transfer" TYPE="text" SIZE=5,1 MAXLENGTH=10 onChange="return CalcIt();"> GB</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Pop Accounts</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="pop" TYPE="text" SIZE=5,1 MAXLENGTH=5 onChange="return CalcIt();"></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Pop Disk Space<BR>(per account)</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="popspace" TYPE="text" SIZE=5,1 MAXLENGTH=5 onChange="return CalcIt();"> MB</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Auto Responders</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="responder" TYPE="text" SIZE=5,1 MAXLENGTH=5 onChange="return CalcIt();"></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>MySQL Databases</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="mysql" TYPE="text" SIZE=5,1 MAXLENGTH=5 onChange="return CalcIt();"></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Sub Domains</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="subs" TYPE="text" SIZE=5,1 MAXLENGTH=5 onChange="return CalcIt();"></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Discount</TD>
<TD CLASS="prgout" ALIGN=left VALIGN=top>\$<INPUT NAME="discount" TYPE="text" SIZE=5,1 onChange="return CalcIt();">*Applied Each Billing<BR><INPUT NAME="dcycle" TYPE="text" SIZE=5,1> Number of Cycles to apply discount. (empty means every cycle)</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Setup Fee</TD>
<TD CLASS="prgout" ALIGN=left>\$<INPUT NAME="setup" TYPE="text" SIZE=5,1 MAXLENGTH=10>*Charged only once</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Montly Price</TD>
<TD CLASS="prgout" ALIGN=left>\$<INPUT NAME="price" TYPE="text" SIZE=5,1 MAXLENGTH=10></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Annual Price</TD>
<TD CLASS="prgout" ALIGN=left>\$<INPUT NAME="annual" TYPE="text" SIZE=5,1 MAXLENGTH=10></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Billing Period</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="billing" TYPE="radio" VALUE="M" onChange="return Mont();" CHECKED> Monthly <INPUT NAME="billing" TYPE="radio" VALUE="A" onChange="return Annual();"> Annual</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Billing Date</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="bmon" SIZE=1>);
my($i);
$mon++;$year+=1900;
my($nextmon)=$mon+1;
my($nextyear)=$year;
if($nextmon > 12){$nextmon=1;$nextyear++;}
for($i=1;$i<=12;$i++)
	{
	print qq(<OPTION VALUE="$i");
	if($i == $nextmon){print qq( SELECTED);}
	print qq(>$months[$i]);
	}
print qq(</SELECT> <SELECT NAME="bday" SIZE=1>);
for($i=1;$i<=31;$i++)
	{
	print qq(<OPTION VALUE="$i");
	if($i == $mday){print qq( SELECTED);}
	print qq(>$i);
	}
print qq(</SELECT> <SELECT NAME="byear" SIZE=1>);
for($i=$year;$i<=($year+10);$i++)
	{
	print qq(<OPTION VALUE="$i");
	if($i == $nextyear){print qq( SELECTED);}
	print qq(>$i);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Add Domain"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Add Domain">
<INPUT NAME="extrastorage" TYPE="hidden">
<INPUT NAME="extratransfer" TYPE="hidden">
<INPUT NAME="extrapop" TYPE="hidden">
<INPUT NAME="extrapopspace" TYPE="hidden">
<INPUT NAME="extraresponder" TYPE="hidden">
<INPUT NAME="extramysql" TYPE="hidden">
<INPUT NAME="extrasubs" TYPE="hidden">
<input name="id" type="hidden">
</FORM>
<script language="javascript">
<!--
function ChgVal2(x)
	{
	document.forms[0].storage.value = eval(group2[x][1]);
	document.forms[0].transfer.value = eval(group2[x][2]);
	document.forms[0].pop.value = eval(group2[x][3]);
	document.forms[0].popspace.value = eval(group2[x][4]);
	document.forms[0].responder.value = eval(group2[x][5]);
	document.forms[0].mysql.value = eval(group2[x][6]);
	document.forms[0].subs.value = eval(group2[x][7]);
	document.forms[0].price.value = eval(group2[x][8]);
	document.forms[0].setup.value = eval(group2[x][9]);
	document.forms[0].annual.value = eval(group2[x][10]);
	CalcIt();
	}
var groups2=document.forms[0].pac.options.length;
var group2=new Array();
for(i=0;i<groups2;i++)
group2[i]=new Array();
group2[0][1]=new String("");
group2[0][2]=new String("");
group2[0][3]=new String("");
group2[0][4]=new String("");
group2[0][5]=new String("");
group2[0][6]=new String("");
group2[0][7]=new String("");
group2[0][8]=new String("");
group2[0][9]=new String("");
group2[0][10]=new String("");\n);
$i=0;
$query_output2->dataseek();
while(($id,$name,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$price,$setup,$annual)=$query_output2->fetchrow)
	{
	$i++;
	print qq(group2[$i][1]=new Number($storage);
group2[$i][2]=new Number($transfer);
group2[$i][3]=new Number($pop);
group2[$i][4]=new Number($popspace);
group2[$i][5]=new Number($responder);
group2[$i][6]=new Number($mysql);
group2[$i][7]=new Number($subs);
group2[$i][8]=new Number($price);
group2[$i][9]=new Number($setup);
group2[$i][10]=new Number($annual);\n);
	}
while(($name,$price,$annual)=$query_output3->fetchrow)
	{
	print qq(var $name=new Number($price);
var ann$name=new Number($annual);\n);
	}
print qq(//-->
</script>);
&Bottom;
}

1;
