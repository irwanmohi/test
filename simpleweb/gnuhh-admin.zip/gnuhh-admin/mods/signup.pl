use Net::SSH::Perl;

##

sub Save_Signup_Layout
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS6'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'top'}=&uri_escape($FORM{'top'});
$FORM{'bottom'}=&uri_escape($FORM{'bottom'});
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port)=$query_output->fetchrow;
my($command)=qq(do=save+layout&top=$FORM{'top'}&bottom=$FORM{'bottom'});
&Connect($ip,$port,$system{'enckey'},$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
else
	{
	&Top;
	print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Signup Layout saved</td></tr>
</table>);
	&Bottom;
	}
}

##

sub Signup_Layout
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port)=$query_output->fetchrow;
my($command)=qq(do=get+layout);
&Connect($ip,$port,$system{'enckey'},$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'top'}=~s/\&/&amp;/g;
$remote{'top'}=~s/"/&quot;/g;
$remote{'top'}=~s/</&lt;/g;
$remote{'top'}=~s/>/&gt;/g;
$remote{'bottom'}=~s/\&/&amp;/g;
$remote{'bottom'}=~s/"/&quot;/g;
$remote{'bottom'}=~s/</&lt;/g;
$remote{'bottom'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Signup Layout for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the signup program</td></tr><tr><td class="prgout" align=left Valign=top>Top HTML (Header)</td></tr>
<tr><td class="prgout" align=left> <textarea name="top" rows=15 cols=75 wrap=off>$remote{'top'}</textarea></td></tr>
<tr><td class="prgout" align=left Valign=top>Bottom HTML (Footer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="bottom" rows=15 cols=75 wrap=off>$remote{'bottom'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Layout"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Signup Layout">
</form>);
&Bottom;
}

##

sub Signup_Layout_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='signup' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Signup Layout</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Signup+Layout&id=$id" class="prgout">$name</A><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Layout"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Signup Layout">
</form>);
&Bottom;
}

##

sub Config_Signup
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS4'} ne "yes")){&Error('Insufficient access for this function');}
my($id)=$_[0];
if($id){$FORM{'id'}=$id;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip FROM server WHERE type='admin');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($aid)=$query_output->fetchrow;
$statement=qq(SELECT ip,port,pools,cgipath,imageurl,user,agroup,netfilter,nfpath,autofirewall,usefilecheck,notifyfilecheck,webstart,webstop,
webrestart,webpid,includepath,sshstart,sshstop,sshrestart,sshpid FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$pools,$cgipath,$imageurl,$user,$group,$netfilter,$nfpath,$autofirewall,$usefilecheck,$notifyfilecheck,$webstart,$webstop,$webrestart,$webpid,$includepath,$sshstart,$sshstop,$sshrestart,$sshpid)=$query_output->fetchrow;
$webstart=&uri_escape($webstart);$webstop=&uri_escape($webstop);$webrestart=&uri_escape($webrestart);$webpid=&uri_escape($webpid);
$sshstart==&uri_escape($sshstart);$sshstop=&uri_escape($sshstop);$sshrestart=&uri_escape($sshrestart);$sshpid=&uri_escape($sshpid);
$pools=~s/\|//g;
my($command)=qq(do=configure+server&dbhost=);
if($system{'dbhost'} eq "localhost"){$command.=qq($aid);}
else{$command.=qq($system{'dbhost'});}
$command.=qq(&dbname=$system{'dbname'}&dbuser=$system{'dbuser'}&dbpass=$system{'dbpass'}&usens1=$system{'usens1'}&usens2=$system{'usens2'}&cgipath=$cgipath&pools=$pools);
$command.=qq(&imageurl=$imageurl&user=$user&group=$group&netfilter=$netfilter&nfpath=$nfpath&autofirewall=$autofirewall&reviewsignup=$system{'reviewsignup'});
$command.=qq(&usefilecheck=$usefilecheck&ticketnotify=$system{'ticketnotify'}&notifyemail=$system{'notifyemail'}&adminemail=$system{'adminemail'});
$command.=qq(&webstart=$webstart&webstop=$webstop&webrestart=$webrestart&webpid=$webpid&allowforward=$system{'allowforward'}&clienturl=$system{'clienturl'}&includepath=$includepath);
$command.=qq(&sshstart=$sshstart&sshstop=$sshstop&sshrestart=$sshrestart&sshpid=$sshpid);
if($system{'ns1'} eq "yes")
	{
	$command.=qq(&ns1=$system{'ns1'});
	}
if($system{'ns2'} eq "yes")
	{
	$command.=qq(&ns2=$system{'ns2'});
	}
if($system{'useauthnet'} eq "yes")
	{
	$command.=qq(&useauthnet=$system{'useauthnet'}&authnetver=$system{'authnetver'}&emailcust=$system{'emailcust'}&authnetlogin=$system{'authnetlogin'}&authnetkey=$system{'authnetkey'});
	$command.=qq(&mastercard=$system{'mastercard'}&visa=$system{'visa'}&discover=$system{'discover'}&americanexpress=$system{'americanexpress'}&autobill=$system{'autobill'});
	}
if($system{'usesrs'} eq "yes")
	{
	my($contact_phone)=&uri_escape($system{'contact_phone'});
	my($contact_fax)=&uri_escape($system{'contact_fax'});
	$command.=qq(&srsmanuser=$system{'srsmanuser'}&srsmanpass=$system{'srsmanpass'}&regfee=$system{'regfee'}&regdiscount=$system{'regdiscount'}&supdoms=$system{'supdoms'});
	$command.=qq(&usesrs=$system{'usesrs'}&srsuser=$system{'srsuser'}&srskey=$system{'srskey'}&srsemail=$system{'srsemail'}&srsrenew=$system{'srsrenew'}&srshost=$system{'srshost'});
	$command.=qq(&srsprocess=$system{'srsprocess'}&contact_firstname=$system{'contact_firstname'}&contact_lastname=$system{'contact_lastname'}&contact_organization=$system{'contact_organization'});
	$command.=qq(&contact_address1=$system{'contact_address1'}&contact_address2=$system{'contact_address2'}&contact_address3=$system{'contact_address3'});
	$command.=qq(&contact_city=$system{'contact_city'}&contact_state=$system{'contact_state'}&contact_zip=$system{'contact_zip'}&contact_country=$system{'contact_country'});
	$command.=qq(&contact_phone=$contact_phone&contact_fax=$contact_fax&contact_email=$system{'contact_email'});
	}
if($system{'usemm'} eq "yes")
	{
	$command.=qq(&usemm=$system{'usemm'}&mmkey=$system{'mmkey'}&mmcountry=$system{'mmcountry'}&mmphone=$system{'mmphone'}&mmfreemail=$system{'mmfreemail'});
	$command.=qq(&mmcarderemail=$system{'mmcarderemail'}&mmhighriskcountry=$system{'highriskcountry'});
	}
&Connect($ip,$port,$system{'enckey'},$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
if($id){return 0;}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Signup server configured</td></tr>
</table>);
&Bottom;
}

##

sub Configure_Signup_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='signup' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Signup Server</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Config+Signup&id=$id" class="prgout">$name</A><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Configure Server"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Config Signup">
</form>);
&Bottom;
}

##

sub Send_Signupdinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,includepath,sshport FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$includepath,$sshport)=$query_output->fetchrow;
$ENV{HOME}=$system{'cgipath'};
my $ssh=Net::SSH::Perl->new($ip,protocol=>'2',port=>$sshport);
my($root)="root";
eval {$ssh->login($root,$FORM{'pass'});};
if($@ =~ /Permission denied/i){&Error("The root password was incorrect.");}
my($cmd)=qq(mkdir -p $includepath;chmod 700 $includepath;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$host="$ip";' > $includepath/signupd.inc;echo '\$port="$port";' >> $includepath/signupd.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$key="$system{'enckey'}";' >> $includepath/signupd.inc;echo "\@referers=('$ENV{'SERVER_ADDR'}');" >> $includepath/signupd.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo "1;" >> $includepath/signupd.inc;chmod 600 $includepath/signupd.inc);
$ssh->cmd($cmd);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>signupd.inc File Creation For $name</td></tr>
<tr><td class="prgout" align=left>The file $includepath/signupd.inc was created and the following information placed in it.</td></tr>
<tr><td class="prgout" align=left>\$host=&quot;$ip&quot;;<br>
\$port=&quot;$port&quot;;<br>
\$key=&quot;$system{'enckey'}&quot;;<br>
\@referers=('$ENV{'SERVER_ADDR'}');<br>
1;
</td></tr>
<tr><td class="prgout" align=left>The signup server daemon, signupd, can now be started</td></tr>
</table>);
&Bottom;
}

##

sub Signupinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,includepath FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$includepath)=$query_output->fetchrow;
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the signup server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>signupd.inc File Creation For $name</td></tr>
<tr><td class="prgout" align=left colspan=2>\$host=&quot;$ip&quot;;<br>
\$port=&quot;$port&quot;;<br>
\$key=&quot;$system{'enckey'}&quot;;<br>
\@referers=('$ENV{'SERVER_ADDR'}');<br>
1;
</td></tr>
<tr><td class="prgout" align=left colspan=2>This file can be created by hand and placed in $includepath,<br>
or can be sent to server via SSH if root ssh with password access is available.</td></tr>
<tr><td class="heada" align=center colspan=2>Generate signupd.inc on signup server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send signupd.inc"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Send signupdinc">
</form>);
&Bottom;
}

##

sub Signupinc_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='signup' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Generate signupd.inc File Information</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Signup Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Signupinc&id=$id" class="prgout">$name</A><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Generate Information"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Signupinc">
</form>);
&Bottom;
}

##

sub Remove_Signup
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip)=$query_output->fetchrow;
$statement=qq(DELETE FROM server WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT id FROM server WHERE ip='$ip' && type='client');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($test)=$query_output->fetchrow;
if(!$test)
	{
	&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},'mysql',$system{'mysqlroot'},$system{'mysqlpass'});
	$statement=qq(DELETE FROM db WHERE Host='$ip' && Db='$system{'dbname'}' && User='$system{'dbuser'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM user WHERE Host='$ip' && User='$system{'dbuser'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(Flush privileges);
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='hosting');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($sip,$sport,$serverpass);
	my($cipher);
	while(($sip,$sport,$serverpass)=$query_output->fetchrow)
		{
		my($command)=qq(do=remove+referer&ip=$ip);
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		&Connect($sip,$sport,$serverpass,$command);
		if($remote{'status'} ne "done"){&Error("Unable to update referers on hosting server $ip, $remote{'status'}");}
		}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Signup server removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Signup_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='signup' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a client interface server to remove");
return false;
}
if(confirm("Do you want to delete this signup server?"))
	{
	return true;
	}
else
return false;
}
function ConFirm()
{
if(confirm("Do you want to delete this signup server?"))
	{
	return true;
	}
else
return false;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Signup Server</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Remove+Signup&id=$id" onClick="return ConFirm();" class="prgout">$name</A><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Remove Server"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Remove Signup">
</form>);
&Bottom;
}

##

sub Save_Signup
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip)=$query_output->fetchrow;
my($pools)="|".join("|",@POOLS)."|";
$statement=qq(UPDATE server SET name='$FORM{'name'}',ip='$FORM{'ip'}',port='$FORM{'port'}',pools='$pools',
netfilter='$FORM{'netfilter'}',nfpath='$FORM{'nfpath'}',autofirewall='$FORM{'autofirewall'}',
clienturl='$FORM{'signupurl'}',cgipath='$FORM{'cgipath'}',imageurl='$FORM{'imageurl'}',user='$FORM{'user'}',
agroup='$FORM{'group'}',usefilecheck='$FORM{'usefilecheck'}',webstart='$FORM{'webstart'}',
webstop='$FORM{'webstop'}',webrestart='$FORM{'webrestart'}',webpid='$FORM{'webpid'}',includepath='$FORM{'includepath'}',
sshport='$FORM{'sshport'}',sshstart='$FORM{'sshstart'}',sshstop='$FORM{'sshstop'}',sshrestart='$FORM{'sshrestart'}',
sshpid='$FORM{'sshpid'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT id FROM server WHERE ip='$FORM{'ip'}' && type='client');
$query_output->fetchrow;
if($error=$db->errmsg){&Error($error);}
my($test)=$query_output->fetchrow;
if((!$test)&&($ip ne $FORM{'ip'}))
	{
	&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},'mysql',$system{'mysqlroot'},$system{'mysqlpass'});
	$statement=qq(UPDATE user SET Host='$FORM{'ip'}' WHERE Host='$ip' && User='$system{'dbuser'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE db SET Host='$FORM{'ip'}' WHERE Host='$ip' && Db='$system{'dbname'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(Flush privileges);
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='hosting');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($sip,$sport,$serverpass);
	my($cipher);
	while(($sip,$sport,$serverpass)=$query_output->fetchrow)
		{
		my($command)=qq(do=remove+referer&ip=$ip);
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		&Connect($sip,$sport,$serverpass,$command);
		if($remote{'status'} ne "done"){&Error("Unable to update referers on hosting server $ip, $remote{'status'}");}
		$command=qq(do=add+referer&ip=$FORM{'ip'});
		&Connect($sip,$sport,$serverpass,$command);
		if($remote{'status'} ne "done"){&Error("Unable to update referers on hosting server $ip, $remote{'status'}");}
		}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Signup server updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Signup
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@values)=$query_output->fetchrow_array;
my($cipher);
if(&decode_base64($values[5]) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverpass)=$cipher->decrypt(&decode_base64($values[5]));
$statement=qq(SELECT id,name FROM server_pool ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Signup Server</td></tr>
<tr><td class="prgout" align=left>Server Name</td>
<td class="prgout" align=left><input name="name" type="text" value="$values[2]" size=20,1 maxlength=80></td></tr>
<tr><td class="prgout" align=left>IP Address</td>
<td class="prgout" align=left><input name="ip" type="text" value="$values[3]" size=15,1 maxlength=15></td></tr>
<tr><td class="prgout" align=left>Port</td>
<td class="prgout" align=left><input name="port" type="text" value="$values[4]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left>Signup Program URL</td>
<td class="prgout" align=left><input name="signupurl" type="text" value="$values[66]" size=30,1 maxlength=200></td></tr>
<tr><td class="prgout" align=left>Signup Program Path</td>
<td class="prgout" align=left><input name="cgipath" type="text" value="$values[67]" size=30,1 maxlength=200></td></tr>
<tr><td class="prgout" align=left>Image URL</td>
<td class="prgout" align=left><input name="imageurl" type="text" value="$values[68]" size=30,1 maxlength=200></td></tr>
<tr><td class="prgout" align=left>User to own files to</td>
<td class="prgout" align=left><input name="user" type="text" value="$values[69]" size=30,1 maxlength=32></td></tr>
<tr><td class="prgout" align=left>Group to own files to</td>
<td class="prgout" align=left><input name="group" type="text" value="$values[70]" size=30,1 maxlength=32></td></tr>
<tr><td class="prgout" align=left>Server Pool(s)</td>
<td class="prgout" align=left><select name="pools" size=3 multiple>);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<option value="$id");
	if($values[6] =~ /\|$id\|/){print qq( selected);}
	print qq(>$name);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="$values[85]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter</A></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no");
if($values[20] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</A></td>
<td class="prgout" align=left><input name="nfpath" type="text" value="$values[52]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</A></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no");
if($values[53] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</A></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no");
if($values[23] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstart');" class="prgout">Web Server Start Command</A></td>
<td class="prgout" align=left><input name="webstart" type="text" value="$values[33]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstop');" class="prgout">Web Server Stop Command</A></td>
<td class="prgout" align=left><input name="webstop" type="text" value="$values[34]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webrestart');" class="prgout">Web Server Restart Command</A></td>
<td class="prgout" align=left><input name="webrestart" type="text" value="$values[33]" size=30,1 maxlength=355></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webpid');" class="prgout">Web Server PID File</A></td>
<td class="prgout" align=left><input name="webpid" type="text" value="$values[35]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">Include Path</A></td>
<td class="prgout" align=left><input name="includepath" type="text" value="$values[74]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" value="$values[86]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" value="$values[87]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" value="$values[88]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" value="$values[89]" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Server"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Signup">
</form>);
&Bottom;
}

##

sub Edit_Signup_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='signup' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a client interface server to edit");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Signup Server</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Edit+Signup&id=$id" class="prgout">$name</A><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Server"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Edit Signup">
</form>);
&Bottom;
}

##

sub Add_Signup
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id FROM server WHERE ip='$FORM{'ip'}' && type='signup');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($test)=$query_output->fetchrow;
if($test){&Error("This signup server is already registered in the system.");}
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($clientkey)=&encode_base64($cipher->encrypt($system{'enckey'}));
my($pools)="|".join("|",@POOLS)."|";
$statement=qq(INSERT INTO server (type,name,ip,port,serverpass,pools,netfilter,nfpath,autofirewall,clienturl,cgipath,imageurl,user,agroup,usefilecheck,
webstart,webstop,webrestart,webpid,includepath,sshport,sshstart,sshstop,sshrestart,sshpid)
VALUES ('signup','$FORM{'name'}','$FORM{'ip'}','$FORM{'port'}','$clientkey','$pools','$FORM{'netfilter'}','$FORM{'nfpath'}','$FORM{'autofirewall'}',
'$FORM{'signupurl'}','$FORM{'cgipath'}','$FORM{'imageurl'}','$FORM{'user'}','$FORM{'group'}','$FORM{'usefilecheck'}',
'$FORM{'webstart'}','$FORM{'webstop'}','$FORM{'webrestart'}','$FORM{'webpid'}','$FORM{'includepath'}','$FORM{'sshport'}',
'$FORM{'sshstart'}','$FORM{'sshstop'}','$FORM{'sshrestart'}','$FORM{'sshpid'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
my($id)=$query_output->fetchrow;
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},'mysql',$system{'mysqlroot'},$system{'mysqlpass'});
$statement=qq(GRANT ALL ON $system{'dbname'}.* TO $system{'dbuser'}\@$FORM{'ip'} IDENTIFIED BY "$system{'dbpass'}" WITH GRANT OPTION);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(Flush privileges);
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='hosting'||type='ns1'||type='ns2');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass);
while(($ip,$port,$serverpass)=$query_output->fetchrow)
	{
	my($command)=qq(do=add+referer&ip=$FORM{'ip'});
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to update referers on server $ip, $remote{'status'}");}
	}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the signup server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Generate signupd.inc on signup server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send signupd.inc"></td></tr>
</table>
<input name="id" type="hidden" value="$id">
<input name="do" type="hidden" value="Send signupdinc">
</form>);
&Bottom;
}

##

sub Add_Signup_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSS1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server_pool ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
// -->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Signup Server</td></tr>
<tr><td class="prgout" align=left>Server Name</td>
<td class="prgout" align=left><input name="name" type="text" size=20,1 maxlength=80></td></tr>
<tr><td class="prgout" align=left>IP Address</td>
<td class="prgout" align=left><input name="ip" type="text" size=15,1 maxlength=15></td></tr>
<tr><td class="prgout" align=left>Port</td>
<td class="prgout" align=left><input name="port" type="text" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left>Signup Program URL</td>
<td class="prgout" align=left><input name="signupurl" type="text" size=30,1 maxlength=200></td></tr>
<tr><td class="prgout" align=left>CGI Path</td>
<td class="prgout" align=left><input name="cgipath" type="text" size=30,1 maxlength=200></td></tr>
<tr><td class="prgout" align=left>Image URL</td>
<td class="prgout" align=left><input name="imageurl" type="text" size=30,1 maxlength=200></td></tr>
<tr><td class="prgout" align=left>User to own files to</td>
<td class="prgout" align=left><input name="user" type="text" size=30,1 maxlength=32></td></tr>
<tr><td class="prgout" align=left>Group to own files to</td>
<td class="prgout" align=left><input name="group" type="text" size=30,1 maxlength=32></td></tr>
<tr><td class="prgout" align=left>Server Pool(s)</td>
<td class="prgout" align=left><select name="pools" size=3 multiple>);
my($id,$name);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<option value="$id">$name);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="22" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter</A></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</A></td>
<td class="prgout" align=left><input name="nfpath" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</A></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</A></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstart');" class="prgout">Web Server Start Command</A></td>
<td class="prgout" align=left><input name="webstart" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstop');" class="prgout">Web Server Stop Command</A></td>
<td class="prgout" align=left><input name="webstop" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webrestart');" class="prgout">Web Server Restart Command</A></td>
<td class="prgout" align=left><input name="webrestart" type="text" size=30,1 maxlength=355></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webpid');" class="prgout">Web Server PID File</A></td>
<td class="prgout" align=left><input name="webpid" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">Include Path</A></td>
<td class="prgout" align=left><input name="includepath" type="text" value="/etc/gnuhh/signup" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Signup Server"></td></tr>
</table>
<input name="do" type="hidden" value="Add Signup">
</form>);
&Bottom;
}

1;
