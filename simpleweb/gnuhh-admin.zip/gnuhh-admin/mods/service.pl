sub Reopen_Ticket
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE ticket SET rtime='0',status='out' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&View_Ticket;
}

##

sub Change_Department
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC1'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'notes'}=~s/\'/\\\'/g;
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min)==1){$min="0".$min;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
if($FORM{'notes'})
	{
	$statement=qq(INSERT INTO notes (ticket,name,comments,ptime) VALUES ('$FORM{'id'}','$Cookies{'auser'}','$FORM{'notes'}','$year-$mon-$mday $hour:$min'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
$statement=qq(UPDATE ticket SET hold='$FORM{'hold'}',status='in',department='$FORM{'department'}');
if($FORM{'resolved'} eq "yes")
	{
	$statement.=qq(,rtime='$year-$mon-$mday $hour:$min');
	}
$statement.=qq( WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){return("status=$error");}
$statement=qq(SELECT name,email,comments,ptime,level FROM ticket WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$email,$comments,$ptime,$level)=$query_output->fetchrow;
my($message)=qq($name,

Your service request,

$comments,

has been updated with the following comments from support:

$FORM{'notes'}\n);
&send_mail($system{'adminemail'},"$name <$email>","Service Request Update",$message);
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
my(@days)=('sun','mon','tue','wed','thu','fri','sat');
my(@levels)=('','normal','high','emergency');
if(length($hour)==1){$hour="0".$hour;}
if(length($min)==1){$min="0".$min;}
$statement=qq(SELECT DISTINCT user,email FROM notify WHERE $days[$wday]='yes' && start <= '$hour:$min' && end >= '$hour:$min');
$statement.=qq( && \($levels[$level]='yes');
if($FORM{'department'} eq "Adv Service"){$statement.=qq( && advanced='yes');}
if($FORM{'department'} eq "Management"){$statement.=qq( || management='yes');}
$statement.=qq(\));
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($user,$email);
while(($user,$email)=$query_output->fetchrow)
	{
	my($message)=qq($user,
A $levels[$level] level service ticket was just changed to $FORM{'department'}.);
	&send_mail($system{'adminemail'},$email,"Service Ticket Department Change ($levels[$level])",$message);
	}
&Tickets;
}

##

sub View_Closed
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC2'} ne "yes")){&Error('Insufficient access for this function');}
my($name,$ip,$port,$serverpass,$domain,$email,$phone,$comments,$level,$ptime,$rtime);
my(%priority)=('1','Normal','2','High','3','Emergency');
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ticket.name,domain_map.domain,ticket.email,ticket.phone,ticket.comments,ticket.level,ticket.ptime,ticket.rtime,ticket.department
FROM ticket,domain_map WHERE domain_map.id=ticket.domain && ticket.id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$domain,$email,$phone,$comments,$level,$ptime,$rtime,$department)=$query_output->fetchrow;
$statement=qq(SELECT name,comments,ptime FROM notes WHERE ticket='$FORM{'id'}' ORDER BY id ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>View Service Ticket $FORM{'id'}</td></tr>
<tr><td class="prgout" align=left>Name</td>
<td class="prgout" align=left>$name</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left>$domain</td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><a href="mailto:$email" class="prgout">$email</A> &nbsp;</td></tr>
<tr><td class="prgout" align=left>Phone</td>
<td class="prgout" align=left>$phone</td></tr>
<tr><td class="prgout" align=left>Priority</td>
<td class="prgout" align=left>$priority{$level}</td></tr>
<tr><td class="prgout" align=left>Department</td>
<td class="prgout" align=left>$department</td></tr>
<tr><td class="prgout" align=left>Time Posted</td>
<td class="prgout" align=left>$ptime</td></tr>
<tr><td class="prgout" align=left>Posted Resolved</td>
<td class="prgout" align=left>$rtime</td></tr>
<tr><td class="prgout" align=left Valign=top>Comments</td>
<td class="prgout" align=left Valign=top>$comments&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top>Notes</td>
<td class="prgout" align=left>);
while(($name,$comments,$ptime)=$query_output->fetchrow)
	{
	print qq($comments - by $name $ptime<BR><BR>);
	}
print qq(&nbsp;</td></tr>
<tr><td class="prgout" align=center colspan=2><a href="$script?do=reopen+ticket&id=$FORM{'id'}" class="prgout">Reopen Ticket</a></td></tr>
</table>\n);
&Bottom;
}

##

sub Search_History
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC2'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'sterm'}=~s/\*/\%/g;
if(!$FORM{'num'}){$FORM{'num'}="0";}
if(!$FORM{'count'}){$FORM{'count'}="25";}
if($FORM{'num'} < $FORM{'count'}){$FORM{'num'}="0";}
my($db,$statement,$query_output,$ampm,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ticket.id,ticket.name,ticket.email,domain_map.domain,ticket.comments,ticket.level,ticket.ptime,ticket.rtime,ticket.department,
domain_map.id FROM ticket,domain_map WHERE domain_map.id=ticket.domain && rtime != '0');
if($FORM{'domain'}){$statement.=qq( && domain_map.id='$FORM{'domain'}');}
if(($FORM{'usename'} eq "yes")||($FORM{'useemail'} eq "yes")||($FORM{'usedomain'} eq "yes")){$statement.=qq( && \();}
if($FORM{'usename'} eq "yes"){$statement.=qq( ticket.name LIKE '$FORM{'sterm'}');}
if(($FORM{'usename'} eq "yes")&&($FORM{'useemail'} eq "yes")){$statement.=qq( || ticket.email LIKE '$FORM{'sterm'}');}
elsif($FORM{'useemail'} eq "yes"){$statement.=qq( ticket.email LIKE '$FORM{'sterm'}');}
if((($FORM{'usename'} eq "yes")||($FORM{'useemail'} eq "yes"))&&($FORM{'usedomain'} eq "yes")){$statement.=qq( || domain_map.domain LIKE '$FORM{'sterm'}');}
elsif($FORM{'usedomain'} eq "yes"){$statement.=qq( domain_map.domain LIKE '$FORM{'sterm'}');}
if(($FORM{'usename'} eq "yes")||($FORM{'useemail'} eq "yes")||($FORM{'usedomain'} eq "yes")){$statement.=qq( \));}
if(!$FORM{'sortby'}){$statement.=qq( ORDER BY ticket.ptime ASC);}
elsif($FORM{'sortby'} eq "nameasc"){$statement.=qq( ORDER BY ticket.name ASC);}
elsif($FORM{'sortby'} eq "namedesc"){$statement.=qq( ORDER BY ticket.name DESC);}
elsif($FORM{'sortby'} eq "domainasc"){$statement.=qq( ORDER BY domain_map.domain ASC);}
elsif($FORM{'sortby'} eq "domaindesc"){$statement.=qq( ORDER BY domain_map.domain DESC);}
elsif($FORM{'sortby'} eq "prioritydesc"){$statement.=qq( ORDER BY ticket.level DESC);}
elsif($FORM{'sortby'} eq "priorityasc"){$statement.=qq( ORDER BY ticket.level ASC);}
elsif($FORM{'sortby'} eq "timeasc"){$statement.=qq( ORDER BY ticket.ptime ASC);}
elsif($FORM{'sortby'} eq "timedesc"){$statement.=qq( ORDER BY ticket.ptime DESC);}
elsif($FORM{'sortby'} eq "resasc"){$statement.=qq( ORDER BY ticket.rtime ASC);}
elsif($FORM{'sortby'} eq "resdesc"){$statement.=qq( ORDER BY ticket.rtime DESC);}
elsif($FORM{'sortby'} eq "departmentasc"){$statement.=qq( ORDER BY ticket.department ASC);}
elsif($FORM{'sortby'} eq "departmentdesc"){$statement.=qq( ORDER BY ticket.department DESC);}
$statement.=qq( LIMIT $FORM{'num'},$FORM{'count'});
my $statement2=$statement;
$statement2=~s/^.*[^(FROM)]*(FROM.*)ORDER.*$/SELECT COUNT(ticket.id) $1/;
$query_output=$db->query($statement2);
if($error=$db->errmsg){&Error($error);}
my $count=$query_output->fetchrow;
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$FORM{'sterm'}=~s/\%/\*/g;
my($id,$name,$email,$domain,$comments,$level,$ptime,$rtime,$department,$domid);
my(%priority)=('1','Normal','2','High','3','Emergency');
&Top;
print qq(<script language="javascript">
<!--
function GoTo(x){
self.location.href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=$FORM{'sortby'}&domain=$FORM{'domain'}&usename=$FORM{'usename'}&useemail=$FORM{'useemail'}&usedomain=$FORM{'usedomain'}&num=$FORM{'num'}&count="+x;
}
// -->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=8>View Service Ticket History</td></tr>
<tr><td class="filler">&nbsp;</td>
<td class="headb" align=center>\n);
if($FORM{'sortby'} ne "nameasc"){print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=nameasc&domain=$FORM{'domain'}&usename=$FORM{'usename'}&useemail=$FORM{'useemail'}&usedomain=$FORM{'usedomain'}" class="prgout">);}
else{print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=namedesc&domain=$FORM{'domain'}" class="prgout">);}
print qq(Name</A></td>
<td class="headb" align=center>);
if($FORM{'sortby'} ne "domainasc"){print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=domainasc&domain=$FORM{'domain'}&usename=$FORM{'usename'}&useemail=$FORM{'useemail'}&usedomain=$FORM{'usedomain'}" class="prgout">);}
else{print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=domaindesc&domain=$FORM{'domain'}" class="prgout">);}
print qq(Domain</A></td>
<td class="headb" align=center>Comments</td>
<td class="headb" align=center>);
if($FORM{'sortby'} ne "prioritydesc"){print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=prioritydesc&domain=$FORM{'domain'}&usename=$FORM{'usename'}&useemail=$FORM{'useemail'}&usedomain=$FORM{'usedomain'}" class="prgout">);}
else{print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=priorityasc&domain=$FORM{'domain'}" class="prgout">);}
print qq(Priority</A></td>
<td class="headb" align=left>);
if($FORM{'sortby'} ne "departmentasc"){print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=departmentasc&domain=$FORM{'domain'}&usename=$FORM{'usename'}&useemail=$FORM{'useemail'}&usedomain=$FORM{'usedomain'}" class="prgout">);}
else{print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=departmentdesc&domain=$FORM{'domain'}" class="prgout">);}
print qq(Department</td>
<td class="headb" align=center>);
if($FORM{'sortby'} ne "timeasc"){print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=timeasc&domain=$FORM{'domain'}&usename=$FORM{'usename'}&useemail=$FORM{'useemail'}&usedomain=$FORM{'usedomain'}" class="prgout">);}
else{print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=timedesc&domain=$FORM{'domain'}" class="prgout">);}
print qq(Post Time</A></td>
<td class="headb" align=center>\n);
if($FORM{'sortby'} ne "resasc"){print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=resasc&domain=$FORM{'domain'}&usename=$FORM{'usename'}&useemail=$FORM{'useemail'}&usedomain=$FORM{'usedomain'}" class="prgout">);}
else{print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=resdesc&domain=$FORM{'domain'}" class="prgout">);}
print qq(Resolved Time</td></tr>\n);
while(($id,$name,$email,$domain,$comments,$level,$ptime,$rtime,$department,$domid)=$query_output->fetchrow)
	{
	print qq(<tr><td class="prgout" align=center Valign=top><a href="$script?do=view+closed&id=$id" class="prgout">View</A></td>
<td class="prgout" align=left Valign=top>$name<br><a href="mailto:$email" class="prgout">$email</A></td>
<td class="prgout" align=left Valign=top><a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=$FORM{'sortby'}&domain=$domid&usename=$FORM{'usename'}&useemail=$FORM{'useemail'}&usedomain=$FORM{'usedomain'}" class="prgout">$domain</A></td>
<td class="prgout" align=left Valign=top>$comments</td>
<td class="prgout" align=left Valign=top>$priority{$level}</td>
<td class="prgout" align=left valign=top>$department</td>
<td class="prgout" align=left Valign=top>$ptime</td>
<td class="prgout" align=left Valign=top>$rtime</td></tr>\n);
	}
if($count <= 0){print qq(<tr><td class="prgout" align=left colspan=8>No tickets found</td></tr>\n);}
print qq(<tr><td class="prgout" align=right colspan=4><input name="sterm" type="text" value="$FORM{'sterm'}" size=20,1></td>
<td class="prgout" align=left colspan=4><input name="usename" type="checkbox" value="yes");
if($FORM{'usename'} eq "yes"){print qq( checked);}
print qq(>Name <input name="useemail" type="checkbox" value="yes");
if($FORM{'useemail'} eq "yes"){print qq( checked);}
print qq(>Email <input name="usedomain" type="checkbox" value="yes");
if($FORM{'usedomain'} eq "yes"){print qq( checked);}
print qq(>Domain</td></tr>
<tr><td class="prgout" align=center colspan=8><input type="submit" value="Search History"></td></tr>);
if(($count > ($FORM{'num'}+$FORM{'count'}))||($FORM{'num'} > 0))
	{
	print qq(<tr><td class="prgout" align=left>);
	if($FORM{'num'} > 0)
		{
		my $prev=$FORM{'num'}-$FORM{'count'};
		print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=$FORM{'sortby'}&domain=$FORM{'domain'}&usename=$FORM{'usename'}&useemail=$FORM{'useemail'}&usedomain=$FORM{'usedomain'}&count=$FORM{'count'}&num=$prev" class="prgout">Previous</a>);
		}
	else{print qq(&nbsp;);}
	print qq(</td>
<td class="prgout" align=center colspan=6><select name="count" size=1 onChange="GoTo(this.value);"><option value="10");
	if($FORM{'count'} eq "10"){print qq( selected);}
	print qq(>10<option value="25");
	if($FORM{'count'} eq "25"){print qq( selected);}
	print qq(>25<option value="50");
	if($FORM{'count'} eq "50"){print qq( selected);}
	print qq(>50<option value="100");
	if($FORM{'count'} eq "100"){print qq( selected);}
	print qq(>100</select></td>
<td class="prgout" align=right>);
	if($count > ($FORM{'num'}+$FORM{'count'}))
		{
		my $next=$FORM{'num'}+$FORM{'count'};
		print qq(<a href="$script?do=Search+History&sterm=$FORM{'sterm'}&sortby=$FORM{'sortby'}&domain=$FORM{'domain'}&usename=$FORM{'usename'}&useemail=$FORM{'useemail'}&usedomain=$FORM{'usedomain'}&count=$FORM{'count'}&num=$next" class="prgout">Next</a>);
		}
	else{print qq(&nbsp;);}
	print qq(</td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Search History">
</form>\n);
&Bottom;
}

##

sub View_History
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC2'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Service Ticket History</td></tr>
<tr><td class="prgout" align=left><input name="sterm" type="text" size=20,1></td>
<td class="prgout" align=left><input name="usename" type="checkbox" value="yes">Name <input name="useemail" type="checkbox" value="yes">Email <input name="usedomain" type="checkbox" value="yes">Domain</td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Search"></td></tr>
</table>
<input name="do" type="hidden" value="Search History">
</form>);
&Bottom;
}
##

sub Update_Ticket
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC1'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'notes'}=~s/\'/\\\'/g;
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min)==1){$min="0".$min;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(INSERT INTO notes (ticket,name,comments,ptime) VALUES ('$FORM{'id'}','$Cookies{'auser'}','$FORM{'notes'}','$year-$mon-$mday $hour:$min'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(UPDATE ticket SET hold='$FORM{'hold'}',status='in');
if($FORM{'resolved'} eq "yes")
	{
	$statement.=qq(,rtime='$year-$mon-$mday $hour:$min');
	}
$statement.=qq( WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){return("status=$error");}
$statement=qq(SELECT name,email,comments,ptime FROM ticket WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$email,$comments,$ptime)=$query_output->fetchrow;
my($message)=qq($name,

Your service request,

$comments,

has been updated with the following comments from support:

$FORM{'notes'}\n);
&send_mail($system{'adminemail'},"$name <$email>","Service Request Update",$message);
&Tickets;
}

##

sub Check_In
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE ticket SET status='in' WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Tickets;
}

##

sub View_Ticket
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC1'} ne "yes")){&Error('Insufficient access for this function');}
my($name,$ip,$port,$serverpass,$domain,$email,$phone,$comments,$level,$ptime,$rtime,$hold);
my(%priority)=('1','Normal','2','High','3','Emergency');
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE ticket SET status='out' WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT ticket.name,domain_map.domain,domain_map.id,ticket.email,ticket.phone,ticket.comments,ticket.access,ticket.level,ticket.ptime,ticket.rtime,ticket.hold,
server.name,domain_map.ip,ticket.department FROM ticket,domain_map,server WHERE domain_map.id=ticket.domain && ticket.id='$FORM{'id'}' && server.id=domain_map.server);
$query_output=$db->query($statement);
my($name,$domain,$domid,$email,$phone,$comments,$access,$level,$ptime,$rtime,$hold,$server,$ip,$department)=$query_output->fetchrow;
$statement=qq(SELECT name,comments,ptime FROM notes WHERE ticket='$FORM{'id'}' ORDER BY id ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>View Service Ticket $FORM{'id'}</td></tr>
<tr><td class="prgout" align=center colspan=2><a href="$script?do=view+domain+info&domain=$domid" target="_new">View Account Data</A> * <a href="$script?do=Search+History&sterm=$domain&usedomain=yes" target="_new" class="prgout">View History</A></td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left>$domain</td></tr>
<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left>$server</td></tr>
<tr><td class="prgout" align=left>IP Address</td>
<td class="prgout" align=left>$ip</td></tr>
<tr><td class="prgout" align=left>Name</td>
<td class="prgout" align=left>$name</td></tr>
<tr><td class="prgout" align=left>Access Level</td>
<td class="prgout" align=left>$access</td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><a href="mailto:$email" class="prgout">$email</A> &nbsp;</td></tr>
<tr><td class="prgout" align=left>Phone</td>
<td class="prgout" align=left>$phone &nbsp;</td></tr>
<tr><td class="prgout" align=left>Priority</td>
<td class="prgout" align=left>$priority{$level}</td></tr>
<tr><td class="prgout" align=left>Department</td>
<td class="prgout" align=left>$department</td></tr>
<tr><td class="prgout" align=left>Time Posted</td>
<td class="prgout" align=left>$ptime</td></tr>
<tr><td class="prgout" align=left>Hold Status</td>
<td class="prgout" align=left><input name="hold" type="checkbox" value="yes");
if($hold eq "yes")
	{
	print qq( CHECKED);
	}
print qq(> On Hold?</td></tr>
<tr><td class="prgout" align=left Valign=top>Comments</td>
<td class="prgout" align=left Valign=top>$comments&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top>Notes</td>
<td class="prgout" align=left>);
while(($name,$comments,$ptime)=$query_output->fetchrow)
	{
	print qq($comments - by $name $ptime<BR><BR>);
	}
print qq(&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top>Add Notes</td>
<td class="prgout" align=left> <textarea name="notes" rows=5 cols=40 wrap=off></textarea></td></tr>
<tr><td class="prgout" align=left>Mark Resolved?</td>
<td class="prgout" align=left><input name="resolved" type="checkbox" value="yes"></td></tr>
<tr><td class="prgout" align=left>Change Department</td>
<td class="prgout" align=left><select name="department" size=1>);
if($department ne "Service"){print qq(<option value="Service">Service);}
if($department ne "Adv Service"){print qq(<option value="Adv Service">Adv Service);}
if($department ne "Billing"){print qq(<option value="Billing">Billing);}
if($department ne "Management"){print qq(<option value="Banagement">Management);}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input name="do" type="submit" value="Update Ticket"> <input name="do" type="submit" value="Check In">
<input name="do" type="submit" value="Change Department"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
</form>\n);
&Bottom;
}

##

sub Tickets
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC1'} ne "yes")){&Error('Insufficient access for this function');}
my(%priority)=('1','Normal','2','High','3','Emergency');
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ticket.id,ticket.name,domain_map.domain,ticket.comments,ticket.level,ticket.ptime,ticket.hold,ticket.status,ticket.department
FROM ticket,domain_map WHERE domain_map.id=ticket.domain && rtime='0000-00-00 00:00:00');
if($FORM{'showout'} ne "yes")
	{
	$statement.=qq( && status='in');
	}
if(!$FORM{'sortby'})
	{
	$statement.=qq( ORDER BY ticket.ptime ASC);
	}
elsif($FORM{'sortby'} eq "nameasc")
	{
	$statement.=qq( ORDER BY ticket.name ASC);
	}
elsif($FORM{'sortby'} eq "namedesc")
	{
	$statement.=qq( ORDER BY ticket.name DESC);
	}
elsif($FORM{'sortby'} eq "domainasc")
	{
	$statement.=qq( ORDER BY domain_map.domain ASC);
	}
elsif($FORM{'sortby'} eq "domaindesc")
	{
	$statement.=qq( ORDER BY domain_map.domain DESC);
	}
elsif($FORM{'sortby'} eq "prioritydesc")
	{
	$statement.=qq( ORDER BY ticket.level DESC);
	}
elsif($FORM{'sortby'} eq "priorityasc")
	{
	$statement.=qq( ORDER BY ticket.level ASC);
	}
elsif($FORM{'sortby'} eq "timeasc")
	{
	$statement.=qq( ORDER BY ticket.ptime ASC);
	}
elsif($FORM{'sortby'} eq "timedesc")
	{
	$statement.=qq( ORDER BY ticket.ptime DESC);
	}
elsif($FORM{'sortby'} eq "departmentasc")
	{
	$statement.=qq( ORDER BY ticket.department ASC);
	}
elsif($FORM{'sortby'} eq "departmentdesc")
	{
	$statement.=qq( ORDER BY ticket.department DESC);
	}
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name,$domain,$comments,$level,$ptime,$hold,$status,$department);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=8><B>Service Ticket Database</B></td></tr>
<tr><td class="filler">&nbsp;</td>
<td class="headb" align=center>);
if($FORM{'sortby'} ne "nameasc")
	{
	print qq(<a href="$script?do=view+tickets&showout=$FORM{'showout'}&sortby=nameasc" class="prgout">);
	}
else
	{
	print qq(<a href="$script?do=view+tickets&showout=$FORM{'showout'}&sortby=namedesc" class="prgout">);
	}
print qq(Name</A></td>
<td class="headb" align=center>);
if($FORM{'sortby'} ne "domainasc")
	{
	print qq(<a href="$script?do=view+tickets&showout=$FORM{'showout'}&sortby=domainasc" class="prgout">);
	}
else
	{
	print qq(<a href="$script?do=view+tickets&showout=$FORM{'showout'}&sortby=domaindesc" class="prgout">);
	}
print qq(Domain</A></td>
<td class="headb" align=center>Comments</td>
<td class="headb" align=center>);
if($FORM{'sortby'} ne "prioritydesc")
	{
	print qq(<a href="$script?do=view+tickets&showout=$FORM{'showout'}&sortby=prioritydesc" class="prgout">);
	}
else
	{
	print qq(<a href="$script?do=view+tickets&showout=$FORM{'showout'}&sortby=priorityasc" class="prgout">);
	}
print qq(Priority</A></td>
<td class="headb" align=center>);
if($FORM{'sortby'} ne "departmentasc")
	{
	print qq(<a href="$script?do=view+tickets&showout=$FORM{'showout'}&sortby=departmentasc" class="prgout">);
	}
else
	{
	print qq(<a href="$script?do=view+tickets&showout=$FORM{'showout'}&sortby=departmentdesc" class="prgout">);
	}
print qq(Department</A></td>
<td class="headb" align=center>);
if($FORM{'sortby'} ne "timeasc")
	{
	print qq(<a href="$script?do=view+tickets&showout=$FORM{'showout'}&sortby=timeasc" class="prgout">);
	}
else
	{
	print qq(<a href="$script?do=view+tickets&showout=$FORM{'showout'}&sortby=timedesc" class="prgout">);
	}
print qq(Time</A></td>
<td class="headb" align=center>Hold Status</td></tr>\n);
while(($id,$name,$domain,$comments,$level,$ptime,$hold,$status,$department)=$query_output->fetchrow)
	{
	print qq(<tr><td class="prgout" align=center Valign=top><a href="$script?do=view+ticket&id=$id" class="prgout">View</A>);
	if($status eq "out")
		{
		print qq(<BR>This ticket is out);
		}
	print qq(</td>
<td class="prgout" align=left Valign=top>$name</td>
<td class="prgout" align=left Valign=top>$domain</td>
<td class="prgout" align=left Valign=top>$comments</td>
<td class="prgout" align=left Valign=top>$priority{$level}</td>
<td class="prgout" align=left>$department</td>
<td class="prgout" align=left Valign=top>$ptime</td>
<td class="prgout" align=center>);
	if($hold eq "yes")
		{
		print qq(On Hold);
		}
	else
		{
		print qq(&nbsp;);
		}
	print qq(</td></tr>\n);
	}
if($FORM{'showout'} ne "yes")
	{
	print qq(<tr><td class="prgout" align=center colspan=8><a href="$script?do=view+tickets&showout=yes" class="prgout">Show "Out" Tickets</A></td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=center colspan=8><a href="$script?do=view+tickets" class="prgout">Hide "Out" Tickets</A></td></tr>\n);
	}
print qq(</table>\n);
&Bottom;
}

##

sub Add_Ticket
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC3'} ne "yes")){&Error('Insufficient access for this function');}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
if(length($min)==1){$min="0".$min;}
my($time)=qq($year-$mon-$mday $hour:$min);
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT user_map.admin,user_map.email,user_map.billing,user_map.ftp,user_map.web FROM user_map,user
WHERE user.email='$FORM{'email'}' && user_map.domain='$FORM{'domain'}' && user_map.user=user.id);
$query_output=$db->query($statement);
my($admin,$email,$billing,$ftp,$web)=$query_output->fetchrow;
my(@access);
if($admin eq "yes"){push(@access,"admin");}
if($email eq "yes"){push(@access,"email");}
if($billing eq "yes"){push(@access,"billing");}
if($ftp eq "yes"){push(@access,"ftp");}
if($web eq "yes"){push(@access,"web");}
$statement=qq(INSERT INTO ticket (name,domain,email,phone,comments,access,level,ptime,status,department) VALUES \('$FORM{'name'}','$FORM{'domain'}',
'$FORM{'email'}','$FORM{'phone'}','$FORM{'comments'}',');
$statement.=join(",",@access);
$statement.=qq(','$FORM{'priority'}','$time','in','$FORM{'department'}'\));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
my(@days)=('sun','mon','tue','wed','thu','fri','sat');
my(@levels)=('','normal','high','emergency');
if(length($hour)==1){$hour="0".$hour;}
if(length($min)==1){$min="0".$min;}
$statement=qq(SELECT DISTINCT user,email FROM notify WHERE $days[$wday]='yes' && start <= '$hour:$min' && end >= '$hour:$min');
$statement.=qq( && \($levels[$FORM{'priority'}]='yes');
if($FORM{'department'} eq "Adv Service"){$statement.=qq( && advanced='yes');}
if($FORM{'department'} eq "Management"){$statement.=qq( || management='yes');}
$statement.=qq(\));
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($user,$email);
while(($user,$email)=$query_output->fetchrow)
	{
	my($message)=qq($user,
A $levels[$FORM{'priority'}] level service ticket for $FORM{'department'} was just placed.);
	&send_mail($system{'adminemail'},$email,"New Service Ticket ($levels[$FORM{'priority'}])",$message);
	}
&Start;
}

##

sub Add_Ticket2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC3'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE domain LIKE '$FORM{'domain'}' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$FORM{'domain'}=~s/\%/\*/g;
my($id,$domain);
&Top;
print qq(<script language="javascript">
function chkData() {
if(document.forms[0].domain.selectedIndex <= 0)
{
alert("Select a domain to enter a ticket for");
return false;
}
if(document.forms[0].name.value <= 0) 
{
alert("Enter the name of the person reporting the request");

return false;
}
if(document.forms[0].email.value <= 0)
{
alert("Enter the email address of the person reporting the request");
return false;
}
if(document.forms[0].comments.value <= 0) 
{
alert("Enter details about the service request");
return false;
}
else
return true;
}
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Servic Ticket</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><select name="domain" size=1"><option value="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<option value="$id");
	if($domain eq $FORM{'domain'}){print qq( selected);}
	print qq(>$domain);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left>Department</td>
<td class="prgout" align=left><select name="department" size=1><option value="Service">Service<option value="Adv Service">Adv Service<option value="Billing">Billing<option value="Management">Management</select></td></tr>
<tr><td class="prgout" align=left>Name</td>
<td class="prgout" align=left><input name="name" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left>Email</td>
<td class="prgout" align=left><input name="email" type="text" size=20,1></td></tr>
<tr><td class="prgout" align=left>Phone</td>
<td class="prgout" align=left><input name="phone" type="text" size=20,1></td></tr>
<tr><td class="prgout" align=left Valign=top>Service Request</td>
<td class="prgout" align=left> <textarea name="comments" rows=10 cols=30 wrap=off></textarea></td></tr>
<tr><td class="prgout" align=left>Priority</td>
<td class="prgout" align=left><select name="priority" size=1><option value="1">Normal
<option value="2">High - Requires Attention Soon
<option value="3">Emergency - Requires Attention Immediatelly</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Ticket"></td></tr>
</table>
<input name="do" type="hidden" value="Add Ticket">
</form>);
&Bottom;
}

##

sub Add_Ticket_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'TC3'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Add Ticket2";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Servic Ticket</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Add Ticket2">
</form>
<div id="dlist" style="position:absolute;display:none;"></div>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

1;
