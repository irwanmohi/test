sub Remove_Notification
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM notify WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Notification entry removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Notification_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM notify ORDER BY user);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@fields)=$query_output->name;
my(@values,$i);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to remove this notification listing?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=4>Remove Notification Listing</td></tr>
<tr><td class="headb" align=left>User</td>
<td class="headb" align=left>Notification</td>
<td class="headb" align=left>Days</td>
<td class="headb" align=left>Time</td></tr>\n);
while((@values)=$query_output->fetchrow_array)
	{
	print qq(<tr><td class="prgout" align=left><A HREF="$script?do=Remove+Notification&id=$values[0]" onClick="return ConFirm();" class="prgout">$values[1]</A></td>
<td class="prgout" align=left>);
	for($i=3;$i<=10;$i++)
		{
		if($values[$i]){print qq(\u$fields[$i] );}
		}
	print qq(</td>
<td class="prgout" align=left>);
	for($i=11;$i<=17;$i++)
		{
		if($values[$i]){print qq(\u$fields[$i] );}
		}
	print qq(</td>
<td class="prgout" align=left>$values[18] - $values[19]</td></tr>\n);
	}
print qq(</table>);
&Bottom;
}

##

sub Save_Notification
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE notify SET email='$FORM{'email'}',normal='$FORM{'normal'}',high='$FORM{'high'}',emergency='$FORM{'emergency'}',
service='$FORM{'service'}',filecheck='$FORM{'filecheck'}',signup='$FORM{'signup'}',sun='$FORM{'sun'}',mon='$FORM{'mon'}',tue='$FORM{'tue'}',
wed='$FORM{'wed'}',thu='$FORM{'thu'}',fri='$FORM{'fri'}',sat='$FORM{'sat'}',start='$FORM{'starthour'}:$FORM{'startmin'}',
end='$FORM{'endhour'}:$FORM{'endmin'}',advanced='$FORM{'advanced'}',management='$FORM{'management'}' WHERE id='$FORM{'id'}');
$db->query($statement);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Notification entry updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Notification
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM notify WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@values)=$query_output->fetchrow_array;
&Top;
print qq(<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Notification Listing</td></tr>
<tr><td class="prgout" align=left>Administrator</td>
<td class="prgout" align=left>$values[1]</td>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><input name="email" type="text" value="$values[2]" size=30,1 maxlength="75"></td></tr>
<tr><td class="prgout" align=left>Normal Ticket</td>
<td class="prgout" align=left><input name="normal" type="checkbox" value="yes");
if($values[3] eq "yes"){print qq( checked);}
print qq(></td></tr>
<tr><td class="prgout" align=left>High Ticket</td>
<td class="prgout" align=left><input name="high" type="checkbox" value="yes");
if($values[4] eq "yes"){print qq( checked);}
print qq(></td></tr>
<tr><td class="prgout" align=left>Emergency Ticket</td>
<td class="prgout" align=left><input name="emergency" type="checkbox" value="yes");
if($values[5] eq "yes"){print qq( checked);}
print qq(></td></tr>
<tr><td class="prgout" align=left>Advanced Ticket</td>
<td class="prgout" align=left><input name="advanced" type="checkbox" value="yes");
if($values[6] eq "yes"){print qq( checked);}
print qq(></td></tr>
<tr><td class="prgout" align=left>Management Ticket</td>
<td class="prgout" align=left><input name="management" type="checkbox" value="yes");
if($values[7] eq "yes"){print qq( checked);}
print qq(></td></tr>
<tr><td class="prgout" align=left>Service Outage</td>
<td class="prgout" align=left><input name="service" type="checkbox" value="yes");
if($values[8] eq "yes"){print qq( checked);}
print qq(></td></tr>
<tr><td class="prgout" align=left>Filecheck</td>
<td class="prgout" align=left><input name="filecheck" type="checkbox" value="yes");
if($values[9] eq "yes"){print qq( checked);}
print qq(></td></tr>
<tr><td class="prgout" align=left>Signup</td>
<td class="prgout" align=left><input name="signup" type="checkbox" value="yes");
if($values[10] eq "yes"){print qq( checked);}
print qq(></td></tr>
<tr><td class="prgout" align=left>Days</td>
<td class="prgout" align=left><input name="sun" type="checkbox" value="yes");
if($values[11] eq "yes"){print qq( checked);}
print qq(>Sun
<input name="mon" type="checkbox" value="yes");
if($values[12] eq "yes"){print qq( checked);}
print qq(>Mon
<input name="tue" type="checkbox" value="yes");
if($values[13] eq "yes"){print qq( checked);}
print qq(>Tue
<input name="wed" type="checkbox" value="yes");
if($values[14] eq "yes"){print qq( checked);}
print qq(>Wed
<input name="thu" type="checkbox" value="yes");
if($values[15] eq "yes"){print qq( checked);}
print qq(>Thu
<input name="fri" type="checkbox" value="yes");
if($values[16] eq "yes"){print qq( checked);}
print qq(>Fri
<input name="sat" type="checkbox" value="yes");
if($values[17] eq "yes"){print qq( checked);}
print qq(>Sat</td></tr>
<tr><td class="prgout" align=left>Start</td>
<td class="prgout" align=left><select name="starthour" size=1>);
my($starthour,$startmin)=split(/:/,$values[18]);
my($endhour,$endmin)=split(/:/,$values[19]);
my($i);
for($i=0;$i<=23;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i");
	if($i eq $starthour){print qq( selected);}
	print qq(>$i);
	}
print qq(</select>:<select name="startmin" size=1>);
for($i=0;$i<=59;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i");
	if($i eq $startmin){print qq( selected);}
	print qq(>$i);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left>Stop</td>
<td class="prgout" align=left><select name="endhour" size=1>);
for($i=0;$i<=23;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i");
	if($i eq $endhour){print qq( selected);}
	print qq(>$i);
	}
print qq(</select>:<select name="endmin" size=1>);
for($i=0;$i<=59;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i");
	if($i eq $endmin){print qq( selected);}
	print qq(>$i);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Notification"></td></tr>
</table>
<input name="do" type="hidden" value="Save Notification">
<input name="id" type="hidden" value="$values[0]">
</form>);
&Bottom;
}

##

sub Edit_Notification_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM notify ORDER BY user);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@fields)=$query_output->name;
my(@values,$i);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=4>Edit Notification Listing</td></tr>
<tr><td class="headb" align=left>User</td>
<td class="headb" align=left>Notification</td>
<td class="headb" align=left>Days</td>
<td class="headb" align=left>Time</td></tr>\n);
while((@values)=$query_output->fetchrow_array)
	{
	print qq(<tr><td class="prgout" align=left><A HREF="$script?do=Edit+Notification&id=$values[0]" class="prgout">$values[1]</A></td>
<td class="prgout" align=left>);
	for($i=3;$i<=10;$i++)
		{
		if($values[$i]){print qq(\u$fields[$i] );}
		}
	print qq(</td>
<td class="prgout" align=left>);
	for($i=11;$i<=17;$i++)
		{
		if($values[$i]){print qq(\u$fields[$i] );}
		}
	print qq(</td>
<td class="prgout" align=left>$values[18] - $values[19]</td></tr>\n);
	}
print qq(</table>);
&Bottom;
}

##

sub Add_Notification
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NS1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(INSERT INTO notify (user,email,normal,high,emergency,advanced,management,service,filecheck,signup,sun,mon,tue,wed,thu,fri,sat,start,end)
VALUES ('$FORM{'user'}','$FORM{'email'}','$FORM{'normal'}','$FORM{'high'}','$FORM{'emergency'}','$FORM{'advanced'}','$FORM{'management'}',
'$FORM{'service'}','$FORM{'filecheck'}','$FORM{'signup'}','$FORM{'sun'}','$FORM{'mon'}','$FORM{'tue'}','$FORM{'wed'}','$FORM{'thu'}',
'$FORM{'fri'}','$FORM{'sat'}','$FORM{'starthour'}:$FORM{'startmin'}','$FORM{'endhour'}:$FORM{'endmin'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Notification entry added</td></tr>
</table>);
&Bottom;
}

##

sub Add_Notification_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NS1'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].email.value <= 0)
{
alert("Enter an email address for notification.");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Notification Listing</td></tr>
<tr><td class="prgout" align=left>Administrator</td>
<td class="prgout" align=left><select name="user" size=1>\n);
open(FILE,"system.dat");
while(<FILE>)
	{
	my(@info)=split(/:/,$_);
	print qq(<option value="$info[0]">$info[0]);
	}
print qq(</select></td>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><input name="email" type="text" size=30,1 maxlength="75"></td></tr>
<tr><td class="prgout" align=left>Normal Ticket</td>
<td class="prgout" align=left><input name="normal" type="checkbox" value="yes"></td></tr>
<tr><td class="prgout" align=left>High Ticket</td>
<td class="prgout" align=left><input name="high" type="checkbox" value="yes"></td></tr>
<tr><td class="prgout" align=left>Emergency Ticket</td>
<td class="prgout" align=left><input name="emergency" type="checkbox" value="yes"></td></tr>
<tr><td class="prgout" align=left>Advanced Ticket</td>
<td class="prgout" align=left><input name="advanced" type="checkbox" value="yes"></td></tr>
<tr><td class="prgout" align=left>Management Ticket</td>
<td class="prgout" align=left><input name="management" type="checkbox" value="yes"></td></tr>
<tr><td class="prgout" align=left>Service Outage</td>
<td class="prgout" align=left><input name="service" type="checkbox" value="yes"></td></tr>
<tr><td class="prgout" align=left>Filecheck</td>
<td class="prgout" align=left><input name="filecheck" type="checkbox" value="yes"></td></tr>
<tr><td class="prgout" align=left>Signup</td>
<td class="prgout" align=left><input name="signup" type="checkbox" value="yes"></td></tr>
<tr><td class="prgout" align=left>Days</td>
<td class="prgout" align=left><input name="sun" type="checkbox" value="yes">Sun
<input name="mon" type="checkbox" value="yes">Mon
<input name="tue" type="checkbox" value="yes">Tue
<input name="wed" type="checkbox" value="yes">Wed
<input name="thu" type="checkbox" value="yes">Thu
<input name="fri" type="checkbox" value="yes">Fri
<input name="sat" type="checkbox" value="yes">Sat</td></tr>
<tr><td class="prgout" align=left>Start</td>
<td class="prgout" align=left><select name="starthour" size=1>);
my($i);
for($i=0;$i<=23;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i">$i);
	}
print qq(</select>:<select name="startmin" size=1>);
for($i=0;$i<=59;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i">$i);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left>Stop</td>
<td class="prgout" align=left><select name="endhour" size=1>);
for($i=0;$i<=23;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i">$i);
	}
print qq(</select>:<select name="endmin" size=1>);
for($i=0;$i<=59;$i++)
	{
	if(length($i)==1){$i="0".$i;}
	print qq(<option value="$i">$i);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Notification"></td></tr>
</table>
<input name="do" type="hidden" value="Add Notification">
</form>);
&Bottom;
}

1;
