use Net::SSH::Perl;

sub Save_Stats_Config
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS10'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'file'}=&uri_escape($FORM{'file'});
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=save+stats+config&file=$FORM{'file'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Statistical configuration file updated for $name</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Stats_Config
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS10'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+stats+config);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
$remote{'file'}=~s/\"/&quot;/g;
$remote{'file'}=~s/\>/&gt;/g;
$remote{'file'}=~s/\</&lt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Statistical Configuration on $name</td></tr>
<tr><td class="prgout" align=left>Use %%LOGFILE%% to designate the access log file<br>
Use %%TEMPFILE%% to designate a temporary file<br>
Use %%WEBALIZERPATH%% to designate the path to webalizer<br>
Use %%WEBALIZERCONF%% to designate the webalizer general configuration file<br>
Use %%DOMAIN%% to designate the domain name<br>
Use %%STATSPATH%% to designate the system path to the statistical storage directory</td></tr>
<tr><td class="prgout" align=left> <textarea name="file" rows=15 cols=75 wrap=off>$remote{'file'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Configuration"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Stats Config">
</form>);
&Bottom;
}

##

sub Edit_Stats_Config_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS10'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Statistical Configuration</td></tr>
<tr><td class="prgout" align=left valign=top>Server</td>\n);
if($count <= 10)
	{
	print qq(<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Edit+Stats+Config&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<td class="prgout" align=left><select name="id" size=1>--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue &gt; &gt;"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Edit Stats Config">
</form>);
&Bottom;
}

##

sub Save_Apache_Defaults
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS10'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'file'}=&uri_escape($FORM{'file'});
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=set+apache+defaults&file=$FORM{'file'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Apache Access Defaults Saved for $name server</td></tr>
</table>);
&Bottom;
}

##

sub Apache_Defaults
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS10'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+apache+defaults);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Hosting Server Apache Access Defaults for $name Server</td></tr>
<tr><td class="prgout" align=left>Use %%CGI%% to place the cgi-bin path for the domain<br>
Use %%HTDOCS%% to place the documentroot directory for the domain</td></tr>
<tr><td class="prgout" align=left> <textarea name="file" rows=20 cols=75 wrap=off>$remote{'file'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Access Defaults"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Apache Defaults">
</form>);
&Bottom;
}

##

sub Apache_Defaults_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS10'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Hosting Server Apache Access Defaults</td></tr>
<tr><td class="prgout" align=left valign=top>Server</td>\n);
if($count <= 10)
	{
	print qq(<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Apache+Defaults&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<td class="prgout" align=left><select name="id" size=1>--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue &gt; &gt;"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Apache Defaults">
</form>);
&Bottom;
}

##

sub Send_hhelperinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass,includepath,sshport FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass,$includepath,$sshport)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$statement=qq(SELECT ip FROM server WHERE type='client');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sip,@ips);
push(@ips,$ENV{'SERVER_ADDR'});
while(($sip)=$query_output->fetchrow)
	{
	if($sip ne $ENV{'SERVER_ADDR'}){push(@ips,$sip);}
	}
$ENV{HOME}=$system{'cgipath'};
my $ssh=Net::SSH::Perl->new($ip,protocol=>'2',port=>$sshport);
my($root)="root";
eval {$ssh->login($root,$FORM{'pass'});};
if($@ =~ /Permission denied/i){&Error("The root password was incorrect.");}
my($cmd)=qq(mkdir -p $includepath;chmod 700 $includepath;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$host="$ip";' > $includepath/hhelper.inc;echo '\$port="$port";' >> $includepath/hhelper.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$key='"'"'$serverpass'"'"';' >> $includepath/hhelper.inc;echo "\@referers=\(');
$cmd.=join("','",@ips);
$cmd.=qq('\);" >> $includepath/hhelper.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo "1;" >> $includepath/hhelper.inc;chmod 700 $includepath/hhelper.inc;);
$ssh->cmd($cmd);
&Top;
print qq(<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center>hhelper.inc File Information For $name</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>\$host=&quot;$ip&quot;;<BR>
\$port=&quot;$port&quot;;<BR>
\$key='$serverpass';<BR>
\@referers=\(');
print join("','",@ips);
print qq('\);<BR>
1;
</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>The hhelper.inc file has been created in $includepath. You can start hhelperd now.</TD></TR>
</TABLE>);
&Bottom;
}

##

sub HHelperinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass,includepath FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass,$includepath)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$statement=qq(SELECT ip FROM server WHERE type='client');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sip,@ips);
push(@ips,$ENV{'SERVER_ADDR'});
while(($sip)=$query_output->fetchrow)
	{
	if($sip ne $ENV{'SERVER_ADDR'}){push(@ips,$sip);}
	}
if(!$includepath){&Error("The includepath has not been defined for this hosting server. Please use edit hosting server function to define the includepath.");}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the hosting server");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center colspan=2>hhelper.inc File Information For $name</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left colspan=2>\$host=&quot;$ip&quot;;<BR>
\$port=&quot;$port&quot;;<BR>
\$key='$serverpass';<BR>
\@referers=\(');
print join("','",@ips);
print qq('\);<BR>
1;
</TD></TR>
<tr><td class="prgout" align=left colspan=2>This file can be created by hand and placed in $includepath,<br>
or can be sent to server via SSH if root ssh with password access is available.</td></tr>
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Generate hhelper.inc on $name hosting server</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Root Password:</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="pass" TYPE="password" SIZE=30,1></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Send hhelper.inc"></TD></TR>
</TABLE>
<INPUT NAME="id" TYPE="hidden" VALUE="$FORM{'id'}">
<INPUT NAME="do" TYPE="hidden" VALUE="Send hhelperinc">
</FORM>);
&Bottom;
}

##

sub Hhelperinc_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Generate helper.inc File Information</TD></TR>\n);
if($count <= 10)
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Hosting Server</TD>
<TD CLASS="prgout" ALIGN=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<A HREF="$script?do=HHelperinc&id=$id" class="prgout">$name</A>);
		}
	print qq(</TD></TR>\n);
	}
else
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left>Hosting Server</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<OPTION VALUE="$id">$name);
		}
	print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Generate Information"></TD></TR>\n);
	}
print qq(</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="HHelperinc">
</FORM>);
&Bottom;
}

##

sub Remove_HS_Template
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS9'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM template WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server template removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_HS_Template_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS9'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM template WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name,$count);
$count=($query_output->execute)+0;
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to delete this template?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove Hosting Server Template</TD></TR>\n);
if($count <= 10)
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Template</TD>
<TD CLASS="prgout" ALIGN=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<A HREF="$script?do=Remove+HS+Template&id=$id" onClick="return ConFirm()" class="prgout">$name<BR>\n);
		}
	print qq(</TD></TR>\n);
	}
else
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left>Template</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<OPTION VALUE="$id">$name);
		}
	print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove Template"></TD></TR>\n);
	}
print qq(</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Remove HS Template">
</FORM>);
&Bottom;
}

##

sub Save_HS_Template
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS8'} ne "yes")){&Error('Insufficient access for this function');}
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($sdbpass)=&encode_base64($cipher->encrypt($FORM{'sdbpass'}));
my($mailpass)=&encode_base64($cipher->encrypt($FORM{'mailpass'}));
my($mysqlpass)=&encode_base64($cipher->encrypt($FORM{'mysqlpass'}));
my($pfdbpass);
if($FORM{'pfdbpass'}){$pfdbpass=&encode_base64($cipher->encrypt($FORM{'pfdbpass'}));}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE template SET name='$FORM{'template'}',maxaccounts='$FORM{'maxaccounts'}',maxspace='$FORM{'maxspace'}',
maxbandwidth='$FORM{'maxbandwidth'}',usequota='$FORM{'usequota'}',hosttype='$FORM{'hosttype'}',
useemail='$FORM{'useemail'}',usemysql='$FORM{'usemysql'}',usesubdomain='$FORM{'usesubdomain'}',usewebalizer='$FORM{'usewebalizer'}',
usevirtftp='$FORM{'usevirtftp'}',sslsupport='$FORM{'sslsupport'}',netfilter='$FORM{'netfilter'}',allowshell='$FORM{'allowshell'}',
clientshell='$FORM{'clientshell'}',usefilecheck='$FORM{'usefilecheck'}',sdbhost='$FORM{'sdbhost'}',sdbname='$FORM{'sdbname'}',sdbuser='$FORM{'sdbuser'}',sdbpass='$sdbpass',
apacheconf='$FORM{'apacheconf'}',virtconf='$FORM{'virtconf'}',userdir='$FORM{'userdir'}',logpath='$FORM{'logpath'}',webrestart='$FORM{'webrestart'}',
webstart='$FORM{'webstart'}',webstop='$FORM{'webstop'}',webpid='$FORM{'webpid'}',mailpath='$FORM{'mailpath'}',mailcw='$FORM{'mailcw'}',mailvirtuser='$FORM{'mailvirtuser'}',
mailrestart='$FORM{'mailrestart'}',mailstart='$FORM{'mailstart'}',mailstop='$FORM{'mailstop'}',mailpid='$FORM{'mailpid'}',mailip='$FORM{'mailip'}',mailport='$FORM{'mailport'}',
mailpass='$mailpass',mysqluser='$FORM{'mysqluser'}',mysqlpass='$mysqlpass',mysqlhost='$FORM{'mysqlhost'}',webalizerpath='$FORM{'webalizerpath'}',
webalizerconf='$FORM{'webalizerconf'}',fpext='$FORM{'fpext'}',nfpath='$FORM{'nfpath'}',autofirewall='$FORM{'autofirewall'}',
ftplog='$FORM{'ftplog'}',ftprestart='$FORM{'ftprestart'}',ftpstart='$FORM{'ftpstart'}',ftpstop='$FORM{'ftpstop'}',ftppid='$FORM{'ftppid'}',
apachever='$FORM{'apachever'}',usesuexec='$FORM{'usesuexec'}',mailtype='$FORM{'mailtype'}',pfdbhost='$FORM{'pfdbhost'}',pfdbname='$FORM{'pfdbname'}',pfdbuser='$FORM{'pfdbuser'}',
pfdbpass='$pfdbpass',pfuser='$FORM{'pfuser'}',pfgroup='$FORM{'pfgroup'}',mailaccess='$FORM{'mailaccess'}',usesa='$FORM{'usesa'}',sshport='$FORM{'sshport'}',
sshstart='$FORM{'sshstart'}',sshstop='$FORM{'sshstop'}',sshrestart='$FORM{'sshrestart'}',sshpid='$FORM{'sshpid'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server template updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_HS_Template
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM template WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@values)=$query_output->fetchrow_array;
my($cipher);
my($sdbpass,$mailpass,$mysqlpass,$pfdbpass);
if($values[21])
	{
	if(&decode_base64($values[21]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$sdbpass=$cipher->decrypt(&decode_base64($values[21]));
	}
if($values[39])
	{
	if(&decode_base64($values[39]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$mailpass=$cipher->decrypt(&decode_base64($values[39]));
	}
if($values[41])
	{
	if(&decode_base64($values[41]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$mysqlpass=$cipher->decrypt(&decode_base64($values[41]));
	}
if($values[60])
	{
	if(&decode_base64($values[60]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$pfdbpass=$cipher->decrypt(&decode_base64($values[60]));
	}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
function changeIt(){
if(document.forms[0].hosttype.selectedIndex==0 || document.forms[0].hosttype.selectedindex==1)
	{
	document.forms[0].sslsupport.disabled=false;
	document.forms[0].usevirtftp.disabled=false;
	}
if(document.forms[0].hosttype.selectedIndex==2)
	{
	document.forms[0].sslsupport.selectedIndex=0;
	document.forms[0].sslsupport.disabled=true;
	}
if(document.forms[0].allowshell.selectedIndex==0)
	{
	document.forms[0].clientshell.selectedIndex=0;
	}
if(document.forms[0].useemail.selectedIndex==0)
	{
	document.forms[0].mailip.disabled=true;
	document.forms[0].mailport.disabled=true;
	document.forms[0].mailpass.disabled=true;
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=false;
	document.forms[0].mailvirtuser.disabled=false;
	document.forms[0].mailrestart.disabled=false;
	document.forms[0].mailstart.disabled=false;
	document.forms[0].mailstop.disabled=false;
	document.forms[0].mailpid.disabled=false;
	document.forms[0].mailtype.disabled=false;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=false;
	document.forms[0].pfdbname.disabled=false;
	document.forms[0].pfdbuser.disabled=false;
	document.forms[0].pfdbpass.disabled=false;
	document.forms[0].pfuser.disabled=false;
	document.forms[0].pfgroup.disabled=false;
	}
if(document.forms[0].useemail.selectedIndex==1)
	{
	document.forms[0].mailip.disabled=false;
	document.forms[0].mailport.disabled=false;
	document.forms[0].mailpass.disabled=false;
	document.forms[0].mailpath.disabled=true;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailrestart.disabled=true;
	document.forms[0].mailstart.disabled=true;
	document.forms[0].mailstop.disabled=true;
	document.forms[0].mailpid.disabled=true;
	document.forms[0].mailtype.disabled=true;
	document.forms[0].mailaccess.disabled=true;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if(document.forms[0].useemail.selectedIndex==2)
	{
	document.forms[0].mailpath.disabled=true;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailrestart.disabled=true;
	document.forms[0].mailstart.disabled=true;
	document.forms[0].mailstop.disabled=true;
	document.forms[0].mailip.disabled=true;
	document.forms[0].mailport.disabled=true;
	document.forms[0].mailpass.disabled=true;
	document.forms[0].mailpid.disabled=true;
	document.forms[0].mailtype.disabled=true;
	document.forms[0].mailaccess.disabled=true;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if((document.forms[0].mailtype.selectedIndex==0 || document.forms[0].mailtype.selectedIndex==1)&&(document.forms[0].useemail.selectedIndex==0))
	{
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=false;
	document.forms[0].mailvirtuser.disabled=false;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if(document.forms[0].mailtype.selectedIndex==2 && document.forms[0].useemail.selectedIndex==0)
	{
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=false;
	document.forms[0].pfdbname.disabled=false;
	document.forms[0].pfdbuser.disabled=false;
	document.forms[0].pfdbpass.disabled=false;
	document.forms[0].pfuser.disabled=false;
	document.forms[0].pfgroup.disabled=false;
	}
if(document.forms[0].usewebalizer.selectedIndex==0)
	{
	document.forms[0].webalizerpath.disabled=false;
	document.forms[0].webalizerconf.disabled=false;
	}
if(document.forms[0].usewebalizer.selectedIndex==1)
	{
	document.forms[0].webalizerpath.disabled=true;
	document.forms[0].webalizerconf.disabled=true;
	}
}

function chkData() {
if(document.forms[0].template.value <= 0)
{
alert("Enter the template name");
return false;
}
if(document.forms[0].maxaccounts.value <= 0)
{
alert("Enter the maximum accounts to be hosted on this server");
return false;
}
if(document.forms[0].maxspace.value <= 0)
{
alert("Enter the maximum amount of disk space (in Megs) to be allocated on this server");
return false;
}
if(document.forms[0].useemail.selectedIndex==0)
	{
	if(document.forms[0].mailpath.value <= 0)
		{
		alert("Enter the path to email users directory.");
		return false;
		}
	if(document.forms[0].mailtype.selectedIndex==0 || document.forms[0].mailtype.selectedIndex==1)
		{
		if(document.forms[0].mailcw.values <= 0)
			{
			alert("Enter Email CW file.");
			return false;
			}
		if(document.forms[0].mailvirtuser.value <= 0)
			{
			alert("Enter Email virtual user file.");
			return false;
			}
		}
	if(document.forms[0].mailrestart.value <= 0)
		{
		alert("Enter the email server restart command.");
		return false;
		}
	if(document.forms[0].mailstart.value <= 0)
		{
		alert("Enter the email server start command.");
		return false;
		}
	if(document.forms[0].mailstop.value <= 0)
		{
		alert("Enter the email server stop command.");
		return false;
		}
	if(document.forms[0].mailpid.value <= 0)
		{
		alert("Enter the email server PID file.");
		return false;
		}
	if(document.forms[0].mailtype.selectedIndex==2)
		{
		if(document.forms[0].pfdbhost.value <= 0)
			{
			alert("Enter the PostFix database hostname");
			return false;
			}
		if(document.forms[0].pfdbname.value <= 0)
			{
			alert("Enter the PostFix database name");
			return false;
			}
		if(document.forms[0].pfdbuser.value <= 0)
			{
			alert("Enter the PostFix database username");
			return false;
			}
		if(document.forms[0].pfdbpass.value <= 0)
			{
			alert("Enter the PostFix database password");
			return false;
			}
		if(document.forms[0].pfuser.value <= 0)
			{
			alert("Enter the PostFix username");
			return false;
			}
		if(document.forms[0].pfgroup.value <= 0)
			{
			alert("Enter the PostFix group");
			return false;
			}
		}
	}
if(document.forms[0].useemail.selectedIndex==1)
	{
	if(document.forms[0].mailip.value <= 0)
		{
		alert("Enter the email server IP.");
		return false;
		}
	if(document.forms[0].mailport.value <= 0)
		{
		alert("Enter the email server port.");
		return false;
		}
	if(document.forms[0].mailpass.value <= 0)
		{
		alert("Enter the mail server password.");
		return false;
		}
	if(document.forms[0].mailpass.value.length <= 0)
		{
		alert("For security reasons the mail server password must be at least 8 characters long.");
		return false;
		}
	}
if(document.forms[0].ftplog.value <= 0)
	{
	alert("Enter the ftp log information.");
	return false;
	}
if(document.forms[0].ftprestart.value <= 0)
	{
	alert("Enter the FTPd restart command.");
	return false;
	}
if(document.forms[0].ftpstart.value <= 0)
	{
	alert("Enter the FTPd start command.");
	return false;
	}
if(document.forms[0].ftpstop.value <= 0)
	{
	alert("Enter the FTPd stop command.");
	return false;
	}
if(document.forms[0].ftppid.value <= 0)
	{
	alert("Enter the FTPd PID file.");
	return false;
	}
return true;
}
var tabcount="6";
var tabname;
var tabtable;
function initTab(){
for(i=1;i<=tabcount;i++)
	{
	tabname=document.getElementById("tab"+i);
	tabtable=document.getElementById("form"+i);
	tabname.style.fontWeight="normal";
	tabtable.style.display="none";
	}
tabname=document.getElementById("tab1");
tabtable=document.getElementById("form1");
tabname.style.fontWeight="bold";
tabtable.style.display="block";
}
function settab(x){
for(i=1;i<=tabcount;i++)
	{
	tabname=document.getElementById("tab"+i);
	tabtable=document.getElementById("form"+i);
	tabname.style.fontWeight="normal";
	tabtable.style.display="none";
	}
tabname=document.getElementById("tab"+x);
tabtable=document.getElementById("form"+x);
tabname.style.fontWeight="bold";
tabtable.style.display="block";
}
//-->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=6>Edit Hosting Server Template</td></tr>
<tr><td class="prgout" align=left colspan=3>Template Name</td>
<td class="prgout" align=left colspan=3><input name="template" type="text" value="$values[2]" size=30,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left><a class="prgout" id="tab1" href="javascript:settab('1');">Server Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab2" href="javascript:settab('2');">MySQL Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab3" href="javascript:settab('3');">Hosting Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab4" href="javascript:settab('4');">Email Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab5" href="javascript:settab('5');">Webserver Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab6" href="javascript:settab('6');">FTP Info</a></td></tr>
<tr><td align=left colspan=6>
<div id="form1" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="$values[65]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no");
if($values[14] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" value="$values[46]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load Firewall at startup?</A></TD>
<td class="prgout" align=left><select name="autofirewall" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no");
if($values[47] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no");
if($values[17] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" value="$values[66]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" value="$values[67]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" value="$values[68]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" value="$values[69]" size=30,1></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('2');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form2" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbhost');" class="prgout">Server Database Hostname</a></td>
<td class="prgout" align=left><input name="sdbhost" type="text" value="$values[18]" size=30,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbname');" class="prgout">Server Database Name</a></td>
<td class="prgout" align=left><input name="sdbname" type="text" value="$values[19]" size=30,1 maxlength=64></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbuser');" class="prgout">Server Database Username</a></td>
<td class="prgout" align=left><input name="sdbuser" type="text" value="$values[20]" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbpass');" class="prgout">Server Database Password</a></td>
<td class="prgout" align=left><input name="sdbpass" type="text" value="$sdbpass" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqlhost');" class="prgout">MySQL server hostname</a></td>
<td class="prgout" align=left><input name="mysqlhost" type="text" value="$values[42]" size=30,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqluser');" class="prgout">MySQL root username</a></td>
<td class="prgout" align=left><input name="mysqluser" type="text" value="$values[40]" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqlpass');" class="prgout">MySQL root password</a></td>
<td class="prgout" align=left><input name="mysqlpass" type="text" value="$mysqlpass" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usemysql');" class="prgout">Use MySQL</a></td>
<td class="prgout" align=left><select name="usemysql" size=1><option value="yes">Yes<option value="no");
if($values[9] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('3');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form3" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxaccounts');" class="prgout">Maximum Accounts</a></td>
<td class="prgout" align=left><input name="maxaccounts" type="text" value="$values[3]" size=5,1></TD></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxspace');" class="prgout">Maximum Allocated Space</a></td>
<td class="prgout" align=left><input name="maxspace" type="text" value="$values[4]" size=5,1> Megabytes</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxbandwidth');" class="prgout">Maximum Allocated Bandwidth</a></td>
<td class="prgout" align=left><input name="maxbandwidth" type="text" value="$values[5]" size=5,1> Gigabytes</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usequota');" class="prgout">Use Linux quota management?</a></td>
<td class="prgout" align=left><select name="usequota" size=1><option value="yes">Yes<option value="no");
if($values[6] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=allowshell');" class="prgout">Allow Shell Access</a></td>
<td class="prgout" align=left><select name="allowshell" size=1 onChange="return changeIt();"><option value="no">No<option value="yes");
if($values[15] eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascritp:newwin('$script?do=help&help=clientshell');" class="prgout">Allow Shell Control by Client?</a></td>
<td class="prgout" align=left><select name="clientshell" size=1 onChange="return changeIt();"><option value="no">No<option value="yes");
if($values[16] eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('4');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form4" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=useemail');" class="prgout">Use Email</a></td>
<td class="prgout" align=left><select name="useemail" size=1 onChange="return changeIt();"><option value="local">Local<option value="remote");
if($values[8] eq "remote"){print qq( selected);}
print qq(>Remote<option value="no");
if($values[8] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailtype');" class="prgout">Email Server Type</a></td>
<td class="prgout" align=left><select name="mailtype" size=1 onchange="return changeIt();"><option value="sendmail">Sendmail<option value="postfix");
if($values[56] eq "postfix"){print qq( selected);}
print qq(>PostFix<option value="pfmysql");
if($values[56] eq "pfmysql"){print qq( selected);}
print qq(>PostFix/MySQL</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesa');" class="prgout">Use SpamAssassin</a></td>
<td class="prgout" align=left><select name="usesa" size=1><option value="no">No<option value="yes");
if($values[64] eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpath');" class="prgout">Path to email users directory</a></td>
<td class="prgout" align=left><input name="mailpath" type="text" value="$values[30]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailcw');" class="prgout">Email CW file</a></td>
<td class="prgout" align=left><input name="mailcw" type="text" value="$values[31]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailvirtuser');" class="prgout">Email virtual user file</a></td>
<td class="prgout" align=left><input name="mailvirtuser" type="text" value="$values[32]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailaccess');" class="prgout">Email server access file</a></td>
<td class="prgout" align=left><input name="mailaccess" type="text" value="$values[63]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstop');" class="prgout">Email server stop command</a></td>
<td class="prgout" align=left><input name="mailstop" type="text" value="$values[35]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstart');" class="prgout">Email server start command</a></td>
<td class="prgout" align=left><input name="mailstart" type="text" value="$values[34]" size=30,1 maxlength=250></td>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailrestart');" class="prgout">Email server restart command</a></td>
<td class="prgout" align=left><input name="mailrestart" type="text" value="$values[33]" size=30,1 maxlength=250></td>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpid');" class="prgout">Mail server PID file</a></td>
<td class="prgout" align=left><input name="mailpid" type="text" value="$values[36]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailip');" class="prgout">Email server IP</a></td>
<td class="prgout" align=left><input name="mailip" type="text" value="$values[37]" size=15,1 maxlength=15></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailport');" class="prgout">Email server port</a></td>
<td class="prgout" align=left><input name="mailport" type="text" value="$values[38]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpass');" class="prgout">Mail server password</a></td>
<td class="prgout" align=left><input name="mailpass" type="text" value="$mailpass" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbhost');" class="prgout">PostFix Database Hostname</a></td>
<td class="prgout" align=left><input name="pfdbhost" type="text" size=30,1 value="$values[57]" maxlength=60 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbname');" class="prgout">PostFix Database Name</a></td>
<td class="prgout" align=left><input name="pfdbname" type="text" size=30,1 value="$values[58]" maxlength=64 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbuser');" class="prgout">PostFix Database Username</a></td>
<td class="prgout" align=left><input name="pfdbuser" type="text" size=16,1 value="$values[59]" maxlength=16 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbpass');" class="prgout">PostFix Database Password</a></td>
<td class="prgout" align=left><input name="pfdbpass" type="text" size=30,1 value="$pfdbpass" disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfuser');" class="prgout">PostFix Username</a></td>
<td class="prgout" align=left><input name="pfuser" type="text" value="$values[61]" size=30,1 maxlength=32></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfgroup');" class="prgout">PostFix Group</a></td>
<td class="prgout" align=left><input name="pfgroup" type="text" value="$values[62]" size=30,1 maxlength=32></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('5');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form5" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout"="prgout" align=left><a href="javascript:newwin('$script?do=help&help=apachever');" class="prgout">Apache Version</a></td>
<td class="prgout"="prgout" align=left><select name="apachever" size=1><option value="1.3x">1.3x<option value="2x");
if($values[54] eq "2x"){print qq( selected);}
print qq(>2x</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesuexec');" class="prgout">Use SuExec?</a></td>
<td class="prgout" align=left><select name="usesuexec" size=1><option value="yes">Yes<option value="no");
if($values[55] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=hosttype');" class="prgout">Hosting type for this server</a></td>
<td class="prgout" align=left><select name="hosttype" size=1 onChange="return changeIt();"><option value="both">Both<option value="ip");
if($values[7] eq "ip"){print qq( selected);}
print qq(>IP Based<option value="name");
if($values[7] eq "name"){print qq( selected);}
print qq(>Name Based</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sslsupport');" class="prgout">Support SSL?</a><br>(Requires IP based hosting)</td>
<td class="prgout" align=left><select name="sslsupport" size=1><option value="no">No<option value="yes");
if($values[13] eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesubdomain');" class="prgout">Use Sub Domain</a></td>
<td class="prgout" align=left><select name="usesubdomain" size=1><option value="yes">Yes<option value="no");
if($values[10] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=apacheconf');" class="prgout">Web server configuration file</a></td>
<td class="prgout" align=left><input name="apacheconf" type="text" value="$values[22]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=virtconf');" class="prgout">Path to virtual hosting configuration files</a></td>
<td class="prgout" align=left><input name="virtconf" type="text" value="$values[23]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=userdir');" class="prgout">Path to user's directory</a></td>
<td class="prgout" align=left><input name="userdir" type="text" value="$values[24]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=logpath');" class="prgout">Path to log files</a></td>
<td class="prgout" align=left><input name="logpath" type="text" value="$values[25]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstart');" class="prgout">Web server start command</a></td>
<td class="prgout" align=left><input name="webstart" type="text" value="$values[27]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstop');" class="prgout">Web server stop command</a></td>
<td class="prgout" align=left><input name="webstop" type="text" value="$values[28]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webrestart');" class="prgout">Web server restart command</a></td>
<td class="prgout" align=left><input name="webrestart" type="text" value="$values[26]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webpid');" class="prgout">Web server PID file</a></td>
<td class="prgout" align=left><input name="webpid" type="text" value="$values[29]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=fpext');" class="prgout">Front Page Extensions</a></td>
<td class="prgout" align=left><select name="fpext" size=1><option value="">None<option value="4.0");
if($values[45] eq "4.0"){print qq( selected);}
print qq(>4.0 (2000)<option value="5.0");
if($values[45] eq "5.0"){print qq( selected);}
print qq(>5.0 (2002)</select ></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usewebalizer');" class="prgout">Use Webalizer</a></td>
<td class="prgout" align=left><select name="usewebalizer" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no");
if($values[11] eq "no"){print qq( selected);}
print qq(>No</select ></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webalizerconf');" class="prgout">Webalizer configuration file</a></td>
<td class="prgout" align=left><input name="webalizerconf" type="text" value="$values[44]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webalizerpath');" class="prgout">Path to webalizer</a></td>
<td class="prgout" align=left><input name="webalizerpath" type="text" value="$values[43]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('6');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form6" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usevirtftp');" class="prgout">Use Virtual FTP Support?</a></td>
<td class="prgout" align=left><select name="usevirtftp" SIZE=1 onChange="return changeIt();"><option value="no">No<option value="yes");
if($values[12] eq "yes"){print qq( selected);}
print qq(>Yes</select ></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftplog');" class="prgout">FTPd log file</a></td>
<td class="prgout" align=left><input name="ftplog" type="text" value="$values[49]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftpstart');" class="prgout">FTPd server start command</a></td>
<td class="prgout" align=left><input name="ftpstart" type="text" value="$values[51]" size=30,1 maxlength=250></d></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftpstop');" class="prgout">FTPd server stop command</a></td>
<td class="prgout" align=left><input name="ftpstop" type="text" value="$values[52]"ss size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftprestart');" class="prgout">FTPd server restart command</a></td>
<td class="prgout" align=left><input name="ftprestart" type="text" value="$values[50]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftppid');" class="prgout">FTPd PID file</a></td>
<td class="prgout" align=left><input name="ftppid" type="text" value="$values[53]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=center colspan=4><input type="submit" value="Save Template"></td></tr>
</table>
</div>
</td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save HS Template">
</form>
<script language="javascript">
<!--
changeIt();
initTab();
//-->
</script>\n);
&Bottom;
}

##

sub Edit_HS_Template_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM template WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name,$count);
$count=($query_output->execute)+0;
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Edit Hosting Server Template</TD></TR>\n);
if($count <= 10)
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Template</TD>
<TD CLASS="prgout" ALIGN=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<A HREF="$script?do=Edit+HS+Template&id=$id" class="prgout">$name</A><BR>\n);
		}
	print qq(</TD></TR>\n);
	}
else
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left>Template</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<OPTION VALUE="$id">$name);
		}
	print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Edit Template"></TD></TR>\n);
	}
print qq(</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Edit HS Template">
</FORM>);
&Bottom;
}

##

sub Create_HS_Template
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS7'} ne "yes")){&Error('Insufficient access for this function');}
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($sdbpass)=&encode_base64($cipher->encrypt($FORM{'sdbpass'}));
my($mailpass)=&encode_base64($cipher->encrypt($FORM{'mailpass'}));
my($mysqlpass)=&encode_base64($cipher->encrypt($FORM{'mysqlpass'}));
my($pfdbpass);
if($FORM{'pfdbpass'}){$pfdbpass=&encode_base64($cipher->encrypt($FORM{'pfdbpass'}));}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(INSERT INTO template (type,name,maxaccounts,maxspace,maxbandwidth,usequota,hosttype,useemail,usemysql,usesubdomain,usewebalizer,usevirtftp,
sslsupport,netfilter,allowshell,clientshell,usefilecheck,sdbhost,sdbname,sdbuser,sdbpass,apacheconf,virtconf,userdir,logpath,webrestart,webstart,
webstop,webpid,mailpath,mailcw,mailvirtuser,mailrestart,mailstart,mailstop,mailpid,mailip,mailport,mailpass,mysqluser,mysqlpass,mysqlhost,webalizerpath,
webalizerconf,fpext,nfpath,autofirewall,ftplog,ftprestart,ftpstart,ftpstop,ftppid,apachever,usesuexec,mailtype,pfdbhost,pfdbname,pfdbuser,pfdbpass,pfuser,
pfgroup,mailaccess,usesa,sshport,sshstart,sshstop,sshrestart,sshpid)
VALUES ('hosting','$FORM{'template'}','$FORM{'maxaccounts'}','$FORM{'maxspace'}','$FORM{'maxbandwidth'}','$FORM{'usequota'}','$FORM{'hosttype'}',
'$FORM{'useemail'}','$FORM{'usemysql'}','$FORM{'usesubdomain'}','$FORM{'usewebalizer'}','$FORM{'usevirtftp'}','$FORM{'sslsupport'}',
'$FORM{'netfilter'}','$FORM{'allowshell'}','$FORM{'clientshell'}','$FORM{'usefilecheck'}','$FORM{'sdbhost'}','$FORM{'sdbname'}','$FORM{'sdbuser'}',
'$sdbpass','$FORM{'apacheconf'}','$FORM{'virtconf'}','$FORM{'userdir'}','$FORM{'logpath'}','$FORM{'webrestart'}','$FORM{'webstart'}','$FORM{'webstop'}',
'$FORM{'webpid'}','$FORM{'mailpath'}','$FORM{'mailcw'}','$FORM{'mailvirtuser'}','$FORM{'mailrestart'}','$FORM{'mailstart'}','$FORM{'mailstop'}',
'$FORM{'mailpid'}','$FORM{'mailip'}','$FORM{'mailport'}','$mailpass','$FORM{'mysqluser'}','$mysqlpass','$FORM{'mysqlhost'}','$FORM{'webalizerpath'}',
'$FORM{'webalizerconf'}','$FORM{'fpext'}','$FORM{'nfpath'}','$FORM{'autofirewall'}','$FORM{'ftplog'}','$FORM{'ftprestart'}','$FORM{'ftpstart'}',
'$FORM{'ftpstop'}','$FORM{'ftppid'}','$FORM{'apachever'}','$FORM{'usesuexec'}','$FORM{'mailtype'}','$FORM{'pfdbhost'}','$FORM{'pfdbname'}','$FORM{'pfdbuser'}',
'$pfdbpass','$FORM{'pfuser'}','$FORM{'pfgroup'}','$FORM{'mailaccess'}','$FORM{'usesa'}','$FORM{'sshport'}','$FORM{'sshstart'}','$FORM{'sshstop'}',
'$FORM{'sshrestart'}','$FORM{'sshpid'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server template added</td></tr>
</table>);
&Bottom;
}

##

sub Create_HS_Template_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS7'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
function changeIt(){
if(document.forms[0].hosttype.selectedIndex==0 || document.forms[0].hosttype.selectedindex==1)
	{
	document.forms[0].sslsupport.disabled=false;
	document.forms[0].usevirtftp.disabled=false;
	}
if(document.forms[0].hosttype.selectedIndex==2)
	{
	document.forms[0].sslsupport.selectedIndex=0;
	document.forms[0].sslsupport.disabled=true;
	}
if(document.forms[0].allowshell.selectedIndex==0)
	{
	document.forms[0].clientshell.selectedIndex=0;
	}
if(document.forms[0].useemail.selectedIndex==0)
	{
	document.forms[0].mailip.disabled=true;
	document.forms[0].mailport.disabled=true;
	document.forms[0].mailpass.disabled=true;
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=false;
	document.forms[0].mailvirtuser.disabled=false;
	document.forms[0].mailrestart.disabled=false;
	document.forms[0].mailstart.disabled=false;
	document.forms[0].mailstop.disabled=false;
	document.forms[0].mailpid.disabled=false;
	document.forms[0].mailtype.disabled=false;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=false;
	document.forms[0].pfdbname.disabled=false;
	document.forms[0].pfdbuser.disabled=false;
	document.forms[0].pfdbpass.disabled=false;
	document.forms[0].pfuser.disabled=false;
	document.forms[0].pfgroup.disabled=false;
	}
if(document.forms[0].useemail.selectedIndex==1)
	{
	document.forms[0].mailip.disabled=false;
	document.forms[0].mailport.disabled=false;
	document.forms[0].mailpass.disabled=false;
	document.forms[0].mailpath.disabled=true;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailrestart.disabled=true;
	document.forms[0].mailstart.disabled=true;
	document.forms[0].mailstop.disabled=true;
	document.forms[0].mailpid.disabled=true;
	document.forms[0].mailtype.disabled=true;
	document.forms[0].mailaccess.disabled=true;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if(document.forms[0].useemail.selectedIndex==2)
	{
	document.forms[0].mailpath.disabled=true;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailrestart.disabled=true;
	document.forms[0].mailstart.disabled=true;
	document.forms[0].mailstop.disabled=true;
	document.forms[0].mailip.disabled=true;
	document.forms[0].mailport.disabled=true;
	document.forms[0].mailpass.disabled=true;
	document.forms[0].mailpid.disabled=true;
	document.forms[0].mailtype.disabled=true;
	document.forms[0].mailaccess.disabled=true;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if((document.forms[0].mailtype.selectedIndex==0 || document.forms[0].mailtype.selectedIndex==1)&&(document.forms[0].useemail.selectedIndex==0))
	{
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=false;
	document.forms[0].mailvirtuser.disabled=false;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if(document.forms[0].mailtype.selectedIndex==2 && document.forms[0].useemail.selectedIndex==0)
	{
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=false;
	document.forms[0].pfdbname.disabled=false;
	document.forms[0].pfdbuser.disabled=false;
	document.forms[0].pfdbpass.disabled=false;
	document.forms[0].pfuser.disabled=false;
	document.forms[0].pfgroup.disabled=false;
	}
if(document.forms[0].usewebalizer.selectedIndex==0)
	{
	document.forms[0].webalizerpath.disabled=false;
	document.forms[0].webalizerconf.disabled=false;
	}
if(document.forms[0].usewebalizer.selectedIndex==1)
	{
	document.forms[0].webalizerpath.disabled=true;
	document.forms[0].webalizerconf.disabled=true;
	}
}

function chkData() {
if(document.forms[0].template.value <= 0)
{
alert("Enter the template name");
return false;
}
if(document.forms[0].maxaccounts.value <= 0)
{
alert("Enter the maximum accounts to be hosted on this server");
return false;
}d
if(document.forms[0].maxspace.value <= 0)
{
alert("Enter the maximum amount of disk space (in Megs) to be allocated on this server");
return false;
}
if(document.forms[0].useemail.selectedIndex==0)
	{
	if(document.forms[0].mailpath.value <= 0)
		{
		alert("Enter the path to email users directory.");
		return false;
		}
	if(document.forms[0].mailtype.selectedIndex==0 || document.forms[0].mailtype.selectedIndex==1)
		{
		if(document.forms[0].mailcw.values <= 0)
			{
			alert("Enter Email CW file.");
			return false;
			}
		if(document.forms[0].mailvirtuser.value <= 0)
			{
			alert("Enter Email virtual user file.");
			return false;
			}
		}
	if(document.forms[0].mailrestart.value <= 0)
		{
		alert("Enter the email server restart command.");
		return false;
		}
	if(document.forms[0].mailstart.value <= 0)
		{
		alert("Enter the email server start command.");
		return false;
		}
	if(document.forms[0].mailstop.value <= 0)
		{
		alert("Enter the email server stop command.");
		return false;
		}
	if(document.forms[0].mailpid.value <= 0)
		{
		alert("Enter the email server PID file.");
		return false;
		}
	if(document.forms[0].mailtype.selectedIndex==2)
		{
		if(document.forms[0].pfdbhost.value <= 0)
			{
			alert("Enter the PostFix database hostname");
			return false;
			}
		if(document.forms[0].pfdbname.value <= 0)
			{
			alert("Enter the PostFix database name");
			return false;
			}
		if(document.forms[0].pfdbuser.value <= 0)
			{
			alert("Enter the PostFix database username");
			return false;
			}
		if(document.forms[0].pfdbpass.value <= 0)
			{
			alert("Enter the PostFix database password");
			return false;
			}
		if(document.forms[0].pfuser.value <= 0)
			{
			alert("Enter the PostFix username");
			return false;
			}
		if(document.forms[0].pfgroup.value <= 0)
			{
			alert("Enter the PostFix group");
			return false;
			}
		}
	}
if(document.forms[0].useemail.selectedIndex==1)
	{
	if(document.forms[0].mailip.value <= 0)
		{
		alert("Enter the email server IP.");
		return false;
		}
	if(document.forms[0].mailport.value <= 0)
		{
		alert("Enter the email server port.");
		return false;
		}
	if(document.forms[0].mailpass.value <= 0)
		{
		alert("Enter the mail server password.");
		return false;
		}
	if(document.forms[0].mailpass.value.length <= 0)
		{
		alert("For security reasons the mail server password must be at least 8 characters long.");
		return false;
		}
	}
if(document.forms[0].ftplog.value <= 0)
	{
	alert("Enter the ftp log information.");
	return false;
	}
if(document.forms[0].ftprestart.value <= 0)
	{
	alert("Enter the FTPd restart command.");
	return false;
	}
if(document.forms[0].ftpstart.value <= 0)
	{
	alert("Enter the FTPd start command.");
	return false;
	}
if(document.forms[0].ftpstop.value <= 0)
	{
	alert("Enter the FTPd stop command.");
	return false;
	}
if(document.forms[0].ftppid.value <= 0)
	{
	alert("Enter the FTPd PID file.");
	return false;
	}
return true;
}
var tabcount="6";
var tabname;
var tabtable;
function initTab(){
for(i=1;i<=tabcount;i++)
	{
	tabname=document.getElementById("tab"+i);
	tabtable=document.getElementById("form"+i);
	tabname.style.fontWeight="normal";
	tabtable.style.display="none";
	}
tabname=document.getElementById("tab1");
tabtable=document.getElementById("form1");
tabname.style.fontWeight="bold";
tabtable.style.display="block";
}
function settab(x){
for(i=1;i<=tabcount;i++)
	{
	tabname=document.getElementById("tab"+i);
	tabtable=document.getElementById("form"+i);
	tabname.style.fontWeight="normal";
	tabtable.style.display="none";
	}
tabname=document.getElementById("tab"+x);
tabtable=document.getElementById("form"+x);
tabname.style.fontWeight="bold";
tabtable.style.display="block";
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=6>Create Hosting Server Template</td></tr>
<tr><td class="prgout" align=left colspan=3>Template Name</TD>
<td class="prgout" ALIGN=left colspan=3><input name="template" type="text" size=30,1 maxlength=50></TD></TR>
<tr><td class="prgout" align=left><a class="prgout" id="tab1" href="javascript:settab('1');">Server Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab2" href="javascript:settab('2');">MySQL Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab3" href="javascript:settab('3');">Hosting Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab4" href="javascript:settab('4');">Email Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab5" href="javascript:settab('5');">Webserver Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab6" href="javascript:settab('6');">FTP Info</a></td></tr>
<tr><td colspan=6>
<div id="form1" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="22" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load Firewall at startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('2');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form2" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbhost');" class="prgout">Server Database Hostname</a></td>
<td class="prgout" align=left><input name="sdbhost" type="text" size=30,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbname');" class="prgout"">Server Database Name</a></td>
<td class="prgout" align=left><input name="sdbname" type="text" size=30,1 maxlength=64></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbuser');" class="prgout">Server Database Username</a></td>
<td class="prgout" align=left><input name="sdbuser" type="text" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbpass');" class="prgout">Server Database Password</a></td>
<td class="prgout" align=left><input name="sdbpass" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqlhost');" class="prgout">MySQL server hostname</a></td>
<td class="prgout" align=left><input name="mysqlhost" type="text" size=30,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqluser');" class="prgout">MySQL root username</a></td>
<td class="prgout" align=left><input name="mysqluser" type="text" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqlpass');" class="prgout">MySQL root password</a></td>
<td class="prgout" align=left><input name="mysqlpass" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usemysql');" class="prgout">Use MySQL</a></td>
<td class="prgout" align=left><select name="usemysql" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('3');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form3" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxaccounts');" class="prgout">Maximum Accounts</a></td>
<td class="prgout" align=left><input name="maxaccounts" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxspace');" class="prgout">Maximum Allocated Space</a></td>
<td class="prgout" align=left><input name="maxspace" type="text" size=5,1> Megabytes</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxbandwidth');" class="prgout">Maximum Allocated Bandwidth</a></td>
<td class="prgout" align=left><input name="maxbandwidth" type="text" size=5,1> Gigabytes</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usequota');" class="prgout">Use Linux quota management?</a></td>
<td class="prgout" align=left><select name="usequota" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=allowshell');" class="prgout">Allow Shell Access</a></td>
<td class="prgout" align=left><select name="allowshell" size=1 onChange="return changeIt();" class="prgout"><option value="no">No<option value="yes">Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascritp:newwin('$script?do=help&help=clientshell');" class="prgout">Allow Shell Control by Client?</a></td>
<td class="prgout" align=left><select name="clientshell" size=1 onChange="return changeIt();"><option value="no">No<option value="yes">Yes</select></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('4');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form4" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=useemail');" class="prgout">Use Email</a></td>
<td class="prgout" align=left><select name="useemail" size=1 onChange="return changeIt();"><option value="local">Local<option value="remote">Remote<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailtype');" class="prgout">Email Server Type</a></td>
<td class="prgout" align=left><select name="mailtype" size=1 onChange="return changeIt();"><option value="sendmail">Sendmail<option value="postfix">PostFix<option value="pfmysql">PostFix/MySQL</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesa');" class="prgout">Use SpamAssassin</a></td>
<td class="prgout" align=left><select name="usesa" size=1><option value="no">No<option value="yes">Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpath');" class="prgout">Path to email users directory</a></td>
<td class="prgout" align=left><input name="mailpath" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailcw');" class="prgout">Email CW file</a></td>
<td class="prgout" align=left><input name="mailcw" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailvirtuser');" class="prgout">Email virtual user file</a></d>
<td class="prgout" align=left><input name="mailvirtuser" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailaccess');" class="prgout">Email server access file</a></td>
<td class="prgout" align=left><input name="mailaccess" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstop');" class="prgout">Email server stop command</a></td>
<td class="prgout" align=left><input name="mailstop" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstart');" class="prgout">Email server start command</a></td>
<td class="prgout" align=left><input name="mailstart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailrestart');" class="prgout">Email server restart command</a></td>
<td class="prgout" align=left><input name="mailrestart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpid');" class="prgout">Email server PID file</a></td>
<td class="prgout" align=left><input name="mailpid" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailip');" class="prgout">Email server IP</a></td>
<td class="prgout" align=left><input name="mailip" type="text" size=15,1 maxlength=15 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailport');" class="prgout">Email server port</a></td>
<td class="prgout" align=left><input name="mailport" type="text" size=5,1 maxlength=5 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpass');" class="prgout">Email server password</a></td>
<td class="prgout" align=left><input name="mailpass" type="text" size=30,1 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbhost');" class="prgout">PostFix Database Hostname</a></td>
<td class="prgout" align=left><input name="pfdbhost" type="text" size=30,1 maxlength=60 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbname');" class="prgout">PostFix Database Name</a></td>
<td class="prgout" align=left><input name="pfdbname" type="text" size=30,1 maxlength=64 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbuser');" class="prgout">PostFix Database Username</a></td>
<td class="prgout" align=left><input name="pfdbuser" type="text" size=16,1 maxlength=16 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbpass');" class="prgout">PostFix Database Password</a></td>
<td class="prgout" align=left><input name="pfdbpass" type="text" size=30,1 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfuser');" class="prgout">PostFix Username</a></td>
<td class="prgout" align=left><input name="pfuser" type="text" size=30,1 maxlength=32 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfgroup');" class="prgout">PostFix Group</a></td>
<td class="prgout" align=left><input name="pfgroup" type="text" size=30,1 maxlength=32 disabled></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('5');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form5" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=apachever');" class="prgout">Apache Version</a></td>
<td class="prgout" align=left><select name="apachever" size=1><option value="1.3x">1.3x<option value="2x">2x</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesuexec');" class="prgout">Use SuExec?</a></td>
<td class="prgout" align=left><select name="usesuexec" size=1><option value="yes">Yes<option value="no"></select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=hosttype');" class="prgout">Hosting type for this server</a></td>
<td class="prgout" align=left><select name="hosttype" size=1 onChange="return changeIt();"><option value="both">Both<option value="ip">IP Based<option value="name">Name Based</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sslsupport');" class="prgout">Support SSL?</a><br>(Requires IP based hosting)</td>
<td class="prgout" align=left><select name="sslsupport" size=1><option value="no">No<option value="yes">Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesubdomain');" class="prgout">Use Sub Domain</a></td>
<td class="prgout" align=left><select name="usesubdomain" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=apacheconf');" class="prgout">Web server configuration file</a></td>
<td class="prgout" align=left><input name="apacheconf" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=virtconf');" class="prgout">Path to virtual hosting configuration files</a></td>
<td class="prgout" align=left><input name="virtconf" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=userdir');" class="prgout">Path to user's directory</a></td>
<td class="prgout" align=left><input name="userdir" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=logpath');" class="prgout">Path to log files</a></td>
<td class="prgout" align=left><input name="logpath" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstart');" class="prgout">Web server start command</a></td>
<td class="prgout" align=left><input name="webstart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstop');" class="prgout">Web server stop command</a></td>
<td class="prgout" align=left><input name="webstop" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webrestart');" class="prgout">Web server restart command</a></td>
<td class="prgout" align=left><input name="webrestart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webpid');" class="prgout">Web server PID file</a></td>
<td class="prgout" align=left><input name="webpid" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=fpext');" class="prgout">Front Page Extensions</a></td>
<td class="prgout" align=left><select name="fpext" size=1><option value="">None<option value="4.0">4.0 (2000)<option value="5.0">5.0 (2002)</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usewebalizer');" class="prgout">Use Webalizer</a></td>
<td class="prgout" align=left><select name="usewebalizer" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webalizerconf');" class="prgout">Webalizer configuration file</a></td>
<td class="prgout" align=left><input name="webalizerconf" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webalizerpath');" class="prgout">Path to webalizer</a></td>
<td class="prgout" align=left><input name="webalizerpath" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('6');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form6" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usevirtftp');" class="prgout">Use Virtual FTP Support?</a></td>
<td class="prgout" align=left><select name="usevirtftp" size=1 onChange="return changeIt();"><option value="no">No<option value="yes">Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftplog');" class="prgout">FTPd log file</a></td>
<td class="prgout" align=left><input name="ftplog" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftpstart');" class="prgout">FTPd server start command</a></td>
<td class="prgout" align=left><input name="ftpstart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftpstop');" class="prgout">FTPd server stop command</a></td>
<td class="prgout" align=left><input name="ftpstop" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftprestart');" class="prgout">FTPd server restart command</a></td>
<td class="prgout" align=left><input name="ftprestart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftppid');" class="prgout">FTPd PID file</a></td>
<td class="prgout" align=left><input name="ftppid" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=center colspan=4><input type="submit" value="Create Template"></td></tr>
</table>
</div>
</td></tr>
</table>
<input name="do" type="hidden" value="Create HS Template">
</form>
<script language="javascript">
<!--
initTab();
// -->
</script>\n);
&Bottom;
}

##

sub Add_Server_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM template WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
$statement=qq(SELECT id,name FROM server_pool ORDER BY name ASC);
$query_output2=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
function changeIt(){
if(document.forms[0].hosttype.selectedIndex==0)
	{
	document.forms[0].sharedip.disabled=false;
	document.forms[0].dedips.disabled=false;
	}
if(document.forms[0].hosttype.selectedIndex==1)
	{
	document.forms[0].sharedip.disabled=true;
	document.forms[0].dedips.disabled=false;
	}
if(document.forms[0].hosttype.selectedIndex==2)
	{
	document.forms[0].sharedip.disabled=false;
	document.forms[0].dedips.disabled=true;
	document.forms[0].sslsupport.selectedIndex=0;
	}
if(document.forms[0].allowshell.selectedIndex==0)
	{
	document.forms[0].clientshell.selectedIndex=0;
	}
if(document.forms[0].useemail.selectedIndex==0)
	{
	document.forms[0].mailip.disabled=true;
	document.forms[0].mailport.disabled=true;
	document.forms[0].mailpass.disabled=true;
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=false;
	document.forms[0].mailvirtuser.disabled=false;
	document.forms[0].mailrestart.disabled=false;
	document.forms[0].mailstart.disabled=false;
	document.forms[0].mailstop.disabled=false;
	document.forms[0].mailpid.disabled=false;
	document.forms[0].mailtype.disabled=false;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=false;
	document.forms[0].pfdbname.disabled=false;
	document.forms[0].pfdbuser.disabled=false;
	document.forms[0].pfdbpass.disabled=false;
	document.forms[0].pfuser.disabled=false;
	document.forms[0].pfgroup.disabled=false;
	}
if(document.forms[0].useemail.selectedIndex==1)
	{
	document.forms[0].mailip.disabled=false;
	document.forms[0].mailport.disabled=false;
	document.forms[0].mailpass.disabled=false;
	document.forms[0].mailpath.disabled=true;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailrestart.disabled=true;
	document.forms[0].mailstart.disabled=true;
	document.forms[0].mailstop.disabled=true;
	document.forms[0].mailpid.disabled=true;
	document.forms[0].mailtype.disabled=true;
	document.forms[0].mailaccess.disabled=true;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if(document.forms[0].useemail.selectedIndex==2)
	{
	document.forms[0].mailpath.disabled=true;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailrestart.disabled=true;
	document.forms[0].mailstart.disabled=true;
	document.forms[0].mailstop.disabled=true;
	document.forms[0].mailip.disabled=true;
	document.forms[0].mailport.disabled=true;
	document.forms[0].mailpass.disabled=true;
	document.forms[0].mailpid.disabled=true;
	document.forms[0].mailtype.disabled=true;
	document.forms[0].mailaccess.disabled=true;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if((document.forms[0].mailtype.selectedIndex==0 || document.forms[0].mailtype.selectedIndex==1)&&(document.forms[0].useemail.selectedIndex==0))
	{
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=false;
	document.forms[0].mailvirtuser.disabled=false;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if(document.forms[0].mailtype.selectedIndex==2 && document.forms[0].useemail.selectedIndex==0)
	{
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=false;
	document.forms[0].pfdbname.disabled=false;
	document.forms[0].pfdbuser.disabled=false;
	document.forms[0].pfdbpass.disabled=false;
	document.forms[0].pfuser.disabled=false;
	document.forms[0].pfgroup.disabled=false;
	}
if(document.forms[0].usewebalizer.selectedIndex==0)
	{
	document.forms[0].webalizerpath.disabled=false;
	document.forms[0].webalizerconf.disabled=false;
	}
if(document.forms[0].usewebalizer.selectedIndex==1)
	{
	document.forms[0].webalizerpath.disabled=true;
	document.forms[0].webalizerconf.disabled=true;
	}
}

function chkData() {
if(document.forms[0].servername.value <= 0)
{
alert("Enter a servername for the server being added");
return false;
}
if(document.forms[0].serverip.value <= 0) 
{
alert("Enter an IP address for the server being added");
return false;
}
if(document.forms[0].serverport.value <= 0)
{
alert("Enter a server port for the server being added");
return false;
}
if(document.forms[0].serverpass.value.length <= 7)
{
alert("For security reasons the server password must be at least 8 characters long");
return false;
}
if(document.forms[0].sshport.value.length <= 0)
{
alert("Enter the port for ssh on the server");
return false;
}
if(document.forms[0].maxaccounts.value <= 0)
{
alert("Enter the maximum accounts to be hosted on this server");
return false;
}
if(document.forms[0].maxspace.value <= 0)
{
alert("Enter the maximum amount of disk space (in Megs) to be allocated on this server");
return false;
}
if(document.forms[0].useemail.selectedIndex==0)
	{
	if(document.forms[0].mailpath.value <= 0)
		{
		alert("Enter the path to email users directory.");
		return false;
		}
	if(document.forms[0].mailtype.selectedIndex==0 || document.forms[0].mailtype.selectedIndex==1)
		{
		if(document.forms[0].mailcw.values <= 0)
			{
			alert("Enter Email CW file.");
			return false;
			}
		if(document.forms[0].mailvirtuser.value <= 0)
			{
			alert("Enter Email virtual user file.");
			return false;
			}
		}
	if(document.forms[0].mailrestart.value <= 0)
		{
		alert("Enter the email server restart command.");
		return false;
		}
	if(document.forms[0].mailstart.value <= 0)
		{
		alert("Enter the email server start command.");
		return false;
		}
	if(document.forms[0].mailstop.value <= 0)
		{
		alert("Enter the email server stop command.");
		return false;
		}
	if(document.forms[0].mailpid.value <= 0)
		{
		alert("Enter the email server PID file.");
		return false;
		}
	if(document.forms[0].mailtype.selectedIndex==2)
		{
		if(document.forms[0].pfdbhost.value <= 0)
			{
			alert("Enter the PostFix database hostname");
			return false;
			}
		if(document.forms[0].pfdbname.value <= 0)
			{
			alert("Enter the PostFix database name");
			return false;
			}
		if(document.forms[0].pfdbuser.value <= 0)
			{
			alert("Enter the PostFix database username");
			return false;
			}
		if(document.forms[0].pfdbpass.value <= 0)
			{
			alert("Enter the PostFix database password");
			return false;
			}
		if(document.forms[0].pfuser.value <= 0)
			{
			alert("Enter the PostFix username");
			return false;
			}
		if(document.forms[0].pfgroup.value <= 0)
			{
			alert("Enter the PostFix group");
			return false;
			}
		}
	}
if(document.forms[0].useemail.selectedIndex==1)
	{
	if(document.forms[0].mailip.value <= 0)
		{
		alert("Enter the email server IP.");
		return false;
		}
	if(document.forms[0].mailport.value <= 0)
		{
		alert("Enter the email server port.");
		return false;
		}
	if(document.forms[0].mailpass.value <= 0)
		{
		alert("Enter the mail server password.");
		return false;
		}
	if(document.forms[0].mailpass.value.length <= 0)
		{
		alert("For security reasons the mail server password must be at least 8 characters long.");
		return false;
		}
	}
var test=0;
var group=document.forms[0].pools.options.length;
for(i=0;i<group;i++)
	{
	if(document.forms[0].pools.options[i].selected==1)
		{
		test=1;
		}
	}
if(!test)
	{
	alert("Select at least 1 server pool for this server.");
	return false;
	}
if(document.forms[0].ftplog.value <= 0)
	{
	alert("Enter the FTPd log file.");
	return false;
	}
if(document.forms[0].ftprestart.value <= 0)
	{
	alert("Enter the FTPd restart command.");
	return false;
	}
if(document.forms[0].ftpstart.value <= 0)
	{
	alert("Enter the FTPd start command.");
	return false;
	}
if(document.forms[0].ftpstop.value <= 0)
	{
	alert("Enter the FTPd stop command.");
	return false;
	}
if(document.forms[0].ftppid.value <= 0)
	{
	alert("Enter the FTPd PID file.");
	return false;
	}
if(document.forms[0].includepath.value <= 0)
	{
	alert("Enter the includepath for hhelper.inc file.");
	return false;
	}
return true;
}
var tabcount="6";
var tabname;
var tabtable;
function initTab(){
for(i=1;i<=tabcount;i++)
	{
	tabname=document.getElementById("tab"+i);
	tabtable=document.getElementById("form"+i);
	tabname.style.fontWeight="normal";
	tabtable.style.display="none";
	}
tabname=document.getElementById("tab1");
tabtable=document.getElementById("form1");
tabname.style.fontWeight="bold";
tabtable.style.display="block";
}
function settab(x){
for(i=1;i<=tabcount;i++)
	{
	tabname=document.getElementById("tab"+i);
	tabtable=document.getElementById("form"+i);
	tabname.style.fontWeight="normal";
	tabtable.style.display="none";
	}
tabname=document.getElementById("tab"+x);
tabtable=document.getElementById("form"+x);
tabname.style.fontWeight="bold";
tabtable.style.display="block";
}
//-->
</script>\n);
if($count > 0){print qq(<script language="javascript" src="$script?do=draw+template&template=hosting"></script>\n);}
print qq(<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=6>Add Hosting Server</td></tr>\n);
if($count > 0)
	{
	print qq(<tr><td class="prgout" align=right colspan=3>Select Hosting Server Template</td>
<td class="prgout" align=left colspan=3><select name="template" size=1 onChange="ChgVal(this.options.selectedIndex);"><option value="">--No Template--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
print qq(</select></td></tr>\n);
	}
print qq(<tr><td class="prgout" align=left><a id="tab1" href="javascript:settab('1');">Server Info</a></td>
<td class="prgout" align=left><a id="tab2" href="javascript:settab('2');">MySQL Info</a></td>
<td class="prgout" align=left><a id="tab3" href="javascript:settab('3');">Hosting Info</a></td>
<td class="prgout" align=left><a id="tab4" href="javascript:settab('4');">Email Info</a></td>
<td class="prgout" align=left><a id="tab5" href="javascript:settab('5');">Webserver Info</a></td>
<td class="prgout" align=left><a id="tab6" href="javascript:settab('6');">FTP Info</a></td></tr>
<tr><td colspan=6 class="tab">
<div id="form1" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=servername');" class="prgout">Server Name (FQDN)</a></td>
<td class="prgout" align=left><input name="servername" type="text" size=30,1 maxlength=75></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverip');" class="prgout">Server IP</a></td>
<td class="prgout" align=left><input name="serverip" type="text" size=30,1 maxlength=20></td></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverport');" class="prgout">Server Port</a></td>
<td class="prgout" align=left><input name="serverport" type="text" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverpass');" class="prgout">Server Password</a></td>
<td class="prgout" align=left><input name="serverpass" type="text" size=30,1 maxlength=56></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="22" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load Firewall at startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('2');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form2" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbhost');" class="prgout">Server Database Hostname</a></td>
<td class="prgout" align=left><input name="sdbhost" type="text" size=30,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbname');" class="prgout">Server Database Name</a></td>
<td class="prgout" align=left><input name="sdbname" type="text" size=30,1 maxlength=64></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbuser');" class="prgout">Server Database Username</a></td>
<td class="prgout" align=left><input name="sdbuser" type="text" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbpass');" class="prgout">Server Database Password</a></td>
<td class="prgout" align=left><input name="sdbpass" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqlhost');" class="prgout">MySQL server hostname</a></td>
<td class="prgout" align=left><input name="mysqlhost" type="text" size=30,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqluser');" class="prgout">MySQL root username</a></td>
<td class="prgout" align=left><input name="mysqluser" type="text" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqlpass');" class="prgout">MySQL root password</a></td>
<td class="prgout" align=left><input name="mysqlpass" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usemysql');" class="prgout">Use MySQL</a></td>
<td class="prgout" align=left><select name="usemysql" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('3');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form3" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxaccounts');" class="prgout">Maximum Accounts</a></td>
<td class="prgout" align=left><input name="maxaccounts" type="text" size=5,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxspace');" class="prgout">Maximum Allocated Space</a></td>
<td class="prgout" align=left><input name="maxspace" type="text" size=5,1> Megabytes</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxbandwidth');" class="prgout">Maximum Allocated Bandwidth</a></td>
<td class="prgout" align=left><input name="maxbandwidth" type="text" size=5,1> Gigabytes</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usequota');" class="prgout">Use Linux quota management?</a></td>
<td class="prgout" align=left><select name="usequota" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=allowshell');" class="prgout">Allow Shell Access</a></td>
<td class="prgout" align=left><select name="allowshell" size=1 onChange="return changeIt();"><option value="no">No<option value="yes">Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascritp:newwin('$script?do=help&help=clientshell');" class="prgout">Allow Shell Control by Client?</a></td>
<td class="prgout" align=left><select name="clientshell" size=1 onChange="return changeIt();"><option value="no">No<option value="yes">Yes</select></td></tr>
<tr><td class="prgout" align=left Valign=top><a href="javascript:newwin('$script?do=help&help=pools');" class="prgout">Server Pools</a></td>
<td class="prgout" align=left><select name="pools" size=3 multiple>);
while(($id,$name)=$query_output2->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sharedip');" class="prgout">Shared IP</a></td>
<td class="prgout" align=left><input name="sharedip" type="text" size=15,1 maxlength=15></td></tr>
<tr><td class="prgout" align=left Valign=top><a href="javascript:newwin('$script?do=help&help=dedips');" class="prgout">Dedicated IPs</a><BR>One ip/set per line</td>
<td class="prgout" align=left><TEXTAREA NAME="dedips" ROWS=3 COLS=20></TEXTAREA></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('4');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form4" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=useemail');" class="prgout">Use Email</a></td>
<td class="prgout" align=left><select name="useemail" size=1 onChange="return changeIt();"><option value="local">Local<option value="remote">Remote<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailtype');" class="prgout">Email Server Type</a></td>
<td class="prgout" align=left><select name="mailtype" size=1 onChange="return changeIt();"><option value="sendmail">Sendmail<option value="postfix">PostFix<option value="pfmysql">PostFix/MySQL</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesa');" class="prgout">Use SpamAssassin</A></td>
<td class="prgout" align=left><select name="usesa" size=1><option value="no">No<option value="yes">Yes</select></td></tr></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpath');" class="prgout">Path to email users directory</a></td>
<td class="prgout" align=left><input name="mailpath" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailcw');" class="prgout">Email CW file</a></td>
<td class="prgout" align=left><input name="mailcw" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailvirtuser');" class="prgout">Email virtual user file</a></td>
<td class="prgout" align=left><input name="mailvirtuser" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailaccess');" class="prgout">Email server access file</a></td>
<td class="prgout" align=left><input name="mailaccess" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstop');" class="prgout">Email server stop command</a></td>
<td class="prgout" align=left><input name="mailstop" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstart');" class="prgout">Email server start command</a></td>
<td class="prgout" align=left><input name="mailstart" type="text" size=30,1 maxlength=250></td></rt>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailrestart');" class="prgout">Email server restart command</a></td>
<td class="prgout" align=left><input name="mailrestart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpid');" class="prgout">Email server PID file</a></td>
<td class="prgout" align=left><input name="mailpid" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailip');" class="prgout">Email server IP</a></td>
<td class="prgout" align=left><input name="mailip" type="text" size=15,1 maxlength=15 DISABLED></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailport');" class="prgout">Email server port</a></td>
<td class="prgout" align=left><input name="mailport" type="text" size=5,1 maxlength=5 DISABLED></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpass');" class="prgout">Email server password</a></td>
<td class="prgout" align=left><input name="mailpass" type="text" size=30,1 DISABLED></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbhost');" class="prgout">PostFix Database Hostname</a></td>
<td class="prgout" align=left><input name="pfdbhost" type="text" size=30,1 maxlength=60 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbname');" class="prgout">PostFix Database Name</a></td>
<td class="prgout" align=left><input name="pfdbname" type="text" size=30,1 maxlength=64 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbuser');" class="prgout">PostFix Database Username</a></td>
<td class="prgout" align=left><input name="pfdbuser" type="text" size=16,1 maxlength=16 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbpass');" class="prgout">PostFix Database Password</a></td>
<td class="prgout" align=left><input name="pfdbpass" type="text" size=30,1 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfuser');" class="prgout">PostFix Username</a></td>
<td class="prgout" align=left><input name="pfuser" type="text" size=30,1 maxlength=32 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfgroup');" class="prgout">PostFix Group</a></td>
<td class="prgout" align=left><input name="pfgroup" type="text" size=30,1 maxlength=32 disabled></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('5');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form5" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=apachever');" class="prgout">Apache Version</a></td>
<td class="prgout" align=left><select name="apachever" size=1><option value="1.3x">1.3x<option value="2x">2x</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesuexec');" class="prgout">Use SuExec?</a></td>
<td class="prgout" align=left><select name="usesuexec" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=hosttype');" class="prgout">Hosting type for this server</a></td>
<td class="prgout" align=left><select name="hosttype" size=1 onChange="return changeIt();"><option value="both">Both<option value="ip">IP Based<option value="name">Name Based</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sslsupport');" class="prgout">Support SSL?</a></td>
<td class="prgout" align=left><select name="sslsupport" size=1><option value="no">No<option value="yes">Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesubdomain');" class="prgout">Use Sub Domain</a></td>
<td class="prgout" align=left><select name="usesubdomain" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=apacheconf');" class="prgout">Web server configuration file</a></td>
<td class="prgout" align=left><input name="apacheconf" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=virtconf');" class="prgout">Path to virtual hosting configuration files</a></td>
<td class="prgout" align=left><input name="virtconf" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=userdir');" class="prgout">Path to user's directory</a></td>
<td class="prgout" align=left><input name="userdir" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=logpath');" class="prgout">Path to log files</a></td>
<td class="prgout" align=left><input name="logpath" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstart');" class="prgout">Web server start command</a></td>
<td class="prgout" align=left><input name="webstart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstop');" class="prgout">Web server stop command</a></td>
<td class="prgout" align=left><input name="webstop" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webrestart');" class="prgout">Web server restart command</a></td>
<td class="prgout" align=left><input name="webrestart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webpid');" class="prgout">Web server PID file</a></td>
<td class="prgout" align=left><input name="webpid" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=fpext');" class="prgout">Front Page Extensions</a></td>
<td class="prgout" align=left><select name="fpext" size=1><option value="">None<option value="4.0">4.0 (2000)<option value="5.0">5.0 (2002)</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usewebalizer');" class="prgout">Use Webalizer</a></td>
<td class="prgout" align=left><select name="usewebalizer" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webalizerconf');" class="prgout">Webalizer configuration file</a></td>
<td class="prgout" align=left><input name="webalizerconf" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webalizerpath');" class="prgout">Path to webalizer</a></td>
<td class="prgout" align=left><input name="webalizerpath" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('6');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form6" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usevirtftp');" class="prgout">Use Virtual FTP Support?</a></td>
<td class="prgout" align=left><select name="usevirtftp" size=1 onChange="return changeIt();"><option value="no">No<option value="yes">Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftplog');" class="prgout">FTPd log file</a></td>
<td class="prgout" align=left><input name="ftplog" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftpstart');" class="prgout">FTPd server start command</a></td>
<td class="prgout" align=left><input name="ftpstart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftpstop');" class="prgout">FTPd server stop command</a></td>
<td class="prgout" align=left><input name="ftpstop" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftprestart');" class="prgout">FTPd server restart command</a></td>
<td class="prgout" align=left><input name="ftprestart" type="text" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftppid');" class="prgout">FTPd PID file</a></td>
<td class="prgout" align=left><input name="ftppid" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">Include Path</a></td>
<td class="prgout" align=left><input name="includepath" type="text" value="/etc/gnuhh/server" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=4><input type="submit" value="Add Server"></td></tr>
</table>
</div>
</td></tr>
</table>
<input name="do" type="hidden" value="Add Server">
</form>
<script language="javascript">
<!--
initTab();
// -->
</script>\n);
&Bottom;
}

##

sub Save_Server
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($sdbpass)=&encode_base64($cipher->encrypt($FORM{'sdbpass'}));
my($mailpass)=&encode_base64($cipher->encrypt($FORM{'mailpass'}));
my($mysqlpass)=&encode_base64($cipher->encrypt($FORM{'mysqlpass'}));
my($pfdbpass);
if($FORM{'pfdbpass'}){$pfdbpass=&encode_base64($cipher->encrypt($FORM{'pfdbpass'}));}
my($pools)="|".join("|",@POOLS)."|";
my(@keys)=keys(%FORM);
$FORM{'dedips'}=~s/ *$//g;
foreach(@keys){$FORM{$_}=~s/\'/\\\'/g;}
$statement=qq(UPDATE server SET ip='$FORM{'serverip'}',port='$FORM{'serverport'}',pools='$pools',maxaccounts='$FORM{'maxaccounts'}',maxspace='$FORM{'maxspace'}',
maxbandwidth='$FORM{'maxbandwidth'}',usequota='$FORM{'usequota'}',hosttype='$FORM{'hosttype'}',sharedip='$FORM{'sharedip'}',dedips='$FORM{'dedips'}',
useemail='$FORM{'useemail'}',usemysql='$FORM{'usemysql'}',usesubdomain='$FORM{'usesubdomain'}',usewebalizer='$FORM{'usewebalizer'}',
usevirtftp='$FORM{'usevirtftp'}',sslsupport='$FORM{'sslsupport'}',netfilter='$FORM{'netfilter'}',allowshell='$FORM{'allowshell'}',clientshell='$FORM{'clientshell'}',
usefilecheck='$FORM{'usefilecheck'}',sdbhost='$FORM{'sdbhost'}',sdbname='$FORM{'sdbname'}',sdbuser='$FORM{'sdbuser'}',sdbpass='$sdbpass',apacheconf='$FORM{'apacheconf'}',
virtconf='$FORM{'virtconf'}',userdir='$FORM{'userdir'}',logpath='$FORM{'logpath'}',webrestart='$FORM{'webrestart'}',webstart='$FORM{'webstart'}',webstop='$FORM{'webstop'}',webpid='$FORM{'webpid'}',
mailpath='$FORM{'mailpath'}',mailcw='$FORM{'mailcw'}',mailvirtuser='$FORM{'mailvirtuser'}',mailrestart='$FORM{'mailrestart'}',mailstart='$FORM{'mailstart'}',mailstop='$FORM{'mailstop'}',mailpid='$FORM{'mailpid'}',
mailip='$FORM{'mailip'}',mailport='$FORM{'mailport'}',mailpass='$mailpass',mysqluser='$FORM{'mysqluser'}',
mysqlpass='$mysqlpass',mysqlhost='$FORM{'mysqlhost'}',webalizerpath='$FORM{'webalizerpath'}',webalizerconf='$FORM{'webalizerconf'}',fpext='$FORM{'fpext'}',nfpath='$FORM{'nfpath'}',
autofirewall='$FORM{'autofirewall'}',ftplog='$FORM{'ftplog'}',ftprestart='$FORM{'ftprestart'}',ftpstart='$FORM{'ftpstart'}',
ftpstop='$FORM{'ftpstop'}',ftppid='$FORM{'ftppid'}',apachever='$FORM{'apachever'}',usesuexec='$FORM{'usesuexec'}',mailtype='$FORM{'mailtype'}',includepath='$FORM{'includepath'}',
pfdbhost='$FORM{'pfdbhost'}',pfdbname='$FORM{'pfdbname'}',pfdbuser='$FORM{'pfdbuser'}',pfdbpass='$pfdbpass',pfuser='$FORM{'pfuser'}',pfgroup='$FORM{'pfgroup'}',
mailaccess='$FORM{'mailaccess'}',usesa='$FORM{'usesa'}',sshport='$FORM{'sshport'}',sshstart='$FORM{'sshstart'}',sshstop='$FORM{'sshstop'}',
sshrestart='$FORM{'sshrestart'}',sshpid='$FORM{'sshpid'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@dedips)=split(/\n/,$FORM{'dedips'});
my($dedips);
foreach(@dedips)
	{
	if($_ =~ /-/)
		{
		my(@info)=split(/-/,$_);
		my(@info2)=split(/\./,$info[0]);
		$dedips+=$info[1]-$info2[3]+1;
		}
	else
		{
		$dedips++;
		}
	}
my($mail)="no";
if($FORM{'useemail'} ne "no"){$mail="yes";}
$statement=qq(UPDATE resource_list SET pools='$pools',maxaccounts='$FORM{'maxaccounts'}',maxspace='$FORM{'maxspace'}',
maxbandwidth='$FORM{'maxbandwidth'}',availdedips='$dedips',mail='$mail',`ssl`='$FORM{'sslsupport'}' WHERE server='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server information updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Server
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@values)=$query_output->fetchrow_array;
$statement=qq(SELECT id,name FROM server_pool ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($serverpass,$sdbpass,$mailpass,$mysqlpass,$pdfdpass);
my($cipher);
if($values[5])
	{
	if(&decode_base64($values[5]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($values[5]));
	}
if($values[27])
	{
	if(&decode_base64($values[27]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$sdbpass=$cipher->decrypt(&decode_base64($values[27]));
	}
if($values[45])
	{
	if(&decode_base64($values[45]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$mailpass=$cipher->decrypt(&decode_base64($values[45]));
	}
if($values[47])
	{
	if(&decode_base64($values[47]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$mysqlpass=$cipher->decrypt(&decode_base64($values[47]));
	}
if($values[79])
	{
	if(&decode_base64($values[79]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$pfdbpass=$cipher->decrypt(&decode_base64($values[79]));
	}
$statement=qq(SELECT id,name FROM server_pool ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizable=no,status=no");}
function changeIt(){
if(document.forms[0].hosttype.selectedIndex==0)
	{
	document.forms[0].sharedip.disabled=false;
	document.forms[0].dedips.disabled=false;
	}
if(document.forms[0].hosttype.selectedIndex==1)
	{
	document.forms[0].sharedip.disabled=true;
	document.forms[0].dedips.disabled=false;
	}
if(document.forms[0].hosttype.selectedIndex==2)
	{
	document.forms[0].sharedip.disabled=false;
	document.forms[0].dedips.disabled=true;
	document.forms[0].sslsupport.selectedIndex=0;
	}
if(document.forms[0].allowshell.selectedIndex==0)
	{
	document.forms[0].clientshell.selectedIndex=0;
	}
if(document.forms[0].useemail.selectedIndex==0)
	{
	document.forms[0].mailip.disabled=true;
	document.forms[0].mailport.disabled=true;
	document.forms[0].mailpass.disabled=true;
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=false;
	document.forms[0].mailvirtuser.disabled=false;
	document.forms[0].mailrestart.disabled=false;
	document.forms[0].mailstart.disabled=false;
	document.forms[0].mailstop.disabled=false;
	document.forms[0].mailpid.disabled=false;
	document.forms[0].mailtype.disabled=false;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=false;
	document.forms[0].pfdbname.disabled=false;
	document.forms[0].pfdbuser.disabled=false;
	document.forms[0].pfdbpass.disabled=false;
	document.forms[0].pfuser.disabled=false;
	document.forms[0].pfgroup.disabled=false;
	}
if(document.forms[0].useemail.selectedIndex==1)
	{
	document.forms[0].mailip.disabled=false;
	document.forms[0].mailport.disabled=false;
	document.forms[0].mailpass.disabled=false;
	document.forms[0].mailpath.disabled=true;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailrestart.disabled=true;
	document.forms[0].mailstart.disabled=true;
	document.forms[0].mailstop.disabled=true;
	document.forms[0].mailpid.disabled=true;
	document.forms[0].mailtype.disabled=true;
	document.forms[0].mailaccess.disabled=true;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if(document.forms[0].useemail.selectedIndex==2)
	{
	document.forms[0].mailpath.disabled=true;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailrestart.disabled=true;
	document.forms[0].mailstart.disabled=true;
	document.forms[0].mailstop.disabled=true;
	document.forms[0].mailip.disabled=true;
	document.forms[0].mailport.disabled=true;
	document.forms[0].mailpass.disabled=true;
	document.forms[0].mailpid.disabled=true;
	document.forms[0].mailtype.disabled=true;
	document.forms[0].mailaccess.disabled=true;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if((document.forms[0].mailtype.selectedIndex==0 || document.forms[0].mailtype.selectedIndex==1)&&(document.forms[0].useemail.selectedIndex==0))
	{
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=false;
	document.forms[0].mailvirtuser.disabled=false;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=true;
	document.forms[0].pfdbname.disabled=true;
	document.forms[0].pfdbuser.disabled=true;
	document.forms[0].pfdbpass.disabled=true;
	document.forms[0].pfuser.disabled=true;
	document.forms[0].pfgroup.disabled=true;
	}
if(document.forms[0].mailtype.selectedIndex==2 && document.forms[0].useemail.selectedIndex==0)
	{
	document.forms[0].mailpath.disabled=false;
	document.forms[0].mailcw.disabled=true;
	document.forms[0].mailvirtuser.disabled=true;
	document.forms[0].mailaccess.disabled=false;
	document.forms[0].pfdbhost.disabled=false;
	document.forms[0].pfdbname.disabled=false;
	document.forms[0].pfdbuser.disabled=false;
	document.forms[0].pfdbpass.disabled=false;
	document.forms[0].pfuser.disabled=false;
	document.forms[0].pfgroup.disabled=false;
	}
if(document.forms[0].usewebalizer.selectedIndex==0)
	{
	document.forms[0].webalizerpath.disabled=false;
	document.forms[0].webalizerconf.disabled=false;
	}
if(document.forms[0].usewebalizer.selectedIndex==1)
	{
	document.forms[0].webalizerpath.disabled=true;
	document.forms[0].webalizerconf.disabled=true;
	}
}

function chkData() {
if(document.forms[0].serverip.value <= 0) 
{
alert("Enter an IP address for the server being added");
return false;
}
if(document.forms[0].serverport.value <= 0)
{
alert("Enter a server port for the server being added");
return false;
}
if(document.forms[0].sshport.value <= 0)
{
alert("Enter the ssh port for the server");
return false;
}
if(document.forms[0].maxaccounts.value <= 0)
{
alert("Enter the maximum accounts to be hosted on this server");
return false;
}
if(document.forms[0].maxspace.value <= 0)
{
alert("Enter the maximum amount of disk space (in Megs) to be allocated on this server");
return false;
}
if(document.forms[0].useemail.selectedIndex==0)
	{
	if(document.forms[0].mailpath.value <= 0)
		{
		alert("Enter the path to email users directory.");
		return false;
		}
	if(document.forms[0].mailtype.selectedIndex==0 || document.forms[0].mailtype.selectedIndex==1)
		{
		if(document.forms[0].mailcw.values <= 0)
			{
			alert("Enter Email CW file.");
			return false;
			}
		if(document.forms[0].mailvirtuser.value <= 0)
			{
			alert("Enter Email virtual user file.");
			return false;
			}
		}
	if(document.forms[0].mailrestart.value <= 0)
		{
		alert("Enter the email server restart command.");
		return false;
		}
	if(document.forms[0].mailstart.value <= 0)
		{
		alert("Enter the email server start command.");
		return false;
		}
	if(document.forms[0].mailstop.value <= 0)
		{
		alert("Enter the email server stop command.");
		return false;
		}
	if(document.forms[0].mailpid.value <= 0)
		{
		alert("Enter the email server PID file.");
		return false;
		}
	if(document.forms[0].mailtype.selectedIndex==2)
		{
		if(document.forms[0].pfdbhost.value <= 0)
			{
			alert("Enter the PostFix database hostname");
			return false;
			}
		if(document.forms[0].pfdbname.value <= 0)
			{
			alert("Enter the PostFix database name");
			return false;
			}
		if(document.forms[0].pfdbuser.value <= 0)
			{
			alert("Enter the PostFix database username");
			return false;
			}
		if(document.forms[0].pfdbpass.value <= 0)
			{
			alert("Enter the PostFix database password");
			return false;
			}
		if(document.forms[0].pfuser.value <= 0)
			{
			alert("Enter the PostFix username");
			return false;
			}
		if(document.forms[0].pfgroup.value <= 0)
			{
			alert("Enter the PostFix group");
			return false;
			}
		}
	}
if(document.forms[0].useemail.selectedIndex==1)
	{
	if(document.forms[0].mailip.value <= 0)
		{
		alert("Enter the email server IP.");
		return false;
		}
	if(document.forms[0].mailport.value <= 0)
		{
		alert("Enter the email server port.");
		return false;
		}
	if(document.forms[0].mailpass.value <= 0)
		{
		alert("Enter the mail server password.");
		return false;
		}
	if(document.forms[0].mailpass.value.length <= 0)
		{
		alert("For security reasons the mail server password must be at least 8 characters long.");
		return false;
		}
	}
var test=0;
var group=document.forms[0].pools.options.length;
for(i=0;i<group;i++)
	{
	if(document.forms[0].pools.options[i].selected==1)
		{
		test=1;
		}
	}
if(!test)
	{
	alert("Select at least 1 server pool for this server.");
	return false;
	}
if(document.forms[0].ftplog.value <= 0)
	{
	alert("Enter the FTPd log file.");
	return false;
	}
if(document.forms[0].ftprestart.value <= 0)
	{
	alert("Enter the FTPd restart command.");
	return false;
	}
if(document.forms[0].ftpstart.value <= 0)
	{
	alert("Enter the FTPd start command.");
	return false;
	}
if(document.forms[0].ftpstop.value <= 0)
	{
	alert("Enter the FTPd stop command.");
	return false;
	}
if(document.forms[0].ftppid.value <= 0)
	{
	alert("Enter the FTPd PID file.");
	return false;
	}
return true;
}
var tabcount="6";
var tabname;
var tabtable;
function initTab(){
for(i=1;i<=tabcount;i++)
	{
	tabname=document.getElementById("tab"+i);
	tabtable=document.getElementById("form"+i);
	tabname.style.fontWeight="normal";
	tabtable.style.display="none";
	}
tabname=document.getElementById("tab1");
tabtable=document.getElementById("form1");
tabname.style.fontWeight="bold";
tabtable.style.display="block";
}
function settab(x){
for(i=1;i<=tabcount;i++)
	{
	tabname=document.getElementById("tab"+i);
	tabtable=document.getElementById("form"+i);
	tabname.style.fontWeight="normal";
	tabtable.style.display="none";
	}
tabname=document.getElementById("tab"+x);
tabtable=document.getElementById("form"+x);
tabname.style.fontWeight="bold";
tabtable.style.display="block";
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=6>Edit Hosting Server $values[2]</td></tr>
<tr><td class="prgout" align=left><a class="prgout" id="tab1" href="javascript:settab('1');">Server Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab2" href="javascript:settab('2');">MySQL Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab3" href="javascript:settab('3');">Hosting Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab4" href="javascript:settab('4');">Email Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab5" href="javascript:settab('5');">Webserver Info</a></td>
<td class="prgout" align=left><a class="prgout" id="tab6" href="javascript:settab('6');">FTP Info</a></td></tr>
<tr><td align=left colspan=6>
<div id="form1" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=servername');" class="prgout">Server Name (FQDN)</a></td>
<td class="prgout" align=left>$values[2]</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverip');" class="prgout">Server IP</a></td>
<td class="prgout" align=left><input name="serverip" type="text" value="$values[3]" size=30,1 maxlength=20></td></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverport');" class="prgout">Server Port</a></td>
<td class="prgout" align=left><input name="serverport" type="text" value="$values[4]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=serverpass');" class="prgout">Server Password</a></td>
<td class="prgout" align=left><input name="serverpass" type="text" value="$serverpass" size=30,1 maxlength=56 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="$values[85]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no");
if($values[20] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" value="$values[52]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load Firewall at startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no");
if($values[53] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no");
if($values[23] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" value="$values[86]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" value="$values[87]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" value="$values[88]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" value="$values[89]" size=30,1></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('2');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form2" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbhost');" class="prgout">Server Database Hostname</a></td>
<td class="prgout" align=left><input name="sdbhost" type="text" value="$values[24]" size=30,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbname');" class="prgout">Server Database Name</a></td>
<td class="prgout" align=left><input name="sdbname" type="text" value="$values[25]" size=30,1 maxlength=64></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbuser');" class="prgout">Server Database Username</a></td>
<td class="prgout" align=left><input name="sdbuser" type="text" value="$values[26]" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sdbpass');" class="prgout">Server Database Password</a></td>
<td class="prgout" align=left><input name="sdbpass" type="text" value="$sdbpass" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqlhost');" class="prgout">MySQL server hostname</a></td>
<td class="prgout" align=left><input name="mysqlhost" type="text" value="$values[48]" size=30,1 maxlength=60></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqluser');" class="prgout">MySQL root username</a></td>
<td class="prgout" align=left><input name="mysqluser" type="text" value="$values[46]" size=16,1 maxlength=16></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mysqlpass');" class="prgout">MySQL root password</a></td>
<td class="prgout" align=left><input name="mysqlpass" type="text" value="$mysqlpass" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usemysql');" class="prgout">Use MySQL</a></td>
<td class="prgout" align=left><select name="usemysql" size=1><option value="yes">Yes<option value="no");
if($values[15] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('3');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form3" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxaccounts');" class="prgout">Maximum Accounts</a></td>
<td class="prgout" align=left><input name="maxaccounts" type="text" value="$values[7]" size=5,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxspace');" class="prgout">Maximum Allocated Space</a></td>
<td class="prgout" align=left><input name="maxspace" type="text" value="$values[8]" size=5,1> Megabytes</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=maxbandwidth');" class="prgout">Maximum Allocated Bandwidth</a></td>
<td class="prgout" align=left><input name="maxbandwidth" type="text" value="$values[9]" size=5,1> Gigabytes</td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usequota');" class="prgout">Use Linux quota management?</a></td>
<td class="prgout" align=left><select name="usequota" size=1><option value="yes">Yes<option value="no");
if($values[10] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=allowshell');" class="prgout">Allow Shell Access</a></td>
<td class="prgout" align=left><select name="allowshell" size=1 onChange="return changeIt();"><option value="no">No<option value="yes");
if($values[21] eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascritp:newwin('$script?do=help&help=clientshell');" class="prgout">Allow Shell Control by Client?</a></td>
<td class="prgout" align=left><select name="clientshell" size=1 onChange="return changeIt();"><option value="no">No<option value="yes");
if($values[22] eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td class="prgout" align=left Valign=top><a href="javascript:newwin('$script?do=help&help=pools');" class="prgout">Server Pools</a></td>
<td class="prgout" align=left><select name="pools" size=3 multiple>);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<option value="$id");
	if($values[6] =~ /\|$id\|/){print qq( selected);}
	print qq(>$name);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sharedip');" class="prgout">Shared IP</a></td>
<td class="prgout" align=left><input name="sharedip" type="text" value="$values[12]" size=15,1 maxlength=15></td></tr>
<tr><td class="prgout" align=left Valign=top><a href="javascript:newwin('$script?do=help&help=dedips');" class="prgout">Dedicated IPs</a><BR>One ip/set per line</td>
<td class="prgout" align=left><textarea name="dedips" rows=3 cols=20>$values[13]</textarea></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('4');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form4" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=useemail');" class="prgout">Use Email</a></td>
<td class="prgout" align=left><select name="useemail" size=1 onChange="return changeIt();"><option value="local">Local<option value="remote");
if($values[14] eq "remote"){print qq( SELECTED);}
print qq(>Remote<option value="no");
if($values[14] eq "no"){print qq( SELECTED);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailtype');" class="prgout">Email Server Type</a></td>
<td class="prgout" align=left><select name="mailtype" size=1 onChange="return changeIt();"><option value="sendmail">Sendmail<option value="postfix");
if($values[73] eq "postfix"){print qq( selected);}
print qq(>PostFix<option value="pfmysql");
if($values[73] eq "pfmysql"){print qq( selected);}
print qq(>PostFix/MySQL</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesa');" class="prgout">Use SpamAssassin</a></td>
<td class="prgout" align=left><select name="usesa" size=1><option value="no">No<option value="yes");
if($values[84] eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpath');" class="prgout">Path to email users directory</a></td>
<td class="prgout" align=left><input name="mailpath" type="text" value="$values[36]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailcw');" class="prgout">Email CW file</a></td>
<td class="prgout" align=left><input name="mailcw" type="text" value="$values[37]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailvirtuser');" class="prgout">Email virtual user file</a></td>
<td class="prgout" align=left><input name="mailvirtuser" type="text" value="$values[38]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailaccess');" class="prgout">Email server access file</a></td>
<td class="prgout" align=left><input name="mailaccess" type="text" value="$values[82]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstop');" class="prgout">Email server stop command</a></td>
<td class="prgout" align=left><input name="mailstop" type="text" value="$values[41]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailstart');" class="prgout">Email server start command</a></td>
<td class="prgout" align=left><input name="mailstart" type="text" value="$values[40]" size=30,1 maxlength=250></td></rt>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailrestart');" class="prgout">Email server restart command</a></td>
<td class="prgout" align=left><input name="mailrestart" type="text" value="$values[39]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpid');" class="prgout">Email server PID file</a></td>
<td class="prgout" align=left><input name="mailpid" type="text" value="$values[42]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailip');" class="prgout">Email server IP</a></td>
<td class="prgout" align=left><input name="mailip" type="text" value="$values[43]" size=15,1 maxlength=15 DISABLED></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailport');" class="prgout">Email server port</a></td>
<td class="prgout" align=left><input name="mailport" type="text" value="$values[44]" size=5,1 maxlength=5 DISABLED></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=mailpass');" class="prgout">Email server password</a></td>
<td class="prgout" align=left><input name="mailpass" type="text" value="$mailpass" size=30,1 DISABLED></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbhost');" class="prgout">PostFix Database Hostname</a></td>
<td class="prgout" align=left><input name="pfdbhost" type="text" value="$values[76]" size=30,1 maxlength=60 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbname');" class="prgout">PostFix Database Name</a></td>
<td class="prgout" align=left><input name="pfdbname" type="text" value="$values[77]" size=30,1 maxlength=64 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbuser');" class="prgout">PostFix Database Username</a></td>
<td class="prgout" align=left><input name="pfdbuser" type="text" value="$values[78]" size=16,1 maxlength=16 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfdbpass');" class="prgout">PostFix Database Password</a></td>
<td class="prgout" align=left><input name="pfdbpass" type="text" value="$pfdbpass" size=30,1 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfuser');" class="prgout">PostFix Username</a></td>
<td class="prgout" align=left><input name="pfuser" type="text" value="$values[80]" size=30,1 maxlength=32 disabled></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=pfgroup');" class="prgout">PostFix Group</a></td>
<td class="prgout" align=left><input name="pfgroup" type="text" value="$values[81]" size=30,1 maxlength=32 disabled></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('5');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form5" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=apachever');" class="prgout">Apache Version</a></td>
<td class="prgout" align=left><select name="apachever" size=1><option value="1.3x">1.3x<option value="2x");
if($values[71] eq "2x"){print qq( selected);}
print qq(>2x</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesuexec');" class="prgout">Use SuExec?</a></td>
<td class="prgout" align=left><select name="usesuexec" size=1><option value="yes">Yes<option value="no");
if($values[72] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=hosttype');" class="prgout">Hosting type for this server</a></td>
<td class="prgout" align=left><select name="hosttype" size=1 onChange="return changeIt();"><option value="both">Both<option value="ip");
if($values[11] eq "ip"){print qq( selected);}
print qq(>IP Based<option value="name");
if($values[11] eq "name"){print qq( selected);}
print qq(>Name Based</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sslsupport');" class="prgout">Support SSL?</a></td>
<td class="prgout" align=left><select name="sslsupport" size=1><option value="no">No<option value="yes");
if($values[19] eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usesubdomain');" class="prgout">Use Sub Domain</a></td>
<td class="prgout" align=left><select name="usesubdomain" size=1><option value="yes">Yes<option value="no");
if($values[16] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=apacheconf');" class="prgout">Web server configuration file</a></td>
<td class="prgout" align=left><input name="apacheconf" type="text" value="$values[28]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=virtconf');" class="prgout">Path to virtual hosting configuration files</a></td>
<td class="prgout" align=left><input name="virtconf" type="text" value="$values[29]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=userdir');" class="prgout">Path to user's directory</a></td>
<td class="prgout" align=left><input name="userdir" type="text" value="$values[30]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=logpath');" class="prgout">Path to log files</a></td>
<td class="prgout" align=left><input name="logpath" type="text" value="$values[31]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstart');" class="prgout">Web server start command</a></td>
<td class="prgout" align=left><input name="webstart" type="text" value="$values[33]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstop');" class="prgout">Web server stop command</a></td>
<td class="prgout" align=left><input name="webstop" type="text" value="$values[34]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webrestart');" class="prgout">Web server restart command</a></td>
<td class="prgout" align=left><input name="webrestart" type="text" value="$values[32]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webpid');" class="prgout">Web server PID file</a></td>
<td class="prgout" align=left><input name="webpid" type="text" value="$values[35]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=fpext');" class="prgout">Front Page Extensions</a></td>
<td class="prgout" align=left><select name="fpext" size=1><option value="">None<option value="4.0");
if($values[51] eq "4.0"){print qq( selected);}
print qq(>4.0 (2000)<option value="5.0");
if($values[51] eq "5.0"){print qq( selected);}
print qq(>5.0 (2002)</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usewebalizer');" class="prgout">Use Webalizer</a></td>
<td class="prgout" align=left><select name="usewebalizer" size=1 onChange="return changeIt();"><option value="yes">Yes<option value="no");
if($values[17] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webalizerconf');" class="prgout">Webalizer configuration file</a></td>
<td class="prgout" align=left><input name="webalizerconf" type="text" value="$values[50]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webalizerpath');" class="prgout">Path to webalizer</a></td>
<td class="prgout" align=left><input name="webalizerpath" type="text" value="$values[49]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=right colspan=2><a href="javascript:settab('6');">Continue&gt;&gt;</a></td></tr>
</table>
</div>
<div id="form6" class="tab">
<table align=left border=0 cellpadding=2 cellspacing=2 width=100% class="tab">
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usevirtftp');" class="prgout">Use Virtual FTP Support?</a></td>
<td class="prgout" align=left><select name="usevirtftp" size=1 onChange="return changeIt();"><option value="no">No<option value="yes");
if($values[18] eq "yes"){print qq( selected);}
print qq(>Yes</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftplog');" class="prgout">FTPd log file</a></td>
<td class="prgout" align=left><input name="ftplog" type="text" value="$values[55]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftpstart');" class="prgout">FTPd server start command</a></td>
<td class="prgout" align=left><input name="ftpstart" type="text" value="$values[57]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftpstop');" class="prgout">FTPd server stop command</a></td>
<td class="prgout" align=left><input name="ftpstop" type="text" value="$values[58]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftprestart');" class="prgout">FTPd server restart command</a></td>
<td class="prgout" align=left><input name="ftprestart" type="text" value="$values[56]" size=30,1 maxlength=250></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=ftppid');" class="prgout">FTPd PID file</a></td>
<td class="prgout" align=left><input name="ftppid" type="text" value="$values[59]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">Include Path</a></td>
<td class="prgout" align=left><input name="includepath" type="text" value="$values[74]" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=4><input type="submit" value="Save Server"></td></tr>
</table>
</div>
</td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Server">
</form>
<script language="javascript">
<!--
changeIt();
initTab();
//-->
</script>\n);
&Bottom;
}

##

sub Edit_Server_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Edit Hosting Server</TD></TR>\n);
if($count <= 10)
	{
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2><A HREF="$script?do=Edit+Server&id=$id" class="prgout">$name</A></TD></TR>\n);
		}
	}
else
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left>Select Server</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<OPTION VALUE="$id">$name);
		}
	print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Edit Server"></TD></TR>\n);
	}
print qq(</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Edit Server">
</FORM>);
&Bottom;
}

##

sub Add_Server
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id FROM server WHERE (name='$FORM{'servername'}' || ip='$FORM{'serverip'}') && type='hosting');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
if($query_output->fetchrow)
	{
	&Error("The server, $FORM{'servername'}, or IP, $FORM{'serverip'}, already exist");
	}
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverpass)=&encode_base64($cipher->encrypt($FORM{'serverpass'}));
my($sdbpass,$mailpass,$mysqlpass,$pfdbpass);
$sdbpass=&encode_base64($cipher->encrypt($FORM{'sdbpass'}));
if($FORM{'mailpass'}){$mailpass=&encode_base64($cipher->encrypt($FORM{'mailpass'}));}
if($FORM{'mysqlpass'}){$mysqlpass=&encode_base64($cipher->encrypt($FORM{'mysqlpass'}));}
if($FORM{'pfdbpass'}){$pfdbpass=&encode_base64($cipher->encrypt($FORM{'pfdbpass'}));}
my($pools)="|".join("|",@POOLS)."|";
$FORM{'dedips'}=~s/ *$//g;
foreach(keys %FORM){$FORM{$_}=~s/\'/\\\'/g;}
$statement=qq(INSERT INTO server (type,name,ip,port,serverpass,pools,maxaccounts,maxspace,maxbandwidth,usequota,hosttype,sharedip,dedips,useemail,usemysql,usesubdomain,
usewebalizer,usevirtftp,sslsupport,netfilter,allowshell,clientshell,usefilecheck,sdbhost,sdbname,sdbuser,sdbpass,apacheconf,virtconf,userdir,
logpath,webrestart,webstart,webstop,webpid,mailpath,mailcw,mailvirtuser,mailrestart,mailstart,mailstop,mailpid,mailip,mailport,mailpass,
mysqluser,mysqlpass,mysqlhost,webalizerpath,webalizerconf,fpext,nfpath,autofirewall,ftplog,ftprestart,ftpstart,ftpstop,ftppid,apachever,usesuexec,mailtype,includepath,
pfdbhost,pfdbname,pfdbuser,pfdbpass,pfuser,pfgroup,mailaccess,usesa,sshport,sshstart,sshstop,sshrestart,sshpid)
VALUES ('hosting','$FORM{'servername'}','$FORM{'serverip'}','$FORM{'serverport'}','$serverpass','$pools','$FORM{'maxaccounts'}',
'$FORM{'maxspace'}','$FORM{'maxbandwidth'}','$FORM{'usequota'}','$FORM{'hosttype'}','$FORM{'sharedip'}','$FORM{'dedips'}','$FORM{'useemail'}',
'$FORM{'usemysql'}','$FORM{'usesubdomain'}','$FORM{'usewebalizer'}','$FORM{'usevirtftp'}','$FORM{'sslsupport'}','$FORM{'netfilter'}','$FORM{'allowshell'}',
'$FORM{'clientshell'}','$FORM{'usefilecheck'}','$FORM{'sdbhost'}','$FORM{'sdbname'}','$FORM{'sdbuser'}','$sdbpass','$FORM{'apacheconf'}','$FORM{'virtconf'}',
'$FORM{'userdir'}','$FORM{'logpath'}','$FORM{'webrestart'}','$FORM{'webstart'}','$FORM{'webstop'}','$FORM{'webpid'}','$FORM{'mailpath'}','$FORM{'mailcw'}',
'$FORM{'mailvirtuser'}','$FORM{'mailrestart'}','$FORM{'mailstart'}','$FORM{'mailstop'}','$FORM{'mailpid'}','$FORM{'mailip'}','$FORM{'mailport'}','$mailpass',
'$FORM{'mysqluser'}','$mysqlpass','$FORM{'mysqlhost'}','$FORM{'webalizerpath'}','$FORM{'webalizerconf'}','$FORM{'fpext'}','$FORM{'nfpath'}','$FORM{'autofirewall'}',
'$FORM{'ftplog'}','$FORM{'ftprestart'}','$FORM{'ftpstart'}','$FORM{'ftpstop'}','$FORM{'ftppid'}','$FORM{'apachever'}','$FORM{'usesuexec'}',
'$FORM{'mailtype'}','$FORM{'includepath'}','$FORM{'pfdbhost'}','$FORM{'pfdbname'}','$FORM{'pfdbuser'}','$pfdbpass','$FORM{'pfuser'}','$FORM{'pfgroup'}',
'$FORM{'mailaccess'}','$FORM{'usesa'}','$FORM{'sshport'}','$FORM{'sshstart'}','$FORM{'sshstop'}','$FORM{'sshrestart'}','$FORM{'sshpid'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id)=$query_output->fetchrow;
my(@dedips)=split(/\n/,$FORM{'dedips'});
my($dedips);
foreach(@dedips)
	{
	if($_ =~ /-/)
		{
		my(@info)=split(/-/,$_);
		my(@info2)=split(/\./,$info[0]);
		$dedips+=$info[1]-$info2[3]+1;
		}
	else
		{
		$dedips++;
		}
	}
my($mail)="no";
if($FORM{'useemail'} ne "no"){$mail="yes";}
$statement=qq(INSERT INTO resource_list (server,pools,maxaccounts,usedaccounts,maxspace,usedspace,totspace,maxbandwidth,usedbandwidth,totbandwidth,availdedips,mail,`ssl`)
VALUES ('$id','$pools','$FORM{'maxaccounts'}','0','$FORM{'maxspace'}','0','0','$FORM{'maxbandwidth'}','0','0','$dedips','$mail','$FORM{'sslsupport'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
if($FORM{'mailip'})
	{
	my($command)=qq(do=add+referer&ip=$FORM{'serverip'});
	&Connect($FORM{'mailip'},$FORM{'mailport'},$FORM{'mailpass'},$command);
	if($remote{'status'} ne "done"){&Error("Unable to update referers on $FORM{'mailip'} mailserver, $remote{'status'}");}
	}
$statement=qq(SELECT ip FROM server WHERE type='client');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sip,@ips);
while(($sip)=$query_output->fetchrow)
	{
	if($sip ne $ENV{'SERVER_ADDR'}){push(@ips,$sip);}
	}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the hosting server");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Generate hhelper.inc on $FORM{'servername'} hosting server</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Root Password:</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="pass" TYPE="password" SIZE=30,1></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Send hhelper.inc"></TD></TR>
</TABLE>
<INPUT NAME="id" TYPE="hidden" VALUE="$id">
<INPUT NAME="do" TYPE="hidden" VALUE="Send hhelperinc">
</FORM>);
&Bottom;
}

##

sub Configure_Server_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Send Hosting Server Configuration</TD></TR>\n);
if($count <= 10)
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Server to Configure</TD>
<TD CLASS="prgout" ALIGN=left>\n);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<A HREF="$script?do=Configure+Server&id=$id" class="prgout">$name</A><BR>\n);
		}
	print qq(</TD></TR>\n);
	}
else
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left>Server to Configure</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<OPTION VALUE="$id">$name);
		}
	print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Configure Server"></TD></TR>\n);
	}
print qq(</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Configure Server">
</FORM>);
&Bottom;
}

##

sub Configure_Server
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@fields)=$query_output->name;
my(@values)=$query_output->fetchrow_array;
my($cipher);
my($serverpass,$sdbpass,$mysqlpass,$mailpass,$pfdbpass);
if($values[5])
	{
	if(&decode_base64($values[5]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($values[5]));
	}
if($values[27])
	{
	if(&decode_base64($values[27]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$sdbpass=$cipher->decrypt(&decode_base64($values[27]));
	}
if($values[45])
	{
	if(&decode_base64($values[45]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$mailpass=$cipher->decrypt(&decode_base64($values[45]));
	}
if($values[47])
	{
	if(&decode_base64($values[47]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$mysqlpass=$cipher->decrypt(&decode_base64($values[47]));
	}
if($values[79])
	{
	if(&decode_base64($values[79]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$pfdbpass=$cipher->decrypt(&decode_base64($values[79]));
	}
my($command)=qq(do=configure+server);
my($i);
for($i=6;$i<=$#fields;$i++)
	{
	if($values[$i])
		{
		if(($i != 27)&&($i != 45)&&($i != 47)&&($i != 12)&&($i != 13)&&($i != 79))
			{
			$values[$i]=&uri_escape($values[$i]);
			$command.=qq(&$fields[$i]=$values[$i]);
			}
		elsif($i == 27){$command.=qq(&sdbpass=$sdbpass);}
		elsif($i == 45){$command.=qq(&mailpass=$mailpass);}
		elsif($i == 47){$command.=qq(&mysqlpass=$mysqlpass);}
		elsif($i == 79){$command.=qq(&pfdbpass=$pfdbpass);}
		}
	}
$command.=qq(&admindbhost=$ENV{'SERVER_ADDR'}&admindbuser=$system{'dbuser'}&admindbpass=$system{'dbpass'});
&Connect($values[3],$values[4],$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server configured</td></tr>
</table>);
&Bottom;
}

##

sub Servertables
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=create+tables);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server database created</td></tr>
</table>);
&Bottom;
}

##

sub Servertables_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
$|=1;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Setup Server Database</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Server</TD>
<TD CLASS="prgout" ALIGN=left>);
if($count > 10)
	{
	print qq(<SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<OPTION VALUE="$id">$name);
		}
	print qq(</SELECT>);
	}
else
	{
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<A HREF="$script?do=Servertables&id=$id" class="prgout">$name</A><BR>);
		}
	}
print qq(</TD></TR>\n);
if($count > 10){print qq(<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Setup Server Database"></TD></TR>\n);}
print qq(</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Servertables">
</FORM>\n);
&Bottom;
}

##

sub Remove_Server
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,mailip,mailport,mailpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($sip,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
if($ip)
	{
	my($command)=qq(do=remove+referer&ip=$sip);
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to update $ip mailserver referer list, $remote{'status'}");}
	}
$statement=qq(DELETE FROM server WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(DELETE FROM resource_list WHERE server='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Server_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a server to remove");
return false;
}
if(confirm("Do you want to delete this server?"))
	{
	return true;
	}
else
return false;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove Hosting Server</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Server To Remove</TD>
<TD CLASS="prgout" ALIGN=left>);
if($count > 10)
	{
	print qq(<SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<OPTION VALUE="$id">$name);
		}
	print qq(</SELECT>);
	}
else
	{
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<A HREF="$script?do=Remove+Server&id=$id" onClick="return chkData()" class="prgout">$name</A><BR>);
		}
	}
print qq(</TD></TR>\n);
if($count > 10){print qq(<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove Server"></TD></TR>\n);}
print qq(</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Remove Server">
</FORM>\n);
&Bottom;
}

##

sub Remove_Pool
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSP3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM server_pool WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server pool removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Pool_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSP3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server_pool ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to delete this server pool?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 NAME="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove Server Pool</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Server Pool to Remove</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1>);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove Pool"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Remove Pool">
</FORM>\n);
&Bottom;
}

##

sub Save_Pool
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSP2'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'name'}=~s/\'/\\'/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE server_pool SET name='$FORM{'name'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server pool updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Pool_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSP2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name FROM server_pool WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name)=$query_output->fetchrow;
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 NAME="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Edit Server Pool</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Server Pool</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="name" TYPE="text" VALUE="$name" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Save Pool"></TD></TR>
</TABLE>
<INPUT NAME="id" TYPE="hidden" VALUE="$FORM{'id'}">
<INPUT NAME="do" TYPE="hidden" VALUE="Save Pool">
</FORM>\n);
&Bottom;
}

##

sub Edit_Pool_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSP2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server_pool ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 NAME="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Edit Server Pool</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Server Pool to Edit</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1>);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Edit Pool"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Edit Pool">
</FORM>\n);
&Bottom;
}

##

sub Add_Pool
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSP1'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'name'}=~s/\'/\\'/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name FROM server_pool WHERE name='$FORM{'name'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($test)=$query_output->fetchrow;
if($test)
	{
	&Error("Server Pool, $test, already exists");
	}
$statement=qq(INSERT INTO server_pool (name) VALUES ('$FORM{'name'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server pool added</td></tr>
</table>);
&Bottom;
}

##

sub Add_Pool_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MSP1'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Add Server Pool</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Pool Name</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="name" TYPE="text" SIZE=20,1 MAXLENGTH=20></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Add Pool"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Add Pool">
</FORM>\n);
&Bottom;
}

##

sub Update_ServerDB_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MHS4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Update Hosting Server Database</TD></TR>\n);
if($count <= 10)
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left VALIGN=top>Server to Update</TD>
<TD CLASS="prgout" ALIGN=left>\n);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<A HREF="$script?do=Update+ServerDB&id=$id" class="prgout">$name</A><BR>\n);
		}
	print qq(</TD></TR>\n);
	}
else
	{
	print qq(<TR><TD CLASS="prgout" ALIGN=left>Server to Configure</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<OPTION VALUE="$id">$name);
		}
	print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Update Server"></TD></TR>\n);
	}
print qq(</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Update ServerDB">
</FORM>);
&Bottom;
}

##

sub Update_ServerDB
{
if(($Cookies{'level'} ne "1")&&($access{'MHS12'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=update+serverdb);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Hosting server configured</td></tr>
</table>);
&Bottom;
}

1;
