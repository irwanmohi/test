sub Sync_Res_Defaults
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD10'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
&Connect($ip,$port,$serverpass,"do=get+all+layouts");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='hosting' && id != '$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
foreach (keys %remote){$remote{$_}=&uri_escape($remote{$_});}
my($command)=qq(do=set+all+layouts&invoice=$remote{'invoice'}&top=$remote{'top'}&bottom=$remote{'bottom'}&front=$remote{'front'}&admin=$remote{'admin'});
$command.=qq(&billing=$remote{'billing'}&email=$remote{'email'}&ftp=$remote{'ftp'}&`ssl`=$remote{'ssl'}&support=$remote{'support'}&web=$remote{'web'}&plugins=$remote{'plugin'});
$command.=qq(&signuptop=$remote{'signuptop'}&signupbottom=$remote{'signupbottom'}&plugin=$remote{'plugin'}&topplugin=$remote{'topplugin'}&bottomplugin=$remote{'bottomplugin'});
while(($ip,$port,$serverpass)=$query_output->fetchrow)
	{
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error($remote{'status'});}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Syncronize Default Reseller Layouts</td></tr>
<tr><td class="prgout" align=left>All reseller default templates have been syncronized.</td></tr>
</table>);
&Bottom;
}

##

sub Sync_Res_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD10'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<script language="javascript">
<!--
function ConFirm(x)
{
if(x == undefined)
	{
	x=document.forms[0].id.options[document.forms[0].id.selectedIndex].text;
	}
if(confirm("Do you want to syncronize against this hosting server? - "+x))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<form action="$script" method="Post" onSubmit="return ConFirm()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Syncronize Default Reseller Layouts</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server to sync against</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Sync+Res+Defaults&id=$id" onClick="return ConFirm('$name');" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server to sync against</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Syncronize Reseller Defaults"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Sync Res Defaults">
</form>);
&Bottom;
}

##

sub Save_Def_Signup_Layout
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD9'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$FORM{'top'}=&uri_escape($FORM{'top'});
$FORM{'bottom'}=&uri_escape($FORM{'bottom'});
my($command)=qq(do=save+signup+layout&top=$FORM{'top'}&bottom=$FORM{'bottom'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Default reseller signup layout saved</td></tr>
</table>);
&Bottom;
}

##

sub Def_Signup_Layout
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD9'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+signup+layout);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'top'}=~s/\&/&amp;/g;
$remote{'top'}=~s/"/&quot;/g;
$remote{'top'}=~s/</&lt;/g;
$remote{'top'}=~s/>/&gt;/g;
$remote{'bottom'}=~s/\&/&amp;/g;
$remote{'bottom'}=~s/"/&quot;/g;
$remote{'bottom'}=~s/</&lt;/g;
$remote{'bottom'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Configure Default Reseller Signup Layout for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the signup program</td></tr><tr><td class="prgout" align=left Valign=top>Top HTML (Header)</td></tr>
<tr><td class="prgout" align=left> <textarea name="top" rows=15 cols=75 wrap=off>$remote{'top'}</textarea></td></tr>
<tr><td class="prgout" align=left Valign=top>Bottom HTML (Footer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="bottom" rows=15 cols=75 wrap=off>$remote{'bottom'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Layout"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Def Signup Layout">
</form>);
&Bottom;
}

##

sub Def_Signup_Layout_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD9'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Default Reseller Signup Layout</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Def+Signup+Layout&id=$id" class="prgout">$name</A><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Layout"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Def Signup Layout">
</form>);
&Bottom;
}

##

sub Save_Def_Client_Web
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$serverpass,"do=save+web+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Default reseller web menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Def_Client_Web
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
&Connect($ip,$port,$serverpass,"do=get+web+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Configure Default Reseller Client Website Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Web Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Def Client Web">
</form>);
&Bottom;
}

##

sub Def_Client_Web_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Default Reseller Client Website Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Def+Client+Web&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Web Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Def Client Web">
</form>);
&Bottom;
}

##

sub Save_Def_Client_Support
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$serverpass,"do=save+support+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Reseller default support menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Def_Client_Support
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
&Connect($ip,$port,$serverpass,"do=get+support+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface Support Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Support Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Def Client Support">
</form>);
&Bottom;
}

##

sub Def_Client_Support_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Default Reseller Client Support Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Def+Client+Support&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Support Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Def Client Support">
</form>);
&Bottom;
}

##

sub Save_Def_Client_SSL
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$serverpass,"do=save+ssl+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Default reseller SSL Menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Def_Client_SSL
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
&Connect($ip,$port,$serverpass,"do=get+ssl+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Configure Default Reseller Client SSL Cert Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left><textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save SSL Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Def Client SSL">
</form>);
&Bottom;
}

##

sub Def_Client_SSL_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Default Reseller Client SSL Cert Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Def+Client+SSL&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit SSL Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Def Client SSL">
</form>);
&Bottom;
}

##

sub Save_Def_Client_FTP
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$serverpass,"do=save+ftp+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Default reseller FTP menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Def_Client_FTP
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
&Connect($ip,$port,$serverpass,"do=get+ftp+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Configure Default Reseller Client FTP Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left><textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save FTP Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Def Client FTP">
</form>);
&Bottom;
}

##

sub Def_Client_FTP_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Default Reseller Client FTP Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Def+Client+FTP&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Virtual FTP Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Def Client FTP">
</form>);
&Bottom;
}

##

sub Save_Def_Client_Email
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$FORM{'html'}=&uri_escape($FORM{'html'});
my($command)=qq(do=save+email+menu&html=$FORM{'html'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Default reseller email menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Def_Client_Email
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+email+menu);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Configure Default Reseller Client Email Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Email Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Def Client Email">
</form>);
&Bottom;
}

##

sub Def_Client_Email_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Default Reseller Client Email Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Def+Client+Email&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Email Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Def Client Email">
</form>);
&Bottom;
}
##

sub Save_Def_Client_Billing
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$serverpass,"do=save+billing+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Default Reseller billing menu updated</td></tr>
</table>);
&Bottom;
}
##

sub Def_Client_Billing
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
&Connect($ip,$port,$serverpass,"do=get+billing+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Configure Default Reseller Client Billing Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Billing Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Def Client Billing">
</form>);
&Bottom;
}

##

sub Def_Client_Billing_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Default Reseller Client Billing Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Def+Client+Billing&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Billing Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Def Client Billing">
</form>);
&Bottom;
}

##

sub Save_Def_Client_Admin
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$serverpass,"do=save+admin+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Default reseller client admin menu updated</td></tr>
</table>);
&Bottom;
}
##

sub Def_Client_Admin
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
&Connect($ip,$port,$serverpass,"do=get+admin+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>onfigure Default Reseller Client Admin Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Admin Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Def Client Admin">
</form>);
&Bottom;
}

##

sub Def_Client_Admin_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Default Reseller Client Admin Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Def+Client+Admin&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Default Client Admin Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Def Client Admin">
</form>);
&Bottom;
}

##

sub Save_Def_Client_Frontpage
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$FORM{'frontpage'}=&uri_escape($FORM{'frontpage'});
$FORM{'plugins'}=&uri_escape($FORM{'plugins'});
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=save+def+frontpage&frontpage=$FORM{'frontpage'}&plugins=$FORM{'plugins'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Default reseller client frontpage updated</td></tr>
</table>);
&Bottom;
}
##

sub Def_Client_Frontpage
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+def+frontpage);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'plugins'}=~s/\&/&amp;/g;
$remote{'plugins'}=~s/"/&quot;/g;
$remote{'plugins'}=~s/</&lt;/g;
$remote{'plugins'}=~s/>/&gt;/g;
$remote{'frontpage'}=~s/\&/&amp;/g;
$remote{'frontpage'}=~s/"/&quot;/g;
$remote{'frontpage'}=~s/</&lt;/g;
$remote{'frontpage'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Configure Default Reseller Client Frontpage for $name</td></tr>
<tr><td class="prgout" align=left>Level Restricted Plugins<br>
This allows you to place plugins that will be placed if the person has appropriate access.<br>
Use WITHADMIN=<something> for administrator privledges<br>
Use WITHEMAIL=<something> for email management access<br>
Use WITHBILLING=<something> for billing management access<br>
Use WITHFTP=<something> for ftp management access<br>
Use WITHWEB=<something> for web management access</td></tr>
<tr><td class="prgout" align=left><textarea name="plugins" rows=6 cols=75 wrap=off>$remote{'plugins'}</textarea></td></tr>
<tr><td class="prgout" align=left>Place plugins with %%<plugin>%% such as %%WITHADMIN%%
Use %%quickview%% to place quickview<br>
Use %%resources%% to place resources vertically<br>
Use %%sysinfo%% to place system information vertically<br>
Use %%sysinfoh%% to place system information horizontally<br>
Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)<br>
Use %%NEWS%% to place a listing of the last 10 news articles<br>
Use %%ADMIN%% to place the admin function menu<br>
Use %%BILLING%% to place the billing function menu<br>
Use %%EMAIL%% to place the email function menu<br>
Use %%FTP%% to place the ftp function menu<br>
Use %%SSL%% to place the SSL Cert Function menu<br>
Use %%SUPPORT%% to place the support function menu<br>
Use %%WEB%% to place the website function menu<br>
Use %%DOMAIN%% to place the domain.</td></tr>
<tr><td class="prgout" align=left> <textarea name="frontpage" rows=15 cols=75 wrap=off>$remote{'frontpage'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Front Page"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Def Client Frontpage">
</form>);
&Bottom;
}

##

sub Def_Client_Frontpage_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Default Reseller Client Frontpage</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Def+Client+Frontpage&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Default Client Frontpage"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Def Client Frontpage">
</form>);
&Bottom;
}

##

sub Save_Def_Client_Layout
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD1'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'top'}=&uri_escape($FORM{'top'});
$FORM{'bottom'}=&uri_escape($FORM{'bottom'});
$FORM{'topplugin'}=&uri_escape($FORM{'topplugin'});
$FORM{'bottomplugin'}=&uri_escape($FORM{'bottomplugin'});
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=save+def+layout&top=$FORM{'top'}&bottom=$FORM{'bottom'}&topplugin=$FORM{'topplugin'}&bottomplugin=$FORM{'bottomplugin'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Default reseller client layout updated</td></tr>
</table>);
&Bottom;
}

##

sub Def_Client_Layout
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+def+layout);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'top'}=~s/\&/&amp;/g;
$remote{'top'}=~s/"/&quot;/g;
$remote{'top'}=~s/</&lt;/g;
$remote{'top'}=~s/>/&gt;/g;
$remote{'bottom'}=~s/\&/&amp;/g;
$remote{'bottom'}=~s/"/&quot;/g;
$remote{'bottom'}=~s/</&lt;/g;
$remote{'bottom'}=~s/>/&gt;/g;
$remote{'topplugin'}=~s/\&/&amp;/g;
$remote{'topplugin'}=~s/"/&quot;/g;
$remote{'topplugin'}=~s/</&lt;/g;
$remote{'topplugin'}=~s/>/&gt;/g;
$remote{'bottomplugin'}=~s/\&/&amp;/g;
$remote{'bottomplugin'}=~s/"/&quot;/g;
$remote{'bottomplugin'}=~s/</&lt;/g;
$remote{'bottomplugin'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Configure Default Reseller Client Page Layout for $name</td></tr>
<tr><td class="prgout" align=left>Level Restricted Plugins for Top<br>
This allows you to place plugins that will be placed if the person has appropriate access.<br>
Use WITHLOGIN==for all users logged in<br>
Use WITHADMIN== for administrator privledges<br>
Use WITHEMAIL== for email management access<br>
Use WITHBILLING== for billing management access<br>
Use WITHFTP== for ftp management access<br>
Use WITHWEB== for web management access<br>
Note * You can have multiple plugins per category by incrementing the plugin names (ie. WITHADMIN, WITHADMIN1, WITHADMIN2)</td></tr>
<tr><td class="prgout" align=left><textarea name="topplugin" rows=10 cols=75 wrap=off>$remote{'topplugin'}</textarea></td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)<br>
Use %%VERSION%% to place the client version number<br>
Use %%ADMIN%% to place the admin function menu<br>
Use %%BILLING%% to place the billing function menu<br>
Use %%EMAIL%% to place the email function menu<br>
Use %%FTP%% to place the ftp function menu<br>
Use %%SSL%% to place the SSL Cert Function menu<br>
Use %%SUPPORT%% to place the support function menu<br>
Use %%WEB%% to place the website function menu<br>
Use %%DOMAIN%% to place the domain.</td></tr>
<tr><td class="prgout" align=left Valign=top>Top HTML (Header)</td></tr>
<tr><td class="prgout" align=left> <textarea name="top" rows=15 cols=75 wrap=off>$remote{'top'}</textarea></td></tr>
<tr><td class="prgout" align=left>Level Restricted Plugins for Bottom<br>
This allows you to place plugins that will be placed if the person has appropriate access.<br>
Use WITHLOGIN==for all users logged in<br>
Use WITHADMIN== for administrator privledges<br>
Use WITHEMAIL== for email management access<br>
Use WITHBILLING== for billing management access<br>
Use WITHFTP== for ftp management access<br>
Use WITHWEB== for web management access<br>
Note * You can have multiple plugins per category by incrementing the plugin names (ie. WITHADMIN, WITHADMIN1, WITHADMIN2)</td></tr>
<tr><td class="prgout" align=left> <textarea name="bottomplugin" rows=10 cols=75 wrap=off>$remote{'bottomplugin'}</textarea></td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)<br>
Use %%VERSION%% to place the client version number<br>
Use %%ADMIN%% to place the admin function menu<br>
Use %%BILLING%% to place the billing function menu<br>
Use %%EMAIL%% to place the email function menu<br>
Use %%FTP%% to place the ftp function menu<br>
Use %%SSL%% to place the SSL Cert Function menu<br>
Use %%SUPPORT%% to place the support function menu<br>
Use %%WEB%% to place the website function menu<br>
Use %%DOMAIN%% to place the domain.</td></tr>
<tr><td class="prgout" align=left Valign=top>Bottom HTML (Footer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="bottom" rows=15 cols=75 wrap=off>$remote{'bottom'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Layout"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Def Client Layout">
</form>);
&Bottom;
}

##

sub Def_Client_Layout_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RMD1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='hosting' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Default Reseller Client Page Layout</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Def+Client+Layout&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Default Client Layout"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Def Client Layout">
</form>);
&Bottom;
}

##

sub Add_Reseller
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RM1'} ne "yes")){&Error('Insufficient access for this function');}
my($cipher);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($password)=&encode_base64($cipher->encrypt($FORM{'pass'}));
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id FROM reseller WHERE email='$FORM{'email'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id)=$query_output->fetchrow;
if($id){&Error("The email address, $FORM{'email'}, is already in the reseller system");}
$statement=qq(SELECT id FROM reseller WHERE domain='$FORM{'domain'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$id=$query_output->fetchrow;
if($id){&Error("The domain, $FORM{'domain'}, is already in the reseller system");}
$statement=qq(SELECT server FROM resource_list WHERE pools LIKE 
'%|$FORM{'pool'}|%'  && availdedips > 0);
if($system{'resourcemethod'} eq "float"){$statement.=qq( ORDER BY maxaccounts,maxspace,maxbandwidth ASC);}
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@servers)=$query_output->fetchrow_array;
if(!$servers[0])
	{
	&Error("A dedicated IP could not be found in the selected server pool for reseller system installation");
	}
$statement=qq(SELECT dedips FROM server WHERE id='$servers[0]');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($dedips)=$query_output->fetchrow;
my(@dedips)=split(/\n/,$dedips);
my(@availips);
my($i);
foreach(@dedips)
	{
	chomp($_);
	if($_ =~ /-/)
		{
		my($start,$stop)=split(/-/,$_);
		my(@info)=split(/\./,$start);
		for($i=$info[3];$i<=$stop;$i++)
			{
			push(@availips,"$info[0].$info[1].$info[2].$i");
			}
		}
	else
		{
		push(@availips,$_);
		}
	}
my($newavail);
for($i=1;$i<=$#availips;$i++){$newavail.=qq($availips[$i]\n);}
chomp($newavail);
$statement=qq(UPDATE server SET dedips='$newavail' WHERE id='$servers[0]');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($newip)=$availips[0];
$statement=qq(UPDATE resource_list SET availdedips=availdedips-1 WHERE server='$servers[0]');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$servers[0]');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=add+reseller&domain=$FORM{'domain'}&ip=$newip&organization=$FORM{'company'}&city=$FORM{'city'}&state=$FORM{'state'});
$command.=qq(&country=$FORM{'country'}&email=$FORM{'email'}&firstname=$FORM{'firstname'}&lastname=$FORM{'lastname'});
&Connect($ip,$port,$serverpass,$command);#create subdomain, create ssl cert, install reseller software
if($remote{'status'} ne "done")
	{
	$statement=qq(SELECT dedips FROM server WHERE id='$servers[0]');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($oldinfo)=$query_output->fetchrow;
	if($oldinfo){$oldinfo.=qq(\n$newip);}
	else{$oldinfo=$newip;}
	$statement=qq(UPDATE server SET dedips='$oldinfo' WHERE id='$servers[0]');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE resource_list SET availdedips=availdedips+1 WHERE server='$servers[0]');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	&Error($remote{'status'});
	}
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE type='ns1');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
$command=qq(do=add+record&zone=$FORM{'domain'}&name=cp&type=A&data=$newip&aux=&ttl=86400);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done")
	{
	&Error($remote{'status'});
	}
$statement=qq(SELECT name,ip,port,serverpass,dnstype FROM server WHERE type='ns2');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($dnstype);
($name,$ip,$port,$serverpass,$dnstype)=$query_output->fetchrow;
if($dnstype eq "mydns")
	{
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
	}
$statement=qq(INSERT INTO reseller (firstname,lastname,password,email,company,address1,address2,address3,city,state,zip,country,phone,fax,domain,package,pool,server,ip) VALUES
('$FORM{'firstname'}','$FORM{'lastname'}','$password','$FORM{'email'}','$FORM{'company'}','$FORM{'address1'}','$FORM{'address2'}','$FORM{'address3'}',
'$FORM{'city'}','$FORM{'state'}','$FORM{'zip'}','$FORM{'country'}','$FORM{'phone'}','$FORM{'fax'}','$FORM{'domain'}','$FORM{'pac'}','$FORM{'hpool'}','$servers[0]','$newip'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($rid)=$query_output->fetchrow;
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},'mysql',$system{'mysqlroot'},$system{'mysqlpass'});
$statement=qq(CREATE DATABASE `reseller_$rid`);
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(GRANT ALL ON reseller_$rid.* TO $system{'dbuser'}\@$system{'dbhost'} IDENTIFIED BY "$system{'dbpass'}" WITH GRANT OPTION);
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(GRANT ALL ON reseller_$rid.* TO $system{'dbuser'}\@$newip IDENTIFIED BY "$system{'dbpass'}" WITH GRANT OPTION);
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Reseller account created for $FORM{'email'}</td></tr>
</table>);
&Bottom;
}

##

sub Add_Reseller_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'RM1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT SUM(availdedips) FROM resource_list);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($dedips)=$query_output->fetchrow;
$statement=qq(SELECT id,name FROM server_pool ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT id,name FROM reseller_packages ORDER BY name ASC);
my($query_output2)=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT id,name,storage,transfer,pop,popspace,responder,mysql,subs,setup FROM reseller_packages ORDER BY name ASC);
my($query_output3)=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
if($dedips <= 0)
	{
	print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>There are no dedicated IPs available for reseller accounts.  Dedicated IPs are required for SSL certificates.</td></tr>
</table>);
	}
else
	{
	print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].firstname.value <= 0)
{
alert("fill in the first name please");
return false;
}
if(document.forms[0].lastname.value <= 0) 
{
alert("fill in the last name please");
return false;
}
if(document.forms[0].pass.value <= 0)
{
alert("fill in the password");
return false;
}
if(document.forms[0].email.value <= 0) 
{
alert("fill in the E-mail address please");
return false;
}
if(document.forms[0].pool.selectedIndex <= 0)
{
alert("Select a control panel server pool to place this reseller on.");
return false;
}
if(document.forms[0].hpool.selectedIndex <= 0)
{
alert("Select a hosted account server pool to place this reseller hosted accounts on.");
return false;
}
if(document.forms[0].domain.value <= 0)
{
alert("Enter the reseller domain that the system will be setup under.");
return false;
}
if(document.forms[0].endns.checked == true)
{
if(confirm("Enabling DNS requires that the original domain, "+document.forms[0].domain.value+", be managed by GNUHH. Continue?"))
	{
	return true;
	}
else
return false;
}
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData();">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Reseller</td></tr>
<tr><td class="prgout" align=left colspan=2>There is $dedips dedicated IP address available for reseller systems.</td></tr>
<tr><td class="prgout" align=left>First Name</td>
<td class="prgout" align=left><input name="firstname" type="text" size=30,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left>Last Name</td>
<td class="prgout" align=left><input name="lastname" type="text" size=30,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left>Password</td>
<td class="prgout" align=left><input name="pass" type="text" size=30,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left>Email Address</td>
<td class="prgout" align=left><input name="email" type="text" size=30,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left>Company</td>
<td class="prgout" align=left><input name="company" type="text" size=30,1 maxlength=100></td></tr>
<tr><td class="prgout" align=left>Address 1</td>
<td class="prgout" align=left><input name="address1" type="text" size=30,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left>Address 2</td>
<td class="prgout" align=left><input name="address2" type="text" size=30,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left>Address 3</td>
<td class="prgout" align=left><input name="address3" type="text" size=30,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left>City</td>
<td class="prgout" align=left><input name="city" type="text" size=30,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left>State</td>
<td class="prgout" align=left><input name="state" type="text" size=30,1 maxlength=50></td></tr>
<tr><td class="prgout" align=left>Zip/Postal Code</td>
<td class="prgout" align=left><input name="zip" type="text" size=20,1 maxlength=20></td></tr>
<tr><td class="prgout" align=left>Country</td>
<td class="prgout" align=left><select name="country" size=1>);
	open(FILE,"countries.dat");
	while(<FILE>)
		{
		chomp($_);
		my(@info)=split(/:/,$_);
		print qq(<option value="$info[0]");
		if($info[0] eq "us"){print qq( selected);}
		print qq(>$info[1]);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=left>Phone</td>
<td class="prgout" align=left><input name="phone" type="text" size=20,1 maxlength=20></td></tr>
<tr><td class="prgout" align=left>Fax</td>
<td class="prgout" align=left><input name="fax" type="text" size=20,1 maxlength=20></td></tr>
<tr><td class="prgout" align=left>Reseller Domain</td>
<td class="prgout" align=left><input name="domain" type="text" size=30,1 maxlength=50> Enable DNS? <input name="endns" type="checkbox" value="yes" checked></td></tr>
<tr><td class="prgout" align=left>Control Panel Server Pool</td>
<td class="prgout" align=left><select name="pool" size=1><option value="">--Select Pool--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=left>Hosted Accounts Server Pool</td>
<td class="prgout" align=left><select name="hpool" size=1><option value="">--Select Pool--);
	$query_output->dataseek();
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=left>Reseller Package</td>
<td class="prgout" align=left><select name="pac" size=1 onchange="ChgVal(this.options.selectedIndex);"><option value="">--Select Package--);
	while(($id,$name)=$query_output2->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=left valign=top>Package Description</td>
<td class="prgout" align=left><div id="desc">&nbsp;</div></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Reseller"></td></tr>
</table>
<input name="do" type="hidden" value="Add Reseller">
</form>
<script language="javascript">
<!--
function ChgVal(x)
	{
	var desc;
	if(x == 0){desc="&nbsp;";}
	else{
	desc = "Storage \$"+group[x][1]+" per Megabyte<br>";
	desc = desc+ "Transfer \$"+group[x][2]+" per Megabyte<br>";
	desc = desc+ "Pop Email Accounts \$"+group[x][3]+" each<br>";
	desc = desc+ "Pop Email Space \$"+group[x][4]+" per megabyte per account<br>";
	desc = desc+ "Email Auto Responder \$"+group[x][5]+" per account<br>";
	desc = desc+ "MySQL database \$"+group[x][6]+" per database<br>";
	desc = desc+ "Sub Domain \$"+group[x][7]+" per sub domain<br>";
	desc = desc + "Setup Fee \$"+group[x][8]+" per new account<br>";
	}
	var descdiv=document.getElementById("desc");
	descdiv.innerHTML=desc;
	}
var groups=document.forms[0].pac.options.length;
var group=new Array();
for(i=0;i<groups;i++)
group[i]=new Array();
group[0][1]=new String("");
group[0][2]=new String("");
group[0][3]=new String("");
group[0][4]=new String("");
group[0][5]=new String("");
group[0][6]=new String("");
group[0][7]=new String("");
group[0][8]=new String("");\n);
	my($i)=0;
	while(($id,$name,$storage,$transfer,$pop,$popspace,$responder,$mysql,$subs,$setup)=$query_output3->fetchrow)
		{
		$i++;
		print qq(group[$i][1]=new String("$storage");
group[$i][2]=new String("$transfer");
group[$i][3]=new String("$pop");
group[$i][4]=new String("$popspace");
group[$i][5]=new String("$responder");
group[$i][6]=new String("$mysql");
group[$i][7]=new String("$subs");
group[$i][8]=new String("$setup");\n);
		}
	print qq(// -->
</script>);
	}
&Bottom;
}

1;
