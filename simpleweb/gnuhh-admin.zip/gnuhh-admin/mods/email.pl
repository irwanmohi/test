sub Add_Access_Entry
{
if(($Cookies{'level'} ne "1")&&($access{'ADM2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=&uri_escape($FORM{$_});}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$FORM{'server'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=add+access&ident=$FORM{'ident'}&perm=$FORM{'perm'}&text=$FORM{'text'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
$FORM{'id'}=$FORM{'server'};
&Edit_Access
}

##

sub Remove_Access_Entry
{
if(($Cookies{'level'} ne "1")&&($access{'ADM2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=&uri_escape($FORM{$_});}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$FORM{'server'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=remove+access&id=$FORM{'id'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
$FORM{'id'}=$FORM{'server'};
&Edit_Access
}

##

sub Update_Access_Entry
{
if(($Cookies{'level'} ne "1")&&($access{'ADM2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=&uri_escape($FORM{$_});}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$FORM{'server'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=update+access&id=$FORM{'id'}&ident=$FORM{'ident'}&perm=$FORM{'perm'}&text=$FORM{'text'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
$FORM{'id'}=$FORM{'server'};
&Edit_Access
}

##

sub Edit_Access
{
if(($Cookies{'level'} ne "1")&&($access{'ADM2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=&uri_escape($FORM{$_});}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+access);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
my(@lines)=split(/\n/,$remote{'file'});
my($i);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=4>Edit Email Access File on $name</td></tr>
<tr><td class="headb" align=left>Identifier</td>
<td class="headb" align=left>Permission</td>
<td class="headb" align=left>Extra Text</td>
<td class="headb" align=center>Action</td></tr>\n);
foreach(@lines)
	{
	chomp($_);
	if(($_ !~ /^#/)&&($_))
		{
		my(@info)=split(/\t+/,$_);
		my($part1,$part2)=split(/:/,$info[1]);
		$part2=~s/\"//g;
		print qq(<form action="$script" method="Post">
<tr><td class="prgout" align=left><input name="ident" type="text" value="$info[0]" size=20,1 maxlength=128></td>
<td class="prgout" align=left><select name="perm" size=1><option value="OK");
if($part1 eq "OK"){print qq( selected);}
print qq(>OK<option value="RELAY");
if($part1 eq "RELAY"){print qq( selected);}
print qq(>RELAY<option value="REJECT");
if($part1 eq "REJECT"){print qq( selected);}
print qq(>REJECT<option value="ERROR");
if($part1 eq "ERROR"){print qq( selected);}
print qq(>ERROR</select></td>
<td class="prgout" align=left><input name="text" type="text" value="$part2" size=20,1 maxlength=128></td>
<td class="prgout" align=left><input name="do" type="submit" value="Update Access Entry"> * <input name="do" type="submit" value="Remove Access Entry"><input name="id" type="hidden" value="$i"><input name="server" type="hidden" value="$FORM{'id'}"></td></tr>
</form>\n);
		}
	$i++;
	}
print qq(<form action="$script" method="Post">
<tr><td class="prgout" align=left><input name="ident" type="text" size=20,1 maxlength=128></td>
<td class="prgout" align=left><select name="perm" size=1><option value="OK">OK<option value="RELAY">RELAY<option value="REJECT">REJECT<option value="ERROR">ERROR</select></td>
<td class="prgout" align=left><input name="text" type="text" size=20,1 maxlength=128></td>
<td class="prgout" align=left><input name="do" type="submit" value="Add Access Entry"><input name="server" type="hidden" value="$FORM{'id'}"></td></tr>
</form>
</table>);
&Bottom;
}

##

sub Edit_Access_Select
{
if(($Cookies{'level'} ne "1")&&($access{'ADM2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=&uri_escape($FORM{$_});}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE (type='hosting' && useemail='local') || (type='mail'));
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Email Access File</td></tr>
<tr><td class="prgout" align=left valign=top>Server</td>\n);
if($count > 10)
	{
	print qq(<td class="prgout" align=left><select name="id" size=1>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Access File"></td></tr>);
	}
else
	{
	print qq(<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Edit+Access&id=$id" class="prgout class="prgout"">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Edit Access">
</form>);
&Bottom;
}

1;
