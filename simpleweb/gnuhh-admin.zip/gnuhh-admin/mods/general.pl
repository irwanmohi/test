sub Search_Action_Log
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'AI1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT COUNT(id) FROM actionlog);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($rowcount)=$query_output->fetchrow;
$statement=qq(SELECT action,adate,admin,comments FROM actionlog WHERE action LIKE '%$FORM{'domain'}%');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($last);
if($FORM{'num'}+10 < $rowcount){$last=$FORM{'num'}+10;}
else{$last=$rowcount;}
my($action,$adate,$admin,$comments);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=4>Administration Action Log</td></tr>
<tr><td class="headb" align=left>Action</td>
<td class="headb" align=left>Date</td>
<td class="headb" align=left>Administrator</td>
<td class="headb" align=left>Comments</td></tr>\n);
while(($action,$adate,$admin,$comments)=$query_output->fetchrow)
	{
	print qq(<tr><td class="prgout" align=left>$action</td>
<td class="prgout" align=left>$adate</td>
<td class="prgout" align=left>$admin</td>
<td class="prgout" align=left>$comments</td></tr>\n);
	}
print qq(<tr><td class="prgout" align=center colspan=4>Showing ).($FORM{'num'}+1).qq( - $last of $rowcount entries</td></tr>
<tr><td class="prgout" align=center colspan=4>Domain Search: <input name="domain" type="text" value="$FORM{'domain'}" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=4><input type="submit" value="Search"></td></tr>
</table>
<input name="do" type="hidden" value="Search Action Log">
</form>);
&Bottom;
}

##

sub Install_Filecheck
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SC5'} ne "yes")){&Error('Insufficient access for this function');}
my($perlpath)=$^X;
open(FILE,">filecheck.cgi");
print FILE qq(#!$perlpath
use vars qw/\$Version \%system \$logfile \$cgipath/;
\$logfile="$FORM{'logfile'}";
\$cgipath="$system{'cgipath'}";\n);
open(TMP,"filecheck.txt");
while(<TMP>)
	{
	print FILE $_;
	}
close(TMP);
close(FILE);
chmod(0755,"filecheck.cgi");
my(@info)=qx|crontab -l|;
open(TMP,">crontab.tmp");
foreach(@info)
	{
	if($_ !~ m|$system{'cgipath'}/filecheck.cgi$|)
		{
		print TMP $_;
		}
	}
print TMP "0 */4 * * * $system{'cgipath'}/filecheck.cgi\n";
close(TMP);
qx|crontab crontab.tmp|;
unlink("crontab.tmp");
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Filecheck monitor installed</td></tr>
</table>);
&Bottom;
}

##

sub Install_Filecheck_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SC5'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Install Services Monitor</td></tr>
<tr><td class="prgout" align=left>Log File</td>
<td class="prgout" align=left><input name="logfile" type="text" value="$system{'cgipath'}/filecheck.log" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Install Filecheck Monitor"></td></tr>
</table>
<input name="do" type="hidden" value="Install Filecheck">
</form>);
&Bottom;
}

##

sub View_Trans
{
&Check_Password;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM transaction WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@info)=$query_output->fetchrow_array;
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($info[1]);
$mon++;$year+=1900;
if(length($min)==1){$min="0".$min;}
my($ampm)="AM";
if($hour > 12){$hour-=12;$ampm="PM";}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Online Transaction Results</td></tr>
<tr><td class="prgout" align=left>Date</td>
<td class="prgout" align=left>$mon-$mday-$year $hour:$min $ampm</td></tr>
<tr><td class="prgout" align=left>Status Text</td>
<td class="prgout" align=left>$info[3]</td></tr>
<tr><td class="prgout" align=left>Amount</td>
<td class="prgout" align=left>\$$info[13]</td></tr>
<tr><td class="prgout" align=left>Description</td>
<td class="prgout" align=left>$info[14]</td></tr>
</table>);
&Bottom;
}

##

sub Monitor
{
&Get_Cookie('admin');
my(%pending,%out,$x,@servers);
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT COUNT(id) FROM ticket WHERE rtime='0000-00-00 00:00:00' && status='in');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($pending)=$query_output->fetchrow;
$statement=qq(SELECT COUNT(id) FROM ticket WHERE status='out' && rtime='0000-00-00 00:00:00');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($out)=$query_output->fetchrow;
$|=1;
print "Content-type:  text/html\r\n\r\n";
print qq(<html>
<head>
<title>Service Ticket Monitor - );
if($pending > 0){print qq(Pending Tickets);}
else{print qq(No Pending Tickets);}
print qq(</title>
<base target="main">
<meta http-equiv="Pragma" Content="no-cache">
<meta content="300;url=$script?do=monitor" http-equiv="Refresh">
<style type="text/css">
<!--
.bodytext {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
td {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
// -->
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#0000FF" vlink="#0000FF" alink="#FF0000">
<table align=center border=0 cellpadding=0 cellspacing=0 width=80% bgcolor="#000000">
<tr bgcolor="#000000"><td bgcolor="#000000">
<table align=center border=0 cellpadding=4 cellspacing=1 width=100% bgcolor="#FFFFFF">
<tr><td align=left><B>Pending</B></td>
<td align=left><B>Out</B></td></tr>
<tr><td align=left>$pending</td>
<td align=left>$out</td></tr>
</table>
</td></tr></table>
<center><a href="" onClick="window.close();return false;" class="prgout">Close Monitor</a></center>\n);
if($pending)
	{
	print qq(<script language="javascript">
<!--
focus();
opener.window.status='Pending Tickets';
//-->
</script>\n);
	}
print qq(</body></html>);
exit;
}

##

sub Monitor_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MF1'} ne "yes")){&Error('Insufficient access for this function');}
&Set_Cookies('admin',$Cookies{'auser'});
$|=1;
print "Content-type:  text/html\r\n\r\n";
print qq(<html>
<head>
<base target="main">
<meta http-equiv="Pragma" Content="no-cache">
<meta content="5;url=$script?do=monitor" http-equiv="Refresh">
<style type="text/css">
<!--
.bodytext {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
td {  font-family: arial,helvetica,verdana,geneva; font-size: 10pt}
// -->
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#0000FF" vlink="#0000FF" alink="#FF0000" onLoad="opener.focus();">
<center>Starting Ticket Monitor</center>
</body></html>);
exit;
}

##

sub Install_Monitor
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'Smon2'} ne "yes")){&Error('Insufficient access for this function');}
my($perlpath)=$^X;
open(FILE,">monitor.cgi");
print FILE qq(#!$perlpath
use vars qw/\$Version \%system \$logfile \$cgipath/;
\$logfile="$FORM{'logfile'}";
\$cgipath="$system{'cgipath'}";\n);
open(TMP,"monitor.txt");
while(<TMP>)
	{
	print FILE $_;
	}
close(TMP);
close(FILE);
chmod(0755,"monitor.cgi");
my(@info)=qx|crontab -l|;
open(TMP,">crontab.tmp");
foreach(@info)
	{
	if($_ !~ m|$system{'cgipath'}/monitor.cgi$|)
		{
		print TMP $_;
		}
	}
print TMP "*/5 * * * * $system{'cgipath'}/monitor.cgi\n";
close(TMP);
qx|crontab crontab.tmp|;
unlink("crontab.tmp");
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Services monitor installed</td></tr>
</table>);
&Bottom;
}

##

sub Install_Monitor_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'Smon2'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Install Services Monitor</td></tr>
<tr><td class="prgout" align=left>Log File</td>
<td class="prgout" align=left><input name="logfile" type="text" value="$system{'cgipath'}/monitor.log" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Install Monitor"></td></tr>
</table>
<input name="do" type="hidden" value="Install Monitor">
</form>);
&Bottom;
}

##

sub Complete_Daemon_History
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'Smon1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,type FROM server WHERE id='$FORM{'server'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($server,$ip,$type)=$query_output->fetchrow;
$statement=qq(SELECT stamp,$FORM{'daemon'} FROM monitor WHERE server='$FORM{'server'}' ORDER BY stamp DESC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($start,$current)=$query_output->fetchrow;
my($stamp,$status,$endstamp);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=3>Service Monitor</td></tr>
<tr><td class="heada" align=left colspan=3>$server - $ip - $type - $FORM{'daemon'} History</td></tr>
<tr><td class="headb" align=left>Date</td>
<td class="headb" align=left>Status</td>
<td class="headb" align=left>Duration</td></tr>);
while(($stamp,$status)=$query_output->fetchrow)
	{
	if($current ne $status)
		{
		use Time::Local;
		my($date,$time)=split(/ /,$start);
		my($year,$mon,$day)=split(/-/,$date);
		my($hour,$min,$sec)=split(/:/,$time);
		my($starttime)=timelocal($sec,$min,$hour,$day,$mon,$year);
		($date,$time)=split(/ /,$stamp);
		($year,$mon,$day)=split(/-/,$date);
		($hour,$min,$sec)=split(/:/,$time);
		my($finishtime)=timelocal($sec,$min,$hour,$day,$mon,$year);
		my($totaltime)=$starttime-$finishtime;
		print qq(<tr><td class="prgout" align=left>$stamp</td>
<td class="prgout" align=left>$current</td>
<td class="prgout" align=left>);
if($totaltime > 31556736){print sprintf("%.2f",($totaltime/31556736))." years";}
if(($totaltime < 31556736)&&($totaltime > 86400)){print sprintf("%.2f",($totaltime/86400))." days";}
if(($totaltime < 86400)&&($totaltime > 3600)){print sprintf("%.2f",($totaltime/3600))." hours";}
if(($totaltime < 3600)&&($totaltime > 60)){print sprintf("%.2f",($totaltime/60))." minutes";}
if($totaltime < 60){print sprintf("%.2f",($totaltime))." seconds";}
print qq(</td></tr>\n);
		$start=$stamp;$current=$status;
		}
	$endstamp=$stamp;
	}
use Time::Local;
my($date,$time)=split(/ /,$start);
my($year,$mon,$day)=split(/-/,$date);
my($hour,$min,$sec)=split(/:/,$time);
my($starttime)=timelocal($sec,$min,$hour,$day,$mon,$year);
($date,$time)=split(/ /,$endstamp);
($year,$mon,$day)=split(/-/,$date);
($hour,$min,$sec)=split(/:/,$time);
my($finishtime)=timelocal($sec,$min,$hour,$day,$mon,$year);
my($totaltime)=$starttime-$finishtime;
print qq(<tr><td class="prgout" align=left>$endstamp</td>
<td class="prgout" align=left>$current</td>
<td class="prgout" align=left>);
if($totaltime > 31556736){print sprintf("%.2f",($totaltime/31556736))." years";}
if(($totaltime < 31556736)&&($totaltime > 86400)){print sprintf("%.2f",($totaltime/86400))." days";}
if(($totaltime < 86400)&&($totaltime > 3600)){print sprintf("%.2f",($totaltime/3600))." hours";}
if(($totaltime < 3600)&&($totaltime > 60)){print sprintf("%.2f",($totaltime/60))." minutes";}
if($totaltime < 60){print sprintf("%.2f",($totaltime))." seconds";}
print qq(</td></tr>\n);

print qq(</table>);
&Bottom;
}

##

sub Daemon_History
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'Smon1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT server.name,server.ip,server.type,monitor.$FORM{'daemon'}comment FROM server,monitor WHERE server.id=monitor.server && server='$FORM{'server'}' ORDER BY stamp DESC LIMIT 0,1);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($server,$ip,$type,$comments)=$query_output->fetchrow;
$comments=~s/\n/<br>\n/g;
$statement=qq(SELECT stamp,$FORM{'daemon'} FROM monitor WHERE server='$FORM{'server'}' ORDER BY stamp DESC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($start,$current)=$query_output->fetchrow;
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($stamp,$daemon,$finish);
while(($stamp,$daemon)=$query_output->fetchrow)
	{
	if($current ne $daemon)
		{
		$finish=$stamp;
		last;
		}
	$finish=$stamp;
	}
use Time::Local;
my($date,$time)=split(/ /,$start);
my($year,$mon,$day)=split(/-/,$date);
my($hour,$min,$sec)=split(/:/,$time);
my($starttime)=timelocal($sec,$min,$hour,$day,$mon,$year);
($date,$time)=split(/ /,$finish);
($year,$mon,$day)=split(/-/,$date);
($hour,$min,$sec)=split(/:/,$time);
my($finishtime)=timelocal($sec,$min,$hour,$day,$mon,$year);
my($totaltime)=$starttime-$finishtime;

&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Service Monitor</td></tr>
<tr><td class="heada" align=center>$server - $ip - $type</td></tr>
<tr><td class="headb" align=left><img src="$system{'imageurl'}/$current.gif" width=10 height=10 border=0> $FORM{'daemon'}</td></tr>
<tr><td class="prgout" align=left>$comments</td></tr>
<tr><td class="prgout" align=left>This has been $current for );
if($totaltime > 31556736){print sprintf("%.2f",($totaltime/31556736))." years";}
if(($totaltime < 31556736)&&($totaltime > 86400)){print sprintf("%.2f",($totaltime/86400))." days";}
if(($totaltime < 86400)&&($totaltime > 3600)){print sprintf("%.2f",($totaltime/3600))." hours";}
if(($totaltime < 3600)&&($totaltime > 60)){print sprintf("%.2f",($totaltime/60))." minutes";}
if($totaltime < 60){print sprintf("%.2f",($totaltime))." seconds";}
print qq(</td></tr>
<tr><td class="prgout" align=center><a href="$script?do=complete+daemon+history&daemon=$FORM{'daemon'}&server=$FORM{'server'}" class="prgout">History</a></td></tr>
</table>);
&Bottom;
}

##

sub Server_Monitor
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'Smon1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,type,name,ip FROM server ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$type,$name,$ip);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=10>Server Monitor<br>
<img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0> - UP <img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0> - DOWN <img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0> - Not Used</td></tr>
<tr><td class="headb" align=left>Conn</td>
<td class="headb" align=left>http</td>
<td class="headb" align=left>https</td>
<td class="headb" align=left>MySQL</td>
<td class="headb" align=left>ftp</td>
<td class="headb" align=left>smtp</td>
<td class="headb" align=left>pop3</td>
<td class="headb" align=left>imap</td>
<td class="headb" align=left>dns</td>
<td class="headb" align=left>ssh</td></tr>\n);
while(($id,$type,$name,$ip)=$query_output->fetchrow)
	{
	$statement=qq(SELECT stamp,conn,http,https,mysql,ftp,smtp,pop3,imap,dns,ssh FROM monitor WHERE server='$id' ORDER BY stamp DESC LIMIT 0,1);
	my($query_output2)=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($stamp,$conn,$http,$https,$mysql,$ftp,$smtp,$pop3,$imap,$dns,$ssh)=$query_output2->fetchrow;
	print qq(<tr><td class="headb" align=left colspan=10>$name - $ip - $type server - $stamp</td></tr>
<tr><td class="prgout" align=left>);
	if($conn eq "up"){print qq(<a href="$script?do=daemon+history&daemon=conn&server=$id" class="prgout"><img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0></a>);}
	elsif($conn eq "down"){print qq(<a href="$script?do=daemon+history&daemon=conn&server=$id" class="prgout"><img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0></a>);}
	else{print qq(<img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0>);}
	print qq(</td>
<td class="prgout" align=left>);
	if($http eq "up"){print qq(<a href="$script?do=daemon+history&daemon=http&server=$id" class="prgout"><img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0></a>);}
	elsif($http eq "down"){print qq(<a href="$script?do=daemon+history&daemon=http&server=$id" class="prgout"><img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0></a>);}
	else{print qq(<img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0>);}
	print qq(</td>
<td class="prgout" align=left>);
	if($https eq "up"){print qq(<a href="$script?do=daemon+history&daemon=https&server=$id" class="prgout"><img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0></a>);}
	elsif($https eq "down"){print qq(<a href="$script?do=daemon+history&daemon=https&server=$id" class="prgout"><img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0></a>);}
	else{print qq(<img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0>);}
	print qq(</td>
<td class="prgout" align=left>);
	if($mysql eq "up"){print qq(<a href="$script?do=daemon+history&daemon=mysql&server=$id" class="prgout"><img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0></a>);}
	elsif($mysql eq "down"){print qq(<a href="$script?do=daemon+history&daemon=mysql&server=$id" class="prgout"><img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0></a>);}
	else{print qq(<img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0>);}
	print qq(</td>
<td class="prgout" align=left>);
	if($ftp eq "up"){print qq(<a href="$script?do=daemon+history&daemon=ftp&server=$id" class="prgout"><img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0></a>);}
	elsif($ftp eq "down"){print qq(<a href="$script?do=daemon+history&daemon=ftp&server=$id" class="prgout"><img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0></a>);}
	else{print qq(<img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0>);}
	print qq(</td>
<td class="prgout" align=left>);
	if($smtp eq "up"){print qq(<a href="$script?do=daemon+history&daemon=smtp&server=$id" class="prgout"><img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0></a>);}
	elsif($smtp eq "down"){print qq(<a href="$script?do=daemon+history&daemon=smtp&server=$id" class="prgout"><img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0></a>);}
	else{print qq(<img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0>);}
	print qq(</td>
<td class="prgout" align=left>);
	if($pop3 eq "up"){print qq(<a href="$script?do=daemon+history&daemon=pop3&server=$id" class="prgout"><img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0></a>);}
	elsif($pop3 eq "down"){print qq(<a href="$script?do=daemon+history&daemon=pop3&server=$id" class="prgout"><img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0></a>);}
	else{print qq(<img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0>);}
	print qq(</td>
<td class="prgout" align=left>);
	if($imap eq "up"){print qq(<a href="$script?do=daemon+history&daemon=imap&server=$id" class="prgout"><img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0></a>);}
	elsif($imap eq "down"){print qq(<a href="$script?do=daemon+history&daemon=imap&server=$id" class="prgout"><img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0></a>);}
	else{print qq(<img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0>);}
	print qq(</td>
<td class="prgout" align=left>);
	if($dns eq "up"){print qq(<a href="$script?do=daemon+history&daemon=dns&server=$id" class="prgout"><img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0></a>);}
	elsif($dns eq "down"){print qq(<a href="$script?do=daemon+history&daemon=dns&server=$id" class="prgout"><img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0></a>);}
	else{print qq(<img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0>);}
	print qq(</td>
<td class="prgout" align=left>);
	if($ssh eq "up"){print qq(<a href="$script?do=daemon+history&daemon=ssh&server=$id" class="prgout"><img src="$system{'imageurl'}/up.gif" width=10 height=10 border=0></a>);}
	elsif($ssh eq "down"){print qq(<a href="$script?do=daemon+history&daemon=ssh&server=$id" class="prgout"><img src="$system{'imageurl'}/down.gif" width=10 height=10 border=0></a>);}
	else{print qq(<img src="$system{'imageurl'}/na.gif" width=10 height=10 border=0>);}
	print qq(</td></tr>\n);
	}
print qq(</table>);
&Bottom;
}

##

sub Bandwidth
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'AI4'} ne "yes")){&Error('Insufficient access for this function');}
my(@months)=('','January','February','March','April','May','June','July','August','September','October','November','December');
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain,server,transfer FROM domain_map WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain,$server,$transfer)=$query_output->fetchrow;
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$server');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=domain+bandwidth&domain=$domain&transfer=$transfer);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
my(@usage)=split(/:/,$remote{'usage'});
my($transext)="G";
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=4>Bandwidth usage for $domain</td></tr>
<tr><td class="headb" align=left>Month</td>
<td class="headb" align=left>Account Bandwidth</td>
<td class="headb" align=left>Bandwidth Used</td>
<td class="headb" align=left>Bandwidth Exceeded By</td></tr>\n);
foreach(@usage)
	{
	my(@info)=split(/\|/,$_);
	print qq(<tr><td class="prgout" align=left>$months[$info[0]] $info[1]</td>
<td class="prgout" align=left>$transfer$transext</td>
<td class="prgout" align=left>$info[2]</td>
<td class="prgout" align=left>$info[3]</td></tr>\n);
	}
print qq(</table>\n);
&Bottom;
}

##

sub Bandwidth2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'AI4'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE domain LIKE '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Show Bandwidth Usage</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<option value="$id">$domain);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Show Bandwidth"></td></tr>
</table>
<input name="do" type="hidden" value="Bandwidth">
</form>);
&Bottom;
}

##

sub Bandwidth_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'AI4'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Bandwidth";
var Extra="id";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Show Bandwidth Usage</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Bandwidth2">
</form>
<div id="dlist" style="position:absolute;display:none;visibility:hide;"></div>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Disk_Quota
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'AI3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT domain,server,storage FROM domain_map WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($domain,$server,$storage)=$query_output->fetchrow;
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$server');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+quota&domain=$domain);
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
my(@info)=split(/\s+/,$remote{'quota'});
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Disk Quota Report for $domain</td></tr>
<tr><td class="headb" align=left>Used</td>
<td class="headb" align=left>Quota</td></tr>
<tr><td class="prgout" align=left>$remote{'quota'}</td>
<td class="prgout" align=left>).($storage*1024).qq(</td></tr>
</table>);
&Bottom;
}

##

sub Disk_Quota2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'AI3'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'domain'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,domain FROM domain_map WHERE domain LIKE '$FORM{'domain'}' && reseller='0' ORDER BY domain ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$domain);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select domain");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Disk Quota Report</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Domain--);
while(($id,$domain)=$query_output->fetchrow)
	{
	print qq(<option value="$id">$domain);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Show Quota Report"></td></tr>
</table>
<input name="do" type="hidden" value="Disk Quota">
</form>);
&Bottom;
}

##

sub Disk_Quota_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'AI3'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Disk Quota";
var Extra="id";
// -->
</script>
<script language="javascript" src="$script?do=prefetch+js"></script><form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Disk Quota Report</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="domain" type="text" size=50,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Disk Quota2">
</form>
<div id="dlist" style="position:absolute;display:none;visibility:hide;"></div>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

##

sub Search
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'AI2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
$FORM{'sterm'}=~s/\*/\%/g;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=5>Search Results</td></tr>\n);
if($FORM{'user'} eq "yes")
	{
	print qq(<tr><td class="headb" align=center colspan=5>User Accounts</td></tr>
<tr><td colspan=2 class="headb" align=left>Name</td>
<td class="headb" align=left>Email Address</td>
<td class="headb" align=left colspan=2>Company</td></tr>\n);
	$statement=qq(SELECT firstname,lastname,email,company FROM user WHERE firstname LIKE '%$FORM{'sterm'}%' || lastname LIKE '%$FORM{'sterm'}%' || email LIKE '%$FORM{'sterm'}%' || company LIKE '%$FORM{'sterm'}%');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($firstname,$lastname,$email,$company);
	while(($firstname,$lastname,$email,$company)=$query_output->fetchrow)
		{
		print qq(<tr><td colspan=2 class="prgout" align=left>$firstname $lastname</td>
<td class="prgout" align=left><a href="mailto:$email" class="prgout">$email</a></td>
<td class="prgout" align=left colspan=2>$company</td></tr>\n);
		}
	}
if($FORM{'domain'} eq "yes")
	{
	print qq(<tr><td class="headb" align=center colspan=5>Domain Accounts</td></tr>
<tr><td class="headb" align=left>domain</td>
<td class="headb" align=left>Name</td>
<td class="headb" align=left>Email Address</td>
<td class="headb" align=left>Company</td>
<td class="headb" align=left>LOGIN</td></tr>\n);
	$statement=qq(SELECT user.email,user.password,user.firstname,user.lastname,user.company,domain_map.domain,domain_map.id FROM user,domain_map,user_map WHERE (user.email LIKE '%$FORM{'sterm'}%' && user_map.user=user.id && domain_map.id=user_map.domain && domain_map.reseller='0') || (domain_map.domain LIKE '%$FORM{'sterm'}%' && user_map.user=user.id && domain_map.id=user_map.domain && domain_map.reseller='0')
|| (user.firstname LIKE '%$FORM{'sterm'}%' && user_map.user=user.id && domain_map.id=user_map.domain && domain_map.reseller='0') || (user.lastname LIKE '%$FORM{'sterm'}%' && user_map.user=user.id && domain_map.id=user_map.domain && domain_map.reseller='0') || (user.company LIKE '%$FORM{'sterm'}%' && user_map.user=user.id && domain_map.id=user_map.domain && domain_map.reseller='0'));
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($cipher);
	my($email,$password,$firstname,$lastname,$company,$domain,$id);
	while(($email,$password,$firstname,$lastname,$company,$domain,$id)=$query_output->fetchrow)
		{
		if(&decode_base64($password) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$password=$cipher->decrypt(&decode_base64($password));
		print qq(<tr><td class="prgout" align=left>$domain</td>
<td class="prgout" align=left>$firstname $lastname</td>
<td class="prgout" align=left>$email</td>
<td class="prgout" align=left>$company</td>
<td class="prgout" align=left><form action="$system{'clienturl'}" method="Post"><input name="do" type="submit" value="Log In"><input name="email" type="hidden" value="$email"><input name="pass" type="hidden" value="$password"><input name="domain" type="hidden" value="$domain"><input name="domid" type="hidden" value="$id"></form></td></tr>\n);
		}
	}
print qq(</table>\n);
&Bottom;
}

##

sub Search_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'AI2'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Search Account Information</td></tr>
<tr><td class="prgout" align=left>Search Term</td>
<td class="prgout" align=left><input name="sterm" type="text" size=40,1></td></tr>
<tr><td class="prgout" align=left colspan=2>Use * as a wild card entry.<br>ie abc* for everything starting with abc</td></tr>
<tr><td class="prgout" align=left>Output Information</td>
<td class="prgout" align=left><input name="user" type="checkbox" value="yes" checked> Usernames <input name="domain" type="checkbox" value="yes" checked> Domains</td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Search"></td></tr>
</table>
<input name="do" type="hidden" value="Search">
</form>\n);
&Bottom;
}

##

sub View_Action_Log
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'AI1'} ne "yes")){&Error('Insufficient access for this function');}
if(!$FORM{'num'}){$FORM{'num'}=0;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT COUNT(id) FROM actionlog);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($rowcount)=$query_output->fetchrow;
$statement=qq(SELECT action,adate,admin,comments FROM actionlog ORDER BY id DESC LIMIT $FORM{'num'},10);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($last);
if($FORM{'num'}+10 < $rowcount){$last=$FORM{'num'}+10;}
else{$last=$rowcount;}
my($action,$adate,$admin,$comments);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=4>Administration Action Log</td></tr>
<tr><td class="headb" align=left>Action</td>
<td class="headb" align=left>Date</td>
<td class="headb" align=left>Administrator</td>
<td class="headb" align=left>Comments</td></tr>\n);
while(($action,$adate,$admin,$comments)=$query_output->fetchrow)
	{
	print qq(<tr><td class="prgout" align=left>$action</td>
<td class="prgout" align=left>$adate</td>
<td class="prgout" align=left>$admin</td>
<td class="prgout" align=left>$comments</td></tr>\n);
	}
print qq(<tr><td class="prgout" align=center colspan=4>Showing ).($FORM{'num'}+1).qq( - $last of $rowcount entries</td></tr>\n);
if(($FORM{'num'} > 0)||($last < $rowcount))
	{
	print qq(<tr>);
	if($FORM{'num'} > 0)
		{
		my($prev)=$FORM{'num'}-10;
		print qq(<td class="prgout" align=left colspan=2><a href="$script?do=action+log&num=$prev" class="prgout">Previous</a></td>\n);
		}
	else{print qq(<td class="prgout" colspan=2>&nbsp;</td>\n);}
	if($last < $rowcount)
		{
		my($next)=$FORM{'num'}+10;
		print qq(<td class="prgout" align=right colspan=2><a href="$script?do=action+log&num=$next" class="prgout">Next</a></td>\n);
		}
	else{print qq(<td class="prgout" colspan=2>&nbsp;</td>\n);}
	print qq(</tr>\n);
	}
print qq(<tr><td class="prgout" align=center colspan=4>Domain Search: <input name="domain" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=4><input type="submit" value="Search"></td></tr>
</table>
<input name="do" type="hidden" value="Search Action Log">
</form>);
&Bottom;
}

##

sub Select_Server_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SS'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name,type FROM server ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name,$type);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a server to manage");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Select Server</td></tr>
<tr><td class="prgout" align=left Valign=top>Server</td>\n);
if($count > 10)
	{
	print qq(<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name,$type)=$query_output->fetchrow)
		{
		if(($type eq "primary")||($type eq "secondary")){$type=$type." nameserver";}
		print qq(<option value="$id">$name ($type));
		}
	print qq(</select></td></tr>
	<tr><td class="prgout" align=center colspan=2><input type="submit" value="Select Server"></td></tr>\n);
	}
else
	{
	print qq(<td class="prgout" align=left>);
	while(($id,$name,$type)=$query_output->fetchrow)
		{
		if(($type eq "primary")||($type eq "secondary")){$type=$type." nameserver";}
		print qq(<a href="$script?do=Select+Server&id=$id" class="prgout">$name</a> ($type)<br>\n);
		}
	print qq(</td>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Select Server">
</form>\n);
&Bottom;
}

##

sub Select_Server
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SS'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name)=$query_output->fetchrow;
&Set_Cookies('serverid',$FORM{'id'},'server',$name);
$Cookies{'serverid'}=$FORM{'id'};
$Cookies{'server'}=$name;
&Start;
}

##

sub Change_Pass
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MF2'} ne "yes")){&Error('Insufficient access for this function');}
my(@info,$i);
if($FORM{'pass'} ne $Cookies{'apass'})
	{
	&Error('Password submitted does not match password on file');
	}
my(@saltchars,$pass,$salt);
@saltchars=('a'..'z','A'..'Z','0'..'9','.','/');
srand($$|time);
for($i=1;$i<=8;$i++)
	{
	$salt.=$saltchars[int(rand($#saltchars+1))];
	}
$salt='$1$'.$salt.'$';
$pass=crypt($FORM{'pass1'},$salt);
open(TEMP,">temp.dat");
open(FILE,"system.dat");
while(<FILE>)
	{
	@info=split(/:/,$_);
	if($info[0] ne $Cookies{'auser'})
		{
		print TEMP $_;
		}
	else
		{
		print TEMP qq($info[0]:$pass:$info[2]:\n);
		}
	}
close(TEMP);
close(FILE);
unlink("$system{'cgipath'}/system.dat");
qx|mv $system{'cgipath'}/temp.dat $system{'cgipath'}/system.dat|;
$Cookies{'apass'}=$FORM{'pass1'};
&Set_Cookies('apass',$FORM{'pass1'});
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Password changed</td></tr>
</table>);
&Bottom;
}

##

sub Change_Pass_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MF2'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
function chkData() {
if(document.forms[0].pass1.value <= 0)
{
alert("New password required");
return false;
}
if(document.forms[0].pass1.value != document.forms[0].pass2.value) 
{
alert("New password and confirm password do not match");
return false;
}
else
return true;
}
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Change Password</td></tr>
<tr><td class="prgout" align=left>Old Password</td>
<td class="prgout" align=left><input name="pass" type="password" size=10,1></td></tr>
<tr><td class="prgout" align=left>New Password</td>
<td class="prgout" align=left><input name="pass1" type="password" size=10,1></td></tr>
<tr><td class="prgout" align=left>Confirm Password</td>
<td class="prgout" align=left><input name="pass2" type="password" size=10,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Change Password"></td></tr>
</table>
<input name="do" type="hidden" value="Change Pass">
</form>\n);
&Bottom;
}

##

sub View_Logins
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MF3'} ne "yes")){&Error('Insufficient access for this function');}
if(!$FORM{'num'}){$FORM{'num'}=0;}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT COUNT(id) FROM adminlog);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($rowcount)=$query_output->fetchrow;
my($last);
if($FORM{'num'}+10 < $rowcount){$last=$FORM{'num'}+10;}
else{$last=$rowcount;}
$statement=qq(SELECT username,ip,adate,success FROM adminlog ORDER BY id DESC LIMIT $FORM{'num'},10);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($username,$ip,$adate,$success);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=4>View Login Log</td></tr>
<tr><td class="heada" align=left>Username</td>
<td class="heada" align=left>Remote IP</td>
<td class="heada" align=left>Time-Date</td>
<td class="heada" align=left>Status</td></tr>\n);
while(($username,$ip,$adate,$success)=$query_output->fetchrow)
	{
	my(@months)=('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($adate);
	$year+=1900;
	my($ampm)="am";
	if($hour == 0){$hour=12;}
	if($hour > 12){$hour-=12;$ampm="pm";}
	if(length($min)==1){$min="0".$min;}
	my($time)="$hour:$min $ampm $months[$mon] $mday, $year";
	print qq(<tr><td class="prgout" align=left>$username</td>
<td class="prgout" align=left>$ip</td>
<td class="prgout" align=left>$time</td>
<td class="prgout" align=left>);
	if($success eq "Y"){print qq(Successful);}
	else{print qq(Failed);}
	print qq(</td></tr>\n);
	}
print qq(<tr><td class="prgout" align=center colspan=4>Showing ).($FORM{'num'}+1).qq( - $last of $rowcount entries</td></tr>\n);
if(($FORM{'num'} > 0)||($last < $rowcount))
	{
	print qq(<tr>);
	if($FORM{'num'} > 0)
		{
		my($prev)=$FORM{'num'}-10;
		print qq(<td class="prgout" align=left colspan=2><a href="$script?do=view+logins&num=$prev" class="prgout">Previous</a></td>\n);
		}
	else{print qq(<td class="prgout" colspan=2>&nbsp;</td>\n);}
	if($last < $rowcount)
		{
		my($next)=$FORM{'num'}+10;
		print qq(<td class="prgout" align=right colspan=2><a href="$script?do=view+logins&num=$next" class="prgout">Next</a></td>\n);
		}
	else{print qq(<td class="prgout" colspan=2>&nbsp;</td>\n);}
	print qq(</tr>\n);
	}
print qq(</table>\n);
&Bottom;
}

1;
