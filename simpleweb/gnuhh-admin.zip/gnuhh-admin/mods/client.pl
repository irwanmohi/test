use Net::SSH::Perl;

##

sub Sync_Clients
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI16'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port)=$query_output->fetchrow;
&Connect($ip,$port,$system{'enckey'},"do=get+all+layouts");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$statement=qq(SELECT ip,port FROM server WHERE type='client' && id != '$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
foreach (keys %remote){$remote{$_}=&uri_escape($remote{$_});}
my($command)=qq(do=set+all+layouts&invoice=$remote{'invoice'}&top=$remote{'top'}&bottom=$remote{'bottom'}&front=$remote{'front'}&admin=$remote{'admin'});
$command.=qq(&billing=$remote{'billing'}&email=$remote{'email'}&ftp=$remote{'ftp'}&`ssl`=$remote{'ssl'}&support=$remote{'support'}&web=$remote{'web'}&plugins=$remote{'plugin'});
while(($ip,$port)=$query_output->fetchrow)
	{
	&Connect($ip,$port,$system{'enckey'},$command);
	if($remote{'status'} ne "done"){&Error($remote{'status'});}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Syncronize Client Layouts</td></tr>
<tr><td class="prgout" align=left>All client servers have been syncronized.</td></tr>
</table>);
&Bottom;
}

##

sub Sync_Clients_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI16'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<script language="javascript">
<!--
function ConFirm(x)
{
if(x == undefined)
	{
	x=document.forms[0].id.options[document.forms[0].id.selectedIndex].text;
	}
if(confirm("Do you want to syncronize against this client server? - "+x))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<form action="$script" method="Post" onSubmit="return ConFirm()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Syncronize Client Interface Layouts</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server to sync against</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Sync+Clients&id=$id" onClick="return ConFirm('$name');" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server to sync against</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Syncronize Clients"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Sync Clients">
</form>);
&Bottom;
}

##

sub Save_Client_Invoice
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI15'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port)=$query_output->fetchrow;
$FORM{'invoice'}=&uri_escape($FORM{'invoice'});
&Connect($ip,$port,$system{'enckey'},"do=save+invoice&invoice=$FORM{'invoice'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Client invoice updated</td></tr>
</table>);
&Bottom;
}

##

sub Client_Invoice
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI15'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port)=$query_output->fetchrow;
&Connect($ip,$port,$system{'enckey'},"do=get+invoice");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'invoice'}=~s/\&/&amp;/g;
$remote{'invoice'}=~s/"/&quot;/g;
$remote{'invoice'}=~s/</&lt;/g;
$remote{'invoice'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface Invoice $name</td></tr>
<tr><td class="prgout" align=left>Use %%NAME%% to place the name (billing information)<br>
Use %%ADDRESS%% to place the address (billing information)<br>
Use %%DOMAIN%% to place the domain name<br>
Use %%INVOICE%% to place the invoice number (&lt;domain&gt;-&lt;id&gt;)<br>
Use %%ENTRY%% to place the charge entry table<br>
Use %%TOTAL%% to place the invoice total amount<br>
Use %%BALANCE%% to place previus balance<br>
Use %%DATE%% to place the date of the invoice</td></tr>
<tr><td class="prgout" align=left> <textarea name="invoice" rows=15 cols=75 wrap=off>$remote{'invoice'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Client Invoice"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Client Invoice">
</form>);
&Bottom;
}

##

sub Client_Invoice_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI15'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface Invoice</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Client+Invoice&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Invoice"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Client Invoice">
</form>);
&Bottom;
}

##

sub Save_SSL_Menu
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI12'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port)=$query_output->fetchrow;
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$system{'enckey'},"do=save+ssl+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>SSL Menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Client_SSL
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI12'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port)=$query_output->fetchrow;
&Connect($ip,$port,$system{'enckey'},"do=get+ssl+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface SSL Functions Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left><textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save SSL Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save SSL Menu">
</form>);
&Bottom;
}

##

sub Client_SSL_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI12'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface SSL Cert Functions Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Client+SSL&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit SSL Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Client SSL">
</form>);
&Bottom;
}

##

sub Save_Support_Menu
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI13'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port)=$query_output->fetchrow;
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$system{'enckey'},"do=save+support+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Support menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Client_Support
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI13'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port)=$query_output->fetchrow;
&Connect($ip,$port,$system{'enckey'},"do=get+support+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface Support Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Support Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Support Menu">
</form>);
&Bottom;
}

##

sub Client_Support_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI13'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface Support Functions Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Client+Support&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Support Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Client Support">
</form>);
&Bottom;
}

##

sub Save_Admin_Menu
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port)=$query_output->fetchrow;
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$system{'enckey'},"do=save+admin+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Admin menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Client_Admin
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port)=$query_output->fetchrow;
&Connect($ip,$port,$system{'enckey'},"do=get+admin+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface Admin Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Admin Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Admin Menu">
</form>);
&Bottom;
}

##

sub Client_Admin_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI8'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface Admin Functions Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Client+Admin&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Admin Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Client Admin">
</form>);
&Bottom;
}

##

sub Save_Billing_Menu
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI9'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port)=$query_output->fetchrow;
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$system{'enckey'},"do=save+billing+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Billing menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Client_Billing
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI9'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port)=$query_output->fetchrow;
&Connect($ip,$port,$system{'enckey'},"do=get+billing+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface Billing Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Billing Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Billing Menu">
</form>);
&Bottom;
}

##

sub Client_Billing_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI9'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface Billing Functions Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Client+Billing&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Billing Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Client Billing">
</form>);
&Bottom;
}

##

sub Save_Ftp_Menu
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI11'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port)=$query_output->fetchrow;
$FORM{'html'}=&uri_escape($FORM{'html'});
$FORM{'plugin'}=&uri_escape($FORM{'plugin'});
&Connect($ip,$port,$system{'enckey'},"do=save+ftp+menu&html=$FORM{'html'}&plugin=$FORM{'plugin'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>FTP menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Client_Ftp
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI11'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port)=$query_output->fetchrow;
&Connect($ip,$port,$system{'enckey'},"do=get+ftp+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface FTP Functions Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left>FTP Menu plugin data<br>
use %%VIRTFTP%% to place this plugin in menu<br>
(it will only be available when virtual ftp is enabled then).</td></tr>
<tr><td class="prgout" align=left><textarea name="plugin" rows=10 cols=75 wrap=off>$remote{'plugin'}</textarea></td></tr>
<tr><td class="prgout" align=left>FTP Functions Menu</td></tr>
<tr><td class="prgout" align=left><textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save FTP Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Ftp Menu">
</form>);
&Bottom;
}

##

sub Client_Ftp_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI11'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface FTP Functions Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Client+Ftp&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Virtual FTP Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Client Ftp">
</form>);
&Bottom;
}

##

sub Save_Web_Menu
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI14'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port)=$query_output->fetchrow;
$FORM{'html'}=&uri_escape($FORM{'html'});
&Connect($ip,$port,$system{'enckey'},"do=save+web+menu&html=$FORM{'html'}");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Web menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Client_Web
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI14'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port)=$query_output->fetchrow;
&Connect($ip,$port,$system{'enckey'},"do=get+web+menu");
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface Website Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Web Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Web Menu">
</form>);
&Bottom;
}

##

sub Client_Web_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI14'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface Website Functions Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Client+Web&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Web Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Client Web">
</form>);
&Bottom;
}

##

sub Send_clientdinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,includepath,sshport FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$includepath,$sshport)=$query_output->fetchrow;
$ENV{HOME}=$system{'cgipath'};
my $ssh=Net::SSH::Perl->new($ip,protocol=>'2',port=>$sshport);
my($root)="root";
eval {$ssh->login($root,$FORM{'pass'});};
if($@ =~ /Permission denied/i){&Error("The root password was incorrect.");}
my($cmd)=qq(mkdir -p $includepath;chmod 700 $includepath;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$host="$ip";' > $includepath/clientd.inc;echo '\$port="$port";' >> $includepath/clientd.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo '\$key='"'"$system{'enckey'}"'"';' >> $includepath/clientd.inc;echo "\@referers=('$ENV{'SERVER_ADDR'}');" >> $includepath/clientd.inc;);
$ssh->cmd($cmd);
$cmd=qq(echo "1;" >> $includepath/clientd.inc;chmod 600 $includepath/clientd.inc;);
$ssh->cmd($cmd);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>clientd.inc File Creation For $name</td></tr>
<tr><td class="prgout" align=left>The file $includepath/clientd.inc was created and the following information placed in it.</td></tr>
<tr><td class="prgout" align=left>\$host=&quot;$ip&quot;;<br>
\$port=&quot;$port&quot;;<br>
\$key='$system{'enckey'}';<br>
\@referers=('$ENV{'SERVER_ADDR'}');<br>
1;
</td></tr>
<tr><td class="prgout" align=left>The client server daemon, clientd, can now be started</td></tr>
</table>);
&Bottom;
}

##

sub Clientinc
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,includepath FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$includepath)=$query_output->fetchrow;
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the client server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>clientd.inc File Creation For $name</td></tr>
<tr><td class="prgout" align=left colspan=2>\$host=&quot;$ip&quot;;<br>
\$port=&quot;$port&quot;;<br>
\$key='$system{'enckey'}';<br>
\@referers=('$ENV{'SERVER_ADDR'}');<br>
1;
</td></tr>
<tr><td class="prgout" align=left colspan=2>This file can be created by hand and placed in $includepath,<br>
or can be sent to server via SSH if root ssh with password access is available.</td></tr>
<tr><td class="heada" align=center colspan=2>Generate clientd.inc on $name client server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send clientd.inc"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Send clientdinc">
</form>);
&Bottom;
}

##

sub Clientinc_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
my($count)=($query_output->execute)+0;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Generate clientd.inc File Information</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Client Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Clientinc&id=$id" class="prgout">$name</a><br>);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Client Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Generate Information"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Clientinc">
</form>);
&Bottom;
}

##

sub Save_Email_Menu
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI10'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$FORM{'html'}=&uri_escape($FORM{'html'});
my($ip,$port)=$query_output->fetchrow;
my($command)=qq(do=save+email+menu&html=$FORM{'html'});
&Connect($ip,$port,$system{'enckey'},$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Email menu updated</td></tr>
</table>);
&Bottom;
}

##

sub Client_Email
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI10'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
my($name,$ip,$port)=$query_output->fetchrow;
my($command)=qq(do=get+email+menu);
&Connect($ip,$port,$system{'enckey'},$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'html'}=~s/\&/&amp;/g;
$remote{'html'}=~s/"/&quot;/g;
$remote{'html'}=~s/</&lt;/g;
$remote{'html'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface Email Functions Menu for $name</td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="html" rows=15 cols=75 wrap=off>$remote{'html'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Email Menu"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Email Menu">
</form>);
&Bottom;
}

##

sub Client_Email_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI10'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface Email Functions Menu</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Client+Email&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Email Menu"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Client Email">
</form>);
&Bottom;
}

##

sub Save_Frontpage
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$FORM{'frontpage'}=&uri_escape($FORM{'frontpage'});
$FORM{'plugins'}=&uri_escape($FORM{'plugins'});
my($ip,$port)=$query_output->fetchrow;
my($command)=qq(do=save+frontpage&frontpage=$FORM{'frontpage'}&plugins=$FORM{'plugins'});
&Connect($ip,$port,$system{'enckey'},$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Client frontpage updated</td></tr>
</table>);
&Bottom;
}

##

sub Client_Frontpage
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
my($name,$ip,$port)=$query_output->fetchrow;
my($command)=qq(do=get+frontpage);
&Connect($ip,$port,$system{'enckey'},$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'plugins'}=~s/\&/&amp;/g;
$remote{'plugins'}=~s/"/&quot;/g;
$remote{'plugins'}=~s/</&lt;/g;
$remote{'plugins'}=~s/>/&gt;/g;
$remote{'frontpage'}=~s/\&/&amp;/g;
$remote{'frontpage'}=~s/"/&quot;/g;
$remote{'frontpage'}=~s/</&lt;/g;
$remote{'frontpage'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface Front Page for $name</td></tr>
<tr><td class="prgout" align=left>Level Restricted Plugins<br>
This allows you to place plugins that will be placed if the person has appropriate access.<br>
Use WITHADMIN=<something> for administrator privledges<br>
Use WITHEMAIL=<something> for email management access<br>
Use WITHBILLING=<something> for billing management access<br>
Use WITHFTP=<something> for ftp management access<br>
Use WITHWEB=<something> for web management access</td></tr>
<tr><td class="prgout" align=left><textarea name="plugins" rows=6 cols=75 wrap=off>$remote{'plugins'}</textarea></td></tr>
<tr><td class="prgout" align=left>Place plugins with %%<plugin>%% such as %%WITHADMIN%%
Use %%quickview%% to place quickview<br>
Use %%resources%% to place resources vertically<br>
Use %%sysinfo%% to place system information vertically<br>
Use %%sysinfoh%% to place system information horizontally<br>
Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)<br>
Use %%NEWS%% to place a listing of the last 10 news articles<br>
Use %%ADMIN%% to place the admin function menu<br>
Use %%BILLING%% to place the billing function menu<br>
Use %%EMAIL%% to place the email function menu<br>
Use %%FTP%% to place the ftp function menu<br>
Use %%SSL%% to place the SSL Cert Function menu<br>
Use %%SUPPORT%% to place the support function menu<br>
Use %%WEB%% to place the website function menu<br>
Use %%DOMAIN%% to place the domain.</td></tr>
<tr><td class="prgout" align=left> <textarea name="frontpage" rows=15 cols=75 wrap=off>$remote{'frontpage'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Front Page"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Frontpage">
</form>);
&Bottom;
}

##

sub Client_Frontpage_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI7'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface Front Page</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Client+Frontpage&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Front Page"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Client Frontpage">
</form>);
&Bottom;
}

##

sub Config_Client
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI4'} ne "yes")){&Error('Insufficient access for this function');}
my($id)=$_[0];
if($id){$FORM{'id'}=$id;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip FROM server WHERE type='admin');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($aid)=$query_output->fetchrow;
$statement=qq(SELECT ip,port,cgipath,imageurl,user,agroup,netfilter,nfpath,autofirewall,usefilecheck,webstart,webstop,webrestart,webpid,includepath,
sshstart,sshstop,sshrestart,sshpid FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$cgipath,$imageurl,$user,$group,$netfilter,$nfpath,$autofirewall,$usefilecheck,$webstart,$webstop,$webrestart,$webpid,$includepath,$sshstart,$sshstop,$sshrestart,$sshpid)=$query_output->fetchrow;
$webstart=&uri_escape($webstart);$webstop=&uri_escape($webstop);$webrestart=&uri_escape($webrestart);$webpid=&uri_escape($webpid);
$sshstart=&uri_escape($sshstart);$sshstop=&uri_escape($sshstop);$sshrestart=&uri_escape($sshrestart);$sshpid=&uri_escape($sshpid);
my($command)=qq(do=config&dbhost=);
if($system{'dbhost'} eq "localhost"){$command.=qq($aid);}
else{$command.=qq($system{'dbhost'});}
$command.=qq(&dbname=$system{'dbname'}&dbuser=$system{'dbuser'}&dbpass=$system{'dbpass'}&cgipath=$cgipath&adminemail=$system{'adminemail'});
$command.=qq(&imageurl=$imageurl&user=$user&group=$group&netfilter=$netfilter&nfpath=$nfpath&autofirewall=$autofirewall&logtime=$system{'logtime'});
$command.=qq(&usefilecheck=$usefilecheck&ticketnotify=$system{'ticketnotify'}&notifyemail=$system{'notifyemail'}&logattempt=$system{'logattempt'});
$command.=qq(&setperiod=$system{'setperiod'}&latefee=$system{'latefee'}&webstart=$webstart&webstop=$webstop&webrestart=$webrestart&webpid=$webpid&includepath=$includepath);
$command.=qq(&sshstart=$sshstart&sshstop=$sshstop&sshrestart=$sshrestart&sshpid=$sshpid);
if($system{'useauthnet'} eq "yes")
	{
	$command.=qq(&useauthnet=$system{'useauthnet'}&authnetver=$system{'authnetver'}&emailcust=$system{'emailcust'}&authnetlogin=$system{'authnetlogin'});
	$command.=qq(&mastercard=$system{'mastercard'}&visa=$system{'visa'}&discover=$system{'discover'}&americanexpress=$system{'americanexpress'}&autobill=$system{'autobill'});
	}
if($system{'usesrs'} eq "yes")
	{
	$command.=qq(&regfee=$system{'regfee'}&regdiscount=$system{'regdiscount'});
	$command.=qq(&usesrs=$system{'usesrs'}&srsuser=$system{'srsuser'}&srskey=$system{'srskey'}&srsemail=$system{'srsemail'}&srsrenew=$system{'srsrenew'}&srshost=$system{'srshost'});
	$command.=qq(&srsprocess=$system{'srsprocess'}&contact_firstname=$system{'contact_firstname'}&contact_lastname=$system{'contact_lastname'}&contact_organization=$system{'contact_organization'});
	$command.=qq(&contact_address1=$system{'contact_address1'}&contact_address2=$system{'contact_address2'}&contact_address3=$system{'contact_address3'});
	$command.=qq(&contact_city=$system{'contact_city'}&contact_state=$system{'contact_state'}&contact_zip=$system{'contact_zip'}&contact_country=$system{'contact_country'});
	$command.=qq(&contact_phone=$system{'contact_phone'}&contact_fax=$system{'contact_fax'}&contact_email=$system{'contact_email'});
	}
&Connect($ip,$port,$system{'enckey'},$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
if($id){return 0;}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Client server configured</td></tr>
</table>);
&Bottom;
}

##

sub Config_Client_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Config+Client&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Configure Server"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Config Client">
</form>);
&Bottom;
}

##

sub Save_Client_Layout
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI6'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'top'}=&uri_escape($FORM{'top'});
$FORM{'bottom'}=&uri_escape($FORM{'bottom'});
$FORM{'topplugin'}=&uri_escape($FORM{'topplugin'});
$FORM{'bottomplugin'}=&uri_escape($FORM{'bottomplugin'});
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port)=$query_output->fetchrow;
my($command)=qq(do=save+layout&top=$FORM{'top'}&bottom=$FORM{'bottom'}&topplugin=$FORM{'topplugin'}&bottomplugin=$FORM{'bottomplugin'});
&Connect($ip,$port,$system{'enckey'},$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Client server layout updated</td></tr>
</table>);
&Bottom;
}

##

sub Client_Layout
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port)=$query_output->fetchrow;
my($command)=qq(do=get+layout);
&Connect($ip,$port,$system{'enckey'},$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$remote{'top'}=~s/\&/&amp;/g;
$remote{'top'}=~s/"/&quot;/g;
$remote{'top'}=~s/</&lt;/g;
$remote{'top'}=~s/>/&gt;/g;
$remote{'bottom'}=~s/\&/&amp;/g;
$remote{'bottom'}=~s/"/&quot;/g;
$remote{'bottom'}=~s/</&lt;/g;
$remote{'bottom'}=~s/>/&gt;/g;
$remote{'topplugin'}=~s/\&/&amp;/g;
$remote{'topplugin'}=~s/"/&quot;/g;
$remote{'topplugin'}=~s/</&lt;/g;
$remote{'topplugin'}=~s/>/&gt;/g;
$remote{'bottomplugin'}=~s/\&/&amp;/g;
$remote{'bottomplugin'}=~s/"/&quot;/g;
$remote{'bottomplugin'}=~s/</&lt;/g;
$remote{'bottomplugin'}=~s/>/&gt;/g;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Edit Client Interface Layout for $name</td></tr>
<tr><td class="prgout" align=left>Level Restricted Plugins for Top<br>
This allows you to place plugins that will be placed if the person has appropriate access.<br>
Use WITHLOGIN==for all users logged in<br>
Use WITHADMIN== for administrator privledges<br>
Use WITHEMAIL== for email management access<br>
Use WITHBILLING== for billing management access<br>
Use WITHFTP== for ftp management access<br>
Use WITHWEB== for web management access<br>
Note * You can have multiple plugins per category by incrementing the plugin names (ie. WITHADMIN, WITHADMIN1, WITHADMIN2)</td></tr>
<tr><td class="prgout" align=left><textarea name="topplugin" rows=10 cols=75 wrap=off>$remote{'topplugin'}</textarea></td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)<br>
Use %%VERSION%% to place the client version number<br>
Use %%ADMIN%% to place the admin function menu<br>
Use %%BILLING%% to place the billing function menu<br>
Use %%EMAIL%% to place the email function menu<br>
Use %%FTP%% to place the ftp function menu<br>
Use %%SSL%% to place the SSL Cert Function menu<br>
Use %%SUPPORT%% to place the support function menu<br>
Use %%WEB%% to place the website function menu<br>
Use %%DOMAIN%% to place the domain.</td></tr>
<tr><td class="prgout" align=left Valign=top>Top HTML (Header)</td></tr>
<tr><td class="prgout" align=left> <textarea name="top" rows=15 cols=75 wrap=off>$remote{'top'}</textarea></td></tr>
<tr><td class="prgout" align=left>Level Restricted Plugins for Bottom<br>
This allows you to place plugins that will be placed if the person has appropriate access.<br>
Use WITHLOGIN==for all users logged in<br>
Use WITHADMIN== for administrator privledges<br>
Use WITHEMAIL== for email management access<br>
Use WITHBILLING== for billing management access<br>
Use WITHFTP== for ftp management access<br>
Use WITHWEB== for web management access<br>
Note * You can have multiple plugins per category by incrementing the plugin names (ie. WITHADMIN, WITHADMIN1, WITHADMIN2)</td></tr>
<tr><td class="prgout" align=left> <textarea name="bottomplugin" rows=10 cols=75 wrap=off>$remote{'bottomplugin'}</textarea></td></tr>
<tr><td class="prgout" align=left>Use %%SCRIPT%% to place the url to the client program<br>
Use %%STATS%% to place the url to the client website statistics (if using webalizer)<br>
Use %%VERSION%% to place the client version number<br>
Use %%ADMIN%% to place the admin function menu<br>
Use %%BILLING%% to place the billing function menu<br>
Use %%EMAIL%% to place the email function menu<br>
Use %%FTP%% to place the ftp function menu<br>
Use %%SSL%% to place the SSL Cert Function menu<br>
Use %%SUPPORT%% to place the support function menu<br>
Use %%WEB%% to place the website function menu<br>
Use %%DOMAIN%% to place the domain.</td></tr>
<tr><td class="prgout" align=left Valign=top>Bottom HTML (Footer)</td></tr>
<tr><td class="prgout" align=left> <textarea name="bottom" rows=15 cols=75 wrap=off>$remote{'bottom'}</textarea></td></tr>
<tr><td class="prgout" align=center><input type="submit" value="Save Layout"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Client Layout">
</form>);
&Bottom;
}

##

sub Client_Layout_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Configure Client Interface Layout</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Interface Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Client+Layout&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Interface Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Layout"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Client Layout">
</form>);
&Bottom;
}

##

sub Remove_Client
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip)=$query_output->fetchrow;
$statement=qq(DELETE FROM server WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT id FROM server WHERE ip='$ip' && (type='signup'||type='webmail'));
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($test)=$query_output->fetchrow;
if(!$test)
	{
	&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},'mysql',$system{'mysqlroot'},$system{'mysqlpass'});
	$statement=qq(DELETE FROM db WHERE Host='$ip' && Db='$system{'dbname'}' && User='$system{'dbuser'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(DELETE FROM user WHERE Host='$ip' && User='$system{'dbuser'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(Flush privileges);
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='hosting');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($sip,$sport,$serverpass);
	my($cipher);
	while(($sip,$sport,$serverpass)=$query_output->fetchrow)
		{
		my($command)=qq(do=remove+referer&ip=$ip);
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		&Connect($sip,$sport,$serverpass,$command);
		if($remote{'status'} ne "done"){&Error("Unable to update referers on hosting server $ip, $remote{'status'}");}
		}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Client server removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Client_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a client interface server to remove");
return false;
}
if(confirm("Do you want to delete this client interface server?"))
	{
	return true;
	}
else
return false;
}
function ConFirm()
{
if(confirm("Do you want to delete this client interface server?"))
	{
	return true;
	}
else
return false;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Client Interface Server</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Remove+Client&id=$id" onClick="return ConFirm();" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Remove Server"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Remove Client">
</form>);
&Bottom;
}

##

sub Save_Client
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip)=$query_output->fetchrow;
$statement=qq(UPDATE server SET name='$FORM{'name'}',ip='$FORM{'ip'}',port='$FORM{'port'}',
netfilter='$FORM{'netfilter'}',nfpath='$FORM{'nfpath'}',autofirewall='$FORM{'autofirewall'}',
clienturl='$FORM{'clienturl'}',cgipath='$FORM{'cgipath'}',imageurl='$FORM{'imageurl'}',user='$FORM{'user'}',
agroup='$FORM{'group'}',usefilecheck='$FORM{'usefilecheck'}',webstart='$FORM{'webstart'}',webstop='$FORM{'webstop'}',
webrestart='$FORM{'webrestart'}',webpid='$FORM{'webpid'}',includepath='$FORM{'includepath'}',sshport='$FORM{'sshport'}',
sshstart='$FORM{'sshstart'}',sshstop='$FORM{'sshstop'}',sshrestart='$FORM{'sshrestart'}',sshpid='$FORM{'sshpid'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT id FROM server WHERE ip='$FORM{'ip'}' && type='signup');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($test)=$query_output->fetchrow;
if((!$test)&&($ip ne $FORM{'ip'}))
	{
	&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},'mysql',$system{'mysqlroot'},$system{'mysqlpass'});
	$statement=qq(UPDATE user SET Host='$FORM{'ip'}' WHERE Host='$ip' && User='$system{'dbuser'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(UPDATE db SET Host='$FORM{'ip'}' WHERE Host='$ip' && Db='$system{'dbname'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	$statement=qq(Flush privileges);
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
	$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='hosting');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($sip,$sport,$serverpass);
	my($cipher);
	while(($sip,$sport,$serverpass)=$query_output->fetchrow)
		{
		if(&decode_base64($serverpass) =~ /^Randomiv/i)
			{
			if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
			else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
			}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
		my($command)=qq(do=remove+referer&ip=$ip);
		$serverpass=$cipher->decrypt(&decode_base64($serverpass));
		&Connect($sip,$sport,$serverpass,$command);
		if($remote{'status'} ne "done"){&Error("Unable to update referers on hosting server $ip, $remote{'status'}");}
		$command=qq(do=add+referer&ip=$FORM{'ip'});
		&Connect($sip,$sport,$serverpass,$command);
		if($remote{'status'} ne "done"){&Error("Unable to update referers on hosting server $ip, $remote{'status'}");}
		}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Client interface information updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Client
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM server WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@fields)=$query_output->name;
my(@values)=$query_output->fetchrow_array;
my($cipher,$serverpass);
if(&decode_base64($values[5]))
	{
	if(&decode_base64($values[5]) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($values[5]));
	}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizeable=no,status=no");}
// -->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Client Interface Server</td></tr>
<tr><td class="prgout" align=left>Server Name</td>
<td class="prgout" align=left><input name="name" type="text" value="$values[2]" size=30,1 maxlength=75></td></tr>
<tr><td class="prgout" align=left>IP Address</td>
<td class="prgout" align=left><input name="ip" type="text" value="$values[3]" size=15,1 maxlength=15></td></tr>
<tr><td class="prgout" align=left>Port</td>
<td class="prgout" align=left><input name="port" type="text" value="$values[4]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left>Client Program URL</td>
<td class="prgout" align=left><input name="clienturl" type="text" value="$values[66]" size=30,1></td></tr>
<tr><td class="prgout" align=left>Client Program Path</td>
<td class="prgout" align=left><input name="cgipath" type="text" value="$values[67]" size=30,1></td></tr>
<tr><td class="prgout" align=left>Image URL</td>
<td class="prgout" align=left><input name="imageurl" type="text" value="$values[68]" size=30,1></td></tr>
<tr><td class="prgout" align=left>User to own files to</td>
<td class="prgout" align=left><input name="user" type="text" value="$values[69]" size=30,1></td></tr>
<tr><td class="prgout" align=left>Group to own files to</td>
<td class="prgout" align=left><input name="group" type="text" value="$values[70]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</a></td>
<td class="prgout" align=left><input name="sshport" type="text" value="$values[85]" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter?</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no");
if($values[20] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" value="$values[52]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no");
if($values[53] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no");
if($values[23] eq "no"){print qq( selected);}
print qq(>No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstart');" class="prgout">Web Server Start Command</a></td>
<td class="prgout" align=left><input name="webstart" type="text" value="$values[33]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstop');" class="prgout">Web Server Stop Command</a></td>
<td class="prgout" align=left><input name="webstop" type="text" value="$values[34]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webrestart');" class="prgout">Web Server Restart Command</a></td>
<td class="prgout" align=left><input name="webrestart" type="text" value="$values[33]" size=30,1 maxlength=355></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webpid');" class="prgout">Web Server PID File</a></td>
<td class="prgout" align=left><input name="webpid" type="text" value="$values[35]" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">Include Path</a></td>
<td class="prgout" align=left><input name="includepath" type="text" value="$values[74]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" value="$values[86]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" value="$values[87]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" value="$values[88]" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" value="$values[89]" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Server"></td></tr>
</table>
<input name="id" type="hidden" value="$FORM{'id'}">
<input name="do" type="hidden" value="Save Client">
</form>);
&Bottom;
}

##

sub Edit_Client_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM server WHERE type='client' ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=($query_output->execute)+0;
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a client interface server to edit");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Client Interface Server</td></tr>\n);
if($count <= 10)
	{
	print qq(<tr><td class="prgout" align=left Valign=top>Server</td>
<td class="prgout" align=left>);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<a href="$script?do=Edit+Client&id=$id" class="prgout">$name</a><br>\n);
		}
	print qq(</td></tr>\n);
	}
else
	{
	print qq(<tr><td class="prgout" align=left>Server</td>
<td class="prgout" align=left><select name="id" size=1><option value="">--Select Server--);
	while(($id,$name)=$query_output->fetchrow)
		{
		print qq(<option value="$id">$name);
		}
	print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Server"></td></tr>\n);
	}
print qq(</table>
<input name="do" type="hidden" value="Edit Client">
</form>);
&Bottom;
}

##

sub Add_Client
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI1'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id FROM server WHERE ip='$FORM{'ip'}' && type='client');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($test)=$query_output->fetchrow;
if($test){&Error("This client server interface is already registered in the system.");}
my($cipher,$clientkey);
if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($clientkey)=&encode_base64($cipher->encrypt($system{'enckey'}));
$statement=qq(INSERT INTO server (type,name,ip,port,serverpass,netfilter,nfpath,autofirewall,clienturl,cgipath,imageurl,user,agroup,usefilecheck,
webstart,webstop,webrestart,webpid,includepath,sshport,sshstart,sshstop,sshrestart,sshpid)
VALUES ('client','$FORM{'name'}','$FORM{'ip'}','$FORM{'port'}','$clientkey','$FORM{'netfilter'}','$FORM{'nfpath'}','$FORM{'autofirewall'}',
'$FORM{'clienturl'}','$FORM{'cgipath'}','$FORM{'imageurl'}','$FORM{'user'}','$FORM{'group'}','$FORM{'usefilecheck'}',
'$FORM{'webstart'}','$FORM{'webstop'}','$FORM{'webrestart'}','$FORM{'webpid'}','$FORM{'includepath'}','$FORM{'sshport'}',
'$FORM{'sshstart'}','$FORM{'sshstop'}','$FORM{'sshrestart'}','$FORM{'sshpid'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(SELECT LAST_INSERT_ID());
$query_output=$db->query($statement);
my($id)=$query_output->fetchrow;
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},'mysql',$system{'mysqlroot'},$system{'mysqlpass'});
$statement=qq(GRANT ALL ON $system{'dbname'}.* TO $system{'dbuser'}\@$FORM{'ip'} IDENTIFIED BY "$system{'dbpass'}" WITH GRANT OPTION);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(Flush privileges);
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE type='hosting');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass);
while(($ip,$port,$serverpass)=$query_output->fetchrow)
	{
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	my($command)=qq(do=add+referer&ip=$FORM{'ip'});
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("Unable to update referers on hosting server $ip, $remote{'status'}");}
	}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].pass.value <= 0)
{
alert("Enter the root password to the client server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Generate clientd.inc on $name client server</td></tr>
<tr><td class="prgout" align=left>Root Password:</td>
<td class="prgout" align=left><input name="pass" type="password" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Send clientd.inc"></td></tr>
</table>
<input name="id" type="hidden" value="$id">
<input name="do" type="hidden" value="Send clientdinc">
</form>);
&Bottom;
}

##

sub Add_Client_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MCI1'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="JavaScript">
<!--
function newwin(help) { var MainWindow = window.open (help,"help","toolbar=no,location=no,menubar=no,scrollbars=yes,width=250,height=150,resizeable=no,status=no");}
function chkData() {
if(document.forms[0].name.value <= 0)
{
alert("Enter a server name for the client interface server");
return false;
}
if(document.forms[0].ip.value <= 0) 
{
alert("Enter the ip address for the client interface server");
return false;
}
if(document.forms[0].port.value <= 0)
{
alert("Enter the port for the client interface server");
return false;
}
if(document.forms[0].clienturl.value <= 0)
{
alert("Enter the client program url for this client interface server");
return false;
}
if(document.forms[0].cgipath.value <= 0) 
{
alert("Enter the client program path for the client interface software");
return false;
}
if(document.forms[0].user.value <= 0) 
{
alert("Enter the system username to own the files to for the client interface server");
return false;
}
if(document.forms[0].group.value <= 0) 
{
alert("Enter the system group to own the files to for the client interface server");
return false;
}
if(document.forms[0].sshport.value <= 0)
{
alert("Enter the ssh port for the server");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Client Interface</td></tr>
<tr><td class="prgout" align=left>Server Name</td>
<td class="prgout" align=left><input name="name" type="text" size=30,1 maxlength=75></td></tr>
<tr><td class="prgout" align=left>IP Address</td>
<td class="prgout" align=left><input name="ip" type="text" size=15,1 maxlength=15></td></tr>
<tr><td class="prgout" align=left>Port</td>
<td class="prgout" align=left><input name="port" type="text" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left>Client Program URL</td>
<td class="prgout" align=left><input name="clienturl" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left>Client Program Path</td>
<td class="prgout" align=left><input name="cgipath" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left>Image URL</td>
<td class="prgout" align=left><input name="imageurl" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left>User to own files to</td>
<td class="prgout" align=left><input name="user" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left>Group to own files to</td>
<td class="prgout" align=left><input name="group" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshport');" class="prgout">SSH Port</td>
<td class="prgout" align=left><input name="sshport" type="text" value="22" size=5,1 maxlength=5></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=netfilter');" class="prgout">Use Netfilter?</a></td>
<td class="prgout" align=left><select name="netfilter" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=nfpath');" class="prgout">iptables path</a></td>
<td class="prgout" align=left><input name="nfpath" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=autofirewall');" class="prgout">Automatically load firewall on startup?</a></td>
<td class="prgout" align=left><select name="autofirewall" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=usefilecheck');" class="prgout">Use Filecheck?</a></td>
<td class="prgout" align=left><select name="usefilecheck" size=1><option value="yes">Yes<option value="no">No</select></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstart');" class="prgout">Web Server Start Command</a></td>
<td class="prgout" align=left><input name="webstart" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webstop');" class="prgout">Web Server Stop Command</a></td>
<td class="prgout" align=left><input name="webstop" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webrestart');" class="prgout">Web Server Restart Command</a></td>
<td class="prgout" align=left><input name="webrestart" type="text" size=30,1 maxlength=355></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=webpid');" class="prgout">Web Server PID File</a></td>
<td class="prgout" align=left><input name="webpid" type="text" size=30,1 maxlength=255></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=includepath');" class="prgout">clientd.inc Include Path</a></td>
<td class="prgout" align=left><input name="includepath" type="text" value="/etc/gnuhh/client" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstart');" class="prgout">SSH server start command</a></td>
<td class="prgout" align=left><input name="sshstart" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshstop');" class="prgout">SSH server stop command</a></td>
<td class="prgout" align=left><input name="sshstop" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshrestart');" class="prgout">SSH server restart command</a></td>
<td class="prgout" align=left><input name="sshrestart" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=left><a href="javascript:newwin('$script?do=help&help=sshpid');" class="prgout">SSH server PID file</a></td>
<td class="prgout" align=left><input name="sshpid" type="text" size=30,1></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="Submit" value="Add Client Interface"></td></tr>
</table>
<input name="do" type="hidden" value="Add Client">
</form>);
&Bottom;
}

1;
