sub Remove_Admin
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MA3'} ne "yes")){&Error('Insufficient access for this function');}
my(@info);
open(TEMP,">temp.dat");
open(FILE,"system.dat");
while(<FILE>)
	{
	@info=split(/:/,$_);
	if($info[0] ne $FORM{'user'})
		{
		print TEMP $_;
		}
	}
close(FILE);
close(TEMP);
unlink("$system{'cgipath'}/system.dat");
qx|mv $system{'cgipath'}/temp.dat $system{'cgipath'}/system.dat|;
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM access WHERE name='$FORM{'user'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Administrator, $FORM{'user'}, removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Admin_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MA3'} ne "yes")){&Error('Insufficient access for this function');}
my(@info);
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove Administrator</td></tr>
<tr><td class="prgout" align=left width=50%>Administrator to remove</td>
<td class="prgout" align=left><select name="user" size=1>);
open(FILE,"system.dat");
while(<FILE>)
	{
	@info=split(/:/,$_);
	print qq(<option>$info[0]);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Remove Administrator"></td></tr>
</table>
<input name="do" type="hidden" value="Remove Admin">
</form>\n);
&Bottom;
}

##

sub Save_Admin
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MA2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
my(@LINES,@info);
open(FILE,"system.dat");
@LINES=<FILE>;
close(FILE);
open(FILE,">system.dat");
foreach(@LINES)
	{
	@info=split(/:/,$_);
	if($info[0] ne $FORM{'user'}){print FILE $_;}
	else{print FILE qq($info[0]:$info[1]:$FORM{'level'}:\n);}
	}
close(FILE);
if($FORM{'level'} eq "1")
	{
	$statement=qq(DELETE FROM access WHERE name='$FORM{'user'}');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
else
	{
	$statement=qq(SELECT count(name) FROM access WHERE name='$FORM{'user'}');
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($test)=$query_output->fetchrow;
	if($test)
		{
		$statement=qq(UPDATE access SET ST='$FORM{'ST'}',ST1='$FORM{'ST1'}',ST2='$FORM{'ST2'}',ST3='$FORM{'ST3'}',ST4='$FORM{'ST4'}',
SM='$FORM{'SM'}',SM1='$FORM{'SM1'}',SM2='$FORM{'SM2'}',SM3='$FORM{'SM3'}',SM4='$FORM{'SM4'}',SM5='$FORM{'SM5'}',SS='$FORM{'SS'}',Smon='$FORM{'Smon'}',
Smon1='$FORM{'Smon1'}',Smon2='$FORM{'Smon2'}',TC='$FORM{'TC'}',TC1='$FORM{'TC1'}',TC2='$FORM{'TC2'}',TC3='$FORM{'TC3'}',NM='$FORM{'NM'}',NM1='$FORM{'NM1'}',
NM2='$FORM{'NM2'}',NM3='$FORM{'NM3'}',KB='$FORM{'KB'}',KB1='$FORM{'KB1'}',KB2='$FORM{'KB2'}',KB3='$FORM{'KB3'}',KB4='$FORM{'KB4'}',KB5='$FORM{'KB5'}',
KB6='$FORM{'KB6'}',FM='$FORM{'FM'}',FM1='$FORM{'FM1'}',FM2='$FORM{'FM2'}',FM3='$FORM{'FM3'}',FM4='$FORM{'FM4'}',DM='$FORM{'DM'}',DM1='$FORM{'DM1'}',
DM2='$FORM{'DM2'}',DM3='$FORM{'DM3'}',DM4='$FORM{'DM4'}',DM5='$FORM{'DM5'}',DM6='$FORM{'DM6'}',DM7='$FORM{'DM7'}',DM8='$FORM{'DM8'}',DM9='$FORM{'DM9'}',
DM10='$FORM{'DM10'}',DM11='$FORM{'DM11'}',DM12='$FORM{'DM12'}',DM13='$FORM{'DM13'}',DM14='$FORM{'DM14'}',UM='$FORM{'UM'}',UM1='$FORM{'UM1'}',UM2='$FORM{'UM2'}',UM3='$FORM{'UM3'}',
UM4='$FORM{'UM4'}',UM5='$FORM{'UM5'}',UM6='$FORM{'UM6'}',BA='$FORM{'BA'}',BA1='$FORM{'BA1'}',BA2='$FORM{'BA2'}',BA3='$FORM{'BA3'}',BA4='$FORM{'BA4'}',
BA5='$FORM{'BA5'}',BA6='$FORM{'BA6'}',AI='$FORM{'AI'}',AI1='$FORM{'AI1'}',AI2='$FORM{'AI2'}',AI3='$FORM{'AI3'}',AI4='$FORM{'AI4'}',MF='$FORM{'MF'}',MF1='$FORM{'MF1'}',
MF2='$FORM{'MF2'}',MF3='$FORM{'MF3'}',PM='$FORM{'PM'}',PM1='$FORM{'PM1'}',PM2='$FORM{'PM2'}',PM3='$FORM{'PM3'}',PM4='$FORM{'PM4'}',PM5='$FORM{'PM5'}',
PM6='$FORM{'PM6'}',PM7='$FORM{'PM7'}',MHS='$FORM{'MHS'}',
MHS1='$FORM{'MHS1'}',MHS2='$FORM{'MHS2'}',MHS3='$FORM{'MHS3'}',MHS4='$FORM{'MHS4'}',MHS5='$FORM{'MHS5'}',MHS6='$FORM{'MHS6'}',MHS7='$FORM{'MHS7'}',
MHS8='$FORM{'MHS8'}',MHS9='$FORM{'MHS9'}',MHS10='$FORM{'MHS10'}',MHS11='$FORM{'MHS11'}',MHS12='$FORM{'MHS12'}',MCI='$FORM{'MCI'}',MCI1='$FORM{'MCI1'}',MCI2='$FORM{'MCI2'}',
MCI3='$FORM{'MCI3'}',MCI4='$FORM{'MCI4'}',MCI5='$FORM{'MCI5'}',MCI6='$FORM{'MCI6'}',MCI7='$FORM{'MCI7'}',MCI8='$FORM{'MCI8'}',MCI9='$FORM{'MCI9'}',
MCI10='$FORM{'MCI10'}',MCI11='$FORM{'MCI11'}',MCI12='$FORM{'MCI12'}',MCI13='$FORM{'MCI13'}',MCI14='$FORM{'MCI14'}',MCI15='$FORM{'MCI15'}',MCI16='$FORM{'MCI16'}',
MMS='$FORM{'MMS'}',MMS1='$FORM{'MMS1'}',MMS2='$FORM{'MMS2'}',MMS3='$FORM{'MMS3'}',MMS4='$FORM{'MMS4'}',MMS5='$FORM{'MMS5'}',MMS6='$FORM{'MMS6'}',
MMS7='$FORM{'MMS7'}',MMS8='$FORM{'MMS8'}',MNS='$FORM{'MNS'}',MNS1='$FORM{'MNS1'}',MNS2='$FORM{'MNS2'}',MNS3='$FORM{'MNS3'}',MNS4='$FORM{'MNS4'}',
MNS5='$FORM{'MNS5'}',MSS='$FORM{'MSS'}',MSS1='$FORM{'MSS1'}',MSS2='$FORM{'MSS2'}',MSS3='$FORM{'MSS3'}',MSS4='$FORM{'MSS4'}',MSS5='$FORM{'MSS5'}',
MSS6='$FORM{'MSS6'}',MSP='$FORM{'MSP'}',MSP1='$FORM{'MSP1'}',MSP2='$FORM{'MSP2'}',MSP3='$FORM{'MSP3'}',MA='$FORM{'MA'}',MA1='$FORM{'MA1'}',MA2='$FORM{'MA2'}',
MA3='$FORM{'MA3'}',SC='$FORM{'SC'}',SC1='$FORM{'SC1'}',SC2='$FORM{'SC2'}',
SC3='$FORM{'SC3'}',SC4='$FORM{'SC4'}',SC5='$FORM{'SC5'}',SC6='$FORM{'SC6'}',NS='$FORM{'NS'}',NS1='$FORM{'NS1'}',NS2='$FORM{'NS2'}',
NS3='$FORM{'NS3'}',AD='$FORM{'AD'}',AD1='$FORM{'AD1'}',AD2='$FORM{'AD2'}',AD3='$FORM{'AD3'}',ADM='$FORM{'ADM'}',ADM1='$FORM{'ADM1'}',ADM2='$FORM{'ADM2'}',
ADM3='$FORM{'ADM3'}',MWS='$FORM{'MWS'}',MWS1='$FORM{'MWS1'}',MWS2='$FORM{'MWS2'}',MWS3='$FORM{'MWS3'}',MWS4='$FORM{'MWS4'}',MWS5='$FORM{'MWS5'}',
MWS6='$FORM{'MWS6'}',MWS7='$FORM{'MWS7'}' WHERE name='$FORM{'user'}');
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	else
		{
		$statement=qq(INSERT INTO access VALUES ('$FORM{'user'}','$FORM{'ST'}','$FORM{'ST1'}','$FORM{'ST2'}','$FORM{'ST3'}','$FORM{'ST4'}',
'$FORM{'SM'}','$FORM{'SM1'}','$FORM{'SM2'}','$FORM{'SM3'}','$FORM{'SM4'}','$FORM{'SM5'}','$FORM{'SS'}','$FORM{'Smon'}','$FORM{'Smon1'}',
'$FORM{'Smon2'}','$FORM{'TC'}','$FORM{'TC1'}','$FORM{'TC2'}','$FORM{'TC3'}','$FORM{'NM'}','$FORM{'NM1'}','$FORM{'NM2'}','$FORM{'NM3'}',
'$FORM{'KB'}','$FORM{'KB1'}','$FORM{'KB2'}','$FORM{'KB3'}','$FORM{'KB4'}','$FORM{'KB5'}','$FORM{'KB6'}','$FORM{'FM'}','$FORM{'FM1'}',
'$FORM{'FM2'}','$FORM{'FM3'}','$FORM{'FM4'}','$FORM{'DM'}','$FORM{'DM1'}','$FORM{'DM2'}','$FORM{'DM3'}','$FORM{'DM4'}','$FORM{'DM5'}',
'$FORM{'DM6'}','$FORM{'DM7'}','$FORM{'DM8'}','$FORM{'DM9'}','$FORM{'DM10'}','$FORM{'DM11'}','$FORM{'DM12'}','$FORM{'DM13'}','$FORM{'DM14'}','$FORM{'UM'}',
'$FORM{'UM1'}','$FORM{'UM2'}','$FORM{'UM3'}','$FORM{'UM4'}','$FORM{'UM5'}','$FORM{'UM6'}','$FORM{'BA'}','$FORM{'BA1'}','$FORM{'BA2'}',
'$FORM{'BA3'}','$FORM{'BA4'}','$FORM{'BA5'}','$FORM{'BA6'}','$FORM{'AI'}','$FORM{'AI1'}','$FORM{'AI2'}','$FORM{'AI3'}','$FORM{'AI4'}','$FORM{'MF'}',
'$FORM{'MF1'}','$FORM{'MF2'}','$FORM{'MF3'}','$FORM{'PM'}','$FORM{'PM1'}','$FORM{'PM2'}','$FORM{'PM3'}','$FORM{'PM4'}','$FORM{'PM5'}','$FORM{'PM6'}',
'$FORM{'PM7'}','$FORM{'MHS'}',
'$FORM{'MHS1'}','$FORM{'MHS2'}','$FORM{'MHS3'}','$FORM{'MHS4'}','$FORM{'MHS5'}','$FORM{'MHS6'}','$FORM{'MHS7'}','$FORM{'MHS8'}','$FORM{'MHS9'}',
'$FORM{'MHS10'}','$FORM{'MHS11'}','$FORM{'MHS12'}','$FORM{'MCI'}','$FORM{'MCI1'}','$FORM{'MCI2'}','$FORM{'MCI3'}','$FORM{'MCI4'}','$FORM{'MCI5'}','$FORM{'MCI6'}',
'$FORM{'MCI7'}','$FORM{'MCI8'}',
'$FORM{'MCI9'}','$FORM{'MCI10'}','$FORM{'MCI11'}','$FORM{'MCI12'}','$FORM{'MCI13'}','$FORM{'MCI14'}','$FORM{'MCI15'}','$FORM{'MCI16'}',
'$FORM{'MMS'}','$FORM{'MMS1'}','$FORM{'MMS2'}','$FORM{'MMS3'}','$FORM{'MMS4'}','$FORM{'MMS5'}','$FORM{'MMS6'}','$FORM{'MMS7'}','$FORM{'MMS8'}',
'$FORM{'MNS'}','$FORM{'MNS1'}','$FORM{'MNS2'}','$FORM{'MNS3'}','$FORM{'MNS4'}','$FORM{'MNS5'}','$FORM{'MSS'}','$FORM{'MSS1'}','$FORM{'MSS2'}',
'$FORM{'MSS3'}','$FORM{'MSS4'}','$FORM{'MSS5'}','$FORM{'MSS6'}','$FORM{'MSP'}','$FORM{'MSP1'}','$FORM{'MSP2'}','$FORM{'MSP3'}','$FORM{'MA'}',
'$FORM{'MA1'}','$FORM{'MA2'}','$FORM{'MA3'}','$FORM{'SC'}','$FORM{'SC1'}','$FORM{'SC2'}','$FORM{'SC3'}','$FORM{'SC4'}','$FORM{'SC5'}','$FORM{'SC6'}','$FORM{'NS'}',
'$FORM{'NS1'}','$FORM{'NS2'}','$FORM{'NS3'}','$FORM{'AD'}','$FORM{'AD1'}','$FORM{'AD2'}','$FORM{'AD3'}','$FORM{'ADM'}','$FORM{'ADM1'}','$FORM{'ADM2'}',
'$FORM{'ADM3'}','$FORM{'MWS'}','$FORM{'MWS1'}','$FORM{'MWS2'}','$FORM{'MWS3'}','$FORM{'MWS4'}','$FORM{'MWS5'}','$FORM{'MWS6'}','$FORM{'MWS7'}'));
		$db->query($statement);
		if($error=$db->errmsg){&Error($error);}
		}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Administrator, $FORM{'user'}, has been updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Admin
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MA2'} ne "yes")){&Error('Insufficient access for this function');}
my(@info);
my($db,$query_output,$statement,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT * FROM access WHERE name='$FORM{'user'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my(@fields)=$query_output->name;
my(@values)=$query_output->fetchrow_array;
my($i,%user);
for($i=1;$i<=$#fields;$i++){$user{$fields[$i]}=$values[$i];}
open(FILE,"system.dat");
while(<FILE>)
	{
	@info=split(/:/,$_);
	if($info[0] eq $FORM{'user'}){last;}
	}
&Top;
print qq(<script language="javascript">
<!--
var AgntUsr=navigator.userAgent.toLowerCase();
var bV=parseInt(navigator.appVersion);
NS4=(document.layers) ? true : false;
IE4=((document.all)&&(bV>=4))?true:false;
NS6=(document.getElementById && !document.all) ? true : false;
ver4 = (NS4 || IE4 || NS6) ? true : false;

function ShowIt(){return}
function ShowAll(){return}

isShown = false;

function getIndex(el) {
	ind = null;
	for (i=0; i<document.layers.length; i++) {
		whichEl = document.layers[i];
		if (whichEl.id == el) {
			ind = i;
			break;
		}
	}
	return ind;
}

function initIt(){
	if (NS4) {
		for (i=0; i<document.layers.length; i++) {
			whichEl = document.layers[i];
			if (whichEl.id.indexOf("Child") != -1)
				{
				whichEl.visibility = "hide";
				}
		}
	}
	else if (IE4) {
		tempColl = document.all.tags("DIV");
		for (i=0; i<tempColl.length; i++) {
			if (tempColl(i).className == "child")
				{
				tempColl(i).style.display = "none";
				}
		}
	}
	else if (NS6) {
		tempColl = document.getElementsByTagName("DIV");
		for (i=0;i<tempColl.length;i++) {
			if (tempColl[i].className == "child")
				{
				tempColl[i].style.display = "none";
				}
		}
	}
}

function ShowIt(el) {
	if (!ver4) return;
	if (IE4) {ShowIE(el)}
	else if (NS4) {ShowNS(el)}
	else {ShowDOM(el)}
}

function HideIt(el) {
	if (!ver4) return;
	if (IE4) {HideIE(el)}
	else if (NS4) {HideNS(el)}
	else {HideDOM(el)}
}

function ShowIE(el) { 
	whichEl = eval(el + "Child");
	if (whichEl.style.display == "none") {
		whichEl.style.display = "block";
	}
}

function HideIE(el) {
	whichEl = eval(el + "Child");
	if (whichEl.style.display == "block") {
		whichEl.style.display = "none";
	}
}

function ShowDOM(el) {
	whichEl=document.getElementById(el + "Child");
	if(whichEl.style.display == "none") {
		whichEl.style.display="block";
		}
	}

function HideDOM(el) {
	whichEl=document.getElementById(el + "Child");
	if(whichEl.style.display == "block") {
		whichEl.style.display = "none";
		}
	}

function ShowNS(el) {
	whichEl = eval("document." + el + "Child");
	if (whichEl.visibility == "hide") {
		whichEl.visibility = "show";
		}
	}

function HideNS(el) {
	whichEl = eval("document." + el + "Child");
	if (whichEl.visibility == "show") {
		whichEl.visibility = "hide";
		}
	}
function CheckIt(x,y) {
if(x == 'el1')
	{
	document.forms[0].ST1.checked=y;
	document.forms[0].ST2.checked=y;
	document.forms[0].ST3.checked=y;
	document.forms[0].ST4.checked=y;
	if(document.forms[0].SS.checked==false){document.forms[0].SS.checked=true};
	}
if(x == 'el2')
	{
	document.forms[0].SM1.checked=y;
	document.forms[0].SM2.checked=y;
	document.forms[0].SM3.checked=y;
	document.forms[0].SM4.checked=y;
	document.forms[0].SM5.checked=y;
	if(document.forms[0].SS.checked==false){document.forms[0].SS.checked=true};
	}
if(x == 'el3')
	{
	if(document.forms[0].SS.checked == false && document.forms[0].ST.checked == true)
		{
		document.forms[0].SS.checked=true;
		alert("Server Select is required for Server Tasks");
		return;
		}
	if(document.forms[0].SS.checked == false && document.forms[0].SM.checked == true)
		{
		document.forms[0].SS.checked=true;
		alert("Server Select is required for Security Management");
		return;
		}
	}
if(x == 'el4')
	{
	document.forms[0].Smon1.checked=y;
	document.forms[0].Smon2.checked=false;
	}
if(x == 'el5')
	{
	document.forms[0].TC1.checked=y;
	document.forms[0].TC2.checked=y;
	document.forms[0].TC3.checked=y;
	}
if(x == 'el6')
	{
	document.forms[0].NM1.checked=y;
	document.forms[0].NM2.checked=y;
	document.forms[0].NM3.checked=y;
	}
if(x == 'el7')
	{
	document.forms[0].KB1.checked=y;
	document.forms[0].KB2.checked=y;
	document.forms[0].KB3.checked=y;
	document.forms[0].KB4.checked=y;
	document.forms[0].KB5.checked=y;
	document.forms[0].KB6.checked=y;
	}
if(x == 'el8')
	{
	document.forms[0].FM1.checked=y;
	document.forms[0].FM2.checked=y;
	document.forms[0].FM3.checked=y;
	document.forms[0].FM4.checked=false;
	}
if(x == 'el9')
	{
	document.forms[0].DM1.checked=y;
	document.forms[0].DM2.checked=y;
	document.forms[0].DM3.checked=y;
	document.forms[0].DM4.checked=y;
	document.forms[0].DM5.checked=y;
	document.forms[0].DM6.checked=y;
	document.forms[0].DM7.checked=y;
	document.forms[0].DM8.checked=y;
	document.forms[0].DM9.checked=y;
	document.forms[0].DM10.checked=y;
	document.forms[0].DM11.checked=y;
	document.forms[0].DM12.checked=y;
	document.forms[0].DM13.checked=y;
	document.forms[0].DM14.checked=y;
	}
if(x == 'el10')
	{
	document.forms[0].ADM.checked=y;
	document.forms[0].ADM1.checked=y;
	document.forms[0].ADM2.checked=y;
	document.forms[0].ADM3.checked=y;
	}
if(x == 'el11')
	{
	document.forms[0].UM1.checked=y;
	document.forms[0].UM2.checked=y;
	document.forms[0].UM3.checked=y;
	document.forms[0].UM4.checked=y;
	document.forms[0].UM5.checked=y;
	document.forms[0].UM6.checked=y;
	}
if(x == 'el12')
	{
	document.forms[0].BA1.checked=y;
	document.forms[0].BA2.checked=y;
	document.forms[0].BA3.checked=y;
	document.forms[0].BA4.checked=y;
	document.forms[0].BA5.checked=y;
	document.forms[0].BA6.checked=y;
	}
if(x == 'el13')
	{
	document.forms[0].AI1.checked=y;
	document.forms[0].AI2.checked=y;
	document.forms[0].AI3.checked=y;
	document.forms[0].AI4.checked=y;
	}
if(x == 'el14')
	{
	document.forms[0].MF1.checked=y;
	document.forms[0].MF2.checked=y;
	document.forms[0].MF3.checked=y;
	}
if(x == 'el15')
	{
	document.forms[0].PM1.checked=y;
	document.forms[0].PM2.checked=y;
	document.forms[0].PM3.checked=y;
	document.forms[0].PM4.checked=y;
	document.forms[0].PM5.checked=y;
	document.forms[0].PM6.checked=y;
	document.forms[0].PM7.checked=y;
	}
if(x == 'el16')
	{
	document.forms[0].MHS1.checked=y;
	document.forms[0].MHS2.checked=y;
	document.forms[0].MHS3.checked=y;
	document.forms[0].MHS4.checked=y;
	document.forms[0].MHS5.checked=y;
	document.forms[0].MHS6.checked=y;
	document.forms[0].MHS7.checked=y;
	document.forms[0].MHS8.checked=y;
	document.forms[0].MHS9.checked=y;
	document.forms[0].MHS10.checked=y;
	document.forms[0].MHS11.checked=y;
	document.forms[0].MHS12.checked=y;
	}
if(x == 'el17')
	{
	document.forms[0].MCI1.checked=y;
	document.forms[0].MCI2.checked=y;
	document.forms[0].MCI3.checked=y;
	document.forms[0].MCI4.checked=y;
	document.forms[0].MCI5.checked=y;
	document.forms[0].MCI6.checked=y;
	document.forms[0].MCI7.checked=y;
	document.forms[0].MCI8.checked=y;
	document.forms[0].MCI9.checked=y;
	document.forms[0].MCI10.checked=y;
	document.forms[0].MCI11.checked=y;
	document.forms[0].MCI12.checked=y;
	document.forms[0].MCI13.checked=y;
	document.forms[0].MCI14.checked=y;
	document.forms[0].MCI15.checked=y;
	document.forms[0].MCI16.checked=y;
	}
if(x == 'el18')
	{
	document.forms[0].MMS1.checked=y;
	document.forms[0].MMS2.checked=y;
	document.forms[0].MMS3.checked=y;
	document.forms[0].MMS4.checked=y;
	document.forms[0].MMS5.checked=y;
	document.forms[0].MMS6.checked=y;
	document.forms[0].MMS7.checked=y;
	document.forms[0].MMS8.checked=y;
	}
if(x == 'el19')
	{
	document.forms[0].MNS1.checked=y;
	document.forms[0].MNS2.checked=y;
	document.forms[0].MNS3.checked=y;
	document.forms[0].MNS4.checked=y;
	document.forms[0].MNS5.checked=y;
	}
if(x == 'el20')
	{
	document.forms[0].MSS1.checked=y;
	document.forms[0].MSS2.checked=y;
	document.forms[0].MSS3.checked=y;
	document.forms[0].MSS4.checked=y;
	document.forms[0].MSS5.checked=y;
	document.forms[0].MSS6.checked=y;
	}
if(x == 'el21')
	{
	document.forms[0].MSP1.checked=y;
	document.forms[0].MSP2.checked=y;
	document.forms[0].MSP3.checked=y;
	}
if(x == 'el22')
	{
	document.forms[0].NS1.checked=y;
	document.forms[0].NS2.checked=y;
	document.forms[0].NS3.checked=y;
	}
if(x == 'el23')
	{
	document.forms[0].MA1.checked=y;
	document.forms[0].MA2.checked=y;
	document.forms[0].MA3.checked=y;
	}
if(x == 'el24')
	{
	document.forms[0].AD1.checked=y;
	document.forms[0].AD2.checked=y;
	document.forms[0].AD3.checked=y;
	}
if(x == 'el25')
	{
	document.forms[0].SC1.checked=y;
	document.forms[0].SC2.checked=y;
	document.forms[0].SC3.checked=y;
	document.forms[0].SC4.checked=y;
	document.forms[0].SC5.checked=y;
	document.forms[0].SC6.checked=y;
	}
if(x == 'el26')
	{
	document.forms[0].MWS1.checked=y;
	document.forms[0].MWS2.checked=y;
	document.forms[0].MWS3.checked=y;
	document.forms[0].MWS4.checked=y;
	document.forms[0].MWS5.checked=y;
	document.forms[0].MWS6.checked=y;
	document.forms[0].MWS7.checked=y;
	}
if(x != 'el3')
	{
	if(y == true){ShowIt(x);}
	else{HideIt(x);}
	}
}
function SelectIt(x) {
if(x == 1)
	{
	document.forms[0].ST.checked=false;
	document.forms[0].ST1.checked=false;
	document.forms[0].ST2.checked=false;
	document.forms[0].ST3.checked=false;
	document.forms[0].ST4.checked=false;
	HideIt('el1');
	document.forms[0].SM.checked=false;
	document.forms[0].SM1.checked=false;
	document.forms[0].SM2.checked=false;
	document.forms[0].SM3.checked=false;
	document.forms[0].SM4.checked=false;
	document.forms[0].SM5.checked=false;
	HideIt('el2');
	document.forms[0].SS.checked=false;
	document.forms[0].Smon.checked=true;
	document.forms[0].Smon1.checked=true;
	document.forms[0].Smon2.checked=false;
	ShowIt('el4');
	document.forms[0].TC.checked=true;
	document.forms[0].TC1.checked=true;
	document.forms[0].TC2.checked=true;
	document.forms[0].TC3.checked=true;
	ShowIt('el5');
	document.forms[0].NM.checked=true;
	document.forms[0].NM1.checked=true;
	document.forms[0].NM2.checked=true;
	document.forms[0].NM3.checked=true;
	ShowIt('el6');
	document.forms[0].KB.checked=true;
	document.forms[0].KB1.checked=true;
	document.forms[0].KB2.checked=true;
	document.forms[0].KB3.checked=true;
	document.forms[0].KB4.checked=true;
	document.forms[0].KB5.checked=true;
	document.forms[0].KB6.checked=true;
	ShowIt('el7');
	document.forms[0].FM.checked=true;
	document.forms[0].FM1.checked=true;
	document.forms[0].FM2.checked=true;
	document.forms[0].FM3.checked=true;
	document.forms[0].FM4.checked=false;
	ShowIt('el8');
	document.forms[0].DM.checked=true;
	document.forms[0].DM1.checked=true;
	document.forms[0].DM2.checked=true;
	document.forms[0].DM3.checked=true;
	document.forms[0].DM4.checked=true;
	document.forms[0].DM5.checked=true;
	document.forms[0].DM6.checked=true;
	document.forms[0].DM7.checked=true;
	document.forms[0].DM8.checked=true;
	document.forms[0].DM9.checked=true;
	document.forms[0].DM10.checked=true;
	document.forms[0].DM11.checked=true;
	document.forms[0].DM12.checked=true;
	document.forms[0].DM13.checked=true;
	document.forms[0].DM14.checked=true;
	ShowIt('el9');
	document.forms[0].ADM.checked=false;
	document.forms[0].ADM1.checked=false;
	document.forms[0].ADM2.checked=false;
	document.forms[0].ADM3.checked=false;
	HideIt('el10');
	document.forms[0].UM.checked=true;
	document.forms[0].UM1.checked=true;
	document.forms[0].UM2.checked=true;
	document.forms[0].UM3.checked=true;
	document.forms[0].UM4.checked=true;
	document.forms[0].UM5.checked=true;
	document.forms[0].UM6.checked=true;
	ShowIt('el11');
	document.forms[0].BA.checked=false;
	document.forms[0].BA1.checked=false;
	document.forms[0].BA2.checked=false;
	document.forms[0].BA3.checked=false;
	document.forms[0].BA4.checked=false;
	document.forms[0].BA5.checked=false;
	document.forms[0].BA6.checked=false;
	HideIt('el12');
	document.forms[0].AI.checked=true;
	document.forms[0].AI1.checked=true;
	document.forms[0].AI2.checked=true;
	document.forms[0].AI3.checked=true;
	document.forms[0].AI4.checked=true;
	ShowIt('el13');
	document.forms[0].MF.checked=true;
	document.forms[0].MF1.checked=true;
	document.forms[0].MF2.checked=true;
	document.forms[0].MF3.checked=true;
	ShowIt('el14');
	document.forms[0].PM.checked=false;
	document.forms[0].PM1.checked=false;
	document.forms[0].PM2.checked=false;
	document.forms[0].PM3.checked=false;
	document.forms[0].PM4.checked=false;
	document.forms[0].PM5.checked=false;
	document.forms[0].PM6.checked=false;
	document.forms[0].PM7.checked=false;
	HideIt('el15');
	document.forms[0].MHS.checked=false;
	document.forms[0].MHS1.checked=false;
	document.forms[0].MHS2.checked=false;
	document.forms[0].MHS3.checked=false;
	document.forms[0].MHS4.checked=false;
	document.forms[0].MHS5.checked=false;
	document.forms[0].MHS6.checked=false;
	document.forms[0].MHS7.checked=false;
	document.forms[0].MHS8.checked=false;
	document.forms[0].MHS9.checked=false;
	document.forms[0].MHS10.checked=false;
	document.forms[0].MHS11.checked=false;
	document.forms[0].MHS12.checked=false;
	HideIt('el16');
	document.forms[0].MCI.checked=false;
	document.forms[0].MCI1.checked=false;
	document.forms[0].MCI2.checked=false;
	document.forms[0].MCI3.checked=false;
	document.forms[0].MCI4.checked=false;
	document.forms[0].MCI5.checked=false;
	document.forms[0].MCI6.checked=false;
	document.forms[0].MCI7.checked=false;
	document.forms[0].MCI8.checked=false;
	document.forms[0].MCI9.checked=false;
	document.forms[0].MCI10.checked=false;
	document.forms[0].MCI11.checked=false;
	document.forms[0].MCI12.checked=false;
	document.forms[0].MCI13.checked=false;
	document.forms[0].MCI14.checked=false;
	document.forms[0].MCI15.checked=false;
	document.forms[0].MCI16.checked=false;
	HideIt('el17');
	document.forms[0].MMS.checked=false;
	document.forms[0].MMS1.checked=false;
	document.forms[0].MMS2.checked=false;
	document.forms[0].MMS3.checked=false;
	document.forms[0].MMS4.checked=false;
	document.forms[0].MMS5.checked=false;
	document.forms[0].MMS6.checked=false;
	document.forms[0].MMS7.checked=false;
	document.forms[0].MMS8.checked=false;
	HideIt('el18');
	document.forms[0].MNS.checked=false;
	document.forms[0].MNS1.checked=false;
	document.forms[0].MNS2.checked=false;
	document.forms[0].MNS3.checked=false;
	document.forms[0].MNS4.checked=false;
	document.forms[0].MNS5.checked=false;
	HideIt('el19');
	document.forms[0].MSS.checked=false;
	document.forms[0].MSS1.checked=false;
	document.forms[0].MSS2.checked=false;
	document.forms[0].MSS3.checked=false;
	document.forms[0].MSS4.checked=false;
	document.forms[0].MSS5.checked=false;
	document.forms[0].MSS6.checked=false;
	HideIt('el20');
	document.forms[0].MSP.checked=false;
	document.forms[0].MSP1.checked=false;
	document.forms[0].MSP2.checked=false;
	document.forms[0].MSP3.checked=false;
	HideIt('el21');
	document.forms[0].NS.checked=false;
	document.forms[0].NS1.checked=false;
	document.forms[0].NS2.checked=false;
	document.forms[0].NS3.checked=false;
	HideIt('el22');
	document.forms[0].MA.checked=false;
	document.forms[0].MA1.checked=false;
	document.forms[0].MA2.checked=false;
	document.forms[0].MA3.checked=false;
	HideIt('el23');
	document.forms[0].AD.checked=false;
	document.forms[0].AD1.checked=false;
	document.forms[0].AD2.checked=false;
	document.forms[0].AD3.checked=false;
	HideIt('el24');
	document.forms[0].SC.checked=false;
	document.forms[0].SC1.checked=false;
	document.forms[0].SC2.checked=false;
	document.forms[0].SC3.checked=false;
	document.forms[0].SC4.checked=false;
	document.forms[0].SC5.checked=false;
	document.forms[0].SC6.checked=false;
	HideIt('el25');
	document.forms[0].MWS1.checked=false;
	document.forms[0].MWS2.checked=false;
	document.forms[0].MWS3.checked=false;
	document.forms[0].MWS4.checked=false;
	document.forms[0].MWS5.checked=false;
	document.forms[0].MWS6.checked=false;
	document.forms[0].MWS7.checked=false;
	HideIt('el26');
	}
if(x == 2)
	{
	document.forms[0].ST.checked=false;
	document.forms[0].ST1.checked=false;
	document.forms[0].ST2.checked=false;
	document.forms[0].ST3.checked=false;
	document.forms[0].ST4.checked=false;
	HideIt('el1');
	document.forms[0].SM.checked=false;
	document.forms[0].SM1.checked=false;
	document.forms[0].SM2.checked=false;
	document.forms[0].SM3.checked=false;
	document.forms[0].SM4.checked=false;
	document.forms[0].SM5.checked=false;
	HideIt('el2');
	document.forms[0].SS.checked=false;
	document.forms[0].Smon.checked=false;
	document.forms[0].Smon1.checked=false;
	document.forms[0].Smon2.checked=false;
	HideIt('el4');
	document.forms[0].TC.checked=true;
	document.forms[0].TC1.checked=true;
	document.forms[0].TC2.checked=true;
	document.forms[0].TC3.checked=true;
	ShowIt('el5');
	document.forms[0].NM.checked=false;
	document.forms[0].NM1.checked=false;
	document.forms[0].NM2.checked=false;
	document.forms[0].NM3.checked=false;
	HideIt('el6');
	document.forms[0].KB.checked=false;
	document.forms[0].KB1.checked=false;
	document.forms[0].KB2.checked=false;
	document.forms[0].KB3.checked=false;
	document.forms[0].KB4.checked=false;
	document.forms[0].KB5.checked=false;
	document.forms[0].KB6.checked=false;
	HideIt('el7');
	document.forms[0].FM.checked=false;
	document.forms[0].FM1.checked=false;
	document.forms[0].FM2.checked=false;
	document.forms[0].FM3.checked=false;
	document.forms[0].FM4.checked=false;
	HideIt('el8');
	document.forms[0].DM.checked=false;
	document.forms[0].DM1.checked=false;
	document.forms[0].DM2.checked=false;
	document.forms[0].DM3.checked=false;
	document.forms[0].DM4.checked=false;
	document.forms[0].DM5.checked=false;
	document.forms[0].DM6.checked=false;
	document.forms[0].DM7.checked=false;
	document.forms[0].DM8.checked=false;
	document.forms[0].DM9.checked=false;
	document.forms[0].DM10.checked=false;
	document.forms[0].DM11.checked=false;
	document.forms[0].DM12.checked=false;
	document.forms[0].DM13.checked=false;
	document.forms[0].DM14.checked=false;
	HideIt('el9');
	document.forms[0].ADM.checked=false;
	document.forms[0].ADM1.checked=false;
	document.forms[0].ADM2.checked=false;
	document.forms[0].ADM3.checked=false;
	HideIt('el10');
	document.forms[0].UM.checked=false;
	document.forms[0].UM1.checked=false;
	document.forms[0].UM2.checked=false;
	document.forms[0].UM3.checked=false;
	document.forms[0].UM4.checked=false;
	document.forms[0].UM5.checked=false;
	document.forms[0].UM6.checked=false;
	HideIt('el11');
	document.forms[0].BA.checked=true;
	document.forms[0].BA1.checked=true;
	document.forms[0].BA2.checked=true;
	document.forms[0].BA3.checked=true;
	document.forms[0].BA4.checked=true;
	document.forms[0].BA5.checked=true;
	document.forms[0].BA6.checked=true;
	ShowIt('el12');
	document.forms[0].AI.checked=true;
	document.forms[0].AI1.checked=true;
	document.forms[0].AI2.checked=true;
	document.forms[0].AI3.checked=true;
	document.forms[0].AI4.checked=true;
	ShowIt('el13');
	document.forms[0].MF.checked=true;
	document.forms[0].MF1.checked=true;
	document.forms[0].MF2.checked=true;
	document.forms[0].MF3.checked=true;
	ShowIt('el14');
	document.forms[0].PM.checked=false;
	document.forms[0].PM1.checked=false;
	document.forms[0].PM2.checked=false;
	document.forms[0].PM3.checked=false;
	document.forms[0].PM4.checked=false;
	document.forms[0].PM5.checked=false;
	document.forms[0].PM6.checked=false;
	document.forms[0].PM7.checked=false;
	HideIt('el15');
	document.forms[0].MHS.checked=false;
	document.forms[0].MHS1.checked=false;
	document.forms[0].MHS2.checked=false;
	document.forms[0].MHS3.checked=false;
	document.forms[0].MHS4.checked=false;
	document.forms[0].MHS5.checked=false;
	document.forms[0].MHS6.checked=false;
	document.forms[0].MHS7.checked=false;
	document.forms[0].MHS8.checked=false;
	document.forms[0].MHS9.checked=false;
	document.forms[0].MHS10.checked=false;
	document.forms[0].MHS11.checked=false;
	document.forms[0].MHS12.checked=false;
	HideIt('el16');
	document.forms[0].MCI.checked=false;
	document.forms[0].MCI1.checked=false;
	document.forms[0].MCI2.checked=false;
	document.forms[0].MCI3.checked=false;
	document.forms[0].MCI4.checked=false;
	document.forms[0].MCI5.checked=false;
	document.forms[0].MCI6.checked=false;
	document.forms[0].MCI7.checked=false;
	document.forms[0].MCI8.checked=false;
	document.forms[0].MCI9.checked=false;
	document.forms[0].MCI10.checked=false;
	document.forms[0].MCI11.checked=false;
	document.forms[0].MCI12.checked=false;
	document.forms[0].MCI13.checked=false;
	document.forms[0].MCI14.checked=false;
	document.forms[0].MCI15.checked=false;
	document.forms[0].MCI16.checked=false;
	HideIt('el17');
	document.forms[0].MMS.checked=false;
	document.forms[0].MMS1.checked=false;
	document.forms[0].MMS2.checked=false;
	document.forms[0].MMS3.checked=false;
	document.forms[0].MMS4.checked=false;
	document.forms[0].MMS5.checked=false;
	document.forms[0].MMS6.checked=false;
	document.forms[0].MMS7.checked=false;
	document.forms[0].MMS8.checked=false;
	HideIt('el18');
	document.forms[0].MNS.checked=false;
	document.forms[0].MNS1.checked=false;
	document.forms[0].MNS2.checked=false;
	document.forms[0].MNS3.checked=false;
	document.forms[0].MNS4.checked=false;
	document.forms[0].MNS5.checked=false;
	HideIt('el19');
	document.forms[0].MSS.checked=false;
	document.forms[0].MSS1.checked=false;
	document.forms[0].MSS2.checked=false;
	document.forms[0].MSS3.checked=false;
	document.forms[0].MSS4.checked=false;
	document.forms[0].MSS5.checked=false;
	document.forms[0].MSS6.checked=false;
	HideIt('el20');
	document.forms[0].MSP.checked=false;
	document.forms[0].MSP1.checked=false;
	document.forms[0].MSP2.checked=false;
	document.forms[0].MSP3.checked=false;
	HideIt('el21');
	document.forms[0].NS.checked=false;
	document.forms[0].NS1.checked=false;
	document.forms[0].NS2.checked=false;
	document.forms[0].NS3.checked=false;
	HideIt('el22');
	document.forms[0].MA.checked=false;
	document.forms[0].MA1.checked=false;
	document.forms[0].MA2.checked=false;
	document.forms[0].MA3.checked=false;
	HideIt('el23');
	document.forms[0].AD.checked=false;
	document.forms[0].AD1.checked=false;
	document.forms[0].AD2.checked=false;
	document.forms[0].AD3.checked=false;
	HideIt('el24');
	document.forms[0].SC.checked=false;
	document.forms[0].SC1.checked=false;
	document.forms[0].SC2.checked=false;
	document.forms[0].SC3.checked=false;
	document.forms[0].SC4.checked=false;
	document.forms[0].SC5.checked=false;
	document.forms[0].SC6.checked=false;
	HideIt('el25');
	document.forms[0].MWS1.checked=false;
	document.forms[0].MWS2.checked=false;
	document.forms[0].MWS3.checked=false;
	document.forms[0].MWS4.checked=false;
	document.forms[0].MWS5.checked=false;
	document.forms[0].MWS6.checked=false;
	document.forms[0].MWS7.checked=false;
	HideIt('el26');
	}
if(x == 3)
	{
	document.forms[0].ST.checked=true;
	document.forms[0].ST1.checked=true;
	document.forms[0].ST2.checked=true;
	document.forms[0].ST3.checked=true;
	document.forms[0].ST4.checked=true;
	ShowIt('el1');
	document.forms[0].SM.checked=true;
	document.forms[0].SM1.checked=true;
	document.forms[0].SM2.checked=true;
	document.forms[0].SM3.checked=true;
	document.forms[0].SM4.checked=true;
	document.forms[0].SM5.checked=true;
	ShowIt('el2');
	document.forms[0].SS.checked=true;
	document.forms[0].Smon.checked=true;
	document.forms[0].Smon1.checked=true;
	document.forms[0].Smon2.checked=false;
	ShowIt('el4');
	document.forms[0].TC.checked=true;
	document.forms[0].TC1.checked=true;
	document.forms[0].TC2.checked=true;
	document.forms[0].TC3.checked=true;
	ShowIt('el5');
	document.forms[0].NM.checked=true;
	document.forms[0].NM1.checked=true;
	document.forms[0].NM2.checked=true;
	document.forms[0].NM3.checked=true;
	ShowIt('el6');
	document.forms[0].KB.checked=true;
	document.forms[0].KB1.checked=true;
	document.forms[0].KB2.checked=true;
	document.forms[0].KB3.checked=true;
	document.forms[0].KB4.checked=true;
	document.forms[0].KB5.checked=true;
	document.forms[0].KB6.checked=true;
	ShowIt('el7');
	document.forms[0].FM.checked=true;
	document.forms[0].FM1.checked=true;
	document.forms[0].FM2.checked=true;
	document.forms[0].FM3.checked=true;
	document.forms[0].FM4.checked=false;
	ShowIt('el8');
	document.forms[0].DM.checked=true;
	document.forms[0].DM1.checked=true;
	document.forms[0].DM2.checked=true;
	document.forms[0].DM3.checked=true;
	document.forms[0].DM4.checked=true;
	document.forms[0].DM5.checked=true;
	document.forms[0].DM6.checked=true;
	document.forms[0].DM7.checked=true;
	document.forms[0].DM8.checked=true;
	document.forms[0].DM9.checked=true;
	document.forms[0].DM10.checked=true;
	document.forms[0].DM11.checked=true;
	document.forms[0].DM12.checked=true;
	document.forms[0].DM13.checked=true;
	document.forms[0].DM14.checked=true;
	ShowIt('el9');
	document.forms[0].ADM.checked=true;
	document.forms[0].ADM1.checked=true;
	document.forms[0].ADM2.checked=true;
	document.forms[0].ADM3.checked=true;
	ShowIt('el10');
	document.forms[0].UM.checked=true;
	document.forms[0].UM1.checked=true;
	document.forms[0].UM2.checked=true;
	document.forms[0].UM3.checked=true;
	document.forms[0].UM4.checked=true;
	document.forms[0].UM5.checked=true;
	document.forms[0].UM6.checked=true;
	ShowIt('el11');
	document.forms[0].BA.checked=false;
	document.forms[0].BA1.checked=false;
	document.forms[0].BA2.checked=false;
	document.forms[0].BA3.checked=false;
	document.forms[0].BA4.checked=false;
	document.forms[0].BA5.checked=false;
	document.forms[0].BA6.checked=false;
	HideIt('el12');
	document.forms[0].AI.checked=true;
	document.forms[0].AI1.checked=true;
	document.forms[0].AI2.checked=true;
	document.forms[0].AI3.checked=true;
	document.forms[0].AI4.checked=true;
	ShowIt('el13');
	document.forms[0].MF.checked=true;
	document.forms[0].MF1.checked=true;
	document.forms[0].MF2.checked=true;
	document.forms[0].MF3.checked=true;
	ShowIt('el14');
	document.forms[0].PM.checked=false;
	document.forms[0].PM1.checked=false;
	document.forms[0].PM2.checked=false;
	document.forms[0].PM3.checked=false;
	document.forms[0].PM4.checked=false;
	document.forms[0].PM5.checked=false;
	document.forms[0].PM6.checked=false;
	document.forms[0].PM7.checked=false;
	HideIt('el15');
	document.forms[0].MHS.checked=false;
	document.forms[0].MHS1.checked=false;
	document.forms[0].MHS2.checked=false;
	document.forms[0].MHS3.checked=false;
	document.forms[0].MHS4.checked=false;
	document.forms[0].MHS5.checked=false;
	document.forms[0].MHS6.checked=false;
	document.forms[0].MHS7.checked=false;
	document.forms[0].MHS8.checked=false;
	document.forms[0].MHS9.checked=false;
	document.forms[0].MHS10.checked=false;
	document.forms[0].MHS11.checked=false;
	document.forms[0].MHS12.checked=false;
	HideIt('el16');
	document.forms[0].MCI.checked=false;
	document.forms[0].MCI1.checked=false;
	document.forms[0].MCI2.checked=false;
	document.forms[0].MCI3.checked=false;
	document.forms[0].MCI4.checked=false;
	document.forms[0].MCI5.checked=false;
	document.forms[0].MCI6.checked=false;
	document.forms[0].MCI7.checked=false;
	document.forms[0].MCI8.checked=false;
	document.forms[0].MCI9.checked=false;
	document.forms[0].MCI10.checked=false;
	document.forms[0].MCI11.checked=false;
	document.forms[0].MCI12.checked=false;
	document.forms[0].MCI13.checked=false;
	document.forms[0].MCI14.checked=false;
	document.forms[0].MCI15.checked=false;
	document.forms[0].MCI16.checked=false;
	HideIt('el17');
	document.forms[0].MMS.checked=false;
	document.forms[0].MMS1.checked=false;
	document.forms[0].MMS2.checked=false;
	document.forms[0].MMS3.checked=false;
	document.forms[0].MMS4.checked=false;
	document.forms[0].MMS5.checked=false;
	document.forms[0].MMS6.checked=false;
	document.forms[0].MMS7.checked=false;
	document.forms[0].MMS8.checked=false;
	HideIt('el18');
	document.forms[0].MNS.checked=false;
	document.forms[0].MNS1.checked=false;
	document.forms[0].MNS2.checked=false;
	document.forms[0].MNS3.checked=false;
	document.forms[0].MNS4.checked=false;
	document.forms[0].MNS5.checked=false;
	HideIt('el19');
	document.forms[0].MSS.checked=false;
	document.forms[0].MSS1.checked=false;
	document.forms[0].MSS2.checked=false;
	document.forms[0].MSS3.checked=false;
	document.forms[0].MSS4.checked=false;
	document.forms[0].MSS5.checked=false;
	document.forms[0].MSS6.checked=false;
	HideIt('el20');
	document.forms[0].MSP.checked=false;
	document.forms[0].MSP1.checked=false;
	document.forms[0].MSP2.checked=false;
	document.forms[0].MSP3.checked=false;
	HideIt('el21');
	document.forms[0].NS.checked=false;
	document.forms[0].NS1.checked=false;
	document.forms[0].NS2.checked=false;
	document.forms[0].NS3.checked=false;
	HideIt('el22');
	document.forms[0].MA.checked=false;
	document.forms[0].MA1.checked=false;
	document.forms[0].MA2.checked=false;
	document.forms[0].MA3.checked=false;
	HideIt('el23');
	document.forms[0].AD.checked=false;
	document.forms[0].AD1.checked=false;
	document.forms[0].AD2.checked=false;
	document.forms[0].AD3.checked=false;
	HideIt('el24');
	document.forms[0].SC.checked=false;
	document.forms[0].SC1.checked=false;
	document.forms[0].SC2.checked=false;
	document.forms[0].SC3.checked=false;
	document.forms[0].SC4.checked=false;
	document.forms[0].SC5.checked=false;
	document.forms[0].SC6.checked=false;
	HideIt('el25');
	document.forms[0].MWS1.checked=false;
	document.forms[0].MWS2.checked=false;
	document.forms[0].MWS3.checked=false;
	document.forms[0].MWS4.checked=false;
	document.forms[0].MWS5.checked=false;
	document.forms[0].MWS6.checked=false;
	document.forms[0].MWS7.checked=false;
	HideIt('el26');
	}
if(x == 4 || x == 0)
	{
	document.forms[0].ST.checked=false;
	document.forms[0].ST1.checked=false;
	document.forms[0].ST2.checked=false;
	document.forms[0].ST3.checked=false;
	document.forms[0].ST4.checked=false;
	document.forms[0].SM.checked=false;
	document.forms[0].SM1.checked=false;
	document.forms[0].SM2.checked=false;
	document.forms[0].SM3.checked=false;
	document.forms[0].SM4.checked=false;
	document.forms[0].SM5.checked=false;
	document.forms[0].SS.checked=false;
	document.forms[0].Smon.checked=false;
	document.forms[0].Smon1.checked=false;
	document.forms[0].Smon2.checked=false;
	document.forms[0].TC.checked=false;
	document.forms[0].TC1.checked=false;
	document.forms[0].TC2.checked=false;
	document.forms[0].TC3.checked=false;
	document.forms[0].NM.checked=false;
	document.forms[0].NM1.checked=false;
	document.forms[0].NM2.checked=false;
	document.forms[0].NM3.checked=false;
	document.forms[0].KB.checked=false;
	document.forms[0].KB1.checked=false;
	document.forms[0].KB2.checked=false;
	document.forms[0].KB3.checked=false;
	document.forms[0].KB4.checked=false;
	document.forms[0].KB5.checked=false;
	document.forms[0].KB6.checked=false;
	document.forms[0].FM.checked=false;
	document.forms[0].FM1.checked=false;
	document.forms[0].FM2.checked=false;
	document.forms[0].FM3.checked=false;
	document.forms[0].FM4.checked=false;
	document.forms[0].DM.checked=false;
	document.forms[0].DM1.checked=false;
	document.forms[0].DM2.checked=false;
	document.forms[0].DM3.checked=false;
	document.forms[0].DM4.checked=false;
	document.forms[0].DM5.checked=false;
	document.forms[0].DM6.checked=false;
	document.forms[0].DM7.checked=false;
	document.forms[0].DM8.checked=false;
	document.forms[0].DM9.checked=false;
	document.forms[0].DM10.checked=false;
	document.forms[0].DM11.checked=false;
	document.forms[0].DM12.checked=false;
	document.forms[0].DM13.checked=false;
	document.forms[0].DM14.checked=false;
	document.forms[0].ADM.checked=false;
	document.forms[0].ADM1.checked=false;
	document.forms[0].ADM2.checked=false;
	document.forms[0].ADM3.checked=false;
	document.forms[0].UM.checked=false;
	document.forms[0].UM1.checked=false;
	document.forms[0].UM2.checked=false;
	document.forms[0].UM3.checked=false;
	document.forms[0].UM4.checked=false;
	document.forms[0].UM5.checked=false;
	document.forms[0].UM6.checked=false;
	document.forms[0].BA.checked=false;
	document.forms[0].BA1.checked=false;
	document.forms[0].BA2.checked=false;
	document.forms[0].BA3.checked=false;
	document.forms[0].BA4.checked=false;
	document.forms[0].BA5.checked=false;
	document.forms[0].BA6.checked=false;
	document.forms[0].AI.checked=false;
	document.forms[0].AI1.checked=false;
	document.forms[0].AI2.checked=false;
	document.forms[0].AI3.checked=false;
	document.forms[0].AI4.checked=false;
	document.forms[0].MF.checked=false;
	document.forms[0].MF1.checked=false;
	document.forms[0].MF2.checked=false;
	document.forms[0].MF3.checked=false;
	document.forms[0].PM.checked=false;
	document.forms[0].PM1.checked=false;
	document.forms[0].PM2.checked=false;
	document.forms[0].PM3.checked=false;
	document.forms[0].PM4.checked=false;
	document.forms[0].PM5.checked=false;
	document.forms[0].PM6.checked=false;
	document.forms[0].PM7.checked=false;
	document.forms[0].MHS.checked=false;
	document.forms[0].MHS1.checked=false;
	document.forms[0].MHS2.checked=false;
	document.forms[0].MHS3.checked=false;
	document.forms[0].MHS4.checked=false;
	document.forms[0].MHS5.checked=false;
	document.forms[0].MHS6.checked=false;
	document.forms[0].MHS7.checked=false;
	document.forms[0].MHS8.checked=false;
	document.forms[0].MHS9.checked=false;
	document.forms[0].MHS10.checked=false;
	document.forms[0].MHS11.checked=false;
	document.forms[0].MHS12.checked=false;
	document.forms[0].MCI.checked=false;
	document.forms[0].MCI1.checked=false;
	document.forms[0].MCI2.checked=false;
	document.forms[0].MCI3.checked=false;
	document.forms[0].MCI4.checked=false;
	document.forms[0].MCI5.checked=false;
	document.forms[0].MCI6.checked=false;
	document.forms[0].MCI7.checked=false;
	document.forms[0].MCI8.checked=false;
	document.forms[0].MCI9.checked=false;
	document.forms[0].MCI10.checked=false;
	document.forms[0].MCI11.checked=false;
	document.forms[0].MCI12.checked=false;
	document.forms[0].MCI13.checked=false;
	document.forms[0].MCI14.checked=false;
	document.forms[0].MCI15.checked=false;
	document.forms[0].MCI16.checked=false;
	document.forms[0].MMS.checked=false;
	document.forms[0].MMS1.checked=false;
	document.forms[0].MMS2.checked=false;
	document.forms[0].MMS3.checked=false;
	document.forms[0].MMS4.checked=false;
	document.forms[0].MMS5.checked=false;
	document.forms[0].MMS6.checked=false;
	document.forms[0].MMS7.checked=false;
	document.forms[0].MMS8.checked=false;
	document.forms[0].MNS.checked=false;
	document.forms[0].MNS1.checked=false;
	document.forms[0].MNS2.checked=false;
	document.forms[0].MNS3.checked=false;
	document.forms[0].MNS4.checked=false;
	document.forms[0].MNS5.checked=false;
	document.forms[0].MSS.checked=false;
	document.forms[0].MSS1.checked=false;
	document.forms[0].MSS2.checked=false;
	document.forms[0].MSS3.checked=false;
	document.forms[0].MSS4.checked=false;
	document.forms[0].MSS5.checked=false;
	document.forms[0].MSS6.checked=false;
	document.forms[0].MSP.checked=false;
	document.forms[0].MSP1.checked=false;
	document.forms[0].MSP2.checked=false;
	document.forms[0].MSP3.checked=false;
	document.forms[0].MA.checked=false;
	document.forms[0].MA1.checked=false;
	document.forms[0].MA2.checked=false;
	document.forms[0].MA3.checked=false;
	document.forms[0].SC.checked=false;
	document.forms[0].SC1.checked=false;
	document.forms[0].SC2.checked=false;
	document.forms[0].SC3.checked=false;
	document.forms[0].SC4.checked=false;
	document.forms[0].SC5.checked=false;
	document.forms[0].SC6.checked=false;
	document.forms[0].NS.checked=false;
	document.forms[0].NS1.checked=false;
	document.forms[0].NS2.checked=false;
	document.forms[0].NS3.checked=false;
	document.forms[0].AD.checked=false;
	document.forms[0].AD1.checked=false;
	document.forms[0].AD2.checked=false;
	document.forms[0].AD3.checked=false;
	document.forms[0].MWS.checked=false;
	document.forms[0].MWS1.checked=false;
	document.forms[0].MWS2.checked=false;
	document.forms[0].MWS3.checked=false;
	document.forms[0].MWS4.checked=false;
	document.forms[0].MWS5.checked=false;
	document.forms[0].MWS6.checked=false;
	document.forms[0].MWS7.checked=false;
	initIt();
	if(x == 4)
		{
		alert("Global Administrators have full access to the entire system no matter the independant settings");
		return;
		}
	}
}
function expandIt(el) {
	if (!ver4) return;
	if (IE4) {expandIE(el)}
	else if (NS4) {expandNS(el)}
	else {expandDOM(el)}
}

function expandIE(el) { 
	whichEl = eval(el);
	if (whichEl.style.display == "none") {
		whichEl.style.display = "block";
	}
	else {
		whichEl.style.display = "none";
	}
    window.event.cancelBubble = true ;
}

function expandDOM(el) {
	whichEl=document.getElementById(el);
	if(whichEl.style.display == "none") {
		whichEl.style.display="block";
		}
	else
		{
		whichEl.style.display="none";
		}
	}

function expandNS(el) {
	whichEl = eval("document." + el);
	whichIm = eval("document." + el + "Parent.document.images['imEx']");
	if (whichEl.visibility == "hide") {
		whichEl.visibility = "show";
	}
	else {
		whichEl.visibility = "hide";
	}
	arrange();
}
// -->
</script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Administrator $FORM{'user'}</td></tr>
<tr><td class="prgout" align=left>Level</td>
<td class="prgout" align=left><select name="level" onChange="SelectIt(this.options.selectedIndex)";><option value="">--Select Level--
<option value="">Technician<option value="">Accounting<option value="">System Administrator<option value="1">Global Administrator</select></td></tr>
<tr><td class="headb" align=center colspan=2><A HREF="#" onClick="expandIt('advanced');" class="prgout">Advanced Settings</A></td></tr>
<tr><td colspan=2><div id="advanced" style="display:none;visibility:hide;">
<table align=center border=0 cellpadding=2 cellspacing=2 width=100%>
<tr><td class="headb" align=center colspan=2>Access Specifics</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="ST" type="checkbox" value="yes" onClick="CheckIt('el1',this.checked);");
if($user{'ST'} eq "yes"){print qq( checked);}
print qq(>Server Tasks</td>
<td class="prgout" align=left><div id="el1Child" class="child" style="display:none;visibility:hide;">
<input name="ST1" type="checkbox" value="yes");
if($user{'ST1'} eq "yes"){print qq( checked);}
print qq(>Daemon Management<br>
<input name="ST2" type="checkbox" value="yes");
if($user{'ST2'} eq "yes"){print qq( checked);}
print qq(>Server Date/Time<br>
<input name="ST3" type="checkbox" value="yes");
if($user{'ST3'} eq "yes"){print qq( checked);}
print qq(>Manage IP Aliases<br>
<input name="ST4" type="checkbox" value="yes");
if($user{'ST4'} eq "yes"){print qq( checked);}
print qq(>Manage Root Crons</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="SM" type="checkbox" value="yes" onClick="CheckIt('el2',this.checked);");
if($user{'SM'} eq "yes"){print qq( checked);}
print qq(>Security Management</td>
<td class="prgout" align=left><div id="el2Child" class="child" style="display:none;visibility:hide;">
<input name="SM1" type="checkbox" value="yes");
if($user{'SM1'} eq "yes"){print qq( checked);}
print qq(>List Open Ports<br>
<input name="SM2" type="checkbox" value="yes");
if($user{'SM2'} eq "yes"){print qq( checked);}
print qq(>View Firewall Rules<br>
<input name="SM3" type="checkbox" value="yes");
if($user{'SM3'} eq "yes"){print qq( checked);}
print qq(>Manage Firewall<br>
<input name="SM4" type="checkbox" value="yes");
if($user{'SM4'} eq "yes"){print qq( checked);}
print qq(>View Filecheck Output<br>
<input name="SM5" type="checkbox" value="yes");
if($user{'SM5'} eq "yes"){print qq( checked);}
print qq(>Configure Filecheck</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left><input name="SS" type="checkbox" value="yes" onClick="CheckIt('el3',this.checked);");
if($user{'SS'} eq "yes"){print qq( checked);}
print qq(>Select Server</td>
<td class="prgout" align=left>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="Smon" type="checkbox" value="yes" onClick="CheckIt('el4',this.checked);");
if($user{'Smon'} eq "yes"){print qq( checked);}
print qq(>Server Monitor</td>
<td class="prgout" align=left><div id="el4Child" class="child" style="display:none;visibility:hide;">
<input name="Smon1" type="checkbox" value="yes");
if($user{'Smon1'} eq "yes"){print qq( checked);}
print qq(>Services Monitor<br>
<input name="Smon2" type="checkbox" value="yes");
if($user{'Smon2'} eq "yes"){print qq( checked);}
print qq(>Install Monitor</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="TC" type="checkbox" value="yes" onClick="CheckIt('el5',this.checked);");
if($user{'TC'} eq "yes"){print qq( checked);}
print qq(>Ticket Center</td>
<td class="prgout" align=left><div id="el5Child" class="child" style="display:none;visibility:hide;">
<input name="TC1" type="checkbox" value="yes");
if($user{'TC1'} eq "yes"){print qq( checked);}
print qq(>View Tickets<br>
<input name="TC2" type="checkbox" value="yes");
if($user{'TC2'} eq "yes"){print qq( checked);}
print qq(>View History<br>
<input name="TC3" type="checkbox" value="yes");
if($user{'TC3'} eq "yes"){print qq( checked);}
print qq(>Add Ticket</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="NM" type="checkbox" value="yes" onClick="CheckIt('el6',this.checked);");
if($user{'NM'} eq "yes"){print qq( checked);}
print qq(>News Management</td>
<td class="prgout" align=left><div id="el6Child" class="child" style="display:none;visibility:hide;">
<input name="NM1" type="checkbox" value="yes");
if($user{'NM1'} eq "yes"){print qq( checked);}
print qq(>Add News<br>
<input name="NM2" type="checkbox" value="yes");
if($user{'NM2'} eq "yes"){print qq( checked);}
print qq(>Edit News<br>
<input name="NM3" type="checkbox" value="yes");
if($user{'NM3'} eq "yes"){print qq( checked);}
print qq(>Remove News</div>&nbsp;</td></tr>
<tr><td class="prgout" LIGN=left Valign=top><input name="KB" type="checkbox" value="yes" onClick="CheckIt('el7',this.checked);");
if($user{'KB'} eq "yes"){print qq( checked);}
print qq(>Knowledge Base</td>
<td class="prgout" align=left><div id="el7Child" class="child" style="display:none;visibility:hide;">
<input name="KB1" type="checkbox" value="yes");
if($user{'KB1'} eq "yes"){print qq( checked);}
print qq(>Add Entry<br>
<input name="KB2" type="checkbox" value="yes");
if($user{'KB2'} eq "yes"){print qq( checked);}
print qq(>Edit Entry<br>
<input name="KB3" type="checkbox" value="yes");
if($user{'KB3'} eq "yes"){print qq( checked);}
print qq(>Remove Entry<br>
<input name="KB4" type="checkbox" value="yes");
if($user{'KB4'} eq "yes"){print qq( checked);}
print qq(>Add Category<br>
<input name="KB5" type="checkbox" value="yes");
if($user{'KB5'} eq "yes"){print qq( checked);}
print qq(>Edit Category<br>
<input name="KB6" type="checkbox" value="yes");
if($user{'KB6'} eq "yes"){print qq( checked);}
print qq(>Remove Category</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="FM" type="checkbox" value="yes" onClick="CheckIt('el8',this.checked);");
if($user{'FM'} eq "yes"){print qq( checked);}
print qq(>Fraudscreen Management</td>
<td class="prgout" align=left><div id="el8Child" class="child" style="display:none;visibility:hide;">
<input name="FM1" type="checkbox" value="yes");
if($user{'FM1'} eq "yes"){print qq( checked);}
print qq(>Add Fraudscreen Entry<br>
<input name="FM2" type="checkbox" value="yes");
if($user{'FM2'} eq "yes"){print qq( checked);}
print qq(>Remove Fraudscreen Entry<br>
<input name="FM3" type="checkbox" value="yes");
if($user{'FM3'} eq "yes"){print qq( checked);}
print qq(>Fraudscreen Lock<br>
<input name="FM4" type="checkbox" value="yes");
if($user{'FM4'} eq "yes"){print qq( checked);}
print qq(>Configure Fraudscreen</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="DM" type="checkbox" value="yes" onClick="CheckIt('el9',this.checked);");
if($user{'DM'} eq "yes"){print qq( checked);}
print qq(>Domain Management</td>
<td class="prgout" align=left><div id="el9Child" class="child" style="display:none;visibility:hide;">
<input name="DM14" type="checkbox" value="yes");
if($user{'DM14'} eq "yes"){print qq (checked);}
print qq(>Change Hosting Package<br>
<input name="DM1" type="checkbox" value="yes");
if($user{'DM1'} eq "yes"){print qq( checked);}
print qq(>Pending Signups<br>
<input name="DM2" type="checkbox" value="yes");
if($user{'DM2'} eq "yes"){print qq( checked);}
print qq(>Pending Registrations<br>
<input name="DM3" type="checkbox" value="yes");
if($user{'DM3'} eq "yes"){print qq( checked);}
print qq(>Add Domain<br>
<input name="DM4" type="checkbox" value="yes");
if($user{'DM4'} eq "yes"){print qq( checked);}
print qq(>Remove Domain<br>
<input name="DM5" type="checkbox" value="yes");
if($user{'DM5'} eq "yes"){print qq( checked);}
print qq(>Suspend Domain<br>
<input name="DM6" type="checkbox" value="yes");
if($user{'DM6'} eq "yes"){print qq( checked);}
print qq(>Reactivate Domain<br>
<input name="DM7" type="checkbox" value="yes");
if($user{'DM7'} eq "yes"){print qq( checked);}
print qq(>Shell Access<br>
<input name="DM8" type="checkbox" value="yes");
if($user{'DM8'} eq "yes"){print qq( checked);}
print qq(>Shell Locking<br>
<input name="DM9" type="checkbox" value="yes");
if($user{'DM9'} eq "yes"){print qq( checked);}
print qq(>Change Domain Admin<br>
<input name="DM10" type="checkbox" value="yes");
if($user{'DM10'} eq "yes"){print qq( checked);}
print qq(>Add Domain Pointer<br>
<input name="DM11" type="checkbox" value="yes");
if($user{'DM11'} eq "yes"){print qq( checked);}
print qq(>Remove Domain Pointer<br>
<input name="DM12" type="checkbox" value="yes");
if($user{'DM12'} eq "yes"){print qq( checked);}
print qq(>Add DNS Entry<br>
<input name="DM13" type="checkbox" value="yes");
if($user{'DM13'} eq "yes"){print qq( checked);}
print qq(>Remove DNS Entry</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left valign=top><input name="ADM" type="checkbox" value="yes" onclick="CheckIt('el10',this.checked);");
if($user{'ADM'} eq "yes"){print qq( checked);}
print qq(>Advanced Management</td>
<td class="prgout" align=left><div id="el10Child" class="child" style="display:none;visibility:hide;">
<input name="ADM1" type="checkbox" value="yes");
if($user{'ADM1'} eq "yes"){print qq( checked);}
print qq(>Edit DNS Zone<br>
<input name="ADM2" type="checkbox" value="yes");
if($user{'ADM2'} eq "yes"){print qq( checked);}
print qq(>Edit Mail Access File<br>
<input name="ADM3" type="checkbox" value="yes");
if($user{'ADM3'} eq "yes"){print qq( checked);}
print qq(>Edit Virtual Host Config File</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="UM" type="checkbox" value="yes" onClick="CheckIt('el11',this.checked);");
if($user{'UM'} eq "yes"){print qq( checked);}
print qq(>User Management</td>
<td class="prgout" align=left><div id="el11Child" class="child" style="display:none;visibility:hide;">
<input name="UM1" type="checkbox" value="yes");
if($user{'UM1'} eq "yes"){print qq( checked);}
print qq(>Add User Account<br>
<input name="UM2" type="checkbox" value="yes");
if($user{'UM2'} eq "yes"){print qq( checked);}
print qq(>Remove User Account<br>
<input name="UM3" type="checkbox" value="yes");
if($user{'UM3'} eq "yes"){print qq( checked);}
print qq(>Suspend User Account<br>
<input name="UM4" type="checkbox" value="yes");
if($user{'UM4'} eq "yes"){print qq( checked);}
print qq(>Reactivate User Account<br>
<input name="UM5" type="checkbox" value="yes");
if($user{'UM5'} eq "yes"){print qq( checked);}
print qq(>Add Block<br>
<input name="UM6" type="checkbox" value="yes");
if($user{'UM6'} eq "yes"){print qq( checked);}
print qq(>Remove Block</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="BA" type="checkbox" value="yes" onClick="CheckIt('el12',this.checked);");
if($user{'BA'} eq "yes"){print qq( checked);}
print qq(>Billing/Accounting</td>
<td class="prgout" align=left><div id="el12Child" class="child" style="display:none;visibility:hide;">
<input name="BA1" type="checkbox" value="yes");
if($user{'BA1'} eq "yes"){print qq( checked);}
print qq(>Add Charge<br>
<input name="BA2" type="checkbox" value="yes");
if($user{'BA2'} eq "yes"){print qq( checked);}
print qq(>Post Payment<br>
<input name="BA6" type="checkbox" value="yes");
if($user{'BA6'} eq "yes"){print qq( checked);}
print qq(>Adjust Discount<br>
<input name="BA3" type="checkbox" value="yes");
if($user{'BA3'} eq "yes"){print qq( checked);}
print qq(>View Billing History<br>
<input name="BA4" type="checkbox" value="yes");
if($user{'BA4'} eq "yes"){print qq( checked);}
print qq(>View Current Status<br>
<input name="BA5" type="checkbox" value="yes");
if($user{'BA5'} eq "yes"){print qq( checked);}
print qq(>View Income Reports</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="AI" type="checkbox" value="yes" onClick="CheckIt('el13',this.checked);");
if($user{'AI'} eq "yes"){print qq( checked);}
print qq(>Account Information</td>
<td class="prgout" align=left><div id="el13Child" class="child" style="display:none;visibility:hide;">
<input name="AI1" type="checkbox" value="yes");
if($user{'AI1'} eq "yes"){print qq( checked);}
print qq(>View Action Log<br>
<input name="AI2" type="checkbox" value="yes");
if($user{'AI2'} eq "yes"){print qq( checked);}
print qq(>Search Account Info<br>
<input name="AI3" type="checkbox" value="yes");
if($user{'AI3'} eq "yes"){print qq( checked);}
print qq(>Disk Usage Report<br>
<input name="AI4" type="checkbox" value="yes");
if($user{'AI4'} eq "yes"){print qq( checked);}
print qq(>Bandwidth Usage Report</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MF" type="checkbox" value="yes" onClick="CheckIt('el14',this.checked);");
if($user{'MF'} eq "yes"){print qq( checked);}
print qq(>Miscellaneous Functions</td>
<td class="prgout" align=left><div id="el14Child" class="child" style="display:none;visibility:hide;">
<input name="MF1" type="checkbox" value="yes");
if($user{'MF1'} eq "yes"){print qq( checked);}
print qq(>Monitor Service Tickets<br>
<input name="MF2" type="checkbox" value="yes");
if($user{'MF2'} eq "yes"){print qq( checked);}
print qq(>Change Password<br>
<input name="MF3" type="checkbox" value="yes");
if($user{'MF3'} eq "yes"){print qq( checked);}
print qq(>View Login Log</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="PM" type="checkbox" value="yes" onClick="CheckIt('el15',this.checked);");
if($user{'PM'} eq "yes"){print qq( checked);}
print qq(>Package Management</td>
<td class="prgout" align=left><div id="el15Child" class="child" style="display:none;visibility:hide;">
<input name="PM1" type="checkbox" value="yes");
if($user{'PM1'} eq "yes"){print qq( checked);}
print qq(>Add Package<br>
<input name="PM2" type="checkbox" value="yes");
if($user{'PM2'} eq "yes"){print qq( checked);}
print qq(>Edit Package<br>
<input name="PM3" type="checkbox" value="yes");
if($user{'PM3'} eq "yes"){print qq( checked);}
print qq(>Remove Package<br>
<input name="PM4" type="checkbox" value="yes");
if($user{'PM4'} eq "yes"){print qq( checked);}
print qq(>Manage Add-Ons<br>
<input name="PM5" type="checkbox" value="yes");
if($user{'PM5'} eq "yes"){print qq( checked);}
print qq(>Add Reseller Package<br>
<input name="PM6" type="checkbox" value="yes");
if($user{'PM6'} eq "yes"){print qq( checked);}
print qq(>Edit Reseller Package<br>
<input name="PM7" type="checkbox" value="yes");
if($user{'PM7'} eq "yes"){print qq( checked);}
print qq(>Remove Reseller Package</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MHS" type="checkbox" value="yes" onClick="CheckIt('el16',this.checked);");
if($user{'MHS'} eq "yes"){print qq( checked);}
print qq(>Manage Hosting Servers</td>
<td class="prgout" align=left><div id="el16Child" class="child" style="display:none;visibility:hide;">
<input name="MHS1" type="checkbox" value="yes");
if($user{'MHS1'} eq "yes"){print qq( checked);}
print qq(>Add Hosting Server<br>
<input name="MHS2" type="checkbox" value="yes");
if($user{'MHS2'} eq "yes"){print qq( checked);}
print qq(>Edit Hosting Server<br>
<input name="MHS3" type="checkbox" value="yes");
if($user{'MHS3'} eq "yes"){print qq( checked);}
print qq(>Generate hhelper.inc File<br>
<input name="MHS4" type="checkbox" value="yes");
if($user{'MHS4'} eq "yes"){print qq( checked);}
print qq(>Configure Hosting Server<br>
<input name="MHS5" type="checkbox" value="yes");
if($user{'MHS5'} eq "yes"){print qq( checked);}
print qq(>Setup Server Database<br>
<input name="MHS12" type="checkbox" value="yes");
if($user{'MHS12'} eq "yes"){print qq( checked);}
print qq(>Update Server Database<br>
<input name="MHS6" type="checkbox" value="yes");
if($user{'MHS6'} eq "yes"){print qq( checked);}
print qq(>Remove Hosting Server<br>
<input name="MHS7" type="checkbox" value="yes");
if($user{'MHS7'} eq "yes"){print qq( checked);}
print qq(>Create Hosting Template<br>
<input name="MHS8" type="checkbox" value="yes");
if($user{'MHS8'} eq "yes"){print qq( checked);}
print qq(>Edit Hosting Template<br>
<input name="MHS9" type="checkbox" value="yes");
if($user{'MHS9'} eq "yes"){print qq( checked);}
print qq(>Remove Hosting Template<br>
<input name="MHS10" type="checkbox" value="yes");
if($user{'MHS10'} eq "yes"){print qq( checked);}
print qq(>Apache Access Defaults<br>
<input name="MHS11" type="checkbox" value="yes");
if($user{'MHS11'} eq "yes"){print qq( checked);}
print qq(>Edit Stats Config</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MCI" type="checkbox" value="yes" onClick="CheckIt('el17',this.checked);");
if($user{'MCI'} eq "yes"){print qq( checked);}
print qq(>Manage Client Interfaces</td>
<td class="prgout" align=left><div id="el17Child" class="child" style="display:none;visibility:hide;">
<input name="MCI1" type="checkbox" value="yes");
if($user{'MCI1'} eq "yes"){print qq( checked);}
print qq(>Add Client Interface<br>
<input name="MCI2" type="checkbox" value="yes");
if($user{'MCI2'} eq "yes"){print qq( checked);}
print qq(>Edit Client Interface<br>
<input name="MCI3" type="checkbox" value="yes");
if($user{'MCI3'} eq "yes"){print qq( checked);}
print qq(>Generate clientd.inc File<br>
<input name="MCI4" type="checkbox" value="yes");
if($user{'MCI4'} eq "yes"){print qq( checked);}
print qq(>Configure Client<br>
<input name="MCI5" type="checkbox" value="yes");
if($user{'MCI5'} eq "yes"){print qq( checked);}
print qq(>Remove Client Interface<br>
<input name="MCI6" type="checkbox" value="yes");
if($user{'MCI6'} eq "yes"){print qq( checked);}
print qq(>Client Page Layout<br>
<input name="MCI7" type="checkbox" value="yes");
if($user{'MCI8'} eq "yes"){print qq( checked);}
print qq(>Client Front Page<br>
<input name="MCI8" type="checkbox" value="yes");
if($user{'MCI8'} eq "yes"){print qq( checked);}
print qq(>Admin Functions Menu<br>
<input name="MCI9" type="checkbox" value="yes");
if($user{'MCI9'} eq "yes"){print qq( checked);}
print qq(>Billing Functions Menu<br>
<input name="MCI10" type="checkbox" value="yes");
if($user{'MCI10'} eq "yes"){print qq( checked);}
print qq(>Email Functions Menu<br>
<input name="MCI11" type="checkbox" value="yes");
if($user{'MCI11'} eq "yes"){print qq( checked);}
print qq(>FTP Functions Menu<br>
<input name="MCI12" type="checkbox" value="yes");
if($user{'MCI12'} eq "yes"){print qq( checked);}
print qq(>SSL Cert Functions Menu<br>
<input name="MCI13" type="checkbox" value="yes");
if($user{'MCI13'} eq "yes"){print qq( checked);}
print qq(>Support Functions Menu<br>
<input name="MCI14" type="checkbox" value="yes");
if($user{'MCI14'} eq "yes"){print qq( checked);}
print qq(>Website Functions Menu<br>
<input name="MCI15" type="checkbox" value="yes");
if($user{'MCI15'} eq "yes"){print qq( checked);}
print qq(>Invoice Layout<br>
<input name="MCI16" type="checkbox" value="yes");
if($user{'MCI16'} eq "yes"){print qq( checked);}
print qq(>Syncronize Clients</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MMS" type="checkbox" value="yes" onClick="CheckIt('el18',this.checked);");
if($user{'MMS'} eq "yes"){print qq( checked);}
print qq(>Manage Mail Servers</td>
<td class="prgout" align=left><div id="el18Child" class="child" style="display:none;visibility:hide;">
<input name="MMS1" type="checkbox" value="yes");
if($user{'MMS1'} eq "yes"){print qq( checked);}
print qq(>Add Mail Server<br>
<input name="MMS2" type="checkbox" value="yes");
if($user{'MMS2'} eq "yes"){print qq( checked);}
print qq(>Edit Mail Server<br>
<input name="MMS3" type="checkbox" value="yes");
if($user{'MMS3'} eq "yes"){print qq( checked);}
print qq(>Generate hhms.inc File<br>
<input name="MMS4" type="checkbox" value="yes");
if($user{'MMS4'} eq "yes"){print qq( checked);}
print qq(>Configure Mail Server<br>
<input name="MMS5" type="checkbox" value="yes");
if($user{'MMS5'} eq "yes"){print qq( checked);}
print qq(>Remove Mail Server<br>
<input name="MMS6" type="checkbox" value="yes");
if($user{'MMS6'} eq "yes"){print qq( checked);}
print qq(>Create Mail Server Template<br>
<input name="MMS7" type="checkbox" value="yes");
if($user{'MMS7'} eq "yes"){print qq( checked);}
print qq(>Edit Mail Server Template<br>
<input name="MMS8" type="checkbox" value="yes");
if($user{'MMS8'} eq "yes"){print qq( checked);}
print qq(>Remove Mail Server Template</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left valign=top><input name="MWS" type="checkbox" value="yes" onclick="CheckIt('el26',this.checked);");
if($user{'MWS'} eq "yes"){print qq( checked);}
print qq(>Manage Webmail Servers</td>
<td class="prgout" align=left><div id="el26Child" class="child" style="display:none;visibility:hide;">
<input name="MWS1" type="checkbox" value="yes");
if($user{'MWS1'} eq "yes"){print qq( checked);}
print qq(>Add Webmail Server<br>
<input name="MWS2" type="checkbox" value="yes");
if($user{'MWS2'} eq "yes"){print qq( checked);}
print qq(>Edit Webmail Server<br>
<input name="MWS3" type="checkbox" value="yes");
if($user{'MWS3'} eq "yes"){print qq( checked);}
print qq(>Generate hhwms.inc File<br>
<input name="MWS4" type="checkbox" value="yes");
if($user{'MWS4'} eq "yes"){print qq( checked);}
print qq(>Configure Webmail Server<br>
<input name="MWS5" type="checkbox" value="yes");
if($user{'MWS5'} eq "yes"){print qq( checked);}
print qq(>Remove Webmail Server<br>
<input name="MWS6" type="checkbox" value="yes");
if($user{'MWS6'} eq "yes"){print qq( checked);}
print qq(>Webmail Page Layout<br>
<input name="MWS7" type="checkbox" value="yes");
if($user{'MWS7'} eq "yes"){print qq( checked);}
print qq(>Syncronize Webmail</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MNS" type="checkbox" value="yes" onClick="CheckIt('el19',this.checked);");
if($user{'MNS'} eq "yes"){print qq( checked);}
print qq(>Manage Name Servers</td>
<td class="prgout" align=left><div id="el19Child" class="child" style="display:none;visibility:hide;">
<input name="MNS1" type="checkbox" value="yes");
if($user{'MNS1'} eq "yes"){print qq( checked);}
print qq(>Define PRI Name Server<br>
<input name="MNS2" type="checkbox" value="yes");
if($user{'MNS2'} eq "yes"){print qq( checked);}
print qq(>Define SEC Name Server<br>
<input name="MNS3" type="checkbox" value="yes");
if($user{'MNS3'} eq "yes"){print qq( checked);}
print qq(>Generate hhms.inc File<br>
<input name="MNS4" type="checkbox" value="yes");
if($user{'MNS4'} eq "yes"){print qq( checked);}
print qq(>Configure PRI Name Server<br>
<input name="MNS5" type="checkbox" value="yes");
if($user{'MNS5'} eq "yes"){print qq( checked);}
print qq(>Configure SEC Name Server</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MSS" type="checkbox" value="yes" onClick="CheckIt('el20',this.checked);");
if($user{'MSS'} eq "yes"){print qq( checked);}
print qq(>Manage Signup Servers</td>
<td class="prgout" align=left><div id="el20Child" class="child" style="display:none;visibility:hide;">
<input name="MSS1" type="checkbox" value="yes");
if($user{'MSS1'} eq "yes"){print qq( checked);}
print qq(>Add Signup Server<br>
<input name="MSS2" type="checkbox" value="yes");
if($user{'MSS2'} eq "yes"){print qq( checked);}
print qq(>Edit Signup Server<br>
<input name="MSS3" type="checkbox" value="yes");
if($user{'MSS3'} eq "yes"){print qq( checked);}
print qq(>Generate signupd.inc File<br>
<input name="MSS4" type="checkbox" value="yes");
if($user{'MSS4'} eq "yes"){print qq( checked);}
print qq(>Configure Signup Server<br>
<input name="MSS5" type="checkbox" value="yes");
if($user{'MSS5'} eq "yes"){print qq( checked);}
print qq(>Remove Signup Server<br>
<input name="MSS6" type="checkbox" value="yes");
if($user{'MSS6'} eq "yes"){print qq( checked);}
print qq(>Configure Signup Page Layout</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MSP" type="checkbox" value="yes" onClick="CheckIt('el21',this.checked);");
if($user{'MSP'} eq "yes"){print qq( checked);}
print qq(>Manage Server Pools</td>
<td class="prgout" align=left><div id="el21Child" class="child" style="display:none;visibility:hide;">
<input name="MSP1" type="checkbox" value="yes");
if($user{'MSP1'} eq "yes"){print qq( checked);}
print qq(>Add Server Pool<br>
<input name="MSP2" type="checkbox" value="yes");
if($user{'MSP2'} eq "yes"){print qq( checked);}
print qq(>Edit Server Pool<br>
<input name="MSP3" type="checkbox" value="yes");
if($user{'MSP3'} eq "yes"){print qq( checked);}
print qq(>Remove Server Pool</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="NS" type="checkbox" value="yes" onClick="CheckIt('el22',this.checked);");
if($user{'NS'} eq "yes"){print qq( checked);}
print qq(>Notification System</td>
<td class="prgout" align=left><div id="el22Child" class="child" style="display:none;visibility:hide;">
<input name="NS1" type="checkbox" value="yes");
if($user{'NS1'} eq "yes"){print qq( checked);}
print qq(>Add Notification<br>
<input name="NS2" type="checkbox" value="yes");
if($user{'NS2'} eq "yes"){print qq( checked);}
print qq(>Edit Notification<br>
<input name="NS3" type="checkbox" value="yes");
if($user{'NS3'} eq "yes"){print qq( checked);}
print qq(>Remove Notification</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MA" type="checkbox" value="yes" onClick="CheckIt('el23',this.checked);");
if($user{'MA'} eq "yes"){print qq( checked);}
print qq(>Manage Administrators</td>
<td class="prgout" align=left><div id="el23Child" class="child" style="display:none;visibility:hide;">
<input name="MA1" type="checkbox" value="yes");
if($user{'MA1'} eq "yes"){print qq( checked);}
print qq(>Add Administrator<br>
<input name="MA2" type="checkbox" value="yes");
if($user{'MA2'} eq "yes"){print qq( checked);}
print qq(>Edit Administrator<br>
<input name="MA3" type="checkbox" value="yes");
if($user{'MA3'} eq "yes"){print qq( checked);}
print qq(>Remove Administrator</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="AD" type="checkbox" value="yes" onClick="CheckIt('el24',this.checked);");
if($user{'AD'} eq "yes"){print qq( checked);}
print qq(>Manage Admin Daemon</td>
<td class="prgout" align=left><div id="el24Child" class="child" style="display:none;visibility:hide;">
<input name="AD1" type="checkbox" value="yes");
if($user{'AD1'} eq "yes"){print qq( checked);}
print qq(>Define Admin Server<br>
<input name="AD2" type="checkbox" value="yes");
if($user{'AD2'} eq "yes"){print qq( checked);}
print qq(>Generate admind.inc File<br>
<input name="AD3" type="checkbox" value="yes");
if($user{'AD3'} eq "yes"){print qq( checked);}
print qq(>Configure Admin Server</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="SC" type="checkbox" value="yes" onClick="CheckIt('el25',this.checked);");
if($user{'SC'} eq "yes"){print qq( checked);}
print qq(>System Config</td>
<td class="prgout" align=left><div id="el25Child" class="child" style="display:none;visibility:hide;">
<input name="SC1" type="checkbox" value="yes");
if($user{'SC1'} eq "yes"){print qq( checked);}
print qq(>Invoice Email<br>
<input name="SC2" type="checkbox" value="yes");
if($user{'SC2'} eq "yes"){print qq( checked);}
print qq(>Statement Email<br>
<input name="SC3" type="checkbox" value="yes");
if($user{'SC3'} eq "yes"){print qq( checked);}
print qq(>Invoice Cron<br>
<input name="SC5" type="checkbox" value="yes");
if($user{'SC5'} eq "yes"){print qq( checked);}
print qq(>Filecheck Cron<br>
<input name="SC4" type="checkbox" value="yes");
if($user{'SC4'} eq "yes"){print qq( checked);}
print qq(>System Variables<br>
<input name="SC6" type="checkbox" value="yes");
if($user{'SC6'} eq "yes"){print qq( checked);}
print qq(>Update Database</div>&nbsp;</td></tr>
</table>
</div></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Save Administrator"></td></tr>
</table>
<input name="user" type="hidden" value="$FORM{'user'}">
<input name="do" type="hidden" value="Save Admin">
</form>
<script language="javascript">
<!--
initIt();\n);
if($user{'ST'} eq "yes"){print qq(ShowIt('el1');\n);}
if($user{'SM'} eq "yes"){print qq(ShowIt('el2');\n);}
if($user{'Smon'} eq "yes"){print qq(ShowIt('el4');\n);}
if($user{'TC'} eq "yes"){print qq(ShowIt('el5');\n);}
if($user{'NM'} eq "yes"){print qq(ShowIt('el6');\n);}
if($user{'KB'} eq "yes"){print qq(ShowIt('el7');\n);}
if($user{'FM'} eq "yes"){print qq(ShowIt('el8');\n);}
if($user{'DM'} eq "yes"){print qq(ShowIt('el9');\n);}
if($user{'ADM'} eq "yes"){print qq(ShowIt('el10');\n);}
if($user{'UM'} eq "yes"){print qq(ShowIt('el11');\n);}
if($user{'BA'} eq "yes"){print qq(ShowIt('el12');\n);}
if($user{'AI'} eq "yes"){print qq(ShowIt('el13');\n);}
if($user{'MF'} eq "yes"){print qq(ShowIt('el14');\n);}
if($user{'PM'} eq "yes"){print qq(ShowIt('el15');\n);}
if($user{'MHS'} eq "yes"){print qq(ShowIt('el16');\n);}
if($user{'MCI'} eq "yes"){print qq(ShowIt('el17');\n);}
if($user{'MMS'} eq "yes"){print qq(ShowIt('el18');\n);}
if($user{'MNS'} eq "yes"){print qq(ShowIt('el19');\n);}
if($user{'MSS'} eq "yes"){print qq(ShowIt('el20');\n);}
if($user{'MSP'} eq "yes"){print qq(ShowIt('el21');\n);}
if($user{'NS'} eq "yes"){print qq(ShowIt('el22');\n);}
if($user{'MA'} eq "yes"){print qq(ShowIt('el23');\n);}
if($user{'AD'} eq "yes"){print qq(ShowIt('el24');\n);}
if($user{'SC'} eq "yes"){print qq(ShowIt('el25');\n);}
if($user{'MWS'} eq "yes"){print qq(ShowIt('el26');\n);}
print qq(//-->
</script>\n);
&Bottom;
}

##

sub Edit_Admin_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MA2'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].user.selectedIndex <= 0)
{
alert("Select an administrator to edit");
return false;
}
else
return true;
}
//-->
</script>
<form action="$script" method="Get" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit Administrator</td></tr>
<tr><td class="prgout" align=left>Administrator</td>
<td class="prgout" align=left><select name="user" size=1><option value="">--Select Admin--);
open(FILE,"system.dat");
while(<FILE>)
	{
	my(@info)=split(/:/,$_);
	print qq(<option value="$info[0]">$info[0]);
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Edit Administrator"></td></tr>
</table>
<input name="do" type="hidden" value="Edit Admin">
</form>\n);
&Bottom;
}

##

sub Add_Admin
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MA1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
my(@saltchars,$pass,$salt,$i);
@saltchars=('a'..'z','A'..'Z','0'..'9','.','/');
srand($$|time);
for($i=1;$i<=8;$i++)
	{
	$salt.=$saltchars[int(rand($#saltchars+1))];
	}
$salt='$1$'.$salt.'$';
$pass=crypt($FORM{'pass'},$salt);
open(FILE,">>system.dat");
print FILE qq($FORM{'user'}:$pass:$FORM{'level'}:\n);
close(FILE);
if($FORM{'level'} ne "1")
	{
	my($db,$query_output,$statement,$error);
	&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
	$statement=qq(INSERT INTO access VALUES ('$FORM{'user'}','$FORM{'ST'}','$FORM{'ST1'}','$FORM{'ST2'}','$FORM{'ST3'}','$FORM{'ST4'}',
'$FORM{'SM'}','$FORM{'SM1'}','$FORM{'SM2'}','$FORM{'SM3'}','$FORM{'SM4'}','$FORM{'SM5'}','$FORM{'SS'}','$FORM{'Smon'}','$FORM{'Smon1'}',
'$FORM{'Smon2'}','$FORM{'TC'}','$FORM{'TC1'}','$FORM{'TC2'}','$FORM{'TC3'}','$FORM{'NM'}','$FORM{'NM1'}','$FORM{'NM2'}','$FORM{'NM3'}',
'$FORM{'KB'}','$FORM{'KB1'}','$FORM{'KB2'}','$FORM{'KB3'}','$FORM{'KB4'}','$FORM{'KB5'}','$FORM{'KB6'}','$FORM{'FM'}','$FORM{'FM1'}',
'$FORM{'FM2'}','$FORM{'FM3'}','$FORM{'FM4'}','$FORM{'DM'}','$FORM{'DM1'}','$FORM{'DM2'}','$FORM{'DM3'}','$FORM{'DM4'}','$FORM{'DM5'}',
'$FORM{'DM6'}','$FORM{'DM7'}','$FORM{'DM8'}','$FORM{'DM9'}','$FORM{'DM10'}','$FORM{'DM11'}','$FORM{'DM12'}','$FORM{'DM13'}','$FORM{'DM14'}','$FORM{'UM'}',
'$FORM{'UM1'}','$FORM{'UM2'}','$FORM{'UM3'}','$FORM{'UM4'}','$FORM{'UM5'}','$FORM{'UM6'}','$FORM{'BA'}','$FORM{'BA1'}','$FORM{'BA2'}',
'$FORM{'BA3'}','$FORM{'BA4'}','$FORM{'BA5'}','$FORM{'BA6'}','$FORM{'AI'}','$FORM{'AI1'}','$FORM{'AI2'}','$FORM{'AI3'}','$FORM{'AI4'}','$FORM{'MF'}',
'$FORM{'MF1'}','$FORM{'MF2'}','$FORM{'MF3'}','$FORM{'PM'}','$FORM{'PM1'}','$FORM{'PM2'}','$FORM{'PM3'}','$FORM{'PM4'}','$FORM{'PM5'}','$FORM{'PM6'}',
'$FORM{'PM7'}','$FORM{'MHS'}',
'$FORM{'MHS1'}','$FORM{'MHS2'}','$FORM{'MHS3'}','$FORM{'MHS4'}','$FORM{'MHS5'}','$FORM{'MHS6'}','$FORM{'MHS7'}','$FORM{'MHS8'}','$FORM{'MHS9'}',
'$FORM{'MHS10'}','$FORM{'MHS11'}','$FORM{'MHS12'}','$FORM{'MCI'}','$FORM{'MCI1'}','$FORM{'MCI2'}','$FORM{'MCI3'}','$FORM{'MCI4'}','$FORM{'MCI5'}','$FORM{'MCI6'}',
'$FORM{'MCI7'}','$FORM{'MCI8'}','$FORM{'MCI9'}','$FORM{'MCI10'}','$FORM{'MCI11'}','$FORM{'MCI12'}','$FORM{'MCI13'}','$FORM{'MCI14'}','$FORM{'MCI15'}',
'$FORM{'MCI16'}','$FORM{'MMS'}','$FORM{'MMS1'}','$FORM{'MMS2'}','$FORM{'MMS3'}','$FORM{'MMS4'}','$FORM{'MMS5'}','$FORM{'MMS6'}','$FORM{'MMS7'}',
'$FORM{'MMS8'}','$FORM{'MNS'}','$FORM{'MNS1'}','$FORM{'MNS2'}','$FORM{'MNS3'}','$FORM{'MNS4'}','$FORM{'MNS5'}','$FORM{'MSS'}','$FORM{'MSS1'}',
'$FORM{'MSS2'}','$FORM{'MSS3'}','$FORM{'MSS4'}','$FORM{'MSS5'}','$FORM{'MSS6'}','$FORM{'MSP'}','$FORM{'MSP1'}','$FORM{'MSP2'}','$FORM{'MSP3'}',
'$FORM{'MA'}','$FORM{'MA1'}','$FORM{'MA2'}','$FORM{'MA3'}','$FORM{'SC'}','$FORM{'SC1'}','$FORM{'SC2'}','$FORM{'SC3'}','$FORM{'SC4'}','$FORM{'SC5'}',
'$FORM{'SC6'}','$FORM{'NS'}','$FORM{'NS1'}','$FORM{'NS2'}','$FORM{'NS3'}','$FORM{'AD'}','$FORM{'AD1'}','$FORM{'AD2'}','$FORM{'AD3'}','$FORM{'ADM'}',
'$FORM{'ADM1'}','$FORM{'ADM2'}','$FORM{'ADM3'}','$FORM{'MWS'}','$FORM{'MWS1'}','$FORM{'MWS2'}','$FORM{'MWS3'}','$FORM{'MWS4'}','$FORM{'MWS5'}','$FORM{'MWS6'}','$FORM{'MWS7'}'));
	$query_output=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Administrator, $FORM{'user'}, has been added</td></tr>
</table>);
&Bottom;
}

##

sub Add_Admin_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'MA1'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].user.value <= 0)
{
alert("Username required");
return false;
}
if(document.forms[0].pass.value <= 0)
{
alert("Password required");
return false;
}
if(document.forms[0].pass.value != document.forms[0].pass1.value)
{
alert("Password and confirm password do not match");
return false;
}
else
return true;
}
var AgntUsr=navigator.userAgent.toLowerCase();
var bV=parseInt(navigator.appVersion);
NS4=(document.layers) ? true : false;
IE4=((document.all)&&(bV>=4))?true:false;
NS6=(document.getElementById && !document.all) ? true : false;
ver4 = (NS4 || IE4 || NS6) ? true : false;

function ShowIt(){return}
function ShowAll(){return}

isShown = false;

function getIndex(el) {
	ind = null;
	for (i=0; i<document.layers.length; i++) {
		whichEl = document.layers[i];
		if (whichEl.id == el) {
			ind = i;
			break;
		}
	}
	return ind;
}

function initIt(){
	if (NS4) {
		for (i=0; i<document.layers.length; i++) {
			whichEl = document.layers[i];
			if (whichEl.id.indexOf("Child") != -1)
				{
				whichEl.visibility = "hide";
				}
		}
	}
	else if (IE4) {
		tempColl = document.all.tags("DIV");
		for (i=0; i<tempColl.length; i++) {
			if (tempColl(i).className == "child")
				{
				tempColl(i).style.display = "none";
				}
		}
	}
	else if (NS6) {
		tempColl = document.getElementsByTagName("DIV");
		for (i=0;i<tempColl.length;i++) {
			if (tempColl[i].className == "child")
				{
				tempColl[i].style.display = "none";
				}
		}
	}
}

function ShowIt(el) {
	if (!ver4) return;
	if (IE4) {ShowIE(el)}
	else if (NS4) {ShowNS(el)}
	else {ShowDOM(el)}
}

function HideIt(el) {
	if (!ver4) return;
	if (IE4) {HideIE(el)}
	else if (NS4) {HideNS(el)}
	else {HideDOM(el)}
}

function ShowIE(el) { 
	whichEl = eval(el + "Child");
	if (whichEl.style.display == "none") {
		whichEl.style.display = "block";
	}
}

function HideIE(el) {
	whichEl = eval(el + "Child");
	if (whichEl.style.display == "block") {
		whichEl.style.display = "none";
	}
}

function ShowDOM(el) {
	whichEl=document.getElementById(el + "Child");
	if(whichEl.style.display == "none") {
		whichEl.style.display="block";
		}
	}

function HideDOM(el) {
	whichEl=document.getElementById(el + "Child");
	if(whichEl.style.display == "block") {
		whichEl.style.display = "none";
		}
	}

function ShowNS(el) {
	whichEl = eval("document." + el + "Child");
	if (whichEl.visibility == "hide") {
		whichEl.visibility = "show";
		}
	}

function HideNS(el) {
	whichEl = eval("document." + el + "Child");
	if (whichEl.visibility == "show") {
		whichEl.visibility = "hide";
		}
	}
function CheckIt(x,y) {
if(x == 'el1')
	{
	document.forms[0].ST1.checked=y;
	document.forms[0].ST2.checked=y;
	document.forms[0].ST3.checked=y;
	document.forms[0].ST4.checked=y;
	if(document.forms[0].SS.checked==false){document.forms[0].SS.checked=true};
	}
if(x == 'el2')
	{
	document.forms[0].SM1.checked=y;
	document.forms[0].SM2.checked=y;
	document.forms[0].SM3.checked=y;
	document.forms[0].SM4.checked=y;
	document.forms[0].SM5.checked=y;
	if(document.forms[0].SS.checked==false){document.forms[0].SS.checked=true};
	}
if(x == 'el3')
	{
	if(document.forms[0].SS.checked == false && document.forms[0].ST.checked == true)
		{
		document.forms[0].SS.checked=true;
		alert("Server Select is required for Server Tasks");
		return;
		}
	if(document.forms[0].SS.checked == false && document.forms[0].SM.checked == true)
		{
		document.forms[0].SS.checked=true;
		alert("Server Select is required for Security Management");
		return;
		}
	}
if(x == 'el4')
	{
	document.forms[0].Smon1.checked=y;
	document.forms[0].Smon2.checked=false;
	}
if(x == 'el5')
	{
	document.forms[0].TC1.checked=y;
	document.forms[0].TC2.checked=y;
	document.forms[0].TC3.checked=y;
	}
if(x == 'el6')
	{
	document.forms[0].NM1.checked=y;
	document.forms[0].NM2.checked=y;
	document.forms[0].NM3.checked=y;
	}
if(x == 'el7')
	{
	document.forms[0].KB1.checked=y;
	document.forms[0].KB2.checked=y;
	document.forms[0].KB3.checked=y;
	document.forms[0].KB4.checked=y;
	document.forms[0].KB5.checked=y;
	document.forms[0].KB6.checked=y;
	}
if(x == 'el8')
	{
	document.forms[0].FM1.checked=y;
	document.forms[0].FM2.checked=y;
	document.forms[0].FM3.checked=y;
	document.forms[0].FM4.checked=false;
	}
if(x == 'el9')
	{
	document.forms[0].DM1.checked=y;
	document.forms[0].DM2.checked=y;
	document.forms[0].DM3.checked=y;
	document.forms[0].DM4.checked=y;
	document.forms[0].DM5.checked=y;
	document.forms[0].DM6.checked=y;
	document.forms[0].DM7.checked=y;
	document.forms[0].DM8.checked=y;
	document.forms[0].DM9.checked=y;
	document.forms[0].DM10.checked=y;
	document.forms[0].DM11.checked=y;
	document.forms[0].DM12.checked=y;
	document.forms[0].DM13.checked=y;
	document.forms[0].DM14.checked=y;
	}
if(x == 'el10')
	{
	document.forms[0].ADM.checked=y;
	document.forms[0].ADM1.checked=y;
	document.forms[0].ADM2.checked=y;
	document.forms[0].ADM3.checked=y;
	}
if(x == 'el11')
	{
	document.forms[0].UM1.checked=y;
	document.forms[0].UM2.checked=y;
	document.forms[0].UM3.checked=y;
	document.forms[0].UM4.checked=y;
	document.forms[0].UM5.checked=y;
	document.forms[0].UM6.checked=y;
	}
if(x == 'el12')
	{
	document.forms[0].BA1.checked=y;
	document.forms[0].BA2.checked=y;
	document.forms[0].BA3.checked=y;
	document.forms[0].BA4.checked=y;
	document.forms[0].BA5.checked=y;
	document.forms[0].BA6.checked=y;
	}
if(x == 'el13')
	{
	document.forms[0].AI1.checked=y;
	document.forms[0].AI2.checked=y;
	document.forms[0].AI3.checked=y;
	document.forms[0].AI4.checked=y;
	}
if(x == 'el14')
	{
	document.forms[0].MF1.checked=y;
	document.forms[0].MF2.checked=y;
	document.forms[0].MF3.checked=y;
	}
if(x == 'el15')
	{
	document.forms[0].PM1.checked=y;
	document.forms[0].PM2.checked=y;
	document.forms[0].PM3.checked=y;
	document.forms[0].PM4.checked=y;
	document.forms[0].PM5.checked=y;
	document.forms[0].PM6.checked=y;
	document.forms[0].PM7.checked=y;
	}
if(x == 'el16')
	{
	document.forms[0].MHS1.checked=y;
	document.forms[0].MHS2.checked=y;
	document.forms[0].MHS3.checked=y;
	document.forms[0].MHS4.checked=y;
	document.forms[0].MHS5.checked=y;
	document.forms[0].MHS6.checked=y;
	document.forms[0].MHS7.checked=y;
	document.forms[0].MHS8.checked=y;
	document.forms[0].MHS9.checked=y;
	document.forms[0].MHS10.checked=y;
	document.forms[0].MHS11.checked=y;
	document.forms[0].MHS12.checked=y;
	}
if(x == 'el17')
	{
	document.forms[0].MCI1.checked=y;
	document.forms[0].MCI2.checked=y;
	document.forms[0].MCI3.checked=y;
	document.forms[0].MCI4.checked=y;
	document.forms[0].MCI5.checked=y;
	document.forms[0].MCI6.checked=y;
	document.forms[0].MCI7.checked=y;
	document.forms[0].MCI8.checked=y;
	document.forms[0].MCI9.checked=y;
	document.forms[0].MCI10.checked=y;
	document.forms[0].MCI11.checked=y;
	document.forms[0].MCI12.checked=y;
	document.forms[0].MCI13.checked=y;
	document.forms[0].MCI14.checked=y;
	document.forms[0].MCI15.checked=y;
	document.forms[0].MCI16.checked=y;
	}
if(x == 'el18')
	{
	document.forms[0].MMS1.checked=y;
	document.forms[0].MMS2.checked=y;
	document.forms[0].MMS3.checked=y;
	document.forms[0].MMS4.checked=y;
	document.forms[0].MMS5.checked=y;
	document.forms[0].MMS6.checked=y;
	document.forms[0].MMS7.checked=y;
	document.forms[0].MMS8.checked=y;
	}
if(x == 'el19')
	{
	document.forms[0].MNS1.checked=y;
	document.forms[0].MNS2.checked=y;
	document.forms[0].MNS3.checked=y;
	document.forms[0].MNS4.checked=y;
	document.forms[0].MNS5.checked=y;
	}
if(x == 'el20')
	{
	document.forms[0].MSS1.checked=y;
	document.forms[0].MSS2.checked=y;
	document.forms[0].MSS3.checked=y;
	document.forms[0].MSS4.checked=y;
	document.forms[0].MSS5.checked=y;
	document.forms[0].MSS6.checked=y;
	}
if(x == 'el21')
	{
	document.forms[0].MSP1.checked=y;
	document.forms[0].MSP2.checked=y;
	document.forms[0].MSP3.checked=y;
	}
if(x == 'el22')
	{
	document.forms[0].NS1.checked=y;
	document.forms[0].NS2.checked=y;
	document.forms[0].NS3.checked=y;
	}
if(x == 'el23')
	{
	document.forms[0].MA1.checked=y;
	document.forms[0].MA2.checked=y;
	document.forms[0].MA3.checked=y;
	}
if(x == 'el24')
	{
	document.forms[0].AD1.checked=y;
	document.forms[0].AD2.checked=y;
	document.forms[0].AD3.checked=y;
	}
if(x == 'el25')
	{
	document.forms[0].SC1.checked=y;
	document.forms[0].SC2.checked=y;
	document.forms[0].SC3.checked=y;
	document.forms[0].SC4.checked=y;
	document.forms[0].SC5.checked=y;
	document.forms[0].SC6.checked=y;
	}
if(x == 'el26')
	{
	document.forms[0].MWS1.checked=y;
	document.forms[0].MWS2.checked=y;
	document.forms[0].MWS3.checked=y;
	document.forms[0].MWS4.checked=y;
	document.forms[0].MWS5.checked=y;
	document.forms[0].MWS6.checked=y;
	document.forms[0].MWS7.checked=y;
	}
if(x != 'el3')
	{
	if(y == true){ShowIt(x);}
	else{HideIt(x);}
	}
}
function SelectIt(x) {
if(x == 1)
	{
	document.forms[0].ST.checked=false;
	document.forms[0].ST1.checked=false;
	document.forms[0].ST2.checked=false;
	document.forms[0].ST3.checked=false;
	document.forms[0].ST4.checked=false;
	HideIt('el1');
	document.forms[0].SM.checked=false;
	document.forms[0].SM1.checked=false;
	document.forms[0].SM2.checked=false;
	document.forms[0].SM3.checked=false;
	document.forms[0].SM4.checked=false;
	document.forms[0].SM5.checked=false;
	HideIt('el2');
	document.forms[0].SS.checked=false;
	document.forms[0].Smon.checked=true;
	document.forms[0].Smon1.checked=true;
	document.forms[0].Smon2.checked=false;
	ShowIt('el4');
	document.forms[0].TC.checked=true;
	document.forms[0].TC1.checked=true;
	document.forms[0].TC2.checked=true;
	document.forms[0].TC3.checked=true;
	ShowIt('el5');
	document.forms[0].NM.checked=true;
	document.forms[0].NM1.checked=true;
	document.forms[0].NM2.checked=true;
	document.forms[0].NM3.checked=true;
	ShowIt('el6');
	document.forms[0].KB.checked=true;
	document.forms[0].KB1.checked=true;
	document.forms[0].KB2.checked=true;
	document.forms[0].KB3.checked=true;
	document.forms[0].KB4.checked=true;
	document.forms[0].KB5.checked=true;
	document.forms[0].KB6.checked=true;
	ShowIt('el7');
	document.forms[0].FM.checked=true;
	document.forms[0].FM1.checked=true;
	document.forms[0].FM2.checked=true;
	document.forms[0].FM3.checked=true;
	document.forms[0].FM4.checked=false;
	ShowIt('el8');
	document.forms[0].DM.checked=true;
	document.forms[0].DM1.checked=true;
	document.forms[0].DM2.checked=true;
	document.forms[0].DM3.checked=true;
	document.forms[0].DM4.checked=true;
	document.forms[0].DM5.checked=true;
	document.forms[0].DM6.checked=true;
	document.forms[0].DM7.checked=true;
	document.forms[0].DM8.checked=true;
	document.forms[0].DM9.checked=true;
	document.forms[0].DM10.checked=true;
	document.forms[0].DM11.checked=true;
	document.forms[0].DM12.checked=true;
	document.forms[0].DM13.checked=true;
	document.forms[0].DM14.checked=true;
	ShowIt('el9');
	document.forms[0].ADM.checked=false;
	document.forms[0].ADM1.checked=false;
	document.forms[0].ADM2.checked=false;
	document.forms[0].ADM3.checked=false;
	HideIt('el10');
	document.forms[0].UM.checked=true;
	document.forms[0].UM1.checked=true;
	document.forms[0].UM2.checked=true;
	document.forms[0].UM3.checked=true;
	document.forms[0].UM4.checked=true;
	document.forms[0].UM5.checked=true;
	document.forms[0].UM6.checked=true;
	ShowIt('el11');
	document.forms[0].BA.checked=false;
	document.forms[0].BA1.checked=false;
	document.forms[0].BA2.checked=false;
	document.forms[0].BA3.checked=false;
	document.forms[0].BA4.checked=false;
	document.forms[0].BA5.checked=false;
	document.forms[0].BA6.checked=false;
	HideIt('el12');
	document.forms[0].AI.checked=true;
	document.forms[0].AI1.checked=true;
	document.forms[0].AI2.checked=true;
	document.forms[0].AI3.checked=true;
	document.forms[0].AI4.checked=true;
	ShowIt('el13');
	document.forms[0].MF.checked=true;
	document.forms[0].MF1.checked=true;
	document.forms[0].MF2.checked=true;
	document.forms[0].MF3.checked=true;
	ShowIt('el14');
	document.forms[0].PM.checked=false;
	document.forms[0].PM1.checked=false;
	document.forms[0].PM2.checked=false;
	document.forms[0].PM3.checked=false;
	document.forms[0].PM4.checked=false;
	document.forms[0].PM5.checked=false;
	document.forms[0].PM6.checked=false;
	document.forms[0].PM7.checked=false;
	HideIt('el15');
	document.forms[0].MHS.checked=false;
	document.forms[0].MHS1.checked=false;
	document.forms[0].MHS2.checked=false;
	document.forms[0].MHS3.checked=false;
	document.forms[0].MHS4.checked=false;
	document.forms[0].MHS5.checked=false;
	document.forms[0].MHS6.checked=false;
	document.forms[0].MHS7.checked=false;
	document.forms[0].MHS8.checked=false;
	document.forms[0].MHS9.checked=false;
	document.forms[0].MHS10.checked=false;
	document.forms[0].MHS11.checked=false;
	document.forms[0].MHS12.checked=false;
	HideIt('el16');
	document.forms[0].MCI.checked=false;
	document.forms[0].MCI1.checked=false;
	document.forms[0].MCI2.checked=false;
	document.forms[0].MCI3.checked=false;
	document.forms[0].MCI4.checked=false;
	document.forms[0].MCI5.checked=false;
	document.forms[0].MCI6.checked=false;
	document.forms[0].MCI7.checked=false;
	document.forms[0].MCI8.checked=false;
	document.forms[0].MCI9.checked=false;
	document.forms[0].MCI10.checked=false;
	document.forms[0].MCI11.checked=false;
	document.forms[0].MCI12.checked=false;
	document.forms[0].MCI13.checked=false;
	document.forms[0].MCI14.checked=false;
	document.forms[0].MCI15.checked=false;
	document.forms[0].MCI16.checked=false;
	HideIt('el17');
	document.forms[0].MMS.checked=false;
	document.forms[0].MMS1.checked=false;
	document.forms[0].MMS2.checked=false;
	document.forms[0].MMS3.checked=false;
	document.forms[0].MMS4.checked=false;
	document.forms[0].MMS5.checked=false;
	document.forms[0].MMS6.checked=false;
	document.forms[0].MMS7.checked=false;
	document.forms[0].MMS8.checked=false;
	HideIt('el18');
	document.forms[0].MNS.checked=false;
	document.forms[0].MNS1.checked=false;
	document.forms[0].MNS2.checked=false;
	document.forms[0].MNS3.checked=false;
	document.forms[0].MNS4.checked=false;
	document.forms[0].MNS5.checked=false;
	HideIt('el19');
	document.forms[0].MSS.checked=false;
	document.forms[0].MSS1.checked=false;
	document.forms[0].MSS2.checked=false;
	document.forms[0].MSS3.checked=false;
	document.forms[0].MSS4.checked=false;
	document.forms[0].MSS5.checked=false;
	document.forms[0].MSS6.checked=false;
	HideIt('el20');
	document.forms[0].MSP.checked=false;
	document.forms[0].MSP1.checked=false;
	document.forms[0].MSP2.checked=false;
	document.forms[0].MSP3.checked=false;
	HideIt('el21');
	document.forms[0].NS.checked=false;
	document.forms[0].NS1.checked=false;
	document.forms[0].NS2.checked=false;
	document.forms[0].NS3.checked=false;
	HideIt('el22');
	document.forms[0].MA.checked=false;
	document.forms[0].MA1.checked=false;
	document.forms[0].MA2.checked=false;
	document.forms[0].MA3.checked=false;
	HideIt('el23');
	document.forms[0].AD.checked=false;
	document.forms[0].AD1.checked=false;
	document.forms[0].AD2.checked=false;
	document.forms[0].AD3.checked=false;
	HideIt('el24');
	document.forms[0].SC.checked=false;
	document.forms[0].SC1.checked=false;
	document.forms[0].SC2.checked=false;
	document.forms[0].SC3.checked=false;
	document.forms[0].SC4.checked=false;
	document.forms[0].SC5.checked=false;
	document.forms[0].SC6.checked=false;
	HideIt('el25');
	document.forms[0].MWS1.checked=false;
	document.forms[0].MWS2.checked=false;
	document.forms[0].MWS3.checked=false;
	document.forms[0].MWS4.checked=false;
	document.forms[0].MWS5.checked=false;
	document.forms[0].MWS6.checked=false;
	document.forms[0].MWS7.checked=false;
	HideIt('el26');
	}
if(x == 2)
	{
	document.forms[0].ST.checked=false;
	document.forms[0].ST1.checked=false;
	document.forms[0].ST2.checked=false;
	document.forms[0].ST3.checked=false;
	document.forms[0].ST4.checked=false;
	HideIt('el1');
	document.forms[0].SM.checked=false;
	document.forms[0].SM1.checked=false;
	document.forms[0].SM2.checked=false;
	document.forms[0].SM3.checked=false;
	document.forms[0].SM4.checked=false;
	document.forms[0].SM5.checked=false;
	HideIt('el2');
	document.forms[0].SS.checked=false;
	document.forms[0].Smon.checked=false;
	document.forms[0].Smon1.checked=false;
	document.forms[0].Smon2.checked=false;
	HideIt('el4');
	document.forms[0].TC.checked=true;
	document.forms[0].TC1.checked=true;
	document.forms[0].TC2.checked=true;
	document.forms[0].TC3.checked=true;
	ShowIt('el5');
	document.forms[0].NM.checked=false;
	document.forms[0].NM1.checked=false;
	document.forms[0].NM2.checked=false;
	document.forms[0].NM3.checked=false;
	HideIt('el6');
	document.forms[0].KB.checked=false;
	document.forms[0].KB1.checked=false;
	document.forms[0].KB2.checked=false;
	document.forms[0].KB3.checked=false;
	document.forms[0].KB4.checked=false;
	document.forms[0].KB5.checked=false;
	document.forms[0].KB6.checked=false;
	HideIt('el7');
	document.forms[0].FM.checked=false;
	document.forms[0].FM1.checked=false;
	document.forms[0].FM2.checked=false;
	document.forms[0].FM3.checked=false;
	document.forms[0].FM4.checked=false;
	HideIt('el8');
	document.forms[0].DM.checked=false;
	document.forms[0].DM1.checked=false;
	document.forms[0].DM2.checked=false;
	document.forms[0].DM3.checked=false;
	document.forms[0].DM4.checked=false;
	document.forms[0].DM5.checked=false;
	document.forms[0].DM6.checked=false;
	document.forms[0].DM7.checked=false;
	document.forms[0].DM8.checked=false;
	document.forms[0].DM9.checked=false;
	document.forms[0].DM10.checked=false;
	document.forms[0].DM11.checked=false;
	document.forms[0].DM12.checked=false;
	document.forms[0].DM13.checked=false;
	document.forms[0].DM14.checked=false;
	HideIt('el9');
	document.forms[0].ADM.checked=false;
	document.forms[0].ADM1.checked=false;
	document.forms[0].ADM2.checked=false;
	document.forms[0].ADM3.checked=false;
	HideIt('el10');
	document.forms[0].UM.checked=false;
	document.forms[0].UM1.checked=false;
	document.forms[0].UM2.checked=false;
	document.forms[0].UM3.checked=false;
	document.forms[0].UM4.checked=false;
	document.forms[0].UM5.checked=false;
	document.forms[0].UM6.checked=false;
	HideIt('el11');
	document.forms[0].BA.checked=true;
	document.forms[0].BA1.checked=true;
	document.forms[0].BA2.checked=true;
	document.forms[0].BA3.checked=true;
	document.forms[0].BA4.checked=true;
	document.forms[0].BA5.checked=true;
	document.forms[0].BA6.checked=true;
	ShowIt('el12');
	document.forms[0].AI.checked=true;
	document.forms[0].AI1.checked=true;
	document.forms[0].AI2.checked=true;
	document.forms[0].AI3.checked=true;
	document.forms[0].AI4.checked=true;
	ShowIt('el13');
	document.forms[0].MF.checked=true;
	document.forms[0].MF1.checked=true;
	document.forms[0].MF2.checked=true;
	document.forms[0].MF3.checked=true;
	ShowIt('el14');
	document.forms[0].PM.checked=false;
	document.forms[0].PM1.checked=false;
	document.forms[0].PM2.checked=false;
	document.forms[0].PM3.checked=false;
	document.forms[0].PM4.checked=false;
	document.forms[0].PM5.checked=false;
	document.forms[0].PM6.checked=false;
	document.forms[0].PM7.checked=false;
	HideIt('el15');
	document.forms[0].MHS.checked=false;
	document.forms[0].MHS1.checked=false;
	document.forms[0].MHS2.checked=false;
	document.forms[0].MHS3.checked=false;
	document.forms[0].MHS4.checked=false;
	document.forms[0].MHS5.checked=false;
	document.forms[0].MHS6.checked=false;
	document.forms[0].MHS7.checked=false;
	document.forms[0].MHS8.checked=false;
	document.forms[0].MHS9.checked=false;
	document.forms[0].MHS10.checked=false;
	document.forms[0].MHS11.checked=false;
	document.forms[0].MHS12.checked=false;
	HideIt('el16');
	document.forms[0].MCI.checked=false;
	document.forms[0].MCI1.checked=false;
	document.forms[0].MCI2.checked=false;
	document.forms[0].MCI3.checked=false;
	document.forms[0].MCI4.checked=false;
	document.forms[0].MCI5.checked=false;
	document.forms[0].MCI6.checked=false;
	document.forms[0].MCI7.checked=false;
	document.forms[0].MCI8.checked=false;
	document.forms[0].MCI9.checked=false;
	document.forms[0].MCI10.checked=false;
	document.forms[0].MCI11.checked=false;
	document.forms[0].MCI12.checked=false;
	document.forms[0].MCI13.checked=false;
	document.forms[0].MCI14.checked=false;
	document.forms[0].MCI15.checked=false;
	document.forms[0].MCI16.checked=false;
	HideIt('el17');
	document.forms[0].MMS.checked=false;
	document.forms[0].MMS1.checked=false;
	document.forms[0].MMS2.checked=false;
	document.forms[0].MMS3.checked=false;
	document.forms[0].MMS4.checked=false;
	document.forms[0].MMS5.checked=false;
	document.forms[0].MMS6.checked=false;
	document.forms[0].MMS7.checked=false;
	document.forms[0].MMS8.checked=false;
	HideIt('el18');
	document.forms[0].MNS.checked=false;
	document.forms[0].MNS1.checked=false;
	document.forms[0].MNS2.checked=false;
	document.forms[0].MNS3.checked=false;
	document.forms[0].MNS4.checked=false;
	document.forms[0].MNS5.checked=false;
	HideIt('el19');
	document.forms[0].MSS.checked=false;
	document.forms[0].MSS1.checked=false;
	document.forms[0].MSS2.checked=false;
	document.forms[0].MSS3.checked=false;
	document.forms[0].MSS4.checked=false;
	document.forms[0].MSS5.checked=false;
	document.forms[0].MSS6.checked=false;
	HideIt('el20');
	document.forms[0].MSP.checked=false;
	document.forms[0].MSP1.checked=false;
	document.forms[0].MSP2.checked=false;
	document.forms[0].MSP3.checked=false;
	HideIt('el21');
	document.forms[0].NS.checked=false;
	document.forms[0].NS1.checked=false;
	document.forms[0].NS2.checked=false;
	document.forms[0].NS3.checked=false;
	HideIt('el22');
	document.forms[0].MA.checked=false;
	document.forms[0].MA1.checked=false;
	document.forms[0].MA2.checked=false;
	document.forms[0].MA3.checked=false;
	HideIt('el23');
	document.forms[0].AD.checked=false;
	document.forms[0].AD1.checked=false;
	document.forms[0].AD2.checked=false;
	document.forms[0].AD3.checked=false;
	HideIt('el24');
	document.forms[0].SC.checked=false;
	document.forms[0].SC1.checked=false;
	document.forms[0].SC2.checked=false;
	document.forms[0].SC3.checked=false;
	document.forms[0].SC4.checked=false;
	document.forms[0].SC5.checked=false;
	document.forms[0].SC6.checked=false;
	HideIt('el25');
	document.forms[0].MWS1.checked=false;
	document.forms[0].MWS2.checked=false;
	document.forms[0].MWS3.checked=false;
	document.forms[0].MWS4.checked=false;
	document.forms[0].MWS5.checked=false;
	document.forms[0].MWS6.checked=false;
	document.forms[0].MWS7.checked=false;
	HideIt('el26');
	}
if(x == 3)
	{
	document.forms[0].ST.checked=true;
	document.forms[0].ST1.checked=true;
	document.forms[0].ST2.checked=true;
	document.forms[0].ST3.checked=true;
	document.forms[0].ST4.checked=true;
	ShowIt('el1');
	document.forms[0].SM.checked=true;
	document.forms[0].SM1.checked=true;
	document.forms[0].SM2.checked=true;
	document.forms[0].SM3.checked=true;
	document.forms[0].SM4.checked=true;
	document.forms[0].SM5.checked=true;
	ShowIt('el2');
	document.forms[0].SS.checked=true;
	document.forms[0].Smon.checked=true;
	document.forms[0].Smon1.checked=true;
	document.forms[0].Smon2.checked=false;
	ShowIt('el4');
	document.forms[0].TC.checked=true;
	document.forms[0].TC1.checked=true;
	document.forms[0].TC2.checked=true;
	document.forms[0].TC3.checked=true;
	ShowIt('el5');
	document.forms[0].NM.checked=true;
	document.forms[0].NM1.checked=true;
	document.forms[0].NM2.checked=true;
	document.forms[0].NM3.checked=true;
	ShowIt('el6');
	document.forms[0].KB.checked=true;
	document.forms[0].KB1.checked=true;
	document.forms[0].KB2.checked=true;
	document.forms[0].KB3.checked=true;
	document.forms[0].KB4.checked=true;
	document.forms[0].KB5.checked=true;
	document.forms[0].KB6.checked=true;
	ShowIt('el7');
	document.forms[0].FM.checked=true;
	document.forms[0].FM1.checked=true;
	document.forms[0].FM2.checked=true;
	document.forms[0].FM3.checked=true;
	document.forms[0].FM4.checked=false;
	ShowIt('el8');
	document.forms[0].DM.checked=true;
	document.forms[0].DM1.checked=true;
	document.forms[0].DM2.checked=true;
	document.forms[0].DM3.checked=true;
	document.forms[0].DM4.checked=true;
	document.forms[0].DM5.checked=true;
	document.forms[0].DM6.checked=true;
	document.forms[0].DM7.checked=true;
	document.forms[0].DM8.checked=true;
	document.forms[0].DM9.checked=true;
	document.forms[0].DM10.checked=true;
	document.forms[0].DM11.checked=true;
	document.forms[0].DM12.checked=true;
	document.forms[0].DM13.checked=true;
	document.forms[0].DM14.checked=true;
	ShowIt('el9');
	document.forms[0].ADM.checked=true;
	document.forms[0].ADM1.checked=true;
	document.forms[0].ADM2.checked=true;
	document.forms[0].ADM3.checked=true;
	ShowIt('el10');
	document.forms[0].UM.checked=true;
	document.forms[0].UM1.checked=true;
	document.forms[0].UM2.checked=true;
	document.forms[0].UM3.checked=true;
	document.forms[0].UM4.checked=true;
	document.forms[0].UM5.checked=true;
	document.forms[0].UM6.checked=true;
	ShowIt('el11');
	document.forms[0].BA.checked=false;
	document.forms[0].BA1.checked=false;
	document.forms[0].BA2.checked=false;
	document.forms[0].BA3.checked=false;
	document.forms[0].BA4.checked=false;
	document.forms[0].BA5.checked=false;
	document.forms[0].BA6.checked=false;
	HideIt('el12');
	document.forms[0].AI.checked=true;
	document.forms[0].AI1.checked=true;
	document.forms[0].AI2.checked=true;
	document.forms[0].AI3.checked=true;
	document.forms[0].AI4.checked=true;
	ShowIt('el13');
	document.forms[0].MF.checked=true;
	document.forms[0].MF1.checked=true;
	document.forms[0].MF2.checked=true;
	document.forms[0].MF3.checked=true;
	ShowIt('el14');
	document.forms[0].PM.checked=false;
	document.forms[0].PM1.checked=false;
	document.forms[0].PM2.checked=false;
	document.forms[0].PM3.checked=false;
	document.forms[0].PM4.checked=false;
	document.forms[0].PM5.checked=false;
	document.forms[0].PM6.checked=false;
	document.forms[0].PM7.checked=false;
	HideIt('el15');
	document.forms[0].MHS.checked=false;
	document.forms[0].MHS1.checked=false;
	document.forms[0].MHS2.checked=false;
	document.forms[0].MHS3.checked=false;
	document.forms[0].MHS4.checked=false;
	document.forms[0].MHS5.checked=false;
	document.forms[0].MHS6.checked=false;
	document.forms[0].MHS7.checked=false;
	document.forms[0].MHS8.checked=false;
	document.forms[0].MHS9.checked=false;
	document.forms[0].MHS10.checked=false;
	document.forms[0].MHS11.checked=false;
	document.forms[0].MHS12.checked=false;
	HideIt('el16');
	document.forms[0].MCI.checked=false;
	document.forms[0].MCI1.checked=false;
	document.forms[0].MCI2.checked=false;
	document.forms[0].MCI3.checked=false;
	document.forms[0].MCI4.checked=false;
	document.forms[0].MCI5.checked=false;
	document.forms[0].MCI6.checked=false;
	document.forms[0].MCI7.checked=false;
	document.forms[0].MCI8.checked=false;
	document.forms[0].MCI9.checked=false;
	document.forms[0].MCI10.checked=false;
	document.forms[0].MCI11.checked=false;
	document.forms[0].MCI12.checked=false;
	document.forms[0].MCI13.checked=false;
	document.forms[0].MCI14.checked=false;
	document.forms[0].MCI15.checked=false;
	document.forms[0].MCI16.checked=false;
	HideIt('el17');
	document.forms[0].MMS.checked=false;
	document.forms[0].MMS1.checked=false;
	document.forms[0].MMS2.checked=false;
	document.forms[0].MMS3.checked=false;
	document.forms[0].MMS4.checked=false;
	document.forms[0].MMS5.checked=false;
	document.forms[0].MMS6.checked=false;
	document.forms[0].MMS7.checked=false;
	document.forms[0].MMS8.checked=false;
	HideIt('el18');
	document.forms[0].MNS.checked=false;
	document.forms[0].MNS1.checked=false;
	document.forms[0].MNS2.checked=false;
	document.forms[0].MNS3.checked=false;
	document.forms[0].MNS4.checked=false;
	document.forms[0].MNS5.checked=false;
	HideIt('el19');
	document.forms[0].MSS.checked=false;
	document.forms[0].MSS1.checked=false;
	document.forms[0].MSS2.checked=false;
	document.forms[0].MSS3.checked=false;
	document.forms[0].MSS4.checked=false;
	document.forms[0].MSS5.checked=false;
	document.forms[0].MSS6.checked=false;
	HideIt('el20');
	document.forms[0].MSP.checked=false;
	document.forms[0].MSP1.checked=false;
	document.forms[0].MSP2.checked=false;
	document.forms[0].MSP3.checked=false;
	HideIt('el21');
	document.forms[0].NS.checked=false;
	document.forms[0].NS1.checked=false;
	document.forms[0].NS2.checked=false;
	document.forms[0].NS3.checked=false;
	HideIt('el22');
	document.forms[0].MA.checked=false;
	document.forms[0].MA1.checked=false;
	document.forms[0].MA2.checked=false;
	document.forms[0].MA3.checked=false;
	HideIt('el23');
	document.forms[0].AD.checked=false;
	document.forms[0].AD1.checked=false;
	document.forms[0].AD2.checked=false;
	document.forms[0].AD3.checked=false;
	HideIt('el24');
	document.forms[0].SC.checked=false;
	document.forms[0].SC1.checked=false;
	document.forms[0].SC2.checked=false;
	document.forms[0].SC3.checked=false;
	document.forms[0].SC4.checked=false;
	document.forms[0].SC5.checked=false;
	document.forms[0].SC6.checked=false;
	HideIt('el25');
	document.forms[0].MWS1.checked=false;
	document.forms[0].MWS2.checked=false;
	document.forms[0].MWS3.checked=false;
	document.forms[0].MWS4.checked=false;
	document.forms[0].MWS5.checked=false;
	document.forms[0].MWS6.checked=false;
	document.forms[0].MWS7.checked=false;
	HideIt('el26');
	}
if(x == 4 || x == 0)
	{
	document.forms[0].ST.checked=false;
	document.forms[0].ST1.checked=false;
	document.forms[0].ST2.checked=false;
	document.forms[0].ST3.checked=false;
	document.forms[0].ST4.checked=false;
	document.forms[0].SM.checked=false;
	document.forms[0].SM1.checked=false;
	document.forms[0].SM2.checked=false;
	document.forms[0].SM3.checked=false;
	document.forms[0].SM4.checked=false;
	document.forms[0].SM5.checked=false;
	document.forms[0].SS.checked=false;
	document.forms[0].Smon.checked=false;
	document.forms[0].Smon1.checked=false;
	document.forms[0].Smon2.checked=false;
	document.forms[0].TC.checked=false;
	document.forms[0].TC1.checked=false;
	document.forms[0].TC2.checked=false;
	document.forms[0].TC3.checked=false;
	document.forms[0].NM.checked=false;
	document.forms[0].NM1.checked=false;
	document.forms[0].NM2.checked=false;
	document.forms[0].NM3.checked=false;
	document.forms[0].KB.checked=false;
	document.forms[0].KB1.checked=false;
	document.forms[0].KB2.checked=false;
	document.forms[0].KB3.checked=false;
	document.forms[0].KB4.checked=false;
	document.forms[0].KB5.checked=false;
	document.forms[0].KB6.checked=false;
	document.forms[0].FM.checked=false;
	document.forms[0].FM1.checked=false;
	document.forms[0].FM2.checked=false;
	document.forms[0].FM3.checked=false;
	document.forms[0].FM4.checked=false;
	document.forms[0].DM.checked=false;
	document.forms[0].DM1.checked=false;
	document.forms[0].DM2.checked=false;
	document.forms[0].DM3.checked=false;
	document.forms[0].DM4.checked=false;
	document.forms[0].DM5.checked=false;
	document.forms[0].DM6.checked=false;
	document.forms[0].DM7.checked=false;
	document.forms[0].DM8.checked=false;
	document.forms[0].DM9.checked=false;
	document.forms[0].DM10.checked=false;
	document.forms[0].DM11.checked=false;
	document.forms[0].DM12.checked=false;
	document.forms[0].DM13.checked=false;
	document.forms[0].DM14.checked=false;
	document.forms[0].ADM.checked=false;
	document.forms[0].ADM1.checked=false;
	document.forms[0].ADM2.checked=false;
	document.forms[0].ADM3.checked=false;
	document.forms[0].UM.checked=false;
	document.forms[0].UM1.checked=false;
	document.forms[0].UM2.checked=false;
	document.forms[0].UM3.checked=false;
	document.forms[0].UM4.checked=false;
	document.forms[0].UM5.checked=false;
	document.forms[0].UM6.checked=false;
	document.forms[0].BA.checked=false;
	document.forms[0].BA1.checked=false;
	document.forms[0].BA2.checked=false;
	document.forms[0].BA3.checked=false;
	document.forms[0].BA4.checked=false;
	document.forms[0].BA5.checked=false;
	document.forms[0].BA6.checked=false;
	document.forms[0].AI.checked=false;
	document.forms[0].AI1.checked=false;
	document.forms[0].AI2.checked=false;
	document.forms[0].AI3.checked=false;
	document.forms[0].AI4.checked=false;
	document.forms[0].MF.checked=false;
	document.forms[0].MF1.checked=false;
	document.forms[0].MF2.checked=false;
	document.forms[0].MF3.checked=false;
	document.forms[0].PM.checked=false;
	document.forms[0].PM1.checked=false;
	document.forms[0].PM2.checked=false;
	document.forms[0].PM3.checked=false;
	document.forms[0].PM4.checked=false;
	document.forms[0].PM5.checked=false;
	document.forms[0].PM6.checked=false;
	document.forms[0].PM7.checked=false;
	document.forms[0].MHS.checked=false;
	document.forms[0].MHS1.checked=false;
	document.forms[0].MHS2.checked=false;
	document.forms[0].MHS3.checked=false;
	document.forms[0].MHS4.checked=false;
	document.forms[0].MHS5.checked=false;
	document.forms[0].MHS6.checked=false;
	document.forms[0].MHS7.checked=false;
	document.forms[0].MHS8.checked=false;
	document.forms[0].MHS9.checked=false;
	document.forms[0].MHS10.checked=false;
	document.forms[0].MHS11.checked=false;
	document.forms[0].MHS12.checked=false;
	document.forms[0].MCI.checked=false;
	document.forms[0].MCI1.checked=false;
	document.forms[0].MCI2.checked=false;
	document.forms[0].MCI3.checked=false;
	document.forms[0].MCI4.checked=false;
	document.forms[0].MCI5.checked=false;
	document.forms[0].MCI6.checked=false;
	document.forms[0].MCI7.checked=false;
	document.forms[0].MCI8.checked=false;
	document.forms[0].MCI9.checked=false;
	document.forms[0].MCI10.checked=false;
	document.forms[0].MCI11.checked=false;
	document.forms[0].MCI12.checked=false;
	document.forms[0].MCI13.checked=false;
	document.forms[0].MCI14.checked=false;
	document.forms[0].MCI15.checked=false;
	document.forms[0].MCI16.checked=false;
	document.forms[0].MMS.checked=false;
	document.forms[0].MMS1.checked=false;
	document.forms[0].MMS2.checked=false;
	document.forms[0].MMS3.checked=false;
	document.forms[0].MMS4.checked=false;
	document.forms[0].MMS5.checked=false;
	document.forms[0].MMS6.checked=false;
	document.forms[0].MMS7.checked=false;
	document.forms[0].MMS8.checked=false;
	document.forms[0].MNS.checked=false;
	document.forms[0].MNS1.checked=false;
	document.forms[0].MNS2.checked=false;
	document.forms[0].MNS3.checked=false;
	document.forms[0].MNS4.checked=false;
	document.forms[0].MNS5.checked=false;
	document.forms[0].MSS.checked=false;
	document.forms[0].MSS1.checked=false;
	document.forms[0].MSS2.checked=false;
	document.forms[0].MSS3.checked=false;
	document.forms[0].MSS4.checked=false;
	document.forms[0].MSS5.checked=false;
	document.forms[0].MSS6.checked=false;
	document.forms[0].MSP.checked=false;
	document.forms[0].MSP1.checked=false;
	document.forms[0].MSP2.checked=false;
	document.forms[0].MSP3.checked=false;
	document.forms[0].MA.checked=false;
	document.forms[0].MA1.checked=false;
	document.forms[0].MA2.checked=false;
	document.forms[0].MA3.checked=false;
	document.forms[0].SC.checked=false;
	document.forms[0].SC1.checked=false;
	document.forms[0].SC2.checked=false;
	document.forms[0].SC3.checked=false;
	document.forms[0].SC4.checked=false;
	document.forms[0].SC5.checked=false;
	document.forms[0].SC6.checked=false;
	document.forms[0].NS.checked=false;
	document.forms[0].NS1.checked=false;
	document.forms[0].NS2.checked=false;
	document.forms[0].NS3.checked=false;
	document.forms[0].AD.checked=false;
	document.forms[0].AD1.checked=false;
	document.forms[0].AD2.checked=false;
	document.forms[0].AD3.checked=false;
	document.forms[0].MWS.checked=false;
	document.forms[0].MWS1.checked=false;
	document.forms[0].MWS2.checked=false;
	document.forms[0].MWS3.checked=false;
	document.forms[0].MWS4.checked=false;
	document.forms[0].MWS5.checked=false;
	document.forms[0].MWS6.checked=false;
	document.forms[0].MWS7.checked=false;
	initIt();
	if(x == 4)
		{
		alert("Global Administrators have full access to the entire system no matter the independant settings");
		return;
		}
	}
}
function expandIt(el) {
	if (!ver4) return;
	if (IE4) {expandIE(el)}
	else if (NS4) {expandNS(el)}
	else {expandDOM(el)}
}

function expandIE(el) { 
	whichEl = eval(el);
	if (whichEl.style.display == "none") {
		whichEl.style.display = "block";
	}
	else {
		whichEl.style.display = "none";
	}
    window.event.cancelBubble = true ;
}

function expandDOM(el) {
	whichEl=document.getElementById(el);
	if(whichEl.style.display == "none") {
		whichEl.style.display="block";
		}
	else
		{
		whichEl.style.display="none";
		}
	}

function expandNS(el) {
	whichEl = eval("document." + el);
	whichIm = eval("document." + el + "Parent.document.images['imEx']");
	if (whichEl.visibility == "hide") {
		whichEl.visibility = "show";
	}
	else {
		whichEl.visibility = "hide";
	}
	arrange();
}
// -->
</script>
<form action="$script" method="Post" onSubmit="return chkData()">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Add Administrator</td></tr>
<tr><td class="prgout" align=left>Username</td>
<td class="prgout" align=left><input name="user" type="text" size=10,1 maxlength=25></td></tr>
<tr><td class="prgout" align=left>Password</td>
<td class="prgout" align=left><input name="pass" type="password" size=10,1></td></tr>
<tr><td class="prgout" align=left>Confirm Password</td>
<td class="prgout" align=left><input name="pass1" type="password" size=10,1></td></tr>
<tr><td class="prgout" align=left>Access Level</td>
<td class="prgout" align=left><select name="level" size=1 onChange="SelectIt(this.options.selectedIndex);"><option value="">--Select Level--<option value="">Technician<option value="">Accounting<option value="">Server Administrator<option value="1">Global Administrator</select></td></tr>
<tr><td class="headb" align=center colspan=2><A HREF="#" onClick="expandIt('advanced');" class="prgout">Advanced Settings</A></td></tr>
<tr><td colspan=2><div id="advanced" style="display:none;visibility:hide;">
<table align=center border=0 cellpadding=2 cellspacing=2 width=100%>
<tr><td class="headb" align=center colspan=2>Access Specifics</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="ST" type="checkbox" value="yes" onClick="CheckIt('el1',this.checked);">Server Tasks</td>
<td class="prgout" align=left><div id="el1Child" class="child" style="display:none;visibility:hide;">
<input name="ST1" type="checkbox" value="yes">Daemon Management<br>
<input name="ST2" type="checkbox" value="yes">Server Date/Time<br>
<input name="ST3" type="checkbox" value="yes">Manage IP Aliases<br>
<input name="ST4" type="checkbox" value="yes">Manage Root Crons</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="SM" type="checkbox" value="yes" onClick="CheckIt('el2',this.checked);">Security Management</td>
<td class="prgout" align=left><div id="el2Child" class="child" style="display:none;visibility:hide;">
<input name="SM1" type="checkbox" value="yes">List Open Ports<br>
<input name="SM2" type="checkbox" value="yes">View Firewall Rules<br>
<input name="SM3" type="checkbox" value="yes">Manage Firewall<br>
<input name="SM4" type="checkbox" value="yes">View Filecheck Output<br>
<input name="SM5" type="checkbox" value="yes">Configure Filecheck</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left><input name="SS" type="checkbox" value="yes" onClick="CheckIt('el3',this.checked);">Select Server</td>
<td class="prgout" align=left>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="Smon" type="checkbox" value="yes" onClick="CheckIt('el4',this.checked);">Server Monitor</td>
<td class="prgout" align=left><div id="el4Child" class="child" style="display:none;visibility:hide;">
<input name="Smon1" type="checkbox" value="yes">Services Monitor<br>
<input name="Smon2" type="checkbox" value="yes">Install Monitor</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="TC" type="checkbox" value="yes" onClick="CheckIt('el5',this.checked);">Ticket Center</td>
<td class="prgout" align=left><div id="el5Child" class="child" style="display:none;visibility:hide;">
<input name="TC1" type="checkbox" value="yes">View Tickets<br>
<input name="TC2" type="checkbox" value="yes">View History<br>
<input name="TC3" type="checkbox" value="yes">Add Ticket</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="NM" type="checkbox" value="yes" onClick="CheckIt('el6',this.checked);">New Management</td>
<td class="prgout" align=left><div id="el6Child" class="child" style="display:none;visibility:hide;">
<input name="NM1" type="checkbox" value="yes">Add News<br>
<input name="NM2" type="checkbox" value="yes">Edit News<br>
<input name="NM3" type="checkbox" value="yes">Remove News</div>&nbsp;</td></tr>
<tr><td class="prgout" LIGN=left Valign=top><input name="KB" type="checkbox" value="yes" onClick="CheckIt('el7',this.checked);">Knowledge Base</td>
<td class="prgout" align=left><div id="el7Child" class="child" style="display:none;visibility:hide;">
<input name="KB1" type="checkbox" value="yes">Add Entry<br>
<input name="KB2" type="checkbox" value="yes">Edit Entry<br>
<input name="KB3" type="checkbox" value="yes">Remove Entry<br>
<input name="KB4" type="checkbox" value="yes">Add Category<br>
<input name="KB5" type="checkbox" value="yes">Edit Category<br>
<input name="KB6" type="checkbox" value="yes">Remove Category</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="FM" type="checkbox" value="yes" onClick="CheckIt('el8',this.checked);">Fraudscreen Management</td>
<td class="prgout" align=left><div id="el8Child" class="child" style="display:none;visibility:hide;">
<input name="FM1" type="checkbox" value="yes">Add Fraudscreen Entry<br>
<input name="FM2" type="checkbox" value="yes">Remove Fraudscreen Entry<br>
<input name="FM3" type="checkbox" value="yes">Fraudscreen Lock<br>
<input name="FM4" type="checkbox" value="yes">Configure Fraudscreen</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="DM" type="checkbox" value="yes" onClick="CheckIt('el9',this.checked);">Domain Management</td>
<td class="prgout" align=left><div id="el9Child" class="child" style="display:none;visibility:hide;">
<input name="DM14" type="checkbox" value="yes">Change Hosting Package<br>
<input name="DM1" type="checkbox" value="yes">Pending Signups<br>
<input name="DM2" type="checkbox" value="yes">Pending Registrations<br>
<input name="DM3" type="checkbox" value="yes">Add Domain<br>
<input name="DM4" type="checkbox" value="yes">Remove Domain<br>
<input name="DM5" type="checkbox" value="yes">Suspend Domain<br>
<input name="DM6" type="checkbox" value="yes">Reactivate Domain<br>
<input name="DM7" type="checkbox" value="yes">Shell Access<br>
<input name="DM8" type="checkbox" value="yes">Shell Locking<br>
<input name="DM9" type="checkbox" value="yes">Change Domain Admin<br>
<input name="DM10" type="checkbox" value="yes">Add Domain Pointer<br>
<input name="DM11" type="checkbox" value="yes">Remove Domain Pointer<br>
<input name="DM12" type="checkbox" value="yes">Add DNS Entry<br>
<input name="DM13" type="checkbox" value="yes">Remove DNS Entry</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left valign=top><input name="ADM" type="checkbox" value="yes" onclick="CheckIt('el10',this.checked);">Advanced Management</td>
<td class="prgout" align=left><div id="el10Child" class="child" style="display:none;visibility:hide;">
<input name="ADM1" type="checkbox" value="yes">Edit DNS Zone<br>
<input name="ADM2" type="checkbox" value="yes">Edit Mail Access File<br>
<input name="ADM3" type="checkbox" value="yes">Edit Virtual Host Config File</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="UM" type="checkbox" value="yes" onClick="CheckIt('el11',this.checked);">User Management</td>
<td class="prgout" align=left><div id="el11Child" class="child" style="display:none;visibility:hide;">
<input name="UM1" type="checkbox" value="yes">Add User Account<br>
<input name="UM2" type="checkbox" value="yes">Remove User Account<br>
<input name="UM3" type="checkbox" value="yes">Suspend User Account<br>
<input name="UM4" type="checkbox" value="yes">Reactivate User Account<br>
<input name="UM5" type="checkbox" value="yes">Add Block<br>
<input name="UM6" type="checkbox" value="yes">Remove Block</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="BA" type="checkbox" value="yes" onClick="CheckIt('el12',this.checked);">Billing/Accounting</td>
<td class="prgout" align=left><div id="el12Child" class="child" style="display:none;visibility:hide;">
<input name="BA1" type="checkbox" value="yes">Add Charge<br>
<input name="BA2" type="checkbox" value="yes">Post Payment<br>
<input name="BA6" type="checkbox" value="yes">Adjust Discount<br>
<input name="BA3" type="checkbox" value="yes">View Billing History<br>
<input name="BA4" type="checkbox" value="yes">View Current Status<br>
<input name="BA5" type="checkbox" value="yes">View Income Reports</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="AI" type="checkbox" value="yes" onClick="CheckIt('el13',this.checked);">Account Information</td>
<td class="prgout" align=left><div id="el13Child" class="child" style="display:none;visibility:hide;">
<input name="AI1" type="checkbox" value="yes">View Action Log<br>
<input name="AI2" type="checkbox" value="yes">Search Account Info<br>
<input name="AI3" type="checkbox" value="yes">Disk Usage Report<br>
<input name="AI4" type="checkbox" value="yes">Bandwidth Usage Report</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MF" type="checkbox" value="yes" onClick="CheckIt('el14',this.checked);">Miscellaneous Functions</td>
<td class="prgout" align=left><div id="el14Child" class="child" style="display:none;visibility:hide;">
<input name="MF1" type="checkbox" value="yes">Monitor Service Tickets<br>
<input name="MF2" type="checkbox" value="yes">Change Password<br>
<input name="MF3" type="checkbox" value="yes">View Login Log</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="PM" type="checkbox" value="yes" onClick="CheckIt('el15',this.checked);">Package Management</td>
<td class="prgout" align=left><div id="el15Child" class="child" style="display:none;visibility:hide;">
<input name="PM1" type="checkbox" value="yes">Add Package<br>
<input name="PM2" type="checkbox" value="yes">Edit Package<br>
<input name="PM3" type="checkbox" value="yes">Remove Package<br>
<input name="PM4" type="checkbox" value="yes">Manage Add-Ons<br>
<input name="PM5" type="checkbox" value="yes">Add Reseller Package<br>
<input name="PM6" type="checkbox" value="yes">Edit Reseller Package<br>
<input name="PM7" type="checkbox" value="yes">Remove Reseller Package</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MHS" type="checkbox" value="yes" onClick="CheckIt('el16',this.checked);">Manage Hosting Servers</td>
<td class="prgout" align=left><div id="el16Child" class="child" style="display:none;visibility:hide;">
<input name="MHS1" type="checkbox" value="yes">Add Hosting Server<br>
<input name="MHS2" type="checkbox" value="yes">Edit Hosting Server<br>
<input name="MHS3" type="checkbox" value="yes">Generate hhelper.inc File<br>
<input name="MHS4" type="checkbox" value="yes">Configure Hosting Server<br>
<input name="MHS5" type="checkbox" value="yes">Setup Server Database<br>
<input name="MHS12" type="checkbox" value="yes">Update Server Database<br>
<input name="MHS6" type="checkbox" value="yes">Remove Hosting Server<br>
<input name="MHS7" type="checkbox" value="yes">Create Hosting Template<br>
<input name="MHS8" type="checkbox" value="yes">Edit Hosting Template<br>
<input name="MHS9" type="checkbox" value="yes">Remove Hosting Template<br>
<input name="MHS10" type="checkbox" value="yes">Apache Access Defaults<br>
<input name="MHS11" type="checkbox" value="yes">Edit Stats Configuration</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MCI" type="checkbox" value="yes" onClick="CheckIt('el17',this.checked);">Manage Client Interfaces</td>
<td class="prgout" align=left><div id="el17Child" class="child" style="display:none;visibility:hide;">
<input name="MCI1" type="checkbox" value="yes">Add Client Interface<br>
<input name="MCI2" type="checkbox" value="yes">Edit Client Interface<br>
<input name="MCI3" type="checkbox" value="yes">Generate clientd.inc File<br>
<input name="MCI4" type="checkbox" value="yes">Configure Client<br>
<input name="MCI5" type="checkbox" value="yes">Remove Client Interface<br>
<input name="MCI6" type="checkbox" value="yes">Client Page Layout<br>
<input name="MCI7" type="checkbox" value="yes">Client Front Page<br>
<input name="MCI8" type="checkbox" value="yes">Admin Functions Menu<br>
<input name="MCI9" type="checkbox" value="yes">Billing Functions Menu<br>
<input name="MCI10" type="checkbox" value="yes">Email Functions Menu<br>
<input name="MCI11" type="checkbox" value="yes">FTP Functions Menu<br>
<input name="MCI12" type="checkbox" value="yes">SSL Cert Functions Menu<br>
<input name="MCI13" type="checkbox" value="yes">Support Functions Menu<br>
<input name="MCI14" type="checkbox" value="yes">Website Functions Menu<br>
<input name="MCI15" type="checkbox" value="yes">Invoice Layout<br>
<input name="MCI16" type="checkbox" value="yes">Syncronize Clients</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left valign=top><input name="MMS" type="checkbox" value="yes" onClick="CheckIt('el18',this.checked);">Manage Mail Servers</td>
<td class="prgout" align=left><div id="el18Child" class="child" style="display:none;visibility:hide;">
<input name="MMS1" type="checkbox" value="yes">Add Mail Server<br>
<input name="MMS2" type="checkbox" value="yes">Edit Mail Server<br>
<input name="MMS3" type="checkbox" value="yes">Generate hhms.inc File<br>
<input name="MMS4" type="checkbox" value="yes">Configure Mail Server<br>
<input name="MMS5" type="checkbox" value="yes">Remove Mail Server<br>
<input name="MMS6" type="checkbox" value="yes">Create Mail Server Template<br>
<input name="MMS7" type="checkbox" value="yes">Edit Mail Server Template<br>
<input name="MMS8" type="checkbox" value="yes">Remove Mail Server Template</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left valign=top><input name="MWS" type="checkbox" value="yes" onclick="CheckIt('el26',this.checked);">Manage Webmail Servers</td>
<td class="prgout" align=left><div id="el26Child" class="child" style="display:none;visibility:hide;">
<input name="MWS1" type="checkbox" value="yes">Add Webmail Server<br>
<input name="MWS2" type="checkbox" value="yes">Edit Webmail Server<br>
<input name="MWS3" type="checkbox" value="yes">Generate hhwms.inc File<br>
<input name="MWS4" type="checkbox" value="yes">Configure Webmail Server<br>
<input name="MWS5" type="checkbox" value="yes">Remove Webmail Server<br>
<input name="MWS6" type="checkbox" value="yes">Webmail Page Layout<br>
<input name="MWS7" type="checkbox" value="yes">Syncronize Webmail</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MNS" type="checkbox" value="yes" onClick="CheckIt('el19',this.checked);">Manage Name Servers</td>
<td class="prgout" align=left><div id="el19Child" class="child" style="display:none;visibility:hide;">
<input name="MNS1" type="checkbox" value="yes">Define PRI Name Server<br>
<input name="MNS2" type="checkbox" value="yes">Define SEC Name Server<br>
<input name="MNS3" type="checkbox" value="yes">Generate hhms.inc File<br>
<input name="MNS4" type="checkbox" value="yes">Configure PRI Name Server<br>
<input name="MNS5" type="checkbox" value="yes">Configure SEC Name Server</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MSS" type="checkbox" value="yes" onClick="CheckIt('el20',this.checked);">Manage Signup Servers</td>
<td class="prgout" align=left><div id="el20Child" class="child" style="display:none;visibility:hide;">
<input name="MSS1" type="checkbox" value="yes">Add Signup Server<br>
<input name="MSS2" type="checkbox" value="yes">Edit Signup Server<br>
<input name="MSS3" type="checkbox" value="yes">Generate signupd.inc File<br>
<input name="MSS4" type="checkbox" value="yes">Configure Signup Server<br>
<input name="MSS5" type="checkbox" value="yes">Remove Signup Server<br>
<input name="MSS6" type="checkbox" value="yes">Configure Signup Page Layout</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MSP" type="checkbox" value="yes" onClick="CheckIt('el21',this.checked);">Manage Server Pools</td>
<td class="prgout" align=left><div id="el21Child" class="child" style="display:none;visibility:hide;">
<input name="MSP1" type="checkbox" value="yes">Add Server Pool<br>
<input name="MSP2" type="checkbox" value="yes">Edit Server Pool<br>
<input name="MSP3" type="checkbox" value="yes">Remove Server Pool</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="NS" type="checkbox" value="yes" onClick="CheckIt('el22',this.checked);">Notification System</td>
<td class="prgout" align=left><div id="el22Child" class="child" style="display:none;visibility:hide;">
<input name="NS1" type="checkbox" value="yes">Add Notification<br>
<input name="NS2" type="checkbox" value="yes">Edit Notification<br>
<input name="NS3" type="checkbox" value="yes">Remove Notification</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="MA" type="checkbox" value="yes" onClick="CheckIt('el23',this.checked);">Manage Administrators</td>
<td class="prgout" align=left><div id="el23Child" class="child" style="display:none;visibility:hide;">
<input name="MA1" type="checkbox" value="yes">Add Administrator<br>
<input name="MA2" type="checkbox" value="yes">Edit Administrator<br>
<input name="MA3" type="checkbox" value="yes">Remove Administrator</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="AD" type="checkbox" value="yes" onClick="CheckIt('el24',this.checked);">Manage Admin Daemon</td>
<td class="prgout" align=left><div id="el24Child" class="child" style="display:none;visibility:hide;">
<input name="AD1" type="checkbox" value="yes">Define Admin Server<br>
<input name="AD2" type="checkbox" value="yes">Generate admind.inc File<br>
<input name="AD3" type="checkbox" value="yes">Configure Admin Server</div>&nbsp;</td></tr>
<tr><td class="prgout" align=left Valign=top><input name="SC" type="checkbox" value="yes" onClick="CheckIt('el25',this.checked);">System Config</td>
<td class="prgout" align=left><div id="el25Child" class="child" style="display:none;visibility:hide;">
<input name="SC1" type="checkbox" value="yes">Invoice Email<br>
<input name="SC2" type="checkbox" value="yes">Statement Email<br>
<input name="SC3" type="checkbox" value="yes">Invoice Cron<br>
<input name="SC5" type="checkbox" value="yes">Filecheck Cron<br>
<input name="SC4" type="checkbox" value="yes">System Variables<br>
<input name="SC6" type="checkbox" value="yes">Update Database</div>&nbsp;</td></tr>
</table>
</div></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Administrator"></td></tr>
</table>
<input name="do" type="hidden" value="Add Admin">
</form>
<script language="javascript">
<!--
initIt();
//-->
</script>\n);
&Bottom;
}

1;
