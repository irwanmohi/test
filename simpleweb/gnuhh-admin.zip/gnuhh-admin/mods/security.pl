sub Remove_Chain
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=remove+chain&chain=$FORM{'chain'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&Manage_Firewall;}
else{&Error("$remote{'status'}");}
}

##

sub Add_Chain
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=add+chain&chain=$FORM{'chain'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&Manage_Firewall;}
else{&Error("$remote{'status'}");}
}

##

sub Restart_Daemon
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'ST1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=restart+daemon&daemon=$FORM{'daemon'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<meta content="5;url=$script?do=daemons" http-equiv="Refresh">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center>Daemon Restart</td></tr>
<td class="prgout" align=left>$FORM{'daemon'} server has been restarted</td>
</table>);
&Bottom;
}

##

sub Start_Daemon
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'ST1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=start+daemon&daemon=$FORM{'daemon'});
&Connect($ip,$port,$serverkey,$command);
&Top;
print qq(<META CONTENT="5;URL=$script?do=daemons" HTTP-EQUIV="Refresh">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="prgout" align=left>Server daemon started</td></tr>
</table>);
&Bottom;
}

##

sub Stop_Daemon
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'ST1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=stop+daemon&daemon=$FORM{'daemon'});
&Connect($ip,$port,$serverkey,$command);
&Top;
print qq(<META CONTENT="5;URL=$script?do=daemons" HTTP-EQUIV="Refresh">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="prgout" align=left>Server daemon stopped</td></tr>
</table>);
&Bottom;
}

##

sub Daemon_Management
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'ST1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT type,name,ip,port,serverpass,useemail FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($type,$name,$ip,$port,$serverpass,$useemail,$usens1,$usens2)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+daemon+status);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=3>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center colspan=3>Daemon Management</td></tr>
<tr><td class="headb" class="prgout" align=left>Daemon</td>
<td class="headb" align=left>Status</td>
<td class="headb" align=left>Start/Stop/Restart</td></tr>\n);
if(($type eq "admin")||($type eq "signup")||($type eq "ns1")||($type eq "ns2")||($type eq "webmail")||($type eq "mail")||($type eq "client")||($type eq "hosting"))
	{
	print qq(<tr><td class="prgout" align=left>SSH Server</td>
<td class="prgout" align=left>);
	if($remote{'sshstatus'} eq "up"){print qq(UP);}
	else{print qq(DOWN);}
	print qq(</td>
<td class="prgout" align=left>);
	if($remote{'sshstatus'} eq "up"){print qq(<a href="$script?do=stop+daemon&daemon=ssh" class="prgout">Stop</a>
<a href="$script?do=restart+daemon&daemon=ssh" class="prgout">Restart</a>);}
	else{print qq(<a href="$script?do=start+daemon&daemon=ssh" class="prgout">Start</a>);}
	print qq(</td></tr>\n);
	}
if(($type eq "signup")||($type eq "client")||($type eq "webmail"))
	{
	print qq(<tr><td class="prgout" align=left>Web Server</td>
<td class="prgout" align=left>);
	if($remote{'webstatus'} eq "up"){print qq(UP);}
	else{print qq(DOWN);}
	print qq(</td>
<td class="prgout" align=left>);
	if($remote{'webstatus'} eq "up"){print qq(<a href="$script?do=stop+daemon&daemon=web" class="prgout">Stop</a>
<a href="$script?do=restart+daemon&daemon=web" class="prgout">Restart</a>);}
	else{print qq(<a href="$script?do=start+daemon&daemon=web" class="prgout">Start</a>);}
	print qq(</td></tr>\n);
	}
if($type eq "hosting")
	{
	print qq(<tr><td class="prgout" align=left>Web Server</td>
<td class="prgout" align=left>);
	if($remote{'webstatus'} eq "up"){print qq(UP);}
	else{print qq(DOWN);}
	print qq(</td>
<td class="prgout" align=left>);
	if($remote{'webstatus'} eq "up"){print qq(<a href="$script?do=stop+daemon&daemon=web" class="prgout">Stop</a>
<a href="$script?do=restart+daemon&daemon=web" class="prgout">Restart</a>);}
	else{print qq(<a href="$script?do=start+daemon&daemon=web" class="prgout">Start</a>);}
	print qq(</td></tr>
<tr><td class="prgout" align=left>FTP Server</td>
<td class="prgout" align=left>);
	if($remote{'ftpstatus'} eq "up"){print qq(UP);}
	else{print qq(DOWN);}
	print qq(</td>
<td class="prgout" align=left>);
	if($remote{'ftpstatus'} eq "up"){print qq(<a href="$script?do=stop+daemon&daemon=ftp" class="prgout">Stop</a>
<a href="$script?do=restart+daemon&daemon=ftp" class="prgout">Restart</a>);}
	else{print qq(<a href="$script?do=start+daemon&daemon=ftp" class="prgout">Start</a>);}
	print qq(</td></tr>\n);
	if($useemail eq "local")
		{
		print qq(<tr><td class="prgout" align=left>Email Server</td>
<td class="prgout" align=left>);
		if($remote{'mailstatus'} eq "up"){print qq(UP);}
		else{print qq(DOWN);}
		print qq(</td>
<td class="prgout" align=left>);
		if($remote{'mailstatus'} eq "up"){print qq(<a href="$script?do=stop+daemon&daemon=mail" class="prgout">Stop</a>
<a href="$script?do=restart+daemon&daemon=mail" class="prgout">Restart</a>);}
		else{print qq(<a href="$script?do=start+daemon&daemon=mail" class="prgout">Start</a>);}
		print qq(</td></tr>\n);
		}
	}
if(($type eq "ns1")||($type eq "ns2"))
	{
	print qq(<tr><td class="prgout" align=left>Name Server</td>
<td class="prgout" align=left>);
	if($remote{'nsstatus'} eq "up"){print qq(UP);}
	else{print qq(DOWN);}
	print qq(</td>
<td class="prgout" align=left>);
	if($remote{'nsstatus'} eq "up"){print qq(<a href="$script?do=stop+daemon&daemon=ns" class="prgout">Stop</a>
<a href="$script?do=restart+daemon&daemon=ns" class="prgout">Restart</a>);}
	else{print qq(<a href="$script?do=start+daemon&daemon=ns" class="prgout">Start</a>);}
	print qq(</td></tr>\n);
	}	
if($type eq "mail")
	{
	print qq(<tr><td class="prgout" align=left>Email Server</td>
<td class="prgout" align=left>);
	if($remote{'mailstatus'} eq "up"){print qq(UP);}
	else{print qq(DOWN);}
	print qq(</td>
<td class="prgout" align=left>);
	if($remote{'mailstatus'} eq "up"){print qq(<a href="$script?do=stop+daemon&daemon=mail" class="prgout">Stop</a>
<a href="$script?do=restart+daemon&daemon=mail" class="prgout">Restart</a>);}
	else{print qq(<a href="$script?do=start+daemon&daemon=mail" class="prgout">Start</a>);}
	print qq(</td></tr>\n);
	}
print qq(</table>);
&Bottom;
}

##

sub Recalc_Filecheck
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=calculate+filecheck);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
&Top;
print qq(<meta content="5;url=$script?do=view+filecheck" http-equiv="Refresh">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=1>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center colspan=1>Calculating Filecheck</td></tr>
<tr><td class="prgout" align=left>The Filecheck validation sums have been recalculated.</td></tr>
</table>\n);
&Bottom;
}

##

sub Remove_Filecheck_File
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=remove+filecheck+file&id=$FORM{'id'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error("|$remote{'status'}|");}
&Config_Filecheck_Form;
}

##

sub Add_Filecheck_Files
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM5'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'files'}=&uri_escape($FORM{'files'});
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=add+filecheck+files&files=$FORM{'files'});
&Connect($ip,$port,$serverkey,$command);
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center>Configure Filecheck</td></tr>
<tr><td class="prgout" align=left>$remote{'status'}</td></tr>
</table>\n);
&Bottom;
}

##

sub Remove_Filecheck_Cron
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=remove+filecheck+cron);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&Config_Filecheck_Form;}
else{&Error($remote{'status'});}
}

##

sub Config_Filecheck_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM5'} ne "yes")){&Error('Insufficient access for this function');}
undef(%remote);
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+filecheck+config);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'}){&Error($remote{'status'});}
my(@files)=split(/:/,$remote{'files'});
my(@cron)=split(/\|/,$remote{'cron'});
my(%id);
foreach(@files)
	{
	my(@info)=split(/\|/,$_);
	$id{$info[0]}=$info[1];
	}
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to delete this filecheck entry?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center colspan=2>Configure Filecheck</td></tr>
<tr><td class="headb" align=left>Action</td>
<td class="headb" align=left>Filename</td></tr>\n);
foreach(keys %id)
	{
	print qq(<tr><td class="prgout" align=left><form action="$script" method="Post" onSubmit="return ConFirm()"><input type="submit" value="Remove"><input name="id" type="hidden" value="$_"><input name="do" type="hidden" value="Remove Filecheck File"></FORM></td>
<td class="prgout" align=left>$id{$_}</td></tr>\n);
	}
print qq(<tr><td class="headb" align=left colspan=2><form action="$script" method="Post">New Entries (enter each file on a seperate line with full path)</td></tr>
<tr><td class="prgout" align=left colspan=2><textarea name="files" rows=20 cols=75></textarea></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Add Files"><input name="do" type="hidden" value="Add Filecheck Files"></FORM></td></tr>
</table>\n);
&Bottom;
}

##

sub View_Filecheck
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM4'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error,$i);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=view+filecheck);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'}){&Error($remote{'status'});}
my(@files)=split(/::/,$remote{'files'});
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=5>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=left colspan=5>View Filecheck Analysis Results</td></tr>
<tr><td class="headb" align=left>File</td>
<td class="headb" align=left>Original MD5</td>
<td class="headb" align=left>Current MD5</td>
<td class="headb" align=left>Date of Scan</td>
<td class="headb" align=left>Status</td></tr>\n);
foreach(@files)
	{
	my(@info)=split(/\|/,$_);
	my($class,$status);
	if($info[1] eq $info[2]){$class="prgout";$status="Valid";}
	else{$class="highlight";$status="Changed";}
	print qq(<tr><td class="$class" align=left>$info[0]</td>
<td class="$class" align=left>$info[1]</td>
<td class="$class" align=left>$info[2]</td>
<td class="$class" align=left>$info[3]</td>
<td class="$class" align=left>$status</td></tr>\n);
	}
print qq(<tr>);
if($remote{'validate'} eq "yes"){print qq(<td class="prgout" align=center colspan=5>Database validation check reports no tampering with database.</td>\n);}
else{print qq(<td class="highlight" align=center colspan=5>Database validation check reports tampering with database.</td>);}
print qq(</tr>
<tr><td class="prgout" align=center colspan=5><input type="submit" value="Recalculate Filecheck"></td></tr>
</table>
<input name="do" type="hidden" value="Recalc Filecheck">
</FORM>\n);
&Bottom;
}

##

sub Restore_Firewall
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=restore+firewall);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done")
	{
	&Top;
	print qq(<meta content="5;url=$script?do=manage+firewall" http-equiv="Refresh">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=1>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center colspan=1>Manage Firewall Rules</td></tr>
<tr><td class="prgout" align=left>Firewall has been restored.</td></tr>
</table>\n);
	&Bottom;
	}
else{&Error("$remote{'status'}");}
}

##

sub Save_Firewall
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=save+firewall);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done")
	{
	&Top;
	print qq(<meta content="5;url=$script?do=manage+firewall" http-equiv="Refresh">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=1>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center colspan=1>Manage Firewall Rules</td></tr>
<tr><td class="prgout" align=left>Firewall has been saved.</td></tr>
</table>\n);
	&Bottom;
	}
else{&Error("$remote{'status'}");}
}

##

sub Add_Rule
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
if((!$FORM{'extra'})&&($FORM{'custom'})){$FORM{'extra'}=$FORM{'custom'};}
my($command)=qq(do=add+rule&chain=$FORM{'chain'}&prot=$FORM{'prot'}&nsource=$FORM{'nsource'}&source=$FORM{'source'}&ndest=$FORM{'ndest'}&how=$FORM{'how'}&insertno=$FORM{'insertno'});
$command.=qq(&dest=$FORM{'dest'}&nsport=$FORM{'nsport'}&sport=$FORM{'sport'}&ndport=$FORM{'ndport'}&dport=$FORM{'dport'}&extra=$FORM{'extra'}&action=$FORM{'action'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&Manage_Firewall;}
else{&Error("$remote{'status'}");}
}

##

sub Remove_Rule
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=remove+rule&info=$FORM{'info'});
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} eq "done"){&Manage_Firewall;}
else{&Error("$remote{'status'}");}
}

##

sub Manage_Firewall
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=list+rules);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
$command=qq(do=list+ports);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
my(@ports)=split(/:/,$remote{'ports'});
my(@chains)=split(/:/,$remote{'chains'});
my(@rules)=split(/:/,$remote{'rules'});
&Top;
print qq(<script language="javascript">
<!--
function ConFirm(x)
{
var prgout="prgout";
var highlight="higlight";
var firewall="firewall";
if(eval(x) == prgout)
	{
	if(confirm("Do you want to delete this firewall rule?"))
		{
		return true;
		}
	else
	return false;
	}
if(eval(x) == highlight)
	{
	if(confirm("WARNING: This is a firewall to protect your management software are you sure you want to remove this firewall?"))
		{
		return true;
		}
	else
	return false;
	}
if(eval(x) == firewall)
	{
	if(confirm("WARNING: This will clear your current firewall and restore from a previously saved firewall.  Do you want to continue?"))
		{
		return true;
		}
	else
	return false;
	}
}

function chkData()
{
if((document.addrule.prot.selectedIndex == 0)&&(document.addrule.sport.value > 0))
{
alert("A specific protocol must be selected when a source port is specified");
return false;
}
if((document.addrule.prot.selectedIndex == 0)&&(document.addrule.dport.value > 0))
{
alert("A specific protocol must be selected when a destination port is specified");
return false;
}
if((document.addrule.nsource.checked==true)&&(document.addrule.source.value <= 0))
{
alert('You must specify a source ip address if you have the "Not" selected for source ip');
return false;
}
if((document.addrule.ndest.checked==true)&&(document.addrule.dest.value <= 0))
{
alert('You must specify a destination ip address if you have the "Not" selected for destination ip');
return false;
}
if((document.addrule.nsport.checked==true)&&(document.addrule.sport.value <= 0))
{
alert('You must specify a source port if you have the "Not" selected for source port');
return false;
}
if((document.addrule.ndport.checked==true)&&(document.addrule.dport.value <= 0))
{
alert('You must specify a destination port if you have the "Not" selected for destination port');
return false;
}
if((document.addrule.prot.selectedIndex != 1)&&(document.addrule.extra.selectedIndex == 10))
{
alert("You can't select tcp-reset unless the protocol is tcp");
return false;
}
else
return true;
}
function chkdis(x){
if(x == 0){document.addrule.insertno.disabled=false;}
else{document.addrule.insertno.disabled=true;}
}
function chkreject(x){
if(document.addrule.extra.selectedIndex >= 4 && document.addrule.action.selectedIndex != 1){document.addrule.extra.selectedIndex=0;}
if(x == 1){
document.addrule.extra.options[4].disabled=false;
document.addrule.extra.options[5].disabled=false;
document.addrule.extra.options[6].disabled=false;
document.addrule.extra.options[7].disabled=false;
document.addrule.extra.options[8].disabled=false;
document.addrule.extra.options[9].disabled=false;
document.addrule.extra.options[10].disabled=false;}
else{document.addrule.extra.options[4].disabled=true;
document.addrule.extra.options[5].disabled=true;
document.addrule.extra.options[6].disabled=true;
document.addrule.extra.options[7].disabled=true;
document.addrule.extra.options[8].disabled=true;
document.addrule.extra.options[9].disabled=true;
document.addrule.extra.options[10].disabled=true;}
if(document.addrule.action.selectedIndex == 1){
document.addrule.insertno.disabled=true;
document.addrule.how.selectedIndex=1;}
}
function chkcustom(x){
if(x > 0){document.addrule.custom.disabled=true;}
else{document.addrule.custom.disabled=false;}
}
//-->
</script>
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=9>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center colspan=9>Manage Firewall Rules</td></tr>\n);
my($ruletest);
foreach(@chains)
	{
	print qq(<tr><td class="headb" align=left>Number</td>
<td class="headb" align=left>Target</td>
<td class="headb" align=left>Protocol</td>
<td class="headb" align=left>Source IP</td>
<td class="headb" align=left>Destination<br>IP</td>
<td class="headb" align=left>Source Port</td>
<td class="headb" align=left>Dest Port</td>
<td class="headb" align=left>Extra</td>
<td class="headb" align=center>Action</td></tr>
<td class="headb" align=left colspan=9>Chain $_</td>\n);
	my($rulecheck)=0;
	foreach $rule(@rules)
		{
		my(@info)=split(/\|/,$rule);
		if($info[0] eq $_)
			{
			$rulecheck=1;
			my($prgout)="prgout";
			if(($info[6] eq $port)||($info[7] eq $port)){$prgout="highlight";}
			print qq(<tr><td class="prgout" align=left>$info[1]</td>
<td class="$prgout" align=left>$info[2]</td>
<td class="$prgout" align=left>$info[3]</td>
<td class="$prgout" align=left>$info[4]</td>
<td class="$prgout" align=left>$info[5]</td>
<td class="$prgout" align=left>);
			if($info[6]){print qq($info[6]);}
			else{print qq(-----);}
			print qq(</td>
<td class="$prgout" align=left>);
			if($info[7]){print qq($info[7]);}
			else{print qq(-----);}
			print qq(</td>
<td class="$prgout" align=left>);
			if($info[8]){print qq($info[8]);}
			else{print qq(-----);}
			print qq(</td>
<td class="$prgout" align=left><form action="$script" method="Post" onSubmit="return ConFirm('$prgout')"><input type="submit" value="Remove"><input name="info" type="hidden" value="$_|$info[1]"><input name="do" type="hidden" value="Remove Rule"></FORM></td></tr>\n);
			}
		}
	if(!$rulecheck)
		{
		print qq(<tr><td class="prgout" align=left colspan=9>No Rules</td></tr>\n);
		if(($_ ne "INPUT")&&($_ ne "FORWARD")&&($_ ne "OUTPUT")){print qq(<tr><td class="prgout" align=left colspan=9><form action="$script" method="Post" name="remchain"><input type="submit" value="Remove Chain?"><input name="do" type="hidden" value="Remove Chain"><input name="chain" type="hidden" value="$_"></form></td></tr>\n);}
		}
	}

print qq(<tr><td class="highlight" align=center colspan=9>Highlighted entry shows the port used by the Hosting Helper server daemon.</td></tr>
<tr><td class="prgout" align=center colspan=9><form action="$script" method="Post"><input name="do" type="submit" value="Save Firewall"> * <input name="do" type="submit" value="Restore Firewall" onClick="return ConFirm('firewall');"></FORM></td></tr>
<tr><td class="headb" align=left colspan=9>Add Firewall Rule</td></tr>
<tr><td class="headb">&nbsp;</td>
<td class="headb" align=left>Chain</td>
<td class="headb" align=left>Protocol</td>
<td class="headb" align=left>Source IP</td>
<td class="headb" align=left>Destination<br>IP</td>
<td class="headb" align=left>Source Port</td>
<td class="headb" align=left>Dest Port</td>
<td class="headb" align=left>Extra</td>
<td class="headb" align=left>Action</td></tr>
<tr><td class="prgout">&nbsp;</td>
<td class="prgout" align=left><form action="$script" method="Post" onSubmit="return chkData();" name="addrule"><select name="chain" size=1>);
foreach(@chains){print qq(<option value="$_">$_);}
print qq(</select></td>
<td class="prgout" align=left><select name="prot" size=1><option value="all">All<option value="tcp">tcp<option value="udp">udp<option value="icmp">icmp</select></td>
<td class="prgout" align=left><input name="nsource" type="checkbox" value="!">Not<br><input name="source" type="text" size=15,1 maxlength=31></td>
<td class="prgout" align=left><input name="ndest" type="checkbox" value="!">Not<br><input name="dest" type="text" size=15,1 maxlength=31></td>
<td class="prgout" align=left><input name="nsport" type="checkbox" value="!">Not<br><input name="sport" type="text" size=5,1 maxlength=5></td>
<td class="prgout" align=left><input name="ndport" type="checkbox" value="!">Not<br><input name="dport" type="text" size=5,1 maxlength=5></td>
<td class="prgout" align=left><select name="extra" size=1 onchange="chkcustom(this.options.selectedIndex);"><option value="">--<option value="state RELATED">state RELATED<option value="state ESTABLISHED">state ESTABLISHED<option value="state RELATED,ESTABLISHED">state RELATED,ESTABLISHED
<option value="reject-with icmp-net-unreachable" disabled>icmp-net-unreachable<option value="reject-with icmp-host-unreach-able" disabled>icmp-host-unreach-able<option value="reject-with icmp-port-unreachable" disabled>icmp-port-unreachable<option value="reject-with icmp-proto-unreachable" disabled>icmp-proto-unreachable
<option value="reject-with icmp-net-prohibited" disabled>icmp-net-prohibited<option value="reject-with icmp-host-prohibited" disabled>icmp-host-prohibited<option value="reject-with tcp-reset" disabled>reject-with tcp-reset</select><br>
<input name="custom" type="text" size=30,1></td>
<td class="prgout" align=left><select name="action" size=1 onchange="chkreject(this.options.selectedIndex);"><option value="ACCEPT">ACCEPT<option value="REJECT">REJECT<option value="DROP">DROP<option value="LOG">LOG);
foreach(@chains)
	{
	if(($_ ne "INPUT")&&($_ ne "FORWARD")&&($_ ne "OUTPUT")){print qq(<option value="$_">$_);}
	}
print qq(</select></td></tr>
<tr><td class="prgout" align=right colspan=5>Manner <select name="how" size=1 onchange="chkdis(this.options.selectedIndex);"><option value="I">INSERT<option value="A">ADD</select></td>
<td class="prgout" align=left colspan=4>Insert After <input name="insertno" type="text" size=2,1></td></tr>
<tr><td class="prgout" align=center colspan=9><input type="submit" value="Add Rule"><input name="do" type="hidden" value="Add Rule"></FORM></td></tr>
<tr><td class="headb" align=left colspan=9>Add Chain</td></tr>
<tr><td class="prgout" align=left colspan=9><form action="$script" method="Post" name="addchain"><input name="chain" type="text" size=20,1> <input type="submit" value="Add Chain"><input name="do" type="hidden" value="Add Chain"></form></td></tr>
<tr><td class="headb" align=left colspan=9>Recommended default rules that are missing.</td></tr>\n);
my($fport,$test,$localhost,$icmp);
foreach(@rules)
	{
	my(@info)=split(/\|/,$_);
	if($info[0] eq "INPUT")
		{
		if("$info[2] $info[3] $info[4] $info[5] $info[6] $info[7] $info[8]" =~ /^ACCEPT all 0.0.0.0\/0 0.0.0.0\/0   state RELATED,ESTABLISHED$/){$test=1;}
		if("$info[2] $info[3] $info[4] $info[5] $info[6] $info[7] $info[8]" =~ /^ACCEPT all 127.0.0.1 127.0.0.1   $/){$localhost=1;}
		if("$info[2] $info[3] $info[4] $info[5] $info[6] $info[7] $info[8]" =~ /^ACCEPT icmp 0.0.0.0\/0 0.0.0.0\/0   $/){$icmp=1;}
		}
	}
if(!$localhost)
	{
	print qq(<tr><td class="prgout">&nbsp;</td>
<td class="prgout" align=left>ACCEPT</td>
<td class="prgout" align=left>all</td>
<td class="prgout" align=left>127.0.0.1</td>
<td class="prgout" align=left>127.0.0.1</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left><form action="$script" method="Post"><input name="do" type="submit" value="Add Rule"><input name="chain" type="hidden" value="INPUT"><input name="prot" type="hidden" value="all"><input name="source" type="hidden" value="127.0.0.1"><input name="dest" type="hidden" value="127.0.0.1"><input name="action" type="hidden" value="ACCEPT"><input name="how" type="hidden" value="I"></FORM></td></tr>\n);
	}
if(!$test)
	{
	print qq(<tr><td class="prgout">&nbsp;</td>
<td class="prgout" align=left>ACCEPT</td>
<td class="prgout" align=left>all</td>
<td class="prgout" align=left>0.0.0.0/0</td>
<td class="prgout" align=left>0.0.0.0/0</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left>RELATED,ESTABLISHED</td>
<td class="prgout" align=left><form action="$script" method="Post"><input name="do" type="submit" value="Add Rule"><input name="chain" type="hidden" value="INPUT"><input name="prot" type="hidden" value="all"><input name="source" type="hidden" value="0.0.0.0/0"><input name="dest" type="hidden" value="0.0.0.0/0"><input name="state" type="hidden" value="RELATED,ESTABLISHED"><input name="action" type="hidden" value="ACCEPT"><input name="how" type="hidden" value="I"></FORM></td></tr>\n);
	}
if(!$icmp)
	{
	print qq(<tr><td class="prgout">&nbsp;</td>
<td class="prgout" align=left>ACCEPT</td>
<td class="prgout" align=left>icmp</td>
<td class="prgout" align=left>0.0.0.0/0</td>
<td class="prgout" align=left>0.0.0.0/0</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left><form action="$script" method="Post"><input name="do" type="submit" value="Add Rule"><input name="chain" type="hidden" value="INPUT"><input name="prot" type="hidden" value="icmp"><input name="source" type="hidden" value="0.0.0.0/0"><input name="dest" type="hidden" value="0.0.0.0/0"><input name="action" type="hidden" value="ACCEPT"><input name="how" type="hidden" value="I"></FORM></td></tr>\n);
	}
my($ftpudp,$ftptcp20,$ftpudp20);
foreach $fport(@ports)
	{
	my(@info)=split(/\|/,$fport);
	if($info[1] eq "0.0.0.0"){$info[1].="/0";}
	my($test);
	foreach(@rules)
		{
		my(@info2)=split(/\|/,$_);
		if($info2[0] eq "INPUT")
			{
			my($testa)="$info2[1] $info2[2] $info2[3] $info2[4] $info2[5] $info2[6] $info2[7]";
			my($testb)="ACCEPT $info[0] 0.0.0.0/0 $info[1]  $info[2] ";
			if(("$info2[2] $info2[3] $info2[4] $info2[5] $info2[6] $info2[7] $info2[8]" =~ /^ACCEPT $info[0] 0.0.0.0\/0 $info[1]  $info[2] $/)||($info[2] eq $port)||($info[1] eq "127.0.0.1")){$test=1;}
			if(($info[2] eq "21")&&($info[0] eq "tcp")&&(!$ftpudp)){$ftpudp=1;push(@ports,"udp|$info[1]|21|$info[3]|$info[4]");}
			if(($info[2] eq "21")&&($info[0] eq "tcp")&&(!$ftpudp20)){$ftpudp20=1;push(@ports,"udp|$info[1]|20|$info[3]|$info[4]");}
			if(($info[2] eq "21")&&($info[0] eq "tcp")&&(!$ftptcp20)){$ftptcp20=1;push(@ports,"tcp|$info[1]|20|$info[3]|$info[4]");}
			}
		}
	if(!$test)
		{
		if($info[1] eq "0.0.0.0"){$info[1].="/0";}
		print qq(<tr><td class="prgout">&nbsp;</td>
<td class="prgout" align=left>ACCEPT</td>
<td class="prgout" align=left>$info[0]</td>
<td class="prgout" align=left>0.0.0.0/0</td>
<td class="prgout" align=left>$info[1]</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left>$info[2]</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=center><form action="$script" method="Post"><input name="do" type="submit" value="Add Rule"><input name="chain" type="hidden" value="INPUT"><input name="prot" type="hidden" value="$info[0]"><input name="source" type="hidden" value="0.0.0.0/0"><input name="dest" type="hidden" value="$info[1]"><input name="dport" type="hidden" value="$info[2]"><input name="action" type="hidden" value="ACCEPT"><input name="how" type="hidden" value="I"></FORM></td></tr>\n);
		}
	}
($test)=0;
foreach(@rules)
	{
	my(@info)=split(/\|/,$_);
	if($info[0] eq "INPUT")
		{
		if("$info[2] $info[3] $info[4] $info[5] $info[6] $info[7]" =~ /^REJECT all 0.0.0.0(\/0)? 0.0.0.0(\/0)?/){$test=1;}
		}
	}
if(!$test)
	{
	print qq(<tr><td class="prgout">&nbsp;</td>
<td class="prgout" align=left>REJECT</td>
<td class="prgout" align=left>all</td>
<td class="prgout" align=left>0.0.0.0/0</td>
<td class="prgout" align=left>0.0.0.0/0</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left>-----</td>
<td class="prgout" align=left>reject-with tcp-reset</td>
<td class="prgout" align=center><form action="$script" method="Post"><input name="do" type="submit" value="Add Rule"><input name="chain" type="hidden" value="INPUT"><input name="prot" type="hidden" value="all"><input name="source" type="hidden" value="0.0.0.0/0"><input name="dest" type="hidden" value="0.0.0.0/0"><input name="action" type="hidden" value="REJECT"><input name="how" type="hidden" value="A"><input name="extra" type="hidden" value="reject-with icmp-port-unreachable"></FORM></td></tr>\n);
	}
print qq(</table>\n);
&Bottom;
}

##

sub Show_Firewall
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=list+rules);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
my(@chains)=split(/:/,$remote{'chains'});
my(@rules)=split(/::/,$remote{'rules'});
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=7>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center colspan=7>View Firewall Rules</td></tr>\n);
foreach(@chains)
	{
	my($rule);
	print qq(<tr><td class="headb" align=left>Target</td>
<td class="headb" align=left>Protocol</td>
<td class="headb" align=left>Source</td>
<td class="headb" align=left>Destination</td>
<td class="headb" align=left>Source Port</td>
<td class="headb" align=left>Destination Port</td>
<td class="headb" align=left>Extra</td></tr>
<td class="headb" align=left colspan=7>Chain $_</td>\n);
	foreach $rule(@rules)
		{
		my(@info)=split(/\|/,$rule);
		if($info[0] eq $_)
			{
			my($prgout)="prgout";
			if(($info[6] eq $port)||($info[7] eq $port)){$prgout="highlight";}
			print qq(<tr><td class="$prgout" align=left>$info[2]</td>
<td class="$prgout" align=left>$info[3]</td>
<td class="$prgout" align=left>$info[4]</td>
<td class="$prgout" align=left>$info[5]</td>
<td class="$prgout" align=left>);
			if($info[6]){print qq($info[6]);}
			else{print qq(-----);}
			print qq(</td>
<td class="$prgout" align=left>);
			if($info[7]){print qq($info[7]);}
			else{print qq(-----);}
			print qq(</td>
<td class="$prgout" align=left>);
			if($info[8]){print qq($info[8]);}
			else{print qq(-----);}
			print qq(</td></tr>\n);
			}
		}
	}
#else{print qq(<tr><td class="prgout" align=left colspan=7>No Rules</td></tr>\n);}

print qq(<tr><td class="highlight" align=center colspan=7>Highlighted entry shows the port used by the Hosting Helper server daemon.</td></tr>
</table>\n);
&Bottom;
}

##

sub List_Ports
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'SM1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE id='$Cookies{'serverid'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
my($serverkey)=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=list+ports);
&Connect($ip,$port,$serverkey,$command);
if($remote{'status'} ne "done"){&Error($remote{'status'});}
my(@ports)=split(/:/,$remote{'ports'});
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=5>Currently Managing $Cookies{'server'}</td></tr>
<tr><td class="heada" align=center colspan=5>List Open Ports</td></tr>
<tr><td class="headb" align=left>Protocol</td>
<td class="headb" align=left>Bound IP Address</td>
<td class="headb" align=left>Port</td>
<td class="headb" align=left>Process ID</td>
<td class="headb" align=left>Program</td></tr>\n);
foreach(@ports)
	{
	if($_)
		{
		my(@info)=split(/\|/,$_);
		my($prgout)="prgout";
		if($info[2] eq $port){$prgout="highlight";}
		print qq(<tr><td class="$prgout" align=left>$info[0]</td>
<td class="$prgout" align=left>$info[1]</td>
<td class="$prgout" align=left>$info[2]</td>
<td class="$prgout" align=left>$info[3]</td>
<td class="$prgout" align=left>$info[4]</td></tr>\n);
		}
	}
print qq(<tr><td class="highlight" align=center colspan=5>Highlighted entry shows the port used by the Hosting Helper server daemon.</td></tr>
</table>\n);
&Bottom;
}

1;
