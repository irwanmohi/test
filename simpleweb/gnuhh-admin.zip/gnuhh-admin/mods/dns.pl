sub Update_SOA
{
if(($Cookies{'level'} ne "1")&&($access{'ADM1'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=&uri_escape($FORM{$_});}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE type='ns1');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=update+soa&zone=$FORM{'zone'}&refresh=$FORM{'refresh'}&retry=$FORM{'retry'}&expire=$FORM{'expire'}&minimum=$FORM{'minimum'}&ttl=$FORM{'ttl'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
$statement=qq(SELECT name,ip,port,serverpass,dnstype FROM server WHERE type='ns2');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($dnstype);
($name,$ip,$port,$serverpass,$dnstype)=$query_output->fetchrow;
if($dnstype eq "mydns")
	{
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
	}
&Edit_Zone;
}

##

sub Delete_Record
{
if(($Cookies{'level'} ne "1")&&($access{'ADM1'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=&uri_escape($FORM{$_});}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE type='ns1');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=delete+record&zone=$FORM{'zone'}&id=$FORM{'id'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
$statement=qq(SELECT name,ip,port,serverpass,dnstype FROM server WHERE type='ns2');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($dnstype);
($name,$ip,$port,$serverpass,$dnstype)=$query_output->fetchrow;
if($dnstype eq "mydns")
	{
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
	}
&Edit_Zone;
}

##

sub Update_Record
{
if(($Cookies{'level'} ne "1")&&($access{'ADM1'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=&uri_escape($FORM{$_});}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE type='ns1');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=update+record&zone=$FORM{'zone'}&id=$FORM{'id'}&name=$FORM{'name'}&type=$FORM{'type'}&data=$FORM{'data'}&aux=$FORM{'aux'}&ttl=$FORM{'ttl'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
$statement=qq(SELECT name,ip,port,serverpass,dnstype FROM server WHERE type='ns2');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($dnstype);
($name,$ip,$port,$serverpass,$dnstype)=$query_output->fetchrow;
if($dnstype eq "mydns")
	{
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
	}
&Edit_Zone;
}

##

sub Add_Record
{
if(($Cookies{'level'} ne "1")&&($access{'ADM1'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=&uri_escape($FORM{$_});}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass FROM server WHERE type='ns1');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=add+record&zone=$FORM{'zone'}&name=$FORM{'name'}&type=$FORM{'type'}&data=$FORM{'data'}&aux=$FORM{'aux'}&ttl=$FORM{'ttl'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
$statement=qq(SELECT name,ip,port,serverpass,dnstype FROM server WHERE type='ns2');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($dnstype);
($name,$ip,$port,$serverpass,$dnstype)=$query_output->fetchrow;
if($dnstype eq "mydns")
	{
	if(&decode_base64($serverpass) =~ /^Randomiv/i)
		{
		if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
		else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
		}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
	$serverpass=$cipher->decrypt(&decode_base64($serverpass));
	&Connect($ip,$port,$serverpass,$command);
	if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
	}
&Edit_Zone;
}

##

sub Edit_Zone
{
if(($Cookies{'level'} ne "1")&&($access{'ADM1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT name,ip,port,serverpass,includepath,dnstype FROM server WHERE type='ns1');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($name,$ip,$port,$serverpass,$includepath,$dnstype)=$query_output->fetchrow;
my($cipher);
if(&decode_base64($serverpass) =~ /^Randomiv/i)
	{
	if($system{'cryptver'} < 2.17){$cipher=new Crypt::CBC($system{'enckey'},'Rijndael');}
	else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-header=>'randomiv',-insecure_legacy_decrypt=>'1');}
	}
else{$cipher=Crypt::CBC->new(-key=>$system{'enckey'},-cipher=>'Rijndael',-salt=>'1');}
$serverpass=$cipher->decrypt(&decode_base64($serverpass));
my($command)=qq(do=get+records&zone=$FORM{'zone'});
&Connect($ip,$port,$serverpass,$command);
if($remote{'status'} ne "done"){&Error("$remote{'status'}");}
my(@records)=split(/:/,$remote{'records'});
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=8>Edit DNS SOA Record for $FORM{'zone'}</td></tr>
<tr><td class="headb" align=left>Name Server</td>
<td class="headb" align=left>Mail Box</td>
<td class="headb" align=left>Serial</td>
<td class="headb" align=left>Refresh</td>
<td class="headb" align=left>Retry</td>
<td class="headb" align=left>Expire</td>
<td class="headb" align=left>Minimum</td>
<td class="headb" align=left>TTL</td></tr>
<tr><td class="prgout" align=left>$remote{'ns'}</td>
<td class="prgout" align=left>$remote{'mbox'}</td>
<td class="prgout" align=left>$remote{'serial'}</td>
<td class="prgout" align=left><input name="refresh" type="text" value="$remote{'refresh'}" size=10,1 maxlength=10></td>
<td class="prgout" align=left><input name="retry" type="text" value="$remote{'retry'}" size=10,1 maxlength=10></td>
<td class="prgout" align=left><input name="expire" type="text" value="$remote{'expire'}" size=10,1 maxlength=10></td>
<td class="prgout" align=left><input name="minimum" type="text" value="$remote{'minimum'}" size=10,1 maxlength=10></td>
<td class="prgout" align=left><input name="ttl" type="text" value="$remote{'ttl'}" size=10,1 maxlength=10></td></tr>
<tr><td class="prgout" align=center colspan=8><input type="submit" value="Update SOA"></td></tr>
</table>
<input name="zone" type="hidden" value="$FORM{'zone'}">
<input name="do" type="hidden" value="Update SOA">
</form>
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=);
if($dnstype eq "mydns"){print qq(6);}
else{print qq(5);}
print qq(>Edit DNS Zone for $FORM{'zone'}</td></tr>
<tr><td class="headb" align=left>Name</td>
<td class="headb" align=left>Type</td>
<td class="headb" align=left>Data</td>
<td class="headb" align=left>Aux</td>\n);
if($dnstype eq "mydns"){print qq(<td class="headb" align=left>TTL</td>\n);}
print qq(<td class="headb" align=center>Action</td></tr>\n);
foreach(@records)
	{
	my(@info)=split(/\|/,$_);
	print qq(<form action="$script" method="Post">
<tr><td class="prgout" align=left><input name="name" type="text" value="$info[1]" size=20,1 maxlength=64></td>
<td class="prgout" align=left><select name="type" size=1><option value="A");
if($info[2] eq "A"){print qq( selected);}
print qq(>A<option value="AAAA");
if($info[2] eq "AAAA"){print qq( selected);}
print qq(>AAAA<option value="CNAME");
if($info[2] eq "CNAME"){print qq( selected);}
print qq(>CNAME<option value="HINFO");
if($info[2] eq "HINFO"){print qq( selected);}
print qq(>HINFO<option value="MX");
if($info[2] eq "MX"){print qq( selected);}
print qq(>MX<option value="NS");
if($info[2] eq "NS"){print qq( selected);}
print qq(>NS<option value="PTR");
if($info[2] eq "PTR"){print qq( selected);}
print qq(>PTR<option value="RP");
if($info[2] eq "RP"){print qq( selected);}
print qq(>RP<option value="SRV");
if($info[2] eq "SRV"){print qq( selected);}
print qq(>SRV<option value="TXT");
if($info[2] eq "TXT"){print qq( selected);}
print qq(>TXT</select></td>
<td class="prgout" align=left><input name="data" type="text" value="$info[3]" size=20,1 maxlength=128></td>
<td class="prgout" align=left><input name="aux" type="text" value="$info[4]" size=10,1 maxlength=10></td>\n);
if($dnstype eq "mydns"){print qq(<td class="prgout" align=left><input name="ttl" type="text" value="$info[5]" size=10,1 maxlength=10></td>\n);}
print qq(<td class="prgout" align=left><input name="do" type="submit" value="Update Record"> * <input name="do" type="submit" value="Delete Record"></td></tr>
<input name="zone" type="hidden" value="$FORM{'zone'}">
<input name="id" type="hidden" value="$info[0]">
</form>\n);
	}
print qq(<form action="$script" method="Post">
<tr><td class="prgout" align=left><input name="name" type="text" size=20,1 maxlength=64></td>
<td class="prgout" align=left><select name="type" size=1><option value="A">A<option value="AAAA">AAAA<option value="CNAME">CNAME<option value="HINFO">HINFO
<option value="MX">MX<option value="NS">NS<option value="PTR">PTR<option value="RP">RP<option value="SRV">SRV<option value="TXT">TXT</select></td>
<td class="prgout" align=left><input name="data" type="text" size=20,1 maxlength=128></td>
<td class="prgout" align=left><input name="aux" type="text" value="0" size=10,1 maxlength=10></td>\n);
if($dnstype eq "mydns"){print qq(<td class="prgout" align=left><input name="ttl" type="text" value="86400" size=10,1 maxlength=10></td>\n);}
print qq(<td class="prgout" align=left><input name="do" type="submit" value="Add Record"></td></tr>
<input name="zone" type="hidden" value="$FORM{'zone'}">
</form>
</table>);
&Bottom;
}

##

sub Edit_Zone_Select
{
if(($Cookies{'level'} ne "1")&&($access{'ADM1'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
var action="Edit Zone";
var Extra;
// -->
</script>
<script language="javascript" src="$script?do=prefetch+zone+js"></script>
<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit DNS Zone</td></tr>
<tr><td class="prgout" align=left>Domain</td>
<td class="prgout" align=left><input id="sfield" name="zone" type="text" size=30,1 maxlength=50 onKeyUp="setTimeout('loadXMLDoc()',timeout*1000);"></td></tr>
</table>
<input name="do" type="hidden" value="Edit Zone">
</form>
<DIV id="dlist" style="position:absolute;display:none;visibility:hide;"></DIV>);
my($more)=qq(<script language="javascript">
<!--
StartUp();
// -->
</script>);
&Bottom($more);
}

1;
