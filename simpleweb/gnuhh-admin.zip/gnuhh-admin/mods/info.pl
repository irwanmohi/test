sub Remove_News
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NM3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM news WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>News entry removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_News2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NM3'} ne "yes")){&Error('Insufficient access for this function');}
if(length($FORM{'mon'})==1){$FORM{'mon'}="0".$FORM{'mon'};}
if(length($FORM{'day'})==1){$FORM{'day'}="0".$FORM{'day'};}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,pdate,subject FROM news WHERE pdate='$FORM{'year'}-$FORM{'mon'}-$FORM{'day'}' ORDER BY id DESC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$pdate,$subject);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to delete this news entry?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove News Select</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Subject-Date</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Article--);
while(($id,$pdate,$subject)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$subject-$pdate);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove Article"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Remove News">
</FORM>);
&Bottom;
}


##

sub Remove_News_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NM3'} ne "yes")){&Error('Insufficient access for this function');}
my @months=('','January','February','March','April','May','June','July','August','September','October','November','December');
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$year+=1900;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Remove News</td></tr>
<tr><td class="prgout" align=left>Post Date</td>
<td class="prgout" align=left><select name="mon" size=1>);
my($i);
for($i=1;$i<=12;$i++){print qq(<option value="$i">$months[$i]);}
print qq(</select><select name="day" size=1>);
for($i=1;$i<=31;$i++){print qq(<option value="$i">$i);}
print qq(</select><select name="year" size=1>);
for($i=2005;$i<=$year;$i++){print qq(<option value="$i">$i);}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Remove News2">
</form>);
&Bottom;
}

##

sub Remove_Ibase_Entry
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM ibase WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Knowledgebase entry removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Ibase_Entry_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB3'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM ibasecat ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function ConFirm()
{
if(confirm("Do you want to delete this knowledge base entry?"))
	{
	return true;
	}
else
return false;
}
// -->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return ConFirm()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove Knowledge Base Entry</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Category</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="cat" SIZE=1 onChange="SetEntry(this.options.selectedIndex);"><OPTION VALUE="">--Select Category--);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Entry</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Entry--</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove Entry"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Remove Ibase Entry">
</FORM>
<SCRIPT LANGUAGE="javascript">
<!--
var groups=document.forms[0].cat.options.length
var group=new Array(groups)
for (i=0; i<groups; i++)
group[i]=new Array()
group[0][0]=new Option("","--Select Entry--");\n);
my($idcount,$entrycount);
$idcount=1;
$query_output->dataseek();
while(($id,$name)=$query_output->fetchrow)
	{
	$entrycount=1;
	print qq(group[$idcount][0]=new Option("","--Select Entry--")\n);
	$statement=qq(SELECT id,question FROM ibase WHERE category='$id' ORDER BY question ASC);
	my($query_output2)=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($eid,$question);
	while(($eid,$question)=$query_output2->fetchrow)
		{
		print qq(group[$idcount][$entrycount]=new Option("$eid","$question")\n);
		$entrycount++;
		}
	$idcount++;
	}
print qq(var temp=document.forms[0].id
function SetEntry(x)
	{
	for (m=temp.options.length-1;m>0;m--)
	temp.options[m]=null
	for (i=0;i<group[x].length;i++)
		{
		temp.options[i]=new Option(group[x][i].value,group[x][i].text)
		}
	temp.options[0].selected=true
	}
//-->
</SCRIPT>);
&Bottom;
}

##

sub Save_Ibase_Entry
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE ibase SET question='$FORM{'question'}',category='$FORM{'cat'}',answer='$FORM{'answer'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Knowledgebase entry updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Ibase_Entry
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT question,category,answer FROM ibase WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($question,$category,$answer)=$query_output->fetchrow;
$answer=~s/"/&quot;/g;
$answer=~s/</&lt;/g;
$answer=~s/>/&gt;/g;
$question=~s/"/&quot;/g;
$statement=qq(SELECT id,name FROM ibasecat ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Edit Knowledge Base Entry</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Category</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="cat" SIZE=1><OPTION VALUE="">--Select Category);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id");
	if($id eq $category){print qq( SELECTED);}
	print qq(>$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Question</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="question" TYPE="text" VALUE="$question" SIZE=50,1 MAXLENGTH=255></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2>Answer<BR>
Use %%DOMAIN%% to place managed domain name<BR>
Use %%IP%% to place managed domain ip address<BR>
Use %%ADMIN%% to place the name and email address of the domain administrator<BR>
Use %%SCRIPT%% to place the url of the client console</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2> <TEXTAREA NAME="answer" ROWS=15 COLS=50 WRAP=off>$answer</TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Save Entry"></TD></TR>
</TABLE>
<INPUT NAME="id" TYPE="hidden" VALUE="$FORM{'id'}">
<INPUT NAME="do" TYPE="hidden" VALUE="Save Ibase Entry">
</FORM>);
&Bottom;
}

##

sub Edit_Ibase_Entry_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM ibasecat ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Edit Knowledge Base Entry Selection</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Category</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="cat" SIZE=1 onChange="SetEntry(this.options.selectedIndex);"><OPTION VALUE="">--Select Category--);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Entry</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Entry--</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Edit Entry"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Edit Ibase Entry">
</FORM>
<SCRIPT LANGUAGE="javascript">
<!--
var groups=document.forms[0].cat.options.length
var group=new Array(groups)
for (i=0; i<groups; i++)
group[i]=new Array()
group[0][0]=new Option("","--Select Entry--");\n);
my($idcount,$entrycount);
$idcount=1;
$query_output=$db->query($statement);
while(($id,$name)=$query_output->fetchrow)
	{
	$entrycount=1;
	print qq(group[$idcount][0]=new Option("","--Select Entry--")\n);
	$statement=qq(SELECT id,question FROM ibase WHERE category='$id' ORDER BY question ASC);
	my($query_output2)=$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	my($eid,$question);
	while(($eid,$question)=$query_output2->fetchrow)
		{
		$question=~s/"/\\"/g;
		print qq(group[$idcount][$entrycount]=new Option("$eid","$question")\n);
		$entrycount++;
		}
	$idcount++;
	}
print qq(var temp=document.forms[0].id
function SetEntry(x)
	{
	for (m=temp.options.length-1;m>0;m--)
	temp.options[m]=null
	for (i=0;i<group[x].length;i++)
		{
		temp.options[i]=new Option(group[x][i].value,group[x][i].text)
		}
	temp.options[0].selected=true
	}
//-->
</SCRIPT>);
&Bottom;
}

##

sub Add_Ibase_Entry
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB1'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(INSERT INTO ibase (question,category,answer) VALUES ('$FORM{'question'}','$FORM{'id'}','$FORM{'answer'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Knowledgebase entry added</td></tr>
</table>);
&Bottom;
}

##

sub Add_Ibase_Entry_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB1'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM ibasecat ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Add Knowledge Base Entry</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Category</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Category);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Question</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="question" TYPE="text" SIZE=50,1 MAXLENGTH=255></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2>Answer<BR>
Use %%DOMAIN%% to place managed domain name<BR>
Use %%IP%% to place managed domain ip address<BR>
Use %%ADMIN%% to place the name and email address of the domain administrator<BR>
Use %%SCRIPT%% to place the url of the client console</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2> <TEXTAREA NAME="answer" ROWS=15 COLS=50 WRAP=off></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Add Entry"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Add Ibase Entry">
</FORM>);
&Bottom;
}

##

sub Remove_Ibase_Cat
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(DELETE FROM ibasecat WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
$statement=qq(UPDATE ibase SET category='$FORM{'newcat'}' WHERE category='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Knowledgebase category removed</td></tr>
</table>);
&Bottom;
}

##

sub Remove_Ibase_Cat_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB6'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM ibasecat ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a category to remove.");
return false;
}
if(document.forms[0].newcat.selectedIndex <= 0)
{
alert("Select a category to move existing information to.");
return false;
}
if(document.forms[0].id.selectedIndex == document.forms[0].newcat.selectedIndex)
{
alert("You can't move items to the category your going to remove.");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Remove Knowledge Base Category</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Category to remove</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Category--);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Category to move entries to</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="newcat" SIZE=1><OPTION VALUE="">--Select Category--);
$query_output->dataseek();
if($error=$db->errmsg){&Error($error);}
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Remove Category"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Remove Ibase Cat">
</FORM>);
&Bottom;
}

##

sub Save_Ibase_Cat
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB5'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'cat'}=~s/\'/\\'/g;
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT COUNT(id) FROM ibasecat WHERE name='$FORM{'cat'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=$query_output->fetchrow;
if($count > 0){&Error("Category, $FORM{'cat'}, already exists");}
$statement=qq(UPDATE ibasecat SET name='$FORM{'cat'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Knowledgebase category updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_Ibase_Cat
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB5'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,name FROM ibasecat ORDER BY name ASC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$name);
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].id.selectedIndex <= 0)
{
alert("Select a category to edit.");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Edit Knowledge Base Category</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Category</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1 onChange="ChgVal();"><OPTION VALUE="">--Select Category--);
while(($id,$name)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$name);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>New Name</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="cat" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Save Category"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Save Ibase Cat">
</FORM>
<SCRIPT LANGUAGE="javascript">
<!--
function ChgVal()
	{
	if(document.forms[0].id.selectedIndex > 0)
		{
		document.forms[0].cat.value=document.forms[0].id.options[document.forms[0].id.options.selectedIndex].text;
		}
	else
		{
		document.forms[0].cat.value="";
		}
	}
//-->
</SCRIPT>);
&Bottom;
}

##

sub Add_Ibase_Cat
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB4'} ne "yes")){&Error('Insufficient access for this function');}
$FORM{'cat'}=~s/\'/\\'/g;
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT COUNT(id) FROM ibasecat WHERE name='$FORM{'cat'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($count)=$query_output->fetchrow;
if($count > 0){&Error("The category $FORM{'cat'} already exists");}
$statement=qq(INSERT INTO ibasecat (name) VALUES ('$FORM{'cat'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>Knowledgebase category added</td></tr>
</table>);
&Bottom;
}

##

sub Add_Ibase_Cat_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'KB4'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<script language="javascript">
<!--
function chkData() {
if(document.forms[0].cat.value <= 0)
{
alert("enter a category name.");
return false;
}
else
return true;
}
//-->
</script>
<FORM ACTION="$script" METHOD="Post" onSubmit="return chkData()">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Add Knowledge Base Category</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Category</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="cat" TYPE="text" SIZE=30,1 MAXLENGTH=50></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Add Category"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Add Ibase Cat">
</FORM>);
&Bottom;
}

##

sub Save_News
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NM2'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(UPDATE news SET subject='$FORM{'subject'}',article='$FORM{'news'}' WHERE id='$FORM{'id'}');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>News entry updated</td></tr>
</table>);
&Bottom;
}

##

sub Edit_News
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NM2'} ne "yes")){&Error('Insufficient access for this function');}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT subject,article FROM news WHERE id='$FORM{'id'}');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($subject,$article)=$query_output->fetchrow;
$subject=~s/"/&quot;/g;
$subject=~s/</&lt;/g;
$subject=~s/>/&gt;/g;
$article=~s/"/&quot;/g;
$article=~s/</&lt;/g;
$article=~s/>/&gt;/g;
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Edit News Article $FORM{'id'}</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Subject</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="subject" TYPE="text" VALUE="$subject" SIZE=50,1 MAXLENGTH=255></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2>News</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2> <TEXTAREA NAME="news" ROWS=25 COLS=75 WRAP=off>$article</TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Save News"></TD></TR>
</TABLE>
<INPUT NAME="id" TYPE="hidden" VALUE="$FORM{'id'}">
<INPUT NAME="do" TYPE="hidden" VALUE="Save News">
</FORM>);
&Bottom;
}

##

sub Edit_News2
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NM2'} ne "yes")){&Error('Insufficient access for this function');}
if(length($FORM{'mon'})==1){$FORM{'mon'}="0".$FORM{'mon'};}
if(length($FORM{'day'})==1){$FORM{'day'}="0".$FORM{'day'};}
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(SELECT id,pdate,subject FROM news WHERE pdate='$FORM{'year'}-$FORM{'mon'}-$FORM{'day'}' ORDER BY id DESC);
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$pdate,$subject);
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Edit News Select</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Subject-Date</TD>
<TD CLASS="prgout" ALIGN=left><SELECT NAME="id" SIZE=1><OPTION VALUE="">--Select Article--);
while(($id,$pdate,$subject)=$query_output->fetchrow)
	{
	print qq(<OPTION VALUE="$id">$subject-$pdate);
	}
print qq(</SELECT></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Edit Article"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Edit News">
</FORM>);
&Bottom;
}

##

sub Edit_News_Select
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NM2'} ne "yes")){&Error('Insufficient access for this function');}
my @months=('','January','February','March','April','May','June','July','August','September','October','November','December');
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$year+=1900;
&Top;
print qq(<form action="$script" method="Post">
<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="heada" align=center colspan=2>Edit News</td></tr>
<tr><td class="prgout" align=left>Post Date</td>
<td class="prgout" align=left><select name="mon" size=1>);
my($i);
for($i=1;$i<=12;$i++){print qq(<option value="$i">$months[$i]);}
print qq(</select><select name="day" size=1>);
for($i=1;$i<=31;$i++){print qq(<option value="$i">$i);}
print qq(</select><select name="year" size=1>);
for($i=2005;$i<=$year;$i++){print qq(<option value="$i">$i);}
print qq(</select></td></tr>
<tr><td class="prgout" align=center colspan=2><input type="submit" value="Continue"></td></tr>
</table>
<input name="do" type="hidden" value="Edit News2">
</form>);
&Bottom;
}

##

sub Add_News
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NM1'} ne "yes")){&Error('Insufficient access for this function');}
foreach(keys %FORM){$FORM{$_}=~s/\'/\\'/g;}
my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$mon++;$year+=1900;
my($db,$statement,$query_output,$error);
&Error("Database connection error") unless $db=Mysql->connect($system{'dbhost'},$system{'dbname'},$system{'dbuser'},$system{'dbpass'});
$statement=qq(INSERT INTO news (pdate,subject,article) VALUES ('$year-$mon-$mday','$FORM{'subject'}','$FORM{'news'}'));
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
&Top;
print qq(<table align=center border=0 cellpadding=2 cellspacing=2 class="admin">
<tr><td class="prgout" align=left>News entry added</td></tr>
</table>);
&Bottom;
}

##

sub Add_News_Form
{
&Check_Password;
if(($Cookies{'level'} ne "1")&&($access{'NM1'} ne "yes")){&Error('Insufficient access for this function');}
&Top;
print qq(<FORM ACTION="$script" METHOD="Post">
<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=2 CLASS="admin">
<TR><TD CLASS="heada" ALIGN=center COLSPAN=2>Add News Article</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left>Subject</TD>
<TD CLASS="prgout" ALIGN=left><INPUT NAME="subject" TYPE="text" SIZE=50,1 MAXLENGTH=255></TD></TR>
<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2>News</TD></TR>
<TR><TD CLASS="prgout" ALIGN=left COLSPAN=2> <TEXTAREA NAME="news" ROWS=25 COLS=75 WRAP=off></TEXTAREA></TD></TR>
<TR><TD CLASS="prgout" ALIGN=center COLSPAN=2><INPUT TYPE="submit" VALUE="Add News"></TD></TR>
</TABLE>
<INPUT NAME="do" TYPE="hidden" VALUE="Add News">
</FORM>);
&Bottom;
}

1;
