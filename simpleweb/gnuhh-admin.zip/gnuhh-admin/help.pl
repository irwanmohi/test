program path|Program Path|The server path the this cgi program
imageurl|Image URL|The URL of the directory containing images used by this program
idletime|Idle Timeout|The number of minutes idle before an admin is automatically logged out
useframes|Use Frames?|Select if frames will be used in the admin control panel
logattempt|Login Lockout After # Attempts|The number of failed attempts in 30 seconds before login is locked to an ip in admin or client
logtime|Login Lockout Timer|The number of minutes that an ip will be locked out of login after login lockout is initiated
adminemail|Administrators Email|The email address of the adminstrator or email address associated with account assistance
dbhost|Database Hostname|The hostname used to access the MySQL database for Hosting Helper Admin
dbname|Database Name|The name of the MySQL database for Hosting Helper Admin
dbuser|Database Username|The username used to access the MySQL database for Hosting Helper Admin
dbpass|Database Password|The password used to access the MySQL database for Hosting Helper Admin
nfpath|iptables path|The system path to the directory containing the iptables program for managing netfilter
servername|Server Name (FQDN)|The fully qualified domain name of the server your adding
serverip|Server IP|The IP address of the server your adding
serverport|Server Port|The port to connect to on the server your adding
serverpass|Server Password|The password used to access the hosting helper daemon on the server
useemail|Use Email|Will you support email functions for this hosting server (email may still be remote)?
usewebmail|Use Webmail|Will you be using webmail services on this server (email must be local)?
usens1|Use Primary Name Server|Will you be using primary name server services?
usens2|Use Secondary Name Server|Will you be using secondary name services?
usemysql|Use MySQL|Will you be using MySQL services for this hosting server?
usesubdomain|Use Sub Domain|Will you be using sub domain services for this hosting server?
usewebalizer|Use Webalizer|Will you be using webalizer for stats on this hosting server?
usevirtftp|Use Virtual FTP Support|Will you be using virtual ftp support for domains?
netfilter|Use Netfilter|Will you use Netfilter (iptables) to add additional security between daemons and web applications? (requires kernel 2.4 or greater with iptables/netfilter support)
usefilecheck|Use Filecheck|Will you use Filecheck system to monitor files for changes?
notifyfilecheck|Filecheck Notify Email|Email address to be sent Filecheck reports
autofirewall|Automatically load Firewall at startup?|Do you want to automatically load saved firewall at hosting helper daemon startup?
sdbhost|Server Database Hostname|The hostname used to access the MySQL database for this Hosting Server
sdbname|Server Database Name|The name of the MySQL database for this Hosting Server
sdbuser|Server Database Username|The username used to access the MySQL database for this Hosting Server
sdbpass|Server Database Password|The password used to access the MySQL database for this Hosting Server
clienturl|Client URL|The full URL to the client program
clientuser|Username running client.cgi|The system user that client.cgi will be running as
clientgroup|Group running client.cgi|The system group that client.cgi will be running as
mailpath|Path to email users directory|The system path to the base directory for email users
mailcw|Sendmail CW file|The system path and name of the Sendmail CW (local-host-names) file
mailvirtuser|Sendmail virtual user file|The system path and name of the Sendmail virtual user (virtusertable) file
mailrestart|Email server restart command|The system command used to restart the mail server
mailstart|Email server start command|The system command used to start the mail server
mailstop|Email server stop command|The system command used to stop the mail server
mailip|Email server IP|The IP address of the mail server machine for process connections
mailport|Email server port|The port to connect to on the mail server for process connections
mailpass|Mail server password|The password used to access the hosting helper daemon on mail server
mailquota|Web Mail Quota|The disk quota for web mail users on a mail server (web mail must be local to a mail server)
fpext|Front Page Extensions|The Front Page Extensions to be supported
apacheconf|Web server configuration file|The system path and name of the web server configuration file
virtconf|Path to virtual hosting configuration files|The system path to the directory that will contain the virtual host files
userdir|Path to user's directory|The system path to the base directory for web server user accounts
logpath|Path to log files|The system path to the directory to contain web server log files|
hosttype|Virtual Hosting Type|The virtual hosting method for the web server (named based or ip based)
sslsupport|Support SSL|Do you want to support for SSL? (IP based hosting only)
firstip|First IP address|The first ip address if named based hosting is used
secondip|Second IP address|The second ip address if named based hosting is used
ftplog|FTPd log file|The system path and name of the log file for the FTPd server
ftprestart|FTPd server restart command|The system command to restart the FTPd server
ftpstart|FTPd server start command|The system command to start the FTPd server
ftpstop|FTPd server stop command|The system command to stop the FTPd server
webrestart|Web server restart command|The system command to restart the web server
webstart|Web server start command|The system command to stop the web server
webstop|Web server stop command|The system command to start the web server
nsname|Name Server name|The FQDN of the name server (ie. ns1.domain.com)
nsip|Name Server IP Address|The IP address of the name server
nsconf|Name Server configuration file|The system path and name of the name server configuration file (ie. /etc/named.conf)
nsdir|Name Server datafile directory|The system path to the directory containing the name server zone datafiles
nsrestart|Name server restart command|The system command to restart the name server
nsstart|Name Server start command|The system command to start the name server
nsstop|Name Server stop command|The system command to stop the name server
nsport|Name Server port|The port of the name server for process connections
nspass|Name Server password|The password used to connect to the name server for process connections
mysqlroot|MySQL root username|The root username for the MySQL database system
mysqlpass|MySQL root password|The root password for the MySQL database system
mysqlhost|MySQL server hostname|The hostname used to connect to the MySQL as root
webalizerpath|Path to webalizer|The system path to webalizer program
webalizerconf|Webalizer configuration file|The system path and name of the webalizer configuration file
ccards|Available Credit Cards|Select the credit cards to accept during online registration
regfee|Domain Registration Fee|Fee to register a domain for 1 year
regdiscount|Registration Discount|Discount percentage to apply for domains registered/renewed over 1 year
supdoms|Support Domains for Registration|List of top level domains you can register seperated by space
regpath|Path to register.cgi|The system path to register.cgi
reguser|Username running register.cgi|The username that the webserver running register.cgi is running under
reggroup|Group running register.cgi|The group that the webserver running register.cgi is running under
authnetver|Authorize.net version|The version number of the authorize.net gateway your using (3.1 required for cvv2)
emailcust|Authorize.net email customer?|Do you want Authorize.net to email a transaction receipt?
authnetlogin|Authorize.net login|The account login name for authorize.net transactions
usesrs|Use OpenSRS|Are you going to use integrated OpenSRS Services?
srsuser|OpenSRS Username|The username for your OpenSRS Reseller account
srskey|OpenSRS Private Key|The private key for access to your OpenSRS Reseller account
srsemail|OpenSRS Admin Email|The email address for OpenSRS Admin
srsrenew|OpenSRS Renewal Notification Email|The email address for OpenSRS domain renewal notification
srshost|OpenSRS host server|The host server to connect to for OpenSRS registrations
srsprocess|Registration Handle|Do you want to save domain registration for activiation via OpenSRS control panel or do you want to process domain registration now?
allowshell|Allow Shell Access|Do you want to allow shell access for the hosting accounts?
clientshell|Allow Shell Control by Client|Do you want the client to be allowed to turn shell access on and off?
srsmanuser|OpenSRS Manamement Username|The username used to manage domains via manage.opensrs.net
srsmanpass|OpenSRS Management Password|The password used to manage domains via manage.opensrs.net
maxaccounts|Maximum Accounts|Maximum number of domain accounts to be housed on this server
maxspace|Maximum Space Allocated|Maximum amount of disk space to be allocated for accounts on this server (Megabyte)
mailpid|Mail server PID file|The path and name of the mail server process id file
webpid|Web server PID file|The path and name of the web server process id file
nspid|Name server PID file|The path and name of the name server process id file
ftppid|FTPd PID file|The path and name of the FTPd process id file
sharedip|Shared IP|The IP address to be used for name based (shared) hosting
dedips|Dedicated IPs|The IP address range to be used for IP based hosting (can use 1.2.3.1-254)
pools|Server Pools|The server pools that this server will belong to
maxbandwidth|Maximum Allocated Bandwidth|Maximum amount of bandwidth to be allocated to this server
usequota|Use Linux quota management?|Use the Linux disk quota management to enforce quota limits
ticketnotify|Notify on Service Ticket?|Do you wish to use email notification of new service tickets submitted by client interface?
notifyemail|Notify Email|The email address to notify of new service tickets
hostname|Admin Server Hostname|The FQDN of the admin server
useauthnet|Use Authorize.net|Will you be using Authorize.net for online credit card processing?
authnetver|Authorize.net version|The version number of the authorize.net gateway your using
emailcust|Authorize.net email customer?|Do you want Authorize.net to email a transaction receipt?
authnetlogin|Authorize.net login|The account login name for authorize.net transactions
setperiod|Payment Settlement Period|The period of time after invoice issue date before late fee is applied
latefee|Late Fee|The fee to be charged for late payment on invoice
usesignup|Use Online Signup?|Are you going to use the online signup system?
allowforward|Allow online signups for Forwards|will you allow online signup for Fowards. Forwards are domains forwarded to another domain or website
apachever|Apache Version|The version line of apache your running
usesuexec|Use SuExec|Will you be using SuExec with apache
mailtype|Mail Server Type|Select the server daemon software that is being used
srsmanuser|OpenSRS Manager Username|The account manager username to be used for management of newly registered domains
srsmanpass|OpenSRS Manager Password|The account manager password to be used for management of newly registered domains
reviewsignup|What Signups require review?|Select if you want human review of all signups or just signups flagged by the fraudscreen system
usemm|Use MaxMind Credit Card Screening?|Select if you will be using MaxMind Credit Card Screening services (this requires a subscription see <a href="http://www.maxmind.com/app/ccv_overview" TARGET="_new">here</a>)
mmkey|MaxMind License Key|The license key for the subscription to MaxMind Credit Card Screening services (this requires a subscription see <a href="http://www.maxmind.com/app/ccv_overview" TARGET="_new">here</a>)
mmcountry|Country Match|Flag if country of IP address doesn't match billing address country
mmphone|Phone Match|Flag if the customer phone number is in the billing location. A return value of Yes provides a positive indication that the phone number listed belongs to the cardholder.
mmfreemail|Free Mail Check|Flag if e-mail is from free e-mail provider (free e-mail = higher risk)
mmcarderemail|Carder Email Check|Flag if e-mail is in database of known carders (credit card fraudster)
mmhighriskcountry|High Risk Country Check|Flag if IP address or billing address country is in Belarus, Colombia, Egypt, Indonesia, Lebanon, Macedonia, Nigeria, Pakistan, Ukraine, Vietnam or Yugoslavia
ns1|Primary Name Server Name|The name of the primary name server (required if using opensrs even if hosting helper is not managing name server)
ns2|Secondary Name Server Name|The name of the secondary name server (required if using opensrs even if hosting helper is not managing name server)
includepath|Include Path|The system path to the .inc file
authnetkey|Authorize.net Transaction Key|The transaction key generated for the authorize.net account being used for credit card processing
resourcemethod|Resource Allocation Method|Select resource allocation method. stack method stacks the accounts till a server is moved then goes to next available server. float method dynamically floats the load on resources across the server pool.
dnstype|DNS Server Type|The DNS server software type
dnsdbhost|Name Server Database Host|The MySQL database hostname for the MyDNS database
dnsdbname|Name Server Database Name|The MySQL database name for the MyDNS database
dnsdbuser|Name Server Database Username|The MySQL database username for the MyDNS database
dnsdbpass|Name Server Database Password|The MySQL database password for the MyDNS database
pfdbhost|PostFix Database Hostname|The MySQL database hostname used for PostFix virtual mail system
pfdbname|PostFix Database Name|The MySQL database used for PostFix virtual mail system
pfdbuser|PostFix Database Username|The MySQL database username used for PostFix virtual mail system
pfdbpass|PostFix Database Password|The MySQL database password used for PostFix virtual mail system
pfuser|PostFix Username|The system user account that PostFix runs as
pfgroup|PostFix Group|The system group account that PostFix runs as
mailaccess|Email Server Access File|The email server software access control file
cgipath|Admin Program Path|The system path the admin.cgi program
usesa|Use Spamassassin|Will the mail server/hosting server support user settings for SpamAssassin?
sshport|SSH Port|The port that SSH is operating on
sshstart|SSH server start command|command to start the SSH server daemon
sshstop|SSH server stop command|command to stop the SSH server daemon
sshrestart|SSH server restart command|command to restart the SSH server daemon
sshpid|SSH PID file|The path and name of the SSH process id file
