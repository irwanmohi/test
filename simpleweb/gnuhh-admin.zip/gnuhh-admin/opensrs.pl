sub Register_Domain
{
my($db,$registryid)=@_;
my($tlds_regex,%OPENSRS,%REGISTER,$XML_Client,$xcp_request,$error);
my(@supdoms)=split(/ /,$system{'supdoms'});
$tlds_regex=qq(\(\\.).join("|\\.",@supdoms).qq(\));
%OPENSRS=&Setup_SRS;
%REGISTER = (
	     debug => 0,
	     );
$form_data->{domain}= "$FORM{'domain'}";
$form_data->{encoding_type} = "";
$form_data->{reg_type} = "new";
$form_data->{reg_username} = $system{'srsmanuser'};
$form_data->{reg_password} = $system{'srsmanpass'};
$form_data->{affiliate_id} = $system{'srsuser'};
$form_data->{period} = $FORM{'years'};
$form_data->{custom_nameservers} = 1;
$form_data->{bulk_order} = 0;
$form_data->{custom_tech_contact} = 1;
$form_data->{link_domains} = 0;
$form_data->{auto_renew} = 0;
#change to process for live
$form_data->{handle} = 'save';
$form_data->{contact_set}->{owner}->{first_name} = $FORM{'firstname'};
$form_data->{contact_set}->{owner}->{last_name} = $FORM{'lastname'};
$form_data->{contact_set}->{owner}->{org_name} = $FORM{'organization'};
$form_data->{contact_set}->{owner}->{address1} = $FORM{'address1'};
$form_data->{contact_set}->{owner}->{address2} = $FORM{'address2'};
$form_data->{contact_set}->{owner}->{address3} = $FORM{'address3'};
$form_data->{contact_set}->{owner}->{city} = $FORM{'city'};
$form_data->{contact_set}->{owner}->{state} = $FORM{'country'};
$form_data->{contact_set}->{owner}->{postal_code} = $FORM{'zip'};
$form_data->{contact_set}->{owner}->{country} = $FORM{'country'};
$form_data->{contact_set}->{owner}->{phone} = $FORM{'phone'};
$form_data->{contact_set}->{owner}->{fax} = $FORM{'fax'};
$form_data->{contact_set}->{owner}->{email} = $FORM{'email'};
$form_data->{contact_set}->{billing}=$form_data->{contact_set}->{owner};
$form_data->{contact_set}->{admin}=$form_data->{contact_set}->{owner};
$form_data->{contact_set}->{tech}->{first_name}=$system{'contact_firstname'};
$form_data->{contact_set}->{tech}->{last_name}=$system{'contact_lastname'};
$form_data->{contact_set}->{tech}->{org_name}=$system{'contact_organization'};
$form_data->{contact_set}->{tech}->{address1}=$system{'contact_address1'};
$form_data->{contact_set}->{tech}->{address2}=$system{'contact_address2'};
$form_data->{contact_set}->{tech}->{address3}=$system{'contact_address3'};
$form_data->{contact_set}->{tech}->{city}=$system{'contact_city'};
$form_data->{contact_set}->{tech}->{state}=$system{'contact_state'};
$form_data->{contact_set}->{tech}->{postal_code}=$system{'contact_zip'};
$form_data->{contact_set}->{tech}->{country}=$system{'contact_country'};
$form_data->{contact_set}->{tech}->{phone}=$system{'contact_phone'};
$form_data->{contact_set}->{tech}->{fax}=$system{'contact_fax'};
$form_data->{contact_set}->{tech}->{email}=$system{'contact_email'};
push @{$form_data->{nameserver_list}},{ name => $system{'ns1'}, sortorder => "1"};
push @{$form_data->{nameserver_list}},{ name => $system{'ns2'}, sortorder => "2"};
use lib "./lib";
use OpenSRS::XML_Client qw(:default);
my($XML_Client) = new OpenSRS::XML_Client(%OPENSRS);
$XML_Client->login;
my($xcp_request) = {
		action => "register",
		object => "domain",
		attributes => $form_data,
		};
my $response = $XML_Client->send_cmd( $xcp_request );
$XML_Client->logout;
if ($response->{is_success} < "0")
	{
	my($regerror);
	$regerror = "$response->{response_text}.<br>\n";
	if ($response->{attributes}->{error})
		{
		$response->{attributes}->{error} =~ s/\n/<br>\n/g;
		$regerror .= $response->{attributes}->{error};
		}
	$statement=qq(INSERT INTO `registry_pending` (domain,registryid,regtext,error) 
VALUES ('$FORM{'domain'}','$response->{attributes}->{forced_pending}','$regerror','y'));
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	&Error($regerror);	
	}
return;
}

##

sub Retrieve_Pending
{
my($registryid)=$_[0];
my($tlds_regex,%OPENSRS,%REGISTER,$XML_Client,$xcp_request,$error);
my(@supdoms)=split(/ /,$system{'supdoms'});
$tlds_regex=qq(\(\\.).join("|\\.",@supdoms).qq(\));
%OPENSRS=&Setup_SRS;
%REGISTER = (
	     debug => 0,
	     );
use lib "./lib";
use OpenSRS::XML_Client qw(:default);
my($XML_Client) = new OpenSRS::XML_Client(%OPENSRS);
$XML_Client->login;
my($xcp_request) = {
	action => 'get_order_info',
	object => 'domain',
	attributes => {
		command => 'cancel',
		order_id => $registryid
		}
	};
my $response = $XML_Client->send_cmd( $xcp_request );
$XML_Client->logout;
if ($response->{is_success} < "0")
	{
	my($error);
	$error = "Error: $response->{response_text}.<br>\n";
	if ($response->{attributes}->{error})
		{
		$response->{attributes}->{error} =~ s/\n/<br>\n/g;
		$error .= $response->{attributes}->{error};
		}
	&Error($error);
	}
return $response;
}

##

sub Register_Pending
{
my($db,$domain)=@_;
my($statement,$query_output,$error);
$statement=qq(SELECT id,registryid FROM `registry_pending` WHERE domain='$domain');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$regid)=$query_output->fetchrow;
if(!$regid){return;}
my($tlds_regex,%OPENSRS,%REGISTER,$XML_Client,$xcp_request,$error);
my(@supdoms)=split(/ /,$system{'supdoms'});
$tlds_regex=qq(\(\\.).join("|\\.",@supdoms).qq(\));
%OPENSRS=&Setup_SRS;
%REGISTER = (
	     debug => 0,
	     );
use lib "./lib";
use OpenSRS::XML_Client qw(:default);
my($XML_Client) = new OpenSRS::XML_Client(%OPENSRS);
$XML_Client->login;
##remove "command" from production version so that domains are registered
my($xcp_request) = {
	action => 'process_pending',
	object => 'domain',
	attributes => {
#		command => 'cancel',
		order_id => $regid
		}
	};
my $response = $XML_Client->send_cmd( $xcp_request );
$XML_Client->logout;
if ($response->{is_success} < "0")
	{
	my($error);
	$error = "Error: $response->{response_text}.<br>\n";
	if ($response->{attributes}->{error})
		{
		$response->{attributes}->{error} =~ s/\n/<br>\n/g;
		$error .= $response->{attributes}->{error};
		}
	&Error($error);
	}
$statement=qq(DELETE FROM `registry_pending` WHERE id='$id');
$db->query($statement);
if($error=$db->errmsg){&Error($error);}
return;
}

##

sub Delete_Pending
{
my($db,$domain)=@_;
my($statement,$query_output,$error);
$statement=qq(SELECT id,registryid FROM `registry_pending` WHERE domain='$domain');
$query_output=$db->query($statement);
if($error=$db->errmsg){&Error($error);}
my($id,$regid);
while(($id,$regid)=$query_output->fetchrow)
	{
	my($tlds_regex,%OPENSRS,%REGISTER,$XML_Client,$xcp_request,$error);
	my(@supdoms)=split(/ /,$system{'supdoms'});
	$tlds_regex=qq(\(\\.).join("|\\.",@supdoms).qq(\));
	%OPENSRS=&Setup_SRS;
	%REGISTER = (
		     debug => 0,
		     );
	use lib "./lib";
	use OpenSRS::XML_Client qw(:default);
	my($XML_Client) = new OpenSRS::XML_Client(%OPENSRS);
	$XML_Client->login;
	my($xcp_request) = {
		action => 'process_pending',
		object => 'domain',
		attributes => {
			command => 'cancel',
			order_id => $regid
			}
		};
	my $response = $XML_Client->send_cmd( $xcp_request );
	$XML_Client->logout;
	if ($response->{is_success} < "0")
		{
		my($error);
		$error = "Error: $response->{response_text}.<br>\n";
		if ($response->{attributes}->{error})
			{
			$response->{attributes}->{error} =~ s/\n/<br>\n/g;
			$error .= $response->{attributes}->{error};
			}
		&Error($error);
		}
	$statement=qq(DELETE FROM `registry_pending` WHERE id='$id');
	$db->query($statement);
	if($error=$db->errmsg){&Error($error);}
	}
return;
}

##

sub Setup_SRS
{
my($tlds_regex,);
my(@supdoms)=split(/ /,$system{'supdoms'});
$tlds_regex=qq(\(\\.).join("|\\.",@supdoms).qq(\));
my %OPENSRS = (
	    username => $system{'srsuser'},
	    private_key => $system{'srskey'},
            REMOTE_PORT => 55000,
            REMOTE_HOST => $system{'srshost'},
		connection_type => 'CBC',
				crypt_type => 'Blowfish',
				OPENSRS_TLDS_REGEX => $tlds_regex,
			      OPENSRS_AUTHORITY => "(\.com|\.net|\.org|\.tv|\.vc|\.cc)",
				lookup_all_tlds => 1,
				RELATED_TLDS => [
			    		[ ".ca" ],
    					[ ".com", ".net", ".org" ],
		    			[ ".co.uk", ".org.uk" ],
					[ ".vc" ],
		    			[ ".cc" ],
					],
			    );
return %OPENSRS;
}

1;
