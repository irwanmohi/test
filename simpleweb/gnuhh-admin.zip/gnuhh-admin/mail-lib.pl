$mailer  = '/usr/lib/sendmail';
$mailer1 = '/usr/bin/sendmail';
$mailer2 = '/usr/sbin/sendmail';
$mailer3 = '/bin/sendmail';
if ( -e $mailer) {
    $mail_program=$mailer;
} elsif( -e $mailer1){
    $mail_program=$mailer1;
} elsif( -e $mailer2){
    $mail_program=$mailer2;
} elsif( -e $mailer3){
    $mail_program=$mailer3;
} else {
    print "Content-type: text/html\n\n";
    print "I can't find sendmail, shutting down...<br>";
    print "Whoever set this machine up put it someplace weird.";
    exit;
}

$mail_program = "$mail_program -t ";

sub real_send_mail {
    local($fromuser, $fromsmtp, $touser, $tosmtp, 
      $subject, $messagebody) = @_;

    local($old_path) = $ENV{"PATH"};
    $ENV{"PATH"} = "";

    open (MAIL, "|$mail_program") || 
	&web_error("Could Not Open Mail Program");

    $ENV{"PATH"} = $old_path;
    print MAIL <<__END_OF_MAIL__;
To: $touser
From: $fromuser
Subject: $subject

$messagebody

__END_OF_MAIL__

    close (MAIL);

}

sub real_send_mail2 {
    local($fromuser, $fromsmtp, $touser, $tosmtp, 
      $subject, $messagebody) = @_;
    local($old_path) = $ENV{"PATH"};
    $ENV{"PATH"} = "";

    open (MAIL, "|$mail_program") || 
	&web_error("Could Not Open Mail Program");

    $ENV{"PATH"} = $old_path;
    print MAIL <<__END_OF_MAIL__;
To: $touser
From: $fromuser
Subject: $subject
MIME-Version: 1.0
Content-Type: text/html;

$messagebody

__END_OF_MAIL__

    close (MAIL);

}
sub send_html_mail {
    local($from, $to, $subject, $messagebody) = @_;
    local($fromuser, $fromsmtp, $touser, $tosmtp);
    $fromuser = $from;
    $touser = $to;
    $fromsmtp = (split(/\@/,$from))[1];
    $tosmtp = (split(/\@/,$to))[1];
    &real_send_mail2($fromuser, $fromsmtp, $touser, 
           $tosmtp, $subject, $messagebody);

}

sub send_mail {
    local($from, $to, $subject, $messagebody) = @_;

    local($fromuser, $fromsmtp, $touser, $tosmtp);
 
    $fromuser = $from;
    $touser = $to;

    $fromsmtp = (split(/\@/,$from))[1];
    $tosmtp = (split(/\@/,$to))[1];

    &real_send_mail($fromuser, $fromsmtp, $touser, 
           $tosmtp, $subject, $messagebody);

}
sub web_error {
    local ($error) = @_;
    $error = "Error Occured: $error";
    print "$error<p>\n";
    die $error;

}
1;
