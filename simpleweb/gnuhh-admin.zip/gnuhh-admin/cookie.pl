#!/usr/bin/perl
##########
#Cookie routines
#       .Copyright (C)  2004 Red Dragon Enterprises.
#       .Contactid:     <redragon@red-dragon.com>
#       .Url:           http://hostingsoftware.net
#
#       This program is free software; you can redistribute it and/or
#       modify it under the terms of the GNU General Public License as
#       published by the Free Software Foundation; either version 2 of
#       the License, or (at your option) any later version.
#
#       This program is distributed in the hope that it will be useful, but
#       WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#       General Public License for more details.
#
#       You should have received a copy of the GNU General Public License along
#       with this program; if not, write to the Free Software Foundation,
#       Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
##########
$C_Exp_Date="Fri, 31-Dec-1999 00:00:00 GMT";
$C_Path="/";
$C_Domain="";
$Secure_Cookie="0";
@C_Encode=('\%','\+','\;','\,','\=','\&','\:\:','\s');
%C_Encode=('\%','%25','\+','%2B','\;','%3B','\,','%2C','\=','%3D','\&','%26','\:\:','%3A%3A','\s','+');
@C_Decode=('\+','%3A3A','\%26','\%3D','\%2C','\%3B','\%2B','\%25');
%C_Decode=('\+',' ','\%3A\%3A','::','\%26','&','\%3D','=','%2C',',','\%3B',';','\%2B','+','\%25','%');

#####Sub Routines
sub Get_Cookie
{
local(@Return_Cookies)=@_;
local($cookie_flag)=0;
local($cookie,$value);
if($ENV{'HTTP_COOKIE'})
	{
	if ($Return_Cookies[0] ne "")
		{
		foreach (split(/; /,$ENV{'HTTP_COOKIE'}))	
			{
			($cookie,$value)=split(/=/);
			foreach $char (@C_Decode)
				{
				$cookie=~s/$char/$C_Decode{$char}/g;
				$value=~s/$char/$C_Decode{$char}/g;
				}
			foreach $Return_Cookie (@Return_Cookies)
				{
				if ($Return_Cookie eq $cookie)
					{
					$Cookies{$cookie}=$value;
					$cookie_flag="1";
					}
				}
			}
		}
	else
		{
		foreach (split(/; /,$ENV{'HTTP_COOKIE'}))
			{
			($cookie,$value)=split(/=/);
			foreach $char (@C_Decode)
				{
				$cookie=~s/$char/$C_Decode{$char}/g;
				$value=~s/$char/$C_Decode{$char}/g;
				}
			$Cookies{$cookie}=$value;
			}
		$cookie_flag="1";
		}
	}
return $cookie_flag;
}

##

sub Set_Cookie_Exp_Date
{
if ($_[0]=~/^\w{3}\,\s\d{2}\-\w{3}-\d{4}\s\d{2}\:\d{2}\sGMT$/ || $_[0] eq '')
	{
	$C_Exp_Date=$_[0];
	return 1;
	}
else
	{
	return 0;
	}
}

##

sub Set_Cookie_Path
	{
	$C_Path=$_[0];
	}

##

sub Set_Cookie_Domain
{
if($_[0]=~/(.com|.edu|.net|.org|.gov|.mil|.int)$/i && $_[0]=~/\..+\.\w{3}$/)
	{
	$Cookie_Domain=$_[0];
	return 1;
	}
elsif ($_[0]!~/(.com|.edu|.net|.org|.gov|.mil|.int)$/i && $_[0]=~/\..+\.\w{3}$/)
	{
	$Cookie_Domain=$_[0];
	return 1;
	}
else
	{
	return 0;
	}
}

##

sub Set_Cookies
{
local(@cookies)=@_;
local($cookie,$value,$char);
while(($cookie,$value)=@cookies)
	{
	foreach $char (@C_Encode)
		{
		$cookie=~s/$char/$C_Encode{$char}/g;
		$value=~s/$char/$C_Encode{$char}/g;
		}
	print "Set-Cookie: ";
	print "$cookie=$value;";
	if ($C_Exp_Date)
		{
		print " expires=$C_Exp_Date;";
		}
	if ($C_Path)
		{
		print " path=$C_Path;";
		}
	if($C_Domain)
		{
		print " domain=$C_Domain;";
		}
	if($Secure_Cookie)
		{
		print " secure";
		}
	print "\n";
	shift(@cookies);shift(@cookies);
	}
}

##

sub Set_Compressed_Cookies
{
local($cookie_name,@cookies)=@_;
local($cookie,$value,$cookie_value);
while(($cookie,$value)=@cookies)
	{
	foreach $char (@C_Encode)
		{
		$cookie=~s/$char/$C_Encode{$char}/g;
		$value=~s/$char/$C_Enchode{$char}/g;
		}
	if ($cookie_value)
		{
		$cookie_value.='&'.$cookie.'::'.$value;
		}
	else
		{
		$cookie_value=$cookie.'::'.$value;
		}
	shift(@cookies);shift(@cookies);
	}
&Set_Cookies("$cookie_name","$cookie_value");
}

##

sub Get_Compressed_Cookies
{
local($cookie_name,@Return_Cookies)=@_;
local($cookie_flag)=0;
local($Return_Cookie,$cookie,$value);
if (&Get_Cookies($cookie_name))
	{
	foreach (split(/&/,$Cookies{$cookie_name}))
		{
		($cookie,$value)=split(/::/);
		foreach $char (@C_Decode)
			{
			$cookie=~s/$char/$C_Decode{$char}/g;
			$value=~s/$char/$C_Decode{$char}/g;
			}
		foreach $Return_Cookie (@Return_Cookies)
			{
			if ($Return_Cookie eq $cookie)
				{
				$Cookies{$cookie}=$value;
				$cookie_flag=1;
				}
			}
		}
	}
else
	{
	foreach(split(/&/,$Cookies{$cookie_name}))
		{
		($cookie,$value)=split(/::/);
		foreach $char (@C_Decode)
			{
			$cookie=~s/$char/$C_Decode{$char}/g;
			$value=~s/$char/$C_Decode{$char}/g;
			}
		$Cookies{$cookie}=$value;
		}
	$cookie_flag=1;
	delete($Cookies{$cookie_name});
	}
return $cookie_flag;
}

1;
