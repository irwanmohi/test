#!/bin/bash
Version="2.05";

start()
{
read -n 1 -p "Will you be installing the client console or signup console on this server also? (y,n) [$shared] " shared
echo

if [ "$htdocs" = "" ]
then
	if test -e "/home/httpd/htdocs"
	then
	htdocs="/home/httpd/htdocs"
	fi
	if test -e "/home/httpd/html"
	then
	htdocs="/home/httpd/html"
	fi
	if test -e "/var/www/htdocs"
	then
	htdocs="/var/www/htdocs"
	fi
fi
read -e -p "Enter the document root path for the administration console [$htdocs] "
if [ ! "$REPLY" = "" ]
then
htdocs="$REPLY"
fi
echo

if [ "$cgibin" = "" ]
then
	if  test -e "/home/httpd/cgi-bin"
	then
	cgibin="/home/httpd/cgi-bin"
	fi
	if test -e "/var/www/cgi-bin"
	then
	cgibin="/var/www/cgi-bin"
	fi
	if [ "$shared" = "y" ]
	then
	cgibin="$cgibin/admin"
	fi
fi
read -e -p "Enter the cgi-bin path for the administration console [$cgibin] "
if [ ! "$REPLY" = "" ]
then
cgibin=$REPLY
fi
echo

if [ "$apacheuser" = "" ]
then
	if id nobody > /dev/null 2>&1
	then
	apacheuser="nobody"
	fi
	if id apache > /dev/null 2>&1
	then
	apacheuser="apache"
	fi
fi
read -e -p "Enter the user that Apache runs as [$apacheuser] "
if [ ! "$REPLY" = "" ]
then
apacheuser="$REPLY"
fi
echo

if [ "$apachegroup" = "" ]
then
apachegroup="$apacheuser"
fi

read -e -p "Enter the group that Apache runs as [$apachegroup] "
if [ ! "$REPLY" = "" ]
then
apachegroup="$REPLY"
fi
echo

if [ "$sbindir" = "" ]
then
sbindir="/usr/sbin";
fi
read -e -p "Enter the system binary directory you want to install admind daemon into [$sbindir] "
if [ ! "$REPLY" = "" ]
then
sbindir="$REPLY"
fi
echo

read -e -p "Enter the configuration directory for the admind daemon process [$confdir] "
if [ ! "$REPLY" = "" ]
then
confdir="$REPLY"
fi
echo

if [ "$userh" = "" ]
then
	if test -e "/etc/sysconfig"
	then
	userh="y"
	else
	userh="n"
	fi
fi
read -n 1 -p "Is this a system that supports RedHat style init scripts? (y,n) [$userh] " userh
if [ ! "$REPLY" = "" ]
then
userh="$REPLY"
else
userh="y";
fi
echo

read -e -p "Enter the log path for the admind daemon process: [$logpath] "
if [ ! "$REPLY" = "" ]
then
logpath="$REPLY"
fi
echo

read -e -p "Enter the log file name for the admind daemon process: [$logfile] "
if [ ! "$REPLY" = "" ]
then
logfile="$REPLY"
fi
echo

read -e -p "Enter the run time directory for the admind daemon process: [$runtimedir] "
if [ ! "$REPLY" = "" ]
then
runtimedir="$REPLY"
fi
echo

read -e -p "Enter the pid file name for the admind daemon process: [$pidfile] "
if [ ! "$REPLY" = "" ]
then
pidfile="$REPLY"
fi
echo

read -e -p "The temporary directory for admind daemon process: [$tempdir] "
if [ ! "$REPLY" = "" ]
then
tempdir="$REPLY"
fi
echo

read -e -p "Enter the document directory for administration console [$docdir] ";
if [ ! "$REPLY" = "" ]
then
docdir="$REPLY"
fi
echo

confirm
}

confirm()
{
clear
echo "The following information is what was submitted:";
echo "Will you be installing the client console or signup console on this server also? $shared"
echo "The document root path for the administration console: $htdocs"
echo "The cgi-bin path for the administration console: $cgibin"
echo "The user that Apache runs as: $apacheuser"
echo "The group that Apache runs as: $apachegroup"
echo "The system binary directory you want to install admind daemon into: $sbindir"
echo "Is this a system that supports RedHat style init scripts? $userh"
echo "The configuration directory for the admind daemon process: $confdir"
echo "The log path for the admind daemon process: $logpath"
echo "The log file name for the admind daemon process: $logfile"
echo "The run time directory for the admind daemon process: $runtimedir"
echo "The pid file name for the admind daemon process: $pidfile"
echo "The temporary directory for the admind daemon process: $tempdir"
echo "The document directory for administration console: $docdir"
echo
read -n 1 -p "Is it correct? (y,n,q) [n] ";
echo
echo
if [ "$REPLY" = "n" ] || [ "$REPLY" = "N" ]
then
clear
start
fi
if [ ! "$REPLY" = "y" ] && [ ! "$REPLY" = "Y" ]
then
exit 0;
fi
installit
}

initialize()
{
shared="n"
htdocs=""
cgibin=""
apacheuser=""
apachegroup=""
sbindir="/usr/sbin"
userh=""
docdir="/usr/share/doc/gnuhh/admin"
confdir="/etc/gnuhh/admin"
logpath="/var/log"
logfile="admind.log"
runtimedir="/var/run"
pidfile="admind.pid"
tempdir="/tmp"
clear
echo "Hosting Helper Administration Installer Version $Version";
echo "If this is an upgrade remember to stop admin daemon process"
echo "before upgrading and start it after upgrade."
echo
read -n 1 -p "continue? [y,n] "
if [ ! "$REPLY" = "y" ]
then 
echo
exit 0;
fi
echo
echo
if test -e "/root/.gnuhh/admin"
then
echo "You have previously saved configuration for administration installation,"
read -n 1 -p "do you want to use it? (y,n) [y] "
if [ ! "$REPLY" = "n" ]
then
. /root/.gnuhh/admin
clear
confirm
fi
fi
clear
start
}

installit()
{
if ! test -e "/root/.gnuhh"
then
mkdir -m0755 /root/.gnuhh
fi
echo -n > /root/.gnuhh/admin.install
if ! test -e "$htdocs/images"
then
mkdir -p -m0755 $htdocs/images
echo "$htdocs/images" >> /root/.gnuhh/admin.install
fi
if ! test -e "$docdir"
then
mkdir -p -m0755 $docdir
echo "$docdir" >> /root/.gnuhh/admin.install
fi
if ! test -e "$cgibin/lib/OpenSRS"
then
mkdir -p -m0755 $cgibin/lib/OpenSRS
echo "$cgibin/lib/OpenSRS" >> /root/.gnuhh/admin.install
fi
if ! test -e "$cgibin/mods"
then
mkdir -p -m0755 $cgibin/mods
echo "$cgibin/mods" >> /root/.gnuhh/admin.install
fi
if ! test -e "$cgibin/tips"
then
mkdir -p -m0755 $cgibin/tips
echo "$cgibin/tips" >> /root/.gnuhh/admin.install
fi
if ! test -e "$confdir"
then
mkdir -p -m0700 $confdir
echo "$confdir" >> /root/.gnuhh/admin.install
fi
chown -R $apacheuser:$apachegroup $cgibin
chown -R $apacheuser:$apachegroup $htdocs

root_group=`id -gn root`
install -m 0755 -o root -g $root_group admind $sbindir
echo "$sbindir/admind" >> /root/.gnuhh/admin.install

if [ ! "$confdir" = "/etc/gnuhh/admin" ]
then
flags="--sysconfdir=$confdir"
fi
if [ ! "$sbindir" = "/usr/sbin" ]
then
	if [ ! "$flags" = "" ]
	then
	flags="$flags --sbindir=$sbindir"
	else
	flags="--sbindir=$sbindir"
	fi
fi
if [ ! "$logpath" = "/var/log" ]
then
	if [ ! "$flags" = "" ]
	then
	flags="$flags --logpath=$logpath"
	else
	flags="--logpath=$logpath"
	fi
fi
if [ ! "$logfile" = "admind.log" ]
then
	if [ ! "$flags" = "" ]
	then
	flags="$flags --logfile=$logfile"
	else
	flags="--logfile=$logfile"
	fi
fi
if [ ! "$runtimedir" = "/var/run" ]
then
	if [ ! "$flags" = "" ]
	then
	flags="$flags --runtimedir=$runtimedir"
	else
	flags="--runtimedir=$runtimedir"
	fi
fi
if [ ! "$pidfile" = "admind.pid" ]
then
	if [ ! "$flags" = "" ]
	then
	flags="$flags --pidfile=$pidfile"
	else
	flags="--pidfile=$pidfile"
	fi
fi
if [ ! "$tempdir" = "/tmp" ]
then
	if [ ! "$flags" = "" ]
	then
	flags="$flags --tempdir=$tempdir"
	else
	flags="--tempdir=$tempdir"
	fi
fi

if [ "$userh" = "y" ]
then
install -m 0755 -o root -g $root_group init/admind /etc/init.d/
echo "/etc/init.d/admind" >> /root/.gnuhh/admin.install
chkconfig --add admind
	if [ ! "$flags" = "" ]
	then
	echo "ADMIND_FLAGS="'"'"$flags"'"' > /etc/sysconfig/admind
	echo "/etc/sysconfig/admind" >> /root/.gnuhh/admin.install
	fi
else
echo "#!/bin/bash" > $confdir/admind.sh
echo "$sbindir/admind $flags" >> $confdir/admind.sh
echo "$confdir/admind.sh" >> /root/.gnuhh/admin.install
fi

install -m 0755 -o $apacheuser -g $apachegroup admin.cgi $cgibin/
echo "$cgibin/admin.cgi" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup cookie.pl $cgibin/
echo "$cgibin/cookie.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup countries.dat $cgibin/
echo "$cgibin/countries.dat" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup fraudscreen.txt $cgibin/
echo "$cgibin/fraudscreen.txt" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup filecheck.txt $cgibin/
echo "$cgibin/filecheck.txt" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup help.pl $cgibin/
echo "$cgibin/help.pl" >> /root/.gnuhh/admin.install
if test -e "$cgibin/invoice.dat"
then
	ORIG=`grep invoice.dat admin.md5|cut -f 1 -d " "`
	NEW=`md5sum "$cgibin/invoice.dat"|cut -f 1 -d " "`
	if [ ! "$ORIG" = "$NEW" ]
	then
	read -n 1 -p "invoice.dat exists and has been modified, do you want to overwrite it? (y,n) [n] "
	echo
		if [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]
		then
		install -m 0644 -o $apacheuser -g $apachegroup invoice.dat $cgibin/
		echo "$cgibin/invoice.dat" >> /root/.gnuhh/admin.install
		fi
	else
	install -m 0644 -o $apacheuser -g $apachegroup invoice.dat $cgibin/
	echo "$cgibin/invoice.dat" >> /root/.gnuhh/admin.install
	fi
else
install -m 0644 -o $apacheuser -g $apachegroup invoice.dat $cgibin/
echo "$cgibin/invoice.dat" >> /root/.gnuhh/admin.install
fi
install -m 0644 -o $apacheuser -g $apachegroup invoice.txt $cgibin/
echo "$cgibin/invoice.txt" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mail-lib.pl $cgibin/
echo "$cgibin/mail-lib.pl" >> /root/.gnuhh/admin.install
install -m 0755 -o $apacheuser -g $apachegroup modules.cgi $cgibin/
echo "$cgibin/modules.cgi" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup monitor.txt $cgibin/
echo "$cgibin/monitor.txt" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup opensrs.pl $cgibin/
echo "$cgibin/opensrs.pl" >> /root/.gnuhh/admin.install
if test -e "$cgibin/statement.dat"
then
	ORIG=`grep statement.dat admin.md5|cut -f 1 -d " "`
	NEW=`md5sum $cgibin/statement.dat|cut -f 1 -d " "`
	if [ ! "$ORIG" = "$NEW" ]
	then
	read -n 1 -p "statement.dat exists and has been modified, do you want to overwrite it? (y,n) [n] "
	echo
		if [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]
		then
		install -m 0644 -o $apacheuser -g $apachegroup statement.dat $cgibin/
		echo "$cgibin/statement.dat" >> /root/.gnuhh/admin.install
		fi
	else
	install -m 0644 -o $apacheuser -g $apachegroup statement.dat $cgibin/
	echo "$cgi-bin/statement.dat" >> /root/.gnuhh/admin.install
	fi
else
install -m 0644 -o $apacheuser -g $apachegroup statement.dat $cgibin/
echo "$cgibin/statement.dat" >> /root/.gnuhh/admin.install
fi
install -m 0644 -o root -g $root_group fields.pl $cgibin/
echo "$cgibin/fields.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup tips.dat $cgibin/
echo "$cgibin/tips.dat" >> /root/.gnuhh/admin.install

install -m 0755 -o $apacheuser -g $apachegroup lib/OPS.pm $cgibin/lib/
echo "$cgibin/lib/OPS.pm" >> /root/.gnuhh/admin.install
install -m 0755 -o $apacheuser -g $apachegroup lib/XML_Codec.pm $cgibin/lib/
echo "$cgibin/lib/XML_Codec.pm" >> /root/.gnuhh/admin.install
install -m 0755 -o $apacheuser -g $apachegroup lib/OpenSRS/Syntax.pm $cgibin/lib/OpenSRS
echo "$cgibin/lib/Syntax.pm" >> /root/.gnuhh/admin.install
install -m 0755 -o $apacheuser -g $apachegroup lib/OpenSRS/XML_Client.pm $cgibin/lib/OpenSRS
echo "$cgibin/lib/XML_Client.pm" >> /root/.gnuhh/admin.install

install -m 0644 -o $apacheuser -g $apachegroup mods/admin.pl $cgibin/mods/
echo "$cgibin/mods/admin.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/admind.pl $cgibin/mods/
echo "$cgibin/mods/admind.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/billing.pl $cgibin/mods/
echo "$cgibin/mods/billing.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/client.pl $cgibin/mods/
echo "$cgibin/mods/client.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/config.pl $cgibin/mods/
echo "$cgibin/mods/config.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/domain.pl $cgibin/mods/
echo "$cgibin/mods/domain.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/general.pl $cgibin/mods/
echo "$cgibin/mods/general.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/hosting.pl $cgibin/mods/
echo "$cgibin/mods/hosting.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/info.pl $cgibin/mods/
echo "$cgibin/mods/info.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/mailserver.pl $cgibin/mods/
echo "$cgibin/mods/mailserver.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/nameserver.pl $cgibin/mods/
echo "$cgibin/mods/nameserver.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/notify.pl $cgibin/mods/
echo "$cgibin/mods/notify.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/register.pl $cgibin/mods/
echo "$cgibin/mods/register.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/security.pl $cgibin/mods/
echo "$cgibin/mods/security.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/service.pl $cgibin/mods/
echo "$cgibin/mods/service.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/signup.pl $cgibin/mods/
echo "$cgibin/mods/signup.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/tasks.pl $cgibin/mods/
echo "$cgibin/mods/tasks.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/user.pl $cgibin/mods/
echo "$cgibin/mods/user.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/email.pl $cgibin/mods/
echo "$cgibin/mods/email.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/dns.pl $cgibin/mods/
echo "$cgibin/mods/dns.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/apache.pl $cgibin/mods/
echo "$cgibin/mods/apache.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/reseller.pl $cgibin/mods/
echo "$cgibin/mods/reseller.pl" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup mods/webmail.pl $cgibin/mods/
echo "$cgibin/mods/webmail.pl" >> /root/.gnuhh/admin.install

install -m 0644 -o $apacheuser -g $apachegroup tips/admincgi.html $cgibin/tips/
echo "$cgibin/tips/admincgi.html" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup tips/admind.html $cgibin/tips/
echo "$cgibin/tips/admind.html" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup tips/clientinterface.html $cgibin/tips/
echo "$cgibin/tips/clientinterface.html" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup tips/hostingserver.html $cgibin/tips/
echo "$cgibin/tips/hostingserver.html" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup tips/mailserver.html $cgibin/tips/
echo "$cgibin/tips/mailserver.html" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup tips/manageadmin.html $cgibin/tips/
echo "$cgibin/tips/manageadmin.html" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup tips/nameserver.html $cgibin/tips/
echo "$cgibin/tips/nameserver.html" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup tips/notification.html $cgibin/tips/
echo "$cgibin/tips/notification.html" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup tips/pools.html $cgibin/tips/
echo "$cgibin/tips/pools.html" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup tips/signup.html $cgibin/tips/
echo "$cgibin/tips/signup.html" >> /root/.gnuhh/admin.install

install -m 0644 -o $apacheuser -g $apachegroup images/down.gif $htdocs/images/
echo "$htdocs/images/down.gif" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/minus.gif $htdocs/images/
echo "$htdocs/images/minus.gif" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/na.gif $htdocs/images/
echo "$htdocs/images/na.gif" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/plus.gif $htdocs/images/
echo "$htdocs/images/plus.gif" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/up.gif $htdocs/images/
echo "$htdocs/images/up.gif" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/bg.gif $htdocs/images/
echo "$htdocs/images/bg.gif" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/spacer.gif $htdocs/images/
echo "$htdocs/images/spacer.gif" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/gnu_01.jpg $htdocs/images/
echo "$htdocs/images/gnu_01.jpg" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/gnu_02.jpg $htdocs/images/
echo "$htdocs/images/gnu_02.jpg" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/newtab.jpg $htdocs/images/
echo "$htdocs/images/newtab.jpg" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/gnu_09.jpg $htdocs/images/
echo "$htdocs/images/gnu_09.jpg" >> /root/.gnuhh/admin.install
install -m 0644 -o $apacheuser -g $apachegroup images/gnu_10.jpg $htdocs/images/
echo "$htdocs/images/gnu_10.jpg" >> /root/.gnuhh/admin.install

install -m 0644 -o root -g $root_group INSTALL $docdir/
echo "$docdir/INSTALL" >> /root/.gnuhh/admin.install
install -m 0644 -o root -g $root_group LICENSE $docdir/
echo "$docdir/LICENSE" >> /root/.gnuhh/admin.install
install -m 0644 -o root -g $root_group CHANGES $docdir/
echo "$docdir/CHANGES" >> /root/.gnuhh/admin.install
echo
echo "Installation of files complete, you can configure admin daemon in"
echo "administration and start the admin daemon"
echo
if [ ! "$userh" = "y" ] && [ ! "$userh" = "Y" ]
then
echo "Since you'r not using RedHat init script system a file, admind.sh, was"
echo "created in $confdir that can be called to start the daemon with the necessary switches"
echo
fi
read -n 1 -p "Do you want to save these configurations for use with later updates? (y,n) [y] "
clear
if [ ! "$REPLY" = "n" ] && [ ! "$REPLY" = "N" ]
then
	if ! test -e /root/.gnuhh
	then
	mkdir /root/.gnuhh
	fi
echo "shared="'"'"$shared"'"' > /root/.gnuhh/admin
echo "htdocs="'"'"$htdocs"'"' >> /root/.gnuhh/admin
echo "cgibin="'"'"$cgibin"'"' >> /root/.gnuhh/admin
echo "apacheuser="'"'"$apacheuser"'"' >> /root/.gnuhh/admin
echo "apachegroup="'"'"$apachegroup"'"' >> /root/.gnuhh/admin
echo "sbindir="'"'"$sbindir"'"' >> /root/.gnuhh/admin
echo "userh="'"'"$userh"'"' >> /root/.gnuhh/admin
echo "docdir="'"'"$docdir"'"' >> /root/.gnuhh/admin
echo "confdir="'"'"$confdir"'"' >> /root/.gnuhh/admin
echo "logpath="'"'"$logpath"'"' >> /root/.gnuhh/admin
echo "logfile="'"'"$logfile"'"' >> /root/.gnuhh/admin
echo "runtimedir="'"'"$runtimedir"'"' >> /root/.gnuhh/admin
echo "pidfile="'"'"$pidfile"'"' >> /root/.gnuhh/admin
echo "tempdir="'"'"$tempdir"'"' >> /root/.gnuhh/admin
echo "The settings you have chosen for install have been saved to"
echo "/root/.gnuhh/admin for use with later upgrades"
echo
fi
echo "If this is an upgrade then you will want to use the update database"
echo "function in administration to bring the database up to this version"
echo
exit;
}

initialize
