<?php
	class proxys extends proxy {
		protected $default_port = 443;
		protected $protocol = "tls";
	}
?>
